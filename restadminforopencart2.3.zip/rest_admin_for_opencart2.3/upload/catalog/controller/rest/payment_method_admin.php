<?php
/**
 * payment_method_admin.php
 *
 * Payment method management
 *
 * @author          Opencart-api.com
 * @copyright       2017
 * @license         License.txt
 * @version         2.0
 * @link            https://opencart-api.com/product/opencart-rest-admin-api/
 * @documentations  https://opencart-api.com/opencart-rest-api-documentations/
 */
require_once(DIR_SYSTEM . 'engine/restadmincontroller.php');

class ControllerRestPaymentMethodAdmin extends RestAdminController
{

    public function paymentmethods()
    {

        $this->checkPlugin();

        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $this->listPaymentMethods();
        } else {
            $this->statusCode = 405;
            $this->allowedHeaders = array("GET");
        }

        return $this->sendResponse();
    }

    public function listPaymentMethods()
    {

        $this->load->model('extension/extension');

        $results = $this->model_extension_extension->getExtensions('payment');

        $this->json['data'] = !empty($results) ? $results : array();

    }
}