<?php
$_['error_name']         = 'Manufacturer Name must be between 2 and 64 characters!';
$_['error_keyword']      = 'SEO keyword already in use!';
$_['error_product']      = 'Warning: This manufacturer cannot be deleted as it is currently assigned to %s products!';