<?php
$_['error_exists']        = 'Warning: Coupon code is already in use!';
$_['error_name']          = 'Coupon Name must be between 3 and 128 characters!';
$_['error_code']          = 'Code must be between 3 and 10 characters!';