<?php
$_['error_name']            = 'Attribute Name must be between 3 and 64 characters!';
$_['error_product']         = 'Warning: This attribute cannot be deleted as it is currently assigned to %s products!';