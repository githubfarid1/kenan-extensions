<?php
// Error
$_['error_name']             = 'Product Name must be greater than 3 and less than 255 characters!';
$_['error_meta_title']       = 'Meta Title must be greater than 3 and less than 255 characters!';
$_['error_model']            = 'Product Model must be greater than 1 and less than 64 characters!';
$_['error_sku']              = 'Product Sku must be greater than 1 and less than 64 characters!';
$_['error_keyword']          = 'SEO keyword already in use( %s )!';
$_['error_model_exist']      = 'Model already in use ( %s )!';

?>