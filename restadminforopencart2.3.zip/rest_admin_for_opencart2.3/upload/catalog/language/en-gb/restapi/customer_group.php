<?php
$_['error_name']         = 'Customer Group Name must be between 3 and 32 characters!';
$_['error_default']      = 'Warning: This customer group cannot be deleted as it is currently assigned as the default store customer group!';
$_['error_store']        = 'Warning: This customer group cannot be deleted as it is currently assigned to %s stores!';
$_['error_customer']     = 'Warning: This customer group cannot be deleted as it is currently assigned to %s customers!';