<?php

$_['error_name']          = 'Option Name must be between 1 and 128 characters!';
$_['error_type']          = 'Warning: Option Type required!';
$_['error_option_value']  = 'Option Value Name must be between 1 and 128 characters!';
$_['error_product']       = 'Warning: This option cannot be deleted as it is currently assigned to %s products!';
