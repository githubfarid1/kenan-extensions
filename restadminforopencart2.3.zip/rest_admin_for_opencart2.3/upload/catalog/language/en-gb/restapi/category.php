<?php
$_['error_name']             = 'Category Name must be between 2 and 32 characters!';
$_['error_meta_title']       = 'Meta Title must be greater than 3 and less than 255 characters!';
$_['error_keyword']          = 'SEO keyword already in use!';

$_['error_upload']     = 'Upload required!';
$_['error_filename']   = 'Filename must be between 3 and 128 characters!';
$_['error_exists']     = 'File does not exist!';
$_['error_mask']       = 'Mask must be between 3 and 128 characters!';
$_['error_filetype']   = 'Invalid file type!';