CONTACT: http://support.ocdemo.eu/

DOCUMENTATION: http://docs.ocdemo.eu/mfp/

#############################
########## INSTALL ##########
#############################

---------------
---- VQMod ----
---------------

1. Please make sure that you have installed the latest version of vQmod
	Releases: https://github.com/vqmod/vqmod/releases
	How to install vQmod: https://github.com/vqmod/vqmod/wiki/Installing-vQmod-on-OpenCart

2. Upload all the files and folders to your server from the "Upload" folder. This can be to anywhere of your choice. e.g. /public_html or /public_html/store

3. Go to: Users -> User Groups and in section "Action" choose edit for "Administrator" group. Next, in field "Access Permission" and in "Modify Permission" click "Select All" and save changes.

4. Go to: Extensions/Modules

5. Click [Install] for Mega Filter PRO

6. DONE !

---------------
---- OCMod ----
---------------

1. Upload all the files and folders to your server from the "Upload" folder. This can be to anywhere of your choice. e.g. /public_html or /public_html/store

2. Go to: Users -> User Groups and in section "Action" choose edit for "Administrator" group. Next, in field "Access Permission" and in "Modify Permission" click "Select All" and save changes.

3. Go to: Extensions -> Modifications -> press button CLEAR and REFRESH

4. Go to: Extensions/Modules

5. Click [Install] for Mega Filter PRO

6. DONE !

#############################
########## UPDATE ###########
#############################

1. Upload all the files and folders to your server from the "Upload" folder. This can be to anywhere of your choice. e.g. /public_html or /public_html/store

2. Go to: Extensions/Modules

3. Click [Edit] for Mega Filter PRO

4. DONE !

EOF