<?php
$this->db->query("DELETE FROM `".DB_PREFIX."modification` WHERE `name` = 'Opencart Progressive Web Application' AND `code` = 'progressive_web_application'");
