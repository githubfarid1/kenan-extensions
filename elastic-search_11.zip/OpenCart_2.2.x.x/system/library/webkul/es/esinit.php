<?php

namespace Webkul\Es;
use Elasticsearch\ClientBuilder;
use Monolog\Logger;
use Monolog\Handler\StreamHandler;

class Esinit {

    public $client;
    private $es;

    public function __construct($es) {
        $this->es = $es;
        $this->client = ClientBuilder::create();
        if($this->es->config->get('wk_elastic_host')) {
            $this->hostSetup();
        }
        return $this;
    }

    public function hostSetup($setting = array(), $has_to_check_status = false) {
        $host_setting = array(
            'host' => $setting['host'] ?? $this->es->config->get('wk_elastic_host'),
            'port' => $setting['port'] ?? $this->es->config->get('wk_elastic_host_port'),
            'scheme' => $setting['scheme'] ?? $this->es->config->get('wk_elastic_host_scheme'),
        );

        $setting['wk_elastic_login_auth'] = $setting['wk_elastic_login_auth'] ?? $this->es->config->get('wk_elastic_login_auth');

        if ($setting['wk_elastic_login_auth']) {
            $host_setting['user'] = $setting['username'] ?? $this->es->config->get('wk_elastic_host_username');
            $host_setting['pass'] = $setting['password'] ?? $this->es->config->get('wk_elastic_host_password');
        }

        $logger = new Logger('name');
        $logger->pushHandler(new StreamHandler(DIR_SYSTEM . '/elastic_log_errors.log', Logger::WARNING));

        $hosts = [
            $this->es->config->get('wk_elastic_host_scheme') . '://' . $this->es->config->get('wk_elastic_host') . ':' . $this->es->config->get('wk_elastic_host_port'), 
        ];

        $this->client = ClientBuilder::create()->setLogger($logger)->setHosts($hosts)->setRetries(0)->build();

        if($has_to_check_status) {
          $this->checkStatus();
        }
        return $this;
    }

    public function checkStatus() {
        return $this->client->info();
    }
}
?>
