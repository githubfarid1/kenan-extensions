<?php
class ControllerExtensionModuleWkelastic extends Controller {
    private $error = array();

    public function install() {
        $this->load->model('es/es');
        $this->model_es_es->createTable();
    }

    public function uninstall() {
        $this->load->model('es/es');
        $this->model_es_es->dropTable();
    }

    public function index() {
        $data = array();
        $data = array_merge($data, $this->load->language('extension/module/wk_elastic'));

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('setting/setting');

        $this->document->addScript("view/javascript/jquery/jquery-ui/jquery-ui.min.js");
        $this->document->addStyle("view/javascript/jquery/jquery-ui/jquery-ui.css");
        $this->document->addStyle("view/javascript/jquery/jquery-ui/jquery-ui.structure.css");

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            if (isset($this->request->post['wk_elastic_store'])) {
              $this->model_setting_setting->editSetting('wk_elastic', $this->request->post ,$this->request->post['wk_elastic_store']);
            } else {
              $this->model_setting_setting->editSetting('wk_elastic', $this->request->post);
            }

            $this->session->data['success'] = $this->language->get('text_success');

            $this->response->redirect($this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=module', true));
        }

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
          'text' => $this->language->get('text_home'),
          'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
        );

        $data['breadcrumbs'][] = array(
          'text' => $this->language->get('text_module'),
          'href' => $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=module', true)
        );

        $data['breadcrumbs'][] = array(
          'text' => $this->language->get('heading_title'),
          'href' => $this->url->link('extension/module/wk_elastic', 'token=' . $this->session->data['token'], true)
        );

        $configs = array(
          'wk_elastic_status',
          'wk_elastic_host',
          'wk_elastic_host_port',
          'wk_elastic_host_scheme',
          'wk_elastic_login_auth',
          'wk_elastic_host_username',
          'wk_elastic_host_password',
          // Search
          'wk_elastic_index_prefix',
          'wk_elastic_minimum_character',
          'wk_elastic_search_in',
          'wk_elastic_search_in_priority',
          'wk_elastic_search_in_for_product',
          'wk_elastic_search_in_for_category',
          'wk_elastic_search_in_for_information',
          'wk_elastic_synonym_keyword',
          'wk_elastic_ignore_keyword',
          'wk_elastic_search_box_detail',
          'wk_elastic_text_box_placeholder',
          'wk_elastic_no_result_text',
          'wk_elastic_more_result_text',
          'wk_elastic_no_of_result',
        );

        if (isset($this->request->get['wk_elastic_store'])) {
            $data['wk_elastic_store'] = $this->request->get['wk_elastic_store'];
            $data = array_merge($data,$this->model_setting_setting->getSetting('wk_elastic', $this->request->get['wk_elastic_store']));
        } else {
            $data = array_merge($data,$this->model_setting_setting->getSetting('wk_elastic', 0));
        }

        foreach ($configs as $key => $config) {
            if (isset($this->request->post[$config])) {
                $data[$config] = $this->request->post[$config];
            }
        }

        $data['stores'] = array();
        $data['stores'][] = array(
          'store_id'  => '0',
          'name'      => $this->config->get('config_name'),
        );

        $this->load->model('setting/store');
        $stores = $this->model_setting_store->getStores();
        if ($stores) {
            foreach ($stores as $key => $store) {
                $data['stores'][] = array(
                  'store_id' => $store['store_id'],
                  'name' => $store['name'],
                );
            }
        }

        $data['search_in'] = [
          'product'       => $this->language->get('text_product'),
          'category'      => $this->language->get('text_category'),
          'manufacturer'  => $this->language->get('text_manufacturer'),
          'information'   => $this->language->get('text_information'),
        ];

        $data['search_box_details'] = array(
          'name'          => $this->language->get('text_product_name'),
          'price'         => $this->language->get('text_product_price'),
          'image'         => $this->language->get('text_product_image'),
          'rating'        => $this->language->get('text_rating'),
        );

        $data['search_in_product'] = array(
          'name.'                 => $this->language->get('text_name'),
          'description.'          => $this->language->get('text_description'),
          'meta_tag_title.'       => $this->language->get('text_meta_tag_title'),
          'meta_tag_description.' => $this->language->get('text_meta_tag_description'),
          'meta_tag_keyword.'     => $this->language->get('text_meta_tag_keywords'),
          'product_tags.'         => $this->language->get('text_tag'),
          'model'                 => $this->language->get('text_model'),
          'manufacturer.name'     => $this->language->get('text_manufacturer'),
        );

        $data['search_in_category'] = array(
          'name.'                 => $this->language->get('text_name'),
          'description.'          => $this->language->get('text_description'),
          'meta_tag_title.'       => $this->language->get('text_meta_tag_title'),
          'meta_tag_description.' => $this->language->get('text_meta_tag_description'),
          'meta_tag_keyword.'     => $this->language->get('text_meta_tag_keywords'),
        );

        $data['search_in_information'] = array(
          'name.'                 => $this->language->get('text_name'),
          'description.'          => $this->language->get('text_description'),
          'meta_title.'           => $this->language->get('text_meta_tag_title'),
          'meta_description.'     => $this->language->get('text_meta_tag_description'),
          'meta_keyword.'         => $this->language->get('text_meta_tag_keywords'),
        );

        $data['action'] = $this->url->link('extension/module/wk_elastic', 'token=' . $this->session->data['token'], true);
        $data['cancel'] = $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=module', true);
        $data['token'] = $this->session->data['token'];

        $error_index = array(
            'wk_elastic_host',
            'wk_elastic_host_port',
            'wk_elastic_host_username',
            'wk_elastic_host_password',
            'wk_elastic_index_prefix',
        );
        foreach ($error_index as $error_key) {
          if (isset($this->error[$error_key])) {
            $data['error_'.$error_key] = $this->error[$error_key];
          } else {
            $data['error_'.$error_key] = '';
          }
        }

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput($this->load->view('extension/module/wk_elastic', $data));
    }

    public function checkStatus() {
        $json = array();
        $host_setting = array();
        $host_setting = array(
          'host'    => $this->request->post['host'],
          'port'    => $this->request->post['port'],
          'scheme'  => $this->request->post['scheme'],
        );

        if ($this->request->post['auth_required']) {
          $host_setting['user'] = $this->request->post['username'];
          $host_setting['pass'] = $this->request->post['password'];
        }

        $this->load->library('webkul/es/es');
        try {
          $status = $this->es->init->hostSetup($host_setting)->checkStatus();

          $this->load->language('extension/module/wk_elastic');

          if ($status) {
            $json['status'] = true;
            $json['msg']    = $this->language->get('text_connected_success');
            $json['detail'] = $status;
          } else {
            $json['status'] = false;
            $json['msg']    = $this->language->get('error_connection');
          }
        } catch (Throwable $e) {
          $error = $e->getMessage();
          $json['status'] = false;
          $json['msg'] = $error;
        } catch (Exception $e) {
          $error = $e->getMessage();
          $json['status'] = false;
          $json['msg'] = $error;
        }
        $this->response->setOutput(json_encode($json));
    }

    protected function validate() {
        $this->load->language('extension/module/wk_elastic');

        if (!$this->user->hasPermission('modify', 'extension/module/wk_elastic')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        $post_data = $this->request->post;

        if (!$post_data['wk_elastic_host']) {
          $this->error['wk_elastic_host'] = $this->language->get('error_wk_elastic_host');
        }

        if (!$post_data['wk_elastic_host_port']) {
          $this->error['wk_elastic_host_port'] = $this->language->get('error_wk_elastic_host_port');
        }

        if (!$post_data['wk_elastic_index_prefix']) {
          $this->error['wk_elastic_index_prefix'] = $this->language->get('error_wk_elastic_index_prefix');
        }

        if (isset($post_data['wk_elastic_index_prefix']) && $post_data['wk_elastic_index_prefix']) {
            if ((preg_match("/^[a-z\_]+$/", $post_data['wk_elastic_index_prefix']) != 1) || (strlen($post_data['wk_elastic_index_prefix']) > 50)) {
              $this->error['wk_elastic_index_prefix'] = $this->language->get('error_wk_elastic_index_prefix_invalid');
            }
        }

        if ($post_data['wk_elastic_login_auth']) {
            if (!$post_data['wk_elastic_host_username']) {
              $this->error['wk_elastic_host_username'] = $this->language->get('error_wk_elastic_host_username');
            }

            if (!$post_data['wk_elastic_host_password']) {
              $this->error['wk_elastic_host_password'] = $this->language->get('error_wk_elastic_host_password');
            }
        }

        return !$this->error;
    }

}
