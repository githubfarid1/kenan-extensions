<?php
/**
 * @version [1.0.0.0] [Supported opencart version 2.3.x.x.]
 * @category Webkul
 * @package Opencart-Webkul-ElasticSearch
 * @author [Webkul] <[<http://webkul.com/>]>
 * @copyright Copyright (c) 2010-2018 Webkul Software Private Limited (https://webkul.com)
 * @license https://store.webkul.com/license.html
 */
// require_once 'sync.php';

class EsCronIndex {
	/**
	 * [private to store the default store's language_id]
	 * @var [type]
	 */
	private $config_language_id = 1;

	private $server_response 	= '';

	private $record_limit 		= 10;

	private $record_error 		= array();

	public function __construct($registry) {
		$this->registry			= $registry;
		$this->load  	      = $this->registry->get('load');
		$this->config 			= $this->registry->get('config');
		$this->db  	        = $this->registry->get('db');
		$this->language  	  = $this->registry->get('language');
		$registry->set('es', new Webkul\Es\Es($this->registry));
		$this->es  	        = $this->registry->get('es');

		$this->load->model('localisation/language');
		$this->model_localisation_language	= $this->registry->get('model_localisation_language');

		$this->load->model('es/es');
		$this->model_es_es	= $this->registry->get('model_es_es');

		$this->config->set('config_language_id', $this->getConfigLanguage());
	}

  public function runIndexShcedule() {
			$server_status = $this->es->esserver->checkServerRunning();
			if ($server_status) { // case: server is running

					$this->reIndex();

			} else { //case: server is not running [Cluster:node is not active]
					$this->startServer($this->getOsName());

					if ($this->server_response && strpos($this->server_response, "elasticsearch.service") !== false) {
							$this->reIndex();
					}
			}
  }

	public function reIndex() {
			$getAllIndices = $this->es->index->getModelIndices();

			if (!empty($getAllIndices)) {
					foreach ($getAllIndices as $key => $index_array) {
							$this->reIndexProcess($index_array);
					}
			}
	}

	public function reIndexProcess($index_array = array()) {
      $type_data_array = array();
			$index_array['page'] 	= 1;
			$index_array['start'] = 0;
			if (!isset($index_array['limit'])) {
					$index_array['limit'] = $this->record_limit;
			} else {
					$this->record_limit = $index_array['limit'];
			}

      if (isset($index_array['type'])) {
          switch($index_array['type']) {
              case 'product':
									$total_steps 	= $this->getTotalSteps($this->model_es_es->getTotalProducts());

									for ($i=1; $i <= $total_steps; $i++) {
											$type_data_array = $this->reindexProduct($index_array);

											if (isset($type_data_array['callback']) && $type_data_array['callback']) {
												$index_array['start'] = ($index_array['page'] * $this->record_limit) + 1;
												$index_array['page']	= ($index_array['page']) + 1;
											}
									}

                  break;
              case 'category':
									$total_steps 	= $this->getTotalSteps($this->model_es_es->getTotalCategories());

									for ($i=1; $i <= $total_steps; $i++) {
											$type_data_array = $this->reindexCategory($index_array);

											if (isset($type_data_array['callback']) && $type_data_array['callback']) {
												$index_array['start'] = ($index_array['page'] * $this->record_limit) + 1;
												$index_array['page']	= ($index_array['page']) + 1;
											}
									}

                  break;
              case 'manufacturer':
									$total_steps 	= $this->getTotalSteps($this->model_es_es->getTotalManufacturers());

									for ($i=1; $i <= $total_steps; $i++) {
											$type_data_array = $this->reindexManufacturer($index_array);

											if (isset($type_data_array['callback']) && $type_data_array['callback']) {
												$index_array['start'] = ($index_array['page'] * $this->record_limit) + 1;
												$index_array['page']	= ($index_array['page']) + 1;
											}
									}

                  break;
              case 'information':
									$total_steps 	= $this->getTotalSteps($this->model_es_es->getTotalInformations());

									for ($i=1; $i <= $total_steps; $i++) {
											$type_data_array = $this->reindexInformation($index_array);

											if (isset($type_data_array['callback']) && $type_data_array['callback']) {
												$index_array['start'] = ($index_array['page'] * $this->record_limit) + 1;
												$index_array['page']	= ($index_array['page']) + 1;
											}
									}

                  break;
          }
      }
      return $type_data_array;
	}

	public function getTotalSteps($total_count = false) {
			$steps_remain 	 = $total_count % $this->record_limit;
			if ($steps_remain == 0) {
					$total_steps = $total_count / $this->record_limit;
			} else {
					$total_steps = ($total_count / $this->record_limit ) + 1;
			}
			return ceil($total_steps);
	}

	public function addBulkData($params) {
			try {
					$index = $this->es->document->addBulkDocument($params);
					return $index->response;
			} catch (throwable $e) {
					return $e->getMessage();
			} catch (Exception $e) {
					return $e->getMessage();
			}
	}

	public function reindexProduct($data = array()) {
			$json = array();
			$this->load->language('es/esindex');
			$this->load->model('catalog/product');
			$this->model_catalog_product	= $this->registry->get('model_catalog_product');

			$languages 	= $this->model_localisation_language->getLanguages();
			$products 	= $this->model_catalog_product->getProducts($data);

			if(!empty($products)) {
					foreach ($products as $key => $product) {
							$params['body'][] = [
									'index' => [
											'_index'  => $data['index_prefix'].$data['name'],
											'_type'   => $data['type'],
											'_id'     => $product['product_id'],
									]
							];
							// product description for all available languages in current store
							$product_detail = $this->model_catalog_product->getProductDescriptions($product['product_id']);
							$name                 = array();
							$description          = array();
							$meta_tag_title       = array();
							$meta_tag_description = array();
							$meta_tag_keyword     = array();
							$product_tags         = array();

							foreach ($languages as $key => $language) {
									$name_autocomplete[$language['name']]     = $product_detail[$language['language_id']]['name'];
									$name[$language['name']]                  = $product_detail[$language['language_id']]['name'];
									$description[$language['name']]           = trim(preg_replace('/\s+/', ' ', strip_tags(html_entity_decode($product_detail[$language['language_id']]['description']))));
									$meta_tag_title[$language['name']]        = $product_detail[$language['language_id']]['meta_title'];
									$meta_tag_description[$language['name']]  = $product_detail[$language['language_id']]['meta_description'];
									$meta_tag_keyword[$language['name']]      = $product_detail[$language['language_id']]['meta_keyword'];
									$product_tags[$language['name']]          = $product_detail[$language['language_id']]['tag'];
							}

							// product's stores
							$stores = array();
							$product_stores = $this->model_catalog_product->getProductStores($product['product_id']);
							foreach ($product_stores as $key => $product_store) {
									$stores[] = $product_store;
							}

							// product's categories
							$categories = $this->model_es_es->getProductCategories($product['product_id']);

							$detail = array(
									'product_id'        => $product['product_id'],
									'price'             => $product['price'],
									'special'           => $this->model_es_es->getProductSpecial($product['product_id']),
									'quantity'          => $product['quantity'],
									'tax_class_id'      => $product['tax_class_id'],
									'minimum'           => $product['minimum'],
									'model'             => $product['model'],
									'model_autocomplete'=> $product['model'],
									'image'             => $product['image'],
									'status'            => $product['status'],
									'sort_order'        => $product['sort_order'],
									'rating'            => $this->model_es_es->getProductRating($product['product_id']),
									'seo_url'           => '',
									'name'              => $name,
									'name_autocomplete' => $name,
									'name_suggest'      => $name,
									'description'       => $description,
									'meta_tag_title'    => $meta_tag_title,
									'meta_tag_description' => $meta_tag_description,
									'meta_tag_keyword'  => $meta_tag_keyword,
									'product_tags'      => $product_tags,
									'stores'            => $stores,
									'categories'        => $categories,
									'options'           => $this->model_catalog_product->getProductOptions($product['product_id']),
									'attribute'         => $this->model_catalog_product->getProductAttributes($product['product_id'])
							);

							foreach ($languages as $key => $language) {
									$detail[$language['name'].'_name_autocomplete'] = $product_detail[$language['language_id']]['name'];
									$detail[$language['name'].'_name_suggest'] 			= $product_detail[$language['language_id']]['name'];
									$detail[$language['name'].'_product_tags'] 			= $product_detail[$language['language_id']]['tag'];
							}

							if(isset($product['manufacturer_id']) && $product['manufacturer_id']) {
									$detail['manufacturer'] = array(
											'manufacturer_id' => $product['manufacturer_id'],
											'name'            => $this->model_es_es->getManufacturerName($product['manufacturer_id']),
									);
							}
							$params['body'][] = $detail;
					}

					$response = $this->addBulkData($params);

					if(isset($response['errors']) && $response['errors']) {
							$this->record_error = array();
							$json['success']  = false;
							if (isset($response['items']) && !empty($response['items'])) {
									array_walk($response['items'], function ($item){
											if (isset($item['index']['error']) && isset($item['index']['_id'])) {
													$this->record_error[$item['index']['_id']] = '<b>'.$item['index']['error']['type'].': </b>'.$item['index']['error']['reason'];
											} else {
												$json['success']  = false;
												$json['callback'] = true;
											}
									});
							}
							if (!empty($this->record_error)) {
									$error_msg_string = '';
									foreach ($this->record_error as $product_id => $error_msg) {
											$product_info = $this->model_catalog_product->getProduct($product_id);
											if (!empty($product_info)) {
													$error_msg_string .= '<br><b>'.$product_info['name'].'</b> -'.$error_msg;
											}
									}
									$json['msg']   = sprintf($this->language->get('error_product_index_result'), $error_msg_string);
							} else {
									$json['msg']      = $this->language->get('error_no_product_index');
							}
					} else {
							$json['success']  = false;
							$json['callback'] = true;
					}
			} else if ($data['page'] == 1) {
					$json['success'] 	= false;
					$json['callback'] = false;
					$json['msg'] 			= $this->language->get('error_product_index');
			} else {
					$json['success'] 	= true;
					$json['callback'] = false;
					$json['msg'] 			= $this->language->get('success_product_indexed');
			}
			return $json;
	}

	public function reindexCategory($data = array()) {
			$json = array();
			$this->load->language('es/esindex');
			$this->load->model('catalog/category');
			$this->model_catalog_category	= $this->registry->get('model_catalog_category');

			$categories = $this->model_catalog_category->getCategories($data);
			if (!empty($categories)) {
					foreach ($categories as $key => $category) {
							$params['body'][] = [
									'index' => [
											'_index'  => $data['index_prefix'].$data['name'],
											'_type'   => $data['type'],
											'_id'     => $category['category_id'],
									]
							];
							$category['name'] = strip_tags(html_entity_decode($category['name']));
							$params['body'][] = $category;
					}
					$response = $this->addBulkData($params);
					if($response['errors']) {
							$json['success'] 	= false;
							$json['callback'] = false;
							$json['msg'] 			= $this->language->get('error_category_index');
					} else {
							$json['success'] 	= false;
							$json['callback'] = true;
					}
			} else if($data['page'] == 1){
					$json['success'] 	= false;
					$json['callback'] = false;
					$json['msg'] 			= $this->language->get('error_no_category_index');
			} else {
					$json['success'] 	= true;
					$json['callback'] = false;
					$json['msg'] 			= $this->language->get('success_category_indexed');
			}
			return $json;
	}

	public function reindexManufacturer($data = array()) {
			$json = array();
			$this->load->language('es/esindex');
			$this->load->model('catalog/manufacturer');
			$this->model_catalog_manufacturer	= $this->registry->get('model_catalog_manufacturer');

			$manufactureres = $this->model_catalog_manufacturer->getManufacturers($data);
			if($manufactureres) {
					foreach ($manufactureres as $key => $manufacturer) {
							$params['body'][] = [
									'index' => [
											'_index'  => $data['index_prefix'].$data['name'],
											'_type'   => $data['type'],
											'_id'     => $manufacturer['manufacturer_id'],
									]
							];
							$manufacturer['manufacturer_id']    = $manufacturer['manufacturer_id'];
							$manufacturer['manufacturer_name']  = strip_tags(html_entity_decode($manufacturer['name']));
							$params['body'][]                   = $manufacturer;
					}
					$response = $this->addBulkData($params);
					if($response['errors']) {
							$json['success'] 	= false;
							$json['callback'] = false;
							$json['msg'] 			= $this->language->get('error_manufacturer_index');
					} else {
							$json['success'] 	= false;
							$json['callback'] = true;
					}
			} else if($data['page'] == 1){
					$json['success'] 	= false;
					$json['callback'] = false;
					$json['msg'] 			= $this->language->get('error_no_manufacturer_index');
			} else {
					$json['success'] 	= true;
					$json['callback'] = false;
					$json['msg'] 			= $this->language->get('success_manufacturer_indexed');
			}
			return $json;
	}

	public function reindexInformation($data = array()) {
			$json = array();
			$this->load->language('es/esindex');
			$this->load->model('catalog/information');
			$this->model_catalog_information	= $this->registry->get('model_catalog_information');

			$languages 		= $this->model_localisation_language->getLanguages();
			$informations = $this->model_catalog_information->getInformations($data);

			if($informations) {
					foreach ($informations as $key => $information) {
							$params['body'][] = [
									'index' => [
											'_index'  => $data['index_prefix'].$data['name'],
											'_type'   => $data['type'],
											'_id'     => $information['information_id'],
									]
							];

							$details = array(
								'information_id'		=>	$information['information_id'],
								'status'						=>	$information['status'],
							);

							$information_detail = $this->model_catalog_information->getInformationDescriptions($information['information_id']);

							foreach ($languages as $key => $language) {
									$details['name'][$language['name']]   = strip_tags(html_entity_decode($information_detail[$language['language_id']]['title']));
									$details['description'][$language['name']]= trim(preg_replace('/\s+/', ' ', strip_tags(html_entity_decode($information_detail[$language['language_id']]['description']))));
									$details['meta_title'][$language['name']] = $information_detail[$language['language_id']]['meta_title'];
									$details['meta_description'][$language['name']] = $information_detail[$language['language_id']]['meta_description'];
									$details['meta_keyword'][$language['name']] = $information_detail[$language['language_id']]['meta_keyword'];
							}
							$params['body'][] 					= $details;
					}

					$response = $this->addBulkData($params);
					if($response['errors']) {
							$json['success'] 	= false;
							$json['callback'] = false;
							$json['msg'] 			= $this->language->get('error_information_index');
					} else {
							$json['success'] 	= false;
							$json['callback'] = true;
					}
			} else if($data['page'] == 1){
					$json['success'] 	= false;
					$json['callback'] = false;
					$json['msg'] 			= $this->language->get('error_no_information_index');
			} else {
					$json['success'] 	= true;
					$json['callback'] = false;
					$json['msg'] 			= $this->language->get('success_information_indexed');
			}
			return $json;
	}

	/**
	 * [getOsName to get the server]
	 * @return [type] [description]
	 */
	public function getOsName() {
			$server_array = array();
			$os_name 			= '';
			exec("hostnamectl", $server_array);
			foreach($server_array as $line) {
					if (strpos($line, "Operating System") !== false) {
							$extract_os = explode(":", $line);
							if (isset($extract_os[1])) {
									$os_name = trim($extract_os[1]);
							}
							break;
					}
			}
			return strtolower($os_name);
	}

	public function startServer($os_name) {
			$this->server_response 	= '';
			$match_string 					= '';
			if ($os_name) {
					switch ($os_name) {
						case strpos($os_name, "ubuntu"):
							$match_string = exec("sudo /etc/init.d/elasticsearch start disown &");
							break;
						case strpos($os_name, "redhat"):
									echo ":redhat";
							break;
						case strpos($os_name, "centos"):
								echo ":centos";
							break;

						default:
							$match_string = exec("sudo /etc/init.d/elasticsearch start disown &");
							break;
					}

					if ($match_string) {
							$server_status = explode(":", $match_string);
							if (isset($server_status[1])) {
									$this->server_response = strtolower(trim($server_status[1]));
							}
					}
			}
	}

	/**
	 * [getConfigLanguage get config default language id]
	 * @return [type] [description]
	 */
	public function getConfigLanguage() {
			$result =  $this->db->query("SELECT language_id FROM ".DB_PREFIX."language WHERE code = '".$this->db->escape($this->config->get('config_language'))."' ")->row;

			if (!empty($result) && isset($result['language_id'])) {
				return $result['language_id'];
			} else {
				return $this->config_language_id;
			}
	}
}
