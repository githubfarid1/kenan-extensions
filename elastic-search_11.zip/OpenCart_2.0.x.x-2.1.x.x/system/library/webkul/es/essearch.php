<?php

namespace Webkul\Es;

class Essearch {

    private $es;
    function __construct($es) {
        $this->es = $es;
        return $this;
    }

    public function getData($args) {
        $json = array();
        $data['name'] = $args['name'];
        $data['type'] = $args['type'];
        if (isset($args['query'])) {
            switch($args['query']) {
                case('prefix') :
                $data['query'] = $this->getPrefixQuery($args);
                break;
                case('match') :
                $data['query'] = $this->getMatchQuery($args);
                break;
                case('multimatch') :
                $data['query'] = $this->getMultiMatchQuery($args);
                break;
                case('category') :
                $data['query'] = $this->getMatchQueryForCategory($args);
                break;
                default:
                $data['query'] = $this->getMultiMatchQuery($args);
                break;
            }
        } else {
            $data['query'] = $this->getMultiMatchQuery($args);
        }
        if(isset($args['start']) && $args['start']) {
            $data['from'] = $args['start'];
        } else {
            $data['from'] = 0;
        }
        if(isset($args['limit']) && $args['limit']) {
            $data['size'] = $args['limit'];
        } else {
            $data['size'] = 10000;
        }

        try {
            $result = $this->search($data);

            $json['items'] = $result->response['hits']['hits'];
            $json['total'] = $result->response['hits']['total'];

            $json['suggestions'] = array();
            if(isset($result->response['suggest']['product_name']) && $result->response['suggest']['product_name']) {
                $json['suggestions'] = array_merge($json['suggestions'], $result->response['suggest']['product_name'][0]['options']);
            }
            if(isset($result->response['suggest']['product_model']) && $result->response['suggest']['product_model']) {
                $json['suggestions'] = array_merge($json['suggestions'], $result->response['suggest']['product_model'][0]['options']);
            }
            if (isset($data['query']['suggest']['name_suggest'])) {
                if(isset($result->response['suggest']['name_suggest'][0]['options']) && $result->response['suggest']['name_suggest'][0]['options']) {
                    $json['suggestions'] = array_merge($json['suggestions'], $result->response['suggest']['name_suggest'][0]['options']);
                }
            }

            if (isset($data['query']['suggest']['tag_suggest'])) {
                if(isset($result->response['suggest']['tag_suggest'][0]['options']) && $result->response['suggest']['tag_suggest'][0]['options']) {
                    $json['suggestions'] = array_merge($json['suggestions'], $result->response['suggest']['tag_suggest'][0]['options']);
                }
            }

            $json['success'] = true;
        } catch(Throwable $e) {
            $json['success'] = false;
            $json['msg'] = $e->getMessage();
        } catch(Exception $e) {
            $json['success'] = false;
            $json['msg'] = $e->getMessage();
        }
        return $json;
    }

    public function getPrefixQuery($args) {
        return [
            '_source' => [
                'include' => $args['source']['include'],
                'excludes' => $args['source']['exclude'],
            ],
            'query' => [
                'prefix' => [
                    $args['field'] => $args['keyword'],
                ]
            ]
        ];
    }

    public function getMatchQuery($args) {
        $fields = array();
        $query = array(
            '_source' => array(
                'include' => $args['source']['include'],
                'excludes' => $args['source']['exclude'],
            ),
            'query' => array(
                'bool' => array(
                    'should' => array(
                        'match' => [ $args['field'] =>  $args['keyword'] ],
                    ),
                ),
            ),
            'sort' => array(
                $args['sort'] => [
                    'order' => strtolower($args['order']),
                ],
                '_score' => ['order' => strtolower($args['order']) ],
            ),
        );
        return $query;
    }

    public function getMultiMatchQuery($args) {
        $query = array(
            '_source' => array(
                'includes' => $args['source']['include'],
                'excludes' => $args['source']['exclude'],
            ),
            'query' => array(
                'multi_match' => array(
                    'query'       => $args['keyword'],
                    'type'        => 'best_fields',
                    'fields'      => $args['fields'],
                    // 'operator'    => 'OR',
                    // 'tie_breaker' => 0.3,
                    // 'minimum_should_match' => '25%',
                    'fuzziness' => 1,
                ),
            ),
        );
        if (isset($args['suggestionfield']) || isset($args['name_suggestion']) || isset($args['tag_suggestion'])) {
          $query['suggest'] = array();
        }
        
        if(isset($args['suggestionfield'])) {
          $query['suggest'] = array_merge($query['suggest'], $this->getSuggestionQuery($args));
        }

        if(isset($args['name_suggestion'])) {
          $query['suggest'] = array_merge($query['suggest'], $this->getNameSuggestionQuery($args));
        }

        if(isset($args['tag_suggestion'])) {
          $query['suggest'] = array_merge($query['suggest'], $this->getTagsSuggestionQuery($args));
        }

        if(isset($args['sort'],$args['order'])) {
            $query['sort'] = array(
                $args['sort'] => [
                    'order' => strtolower($args['order']),
                ],
                // '_score' => ['order' => strtolower($args['order']) ],
            );
        }
        return $query;
    }

    public function getMatchQueryForCategory($args) {
        $fields = array();
        $query = array(
            '_source' => array(
                'include' => $args['source']['include'],
                'excludes' => $args['source']['exclude'],
            ),
            'query' => array(
                'bool' => array(
                    'must' => array(
                        'match' => [ $args['field'] =>  $args['keyword'] ],
                    ),
                ),
            ),
            'sort' => array(
                $args['sort'] => [
                    'order' => strtolower($args['order']),
                ],
            ),
        );
        return $query;
    }

    public function prefixsearch($data) {
        $params = [
            'index' => $data['name'],
            'type' => $data['type'],
            'size' => 20,
            'body' => $data['query'],
        ];
        $this->response = $this->es->init->client->search($params);
        return $this;
    }

    public function search($data) {
        $params = [
            'index' => $data['name'],
            'type'  => $data['type'],
            'from'  => $data['from'],
            'size'  => $data['size'],
            'body'  => $data['query'],
        ];

        $this->response = $this->es->init->client->search($params);

        return $this;
    }

    public function getSuggestion($args) {
        $json = array();
        $data['query'] = $this->getSuggestionQuery($args);
        $data['_source'] = ['product_id'];

        try {
            $result = $this->suggest($data);
            $json['suggestions'] = array();
            $json['suggestions'] = array_merge($json['suggestions'], $result->response['product_name'][0]['options'], $result->response['product_model'][0]['options']);
            $json['success'] = true;
        } catch(Throwable $e) {
            $json['success'] = false;
            $json['msg'] = $e->getMessage();
        } catch(Exception $e) {
            $json['success'] = false;
            $json['msg'] = $e->getMessage();
        }
        return $json;
    }

    public function getSuggestionQuery($args) {
        $query = array();
        if(isset($args['suggestionfield'])) {
            $query['product_name'] = array(
                'text' => $args['keyword'],
                'completion' => [
                    'field' => $args['suggestionfield'],
                    'size'  => 2,
                    'fuzzy' => [
                        // 'edit_distance' => 1
                        'fuzziness' => 1
                    ]
                ],
            );
        }

        return $query;
    }

    public function getNameSuggestionQuery($args) {
        $query = array();
        if(isset($args['name_suggestion'])) {
                $query['text']          = $args['keyword'];
                $query['name_suggest'] = array(
                                    'phrase' => array(
                                                    'field'             => $args['name_suggestion'],
                                                    'size'              => 1,
                                                    'gram_size'         => 1,
                                                    'direct_generator'  => [ [
                                                                              'field'       => $args['name_suggestion'],
                                                                              'suggest_mode'=> 'always'
                                                                            ] ],
                                                    'highlight'         => array(
                                                                              'pre_tag'   => '<em>',
                                                                              'post_tag'  => '</em>'
                                                                            )
                                                  )
                                    );
        }
        return $query;
    }

    public function getTagsSuggestionQuery($args) {
        $query = array();
        if(isset($args['tag_suggestion'])) {
                $query['text']        = $args['keyword'];
                $query['tag_suggest'] = array(
                                    'phrase' => array(
                                                    'field'             => $args['tag_suggestion'],
                                                    'size'              => 1,
                                                    'gram_size'         => 1,
                                                    'direct_generator'  => [ [
                                                                              'field'       => $args['tag_suggestion'],
                                                                              'suggest_mode'=> 'always'
                                                                            ] ],
                                                    'highlight'         => array(
                                                                              'pre_tag'   => '<em>',
                                                                              'post_tag'  => '</em>'
                                                                            )
                                                  )
                                    );
        }
        return $query;
    }

    public function suggest($data) {
        $params = [
            'body' => $data['query'],
        ];
        $this->response = $this->es->init->client->suggest($params);
        return $this;
    }
}
?>
