<?php

namespace Webkul\Es;

use Elasticsearch\ClientBuilder;

class EsServer {

    private $es;

    function __construct($es) {
      $this->es = $es;
    }

  /**
	 * [checkServerRunning check server is running or not]
	 * @return [boolean] [return true on success]
	 */
  	public function checkServerRunning(){
  		$ip_address = $this->es->config->get('wk_elastic_host');
  		$port 			= $this->es->config->get('wk_elastic_host_port');
  		$chk_serverRunning = exec('timeout 2s telnet '.$ip_address.' '.$port);

  		$get_brack = explode(' ', $chk_serverRunning);

  			if((count($get_brack) > 2) && (strtolower($get_brack[0]) == 'escape') ){
  				return true;
  			}
  		return false;
  	}

    public function checkStatus() {
        $json = array();
        $host_setting = array(
          'host'    => $this->es->config->get('wk_elastic_host'),
          'port'    => $this->es->config->get('wk_elastic_host_port'),
          'scheme'  => $this->es->config->get('wk_elastic_host_scheme'),
        );

        if ($this->es->config->get('wk_elastic_login_auth')) {
            $host_setting['user'] = $this->es->config->get('wk_elastic_host_username');
            $host_setting['pass'] = $this->es->config->get('wk_elastic_host_password');
        }

        try {
          $status = $this->es->init->hostSetup($host_setting)->checkStatus();

          if ($status) {
            $json['status'] = true;
            $json['detail'] = $status;
          } else {
            $json['status'] = false;
          }
        } catch (Throwable $e) {
          $error = $e->getMessage();
          $json['status'] = false;
          $json['msg'] = $error;
        } catch (Exception $e) {
          $error = $e->getMessage();
          $json['status'] = false;
          $json['msg'] = $error;
        }
        return $json;
    }
}
