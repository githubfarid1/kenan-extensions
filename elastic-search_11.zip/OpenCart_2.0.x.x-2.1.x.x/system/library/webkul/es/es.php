<?php

namespace Webkul\Es;

use Elasticsearch\ClientBuilder;

require_once DIR_SYSTEM.'../vendor/autoload.php';
require_once 'esinit.php';
require_once 'esindex.php';
require_once 'essearch.php';

class Es {

    public $init;
    public $index;
    public $search;
    public $document;
    public $escron;
    public $sync;

    function __construct($registry) {
        $this->config             = $registry->get('config');
		    $this->customer           = $registry->get('customer');
        $this->session            = $registry->get('session');
        $this->load               = $registry->get('load');
        $this->db                 = $registry->get('db');
        $this->init               = new Esinit($this);
        $this->index              = new Esindex($this);
        $this->search             = new Essearch($this);
        $this->document           = new Esdocument($this);
        $this->esserver           = new EsServer($this);
    }
}
