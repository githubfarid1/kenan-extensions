<?php

namespace Webkul\Es;

/**
 *
 */
class Esindex {

    private $es;
    private $index;
    private $type;
    private $shrad;
    private $replica;
    private $id;
    public $response;

    function __construct($es) {
        $this->es     = $es;
        return $this;
    }

    /**
     *
     * @param [string] $index
     * @return this
     */
    public function get($index) {
        $params = ['index' => $index];
        $this->response = $this->es->init->client->indices()->getSettings($params);
        return $this;
    }

    public function Exist($index) {
        try {
            $index = $this->get($index);
            return true;
        } catch(Throwable $e) {
            echo $e->getMessage();
            return false;
        } catch (Exception $e) {
            echo $e->getMessage();
            return false;
        }
    }

    public function create($setting) {
        $params = [
            'index'   => $setting['index_prefix'].$setting['name'],
            'body'    => [
                          'settings' => $setting['setting'],
                          'mappings' => $setting['mappings'],
                        ],
        ];
        $this->response = $this->es->init->client->indices()->create($params);

        return $this;
    }

    public function update($setting) {
        $close_index_response = $this->closeIndex($setting);
        $params = [
            'index'   => $setting['index_prefix'].$setting['name'],
            'body'    => [
                          'settings' => $setting['setting'],
                        ],
        ];
        if (isset($close_index_response['acknowledged']) && $close_index_response['acknowledged']) {
            $this->response       = $this->es->init->client->indices()->putSettings($params);
            $open_index_response  = $this->openIndex($setting);
        }
        return $this;
    }

    public function closeIndex($setting) {
        $index_params = [
            'index'   => $setting['index_prefix'].$setting['name']
        ];
        try {
            $close_index = $this->es->init->client->indices()->close($index_params);
            return $close_index;
        } catch(Throwable $e) {
            return array('status' => false, 'msg' => $e->getMessage());
        } catch (Exception $e) {
            echo $e->getMessage();
            return array('status' => false, 'msg' => $e->getMessage());
        }
    }

    public function openIndex($setting) {
        $index_params = [
            'index'   => $setting['index_prefix'].$setting['name']
        ];
        try {
            $open_index = $this->es->init->client->indices()->open($index_params);
            return $open_index;
        } catch(Throwable $e) {
            return array('status' => false, 'msg' => $e->getMessage());
        } catch (Exception $e) {
            echo $e->getMessage();
            return array('status' => false, 'msg' => $e->getMessage());
        }
    }

    public function updateMapping($setting) {
        $params = [
            'index'   => $setting['index_prefix'].$setting['name'],
            'body' => [
                'settings' => $setting['setting'],
            ],
        ];
        $this->response = $this->es->init->client->indices()->putMapping($params);
        return $this;
    }

    public function delete($index) {
        $params = [
            'index' => $index,
        ];
        $this->response = $this->es->init->client->indices()->delete($params);
        return $this;
    }

    public function getModelIndices($data = array()) {
        $results = $this->es->db->query("SELECT * FROM ".DB_PREFIX."es_index ")->rows;

        return $results;
    }

    public function getTotalModelIndices($data = array()) {
        $result = $this->es->db->query("SELECT COUNT(*) AS total FROM ".DB_PREFIX."es_index ")->row;

        return $result['total'];
    }
}
?>
