<?php

namespace Webkul\Es;

class Esdocument {

    private $es;
    public $response;

    function __construct($es) {
        $this->es = $es;
        return $this;
    }

    public function addDocument($data) {
        $params = [
            'index' => $data['index'],
            'type'  => $data['type'],
            'id'    => $data['id'],
            'body'  => $data['data'],
        ];

        $this->response = $this->es->init->client->index($params);
        return $this;
    }

    public function addBulkDocument($data = array()) {
        $this->response = $this->es->init->client->bulk($data);
        return $this;
    }

    public function getAllByIndex($data = array()) {
        $params = [
            'index' => $data['index'],
            'type' => $data['type'],
        ];
        $this->response = $this->es->init->client->search($params);
        return $this;
    }

}
