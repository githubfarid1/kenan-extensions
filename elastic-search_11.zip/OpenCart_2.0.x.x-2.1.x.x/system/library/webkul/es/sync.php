<?php

namespace Webkul\Es;

class Sync {

    private $es;
    public $response;

    function __construct($es) {
        $this->es = $es;
        $this->registry = $es;
        // $es->load->modelloader('admin','es/es');
        $es->load->model('es/es');
        return $this;
    }

}
