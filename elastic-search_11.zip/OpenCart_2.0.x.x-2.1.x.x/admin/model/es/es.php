<?php

class ModelEsEs extends Model {

    public function getTotalProducts() {
        $sql = "SELECT product_id FROM " . DB_PREFIX . "product ";
        $result = $this->db->query($sql)->rows;
        if ($result) {
            return count($result);
        } else {
            return false;
        }
    }

    public function getTotalCategories() {
        $sql = "SELECT category_id FROM " . DB_PREFIX . "category ";
        $result = $this->db->query($sql)->rows;
        if ($result) {
            return count($result);
        } else {
            return false;
        }
    }

    public function getTotalManufacturers() {
        $sql = "SELECT manufacturer_id FROM " . DB_PREFIX . "manufacturer ";
        $result = $this->db->query($sql)->rows;
        if ($result) {
            return count($result);
        } else {
            return false;
        }
    }

    public function getTotalInformations() {
        $sql = "SELECT information_id FROM " . DB_PREFIX . "information ";
        $result = $this->db->query($sql)->rows;
        if ($result) {
            return count($result);
        } else {
            return false;
        }
    }

    public function getProductRating($product_id) {
        $sql = "SELECT AVG(rating) AS total FROM " . DB_PREFIX . "review r1 WHERE r1.product_id = '" . (int)$product_id . "' AND r1.status = '1' GROUP BY r1.product_id";
        $result = $this->db->query($sql)->row;
        if ($result) {
            return $result['total'];
        } else {
            return 0;
        }
    }

    public function getProductSpecial($product_id) {
        $sql = "SELECT price FROM " . DB_PREFIX . "product_special ps WHERE ps.product_id = '" . (int)$product_id . "' AND ps.customer_group_id = '" . (int)$this->config->get('config_customer_group_id') . "' AND ((ps.date_start = '0000-00-00' OR ps.date_start < NOW()) AND (ps.date_end = '0000-00-00' OR ps.date_end > NOW())) ORDER BY ps.priority ASC, ps.price ASC LIMIT 1";
        $result = $this->db->query($sql)->row;
        if ($result) {
            return $result['price'];
        } else {
            return 0;
        }
    }

    public function getProductCategories($product_id) {
	    $product_category_data = array();

      $query = $this->db->query("SELECT p2c.product_id, c.parent_id, p2c.category_id, cd.name, cd.description, cd.meta_title, cd.meta_description, cd.meta_keyword, l.name as language_name, l.language_id FROM " . DB_PREFIX . "product_to_category p2c LEFT JOIN " . DB_PREFIX . "category_description cd ON (cd.category_id = p2c.category_id && p2c.product_id = '" . (int)$product_id . "') LEFT JOIN " . DB_PREFIX . "category c ON (c.category_id = p2c.category_id) LEFT JOIN " . DB_PREFIX . "language l ON (l.language_id = cd.language_id) WHERE product_id = '" . (int)$product_id . "' ");

      foreach ($query->rows as $result) {
        $product_category_data[$result['category_id']][$result['language_name']] = array(
          'category_id' => $result['category_id'],
          'parent_id'   => $result['parent_id'],
          'name'        => $result['name'],
          'meta_title'  => $result['meta_title'],
          'meta_description' => $result['meta_description'],
          'meta_keyword'=> $result['meta_keyword'],
        );
	    }
      return $product_category_data;
	}

  public function getManufacturerName($manufacturer_id) {
      $result = $this->db->query("SELECT name FROM " . DB_PREFIX . "manufacturer WHERE manufacturer_id = '" . (int)$manufacturer_id . "' ")->row;
      if ($result) {
          return $result['name'];
      } else {
          return false;
      }
  }

  public function addIndex($data) {
      $this->db->query("INSERT INTO " . DB_PREFIX . "es_index SET `es_uuid` = '".$this->db->escape($data['es_uuid']) . "', `name` = '".$this->db->escape($data['name']) . "', `index_prefix` = '".$this->db->escape($data['index_prefix']) . "', `type` = '".$this->db->escape($data['type']) . "', `shards` = '" . (int)$data['shards'] . "', `replica` = '" . (int)$data['replica'] . "', `status` = '" . (int)$data['status'] . "', `date_added` = NOW() , `date_modified` = NOW() ");
  }

  public function editIndex($data) {
      $this->db->query("UPDATE " . DB_PREFIX . "es_index SET replica = '" . (int)$data['replica'] . "', status = '" . (int)$data['status'] . "', date_modified = NOW() WHERE id = '" . (int)$data['id'] . "' ");
  }

  public function getIndex($id) {
      $result = array();
      $result = $this->db->query("SELECT * FROM " . DB_PREFIX . "es_index WHERE id = '" . (int)$id . "' ")->row;
      if ($result) {
          return $result;
      } else {
          return false;
      }
  }

  public function getIndexByNameType($name, $type) {
      $result = array();
      $result = $this->db->query("SELECT * FROM " . DB_PREFIX . "es_index WHERE name = '".$this->db->escape($name) . "' || type = '".$this->db->escape($type) . "' ")->row;
      if ($result) {
          return $result;
      } else {
          return false;
      }
  }

  public function deleteIndex($id) {
      $result = $this->getIndex($id);
      if ($result) {
          $this->load->library('webkul/es/es');
          try {
              $index = $this->es->index->delete($result['index_prefix'].$result['name']);
          } catch(Exception $ex) {

          }
          $this->db->query("DELETE FROM " . DB_PREFIX . "es_index WHERE id = '" . (int)$id . "' ");
      }
      return true;
  }

  public function createTable() {
      $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX ."es_index` (
          `id` int(11) NOT NULL AUTO_INCREMENT,
          `es_uuid` varchar(100) NOT NULL,
          `name` varchar(100) NOT NULL,
          `index_prefix` varchar(50) NOT NULL,
          `type` varchar(100) NOT NULL,
          `shards` int(11) NOT NULL,
          `replica` int(11) NOT NULL,
          `status` tinyint(1) NOT NULL,
          `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
          `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
          PRIMARY KEY (`id`)
        ) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci AUTO_INCREMENT=1") ;
  }

  public function dropTable() {
      $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX ."es_index` ");
  }
}
?>
