<?php

// Heading
$_['heading_title']                 =   'ElasticSearch Index';

// Entry
$_['entry_index_prefix']            =   'Index Prefix';
$_['entry_index_name']              =   'Index Name';
$_['entry_index_name_info']         =   'Must not contain the following characters [\, /, *, ?, ", <, >, |, , ,]], must be lowercase ';
$_['entry_index_type']              =   'Index Type';
$_['entry_shards']                  =   'No. of Shards';
$_['entry_replica']                 =   'No. of Replica';
$_['entry_status']                  =   'Status';
$_['entry_action']                  =   'Action';

// Text
$_['text_list']                     =   'ElasticSearch Index List';
$_['text_add']                      =   'ElasticSearch Index Add';
$_['text_update']                   =   'ElasticSearch Index Update';

$_['text_catalog']                  =   'Catalog';
$_['text_product']                  =   'Products';
$_['text_category']                 =   'Categories';
$_['text_manufacturer']             =   'Manufacturer';
$_['text_information']              =   'Information';
$_['text_only_number']              =   'Must be numeric!';
$_['text_no_product']               =   'Currently no product(s) to import!';

// Success
$_['success_index_add']             = 'Success: You have successfully added elasticsearch index.';
$_['success_index_edit']            = 'Success: You have successfully updated elasticsearch index.';
$_['success_index_delete']          = 'Success: You have successfully deleted selected elasticsearch index.';
$_['success_product_indexed']       = 'Success: All products are indexed.';
$_['success_category_indexed']      = 'Success: All categories are indexed.';
$_['success_manufacturer_indexed']  = 'Success: All manufacturers are indexed.';
$_['success_information_indexed']   = 'Success: All informations are indexed.';

// Error
$_['error_name_change']             = 'Warning: As you are changing name of existing index name, all the mapping related to above index will be removed after saving the changes and you will have to reindex it!';
$_['error_type_change']             = 'Warning: As you are changing type of existing index, all the mapping related to above index will be removed after saving the changes and you will have to reindex it!';
$_['error_permission']              = 'Warning: You do not have permission to modify ElasticSearch index!';
$_['error_general']                 = 'Warning: There is some issue, please try again later!';
$_['error_warning']                 = 'Warning: Please check the form carefully!';
$_['error_same_value']              = 'Warning: Same index name and index type can not exist!';
$_['error_index_delete']            = 'Warning: Please select atleast one index to delete!';
$_['error_name']                    = 'Warning: Index name must be between 3 to 100 characters!';
$_['error_name_unique']             = 'Warning: Must be unique in mapping with index type!';
$_['error_name_exist']              = 'Warning: Given name already exist, please enter other name!';
$_['error_type']                    = 'Warning: Please select index type!';
$_['error_type_unique']             = 'Warning: Must be unique in mapping with index name!';
$_['error_shards']                  = 'Warning: Shard value must be +ive integer!';
$_['error_replica']                 = 'Warning: Replica value must be +ive integer!';

$_['error_product_index']           = 'Warning: No product found to index!';
$_['error_no_product_index']        = 'Warning: No product are indexed, please try again later!';
$_['error_category_index']          = 'Warning: No category found to index!';
$_['error_no_category_index']       = 'Warning: No categories are indexed, please try again later!';
$_['error_manufacturer_index']      = 'Warning: No manufacturer found to index!';
$_['error_no_manufacturer_index']   = 'Warning: No manufacturers are indexed, please try again later!';
$_['error_information_index']       = 'Warning: No information found to index!';
$_['error_no_information_index']    = 'Warning: No informations are indexed, please try again later!';
$_['error_server_stop']             = 'Warning: No alive nodes found in your cluster, please check the server configuration!';
$_['error_product_index_result']    = 'Warning: These products didn\'t index on elastic search server %s <br> Please try again!';
?>
