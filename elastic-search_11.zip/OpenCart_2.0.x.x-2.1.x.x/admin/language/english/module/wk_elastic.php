<?php

// Heading
$_['heading_title']                         =       'Webkul Elastic Search';

// Entry
// General
$_['entry_store']                           =       'Store';
$_['entry_status']                          =       'Status';
$_['entry_es_host']                         =       'ElasticSearch Host';
$_['entry_es_port']                         =       'ElasticSearch Port';
$_['entry_index_prefix']                    =       'Index Prefix';
$_['help_index_prefix']                     =       'Info: Index prefix will be used to create your data index unique on elastic server.';
$_['entry_es_scheme']                       =       'ElasticSearch Scheme';
$_['entry_login_auth']                      =       'Login Authentication';
$_['entry_es_username']                     =       'ElasticSearch Username';
$_['entry_es_password']                     =       'ElasticSearch Password';
// Search
$_['entry_search_in']                       =       'Search In';
$_['entry_search_in_help']                  =       'Select in which you want to search at front end';
$_['entry_search_in_priority']              =       'Search In Priority';
$_['entry_search_in_product']               =       'Search In Product For';
$_['entry_search_in_category']              =       'Search In Category For';
$_['entry_search_in_information']           =       'Search In Information For';
$_['entry_synonym_keyword']                 =       'Synonym Keywords';
$_['entry_ignore_keyword']                  =       'Ignore Keywords';
$_['entry_single_result_redirect']          =       'Redirect If Single Result';
$_['entry_minimum_search_character']        =       'Minimum Number Of Character To Search';
$_['entry_search_result_detail']            =       'Details To Be Shown On Search Result';
$_['entry_search_textbox_placeholder']      =       'Search Text Box Placeholder';
$_['entry_no_result_text']                  =       'No Result Text';
$_['entry_more_result_text']                =       'More Result text';
$_['entry_total_no_of_result']              =       'Show Total Number Of Results';

// Tab
$_['tab_general']                           =       'General';
$_['tab_search']                            =       'Search';
$_['tab_advanced']                          =       'Advanced';
$_['tab_design']                            =       'Design';

// Text
$_['text_extension']                        =       'Extension';
$_['text_module']                           =       'Module';
$_['text_http']                             =       'Http';
$_['text_https']                            =       'Https';
$_['text_confirmation']                     =       'Are you sure?';
$_['text_store_confirmation']               =       'Current setting will be changed as per store selection. Are you sure?';
$_['text_comma_seperated']                  =       'Comma seperated values';
$_['text_product']                          =       'Product';
$_['text_category']                         =       'Category';
$_['text_manufacturer']                     =       'Manufacturer';
$_['text_information']                      =       'Information';
$_['text_title']                            =       'Title';
$_['text_name']                             =       'Name';
$_['text_description']                      =       'Description';
$_['text_meta_tag_title']                   =       'Meta Tag Title';
$_['text_meta_tag_description']             =       'Meta Tag Description';
$_['text_meta_tag_keywords']                =       'Meta Tag Keywords';
$_['text_tag']                              =       'Tags';
$_['text_model']                            =       'Model';
$_['text_sku']                              =       'SKU';
$_['text_upc']                              =       'UPC';
$_['text_ean']                              =       'EAN';
$_['text_jan']                              =       'JAN';
$_['text_isbn']                             =       'ISBN';
$_['text_mpn']                              =       'MPN';
$_['text_attribute']                        =       'Attribute';
$_['text_option']                           =       'Option';
$_['text_selectall']                        =       'Select All';
$_['text_deselectall']                      =       'Deselect All';
$_['text_product_name']                     =       'Product Name';
$_['text_product_price']                    =       'Product Price';
$_['text_product_model']                    =       'Product Model';
$_['text_product_description']              =       'Product Description';
$_['text_product_image']                    =       'Product Image';
$_['text_rating']                           =       'Product Rating';
$_['text_category_name']                    =       'Category Name';
$_['text_manufacturer_name']                =       'Manufacturer Name';
$_['text_keyword']                          =       'Keyword';
$_['text_synonym']                          =       'Synonym';
$_['text_action']                           =       'Action';
$_['text_server_running']                   =       'Server is running';
$_['text_status']                           =       'Status';
$_['text_cluster_name']                     =       'Cluster name';
$_['text_version']                          =       'Version';
$_['text_number']                           =       'Number';
$_['text_build_hash']                       =       'Build hash';
$_['text_build_time']                       =       'Build timestamp';
$_['text_build_snap']                       =       'Build snapshot';
$_['text_lucene_version']                   =       'Lucene version';
$_['text_tag_line']                         =       'Tag line';

// Success
$_['text_success']                          =       'Success: You have successfully modified webkul elastic search module.';
$_['text_connected_success']                =       'Success: You have successfully connected to the elasticsearch server.';


//button
$_['button_check_status']                   =       'Check Status';

// Error, Warning
$_['error_general']                         =       'Warning: There is some issue, please try again later!';
$_['error_form']                            =       'Warning: Please check the form carefully!';
$_['error_required_field']                  =       'Required field!';
$_['error_connection']                      =       'Warning: There is some authentication issue, please check given details and try again.';
$_['error_permission']                      =       'Warning: You do not have permission to modify webkul elastic search module!';
$_['error_wk_elastic_host']                 =       'Warning: Please provide the host for connection.';
$_['error_wk_elastic_host_port']            =       'Warning: Please provide the port for connection.';
$_['error_wk_elastic_host_username']        =       'Warning: Please provide the Elastic Search server Username.';
$_['error_wk_elastic_host_password']        =       'Warning: Please provide the Elastic Search server password.';
$_['error_wk_elastic_index_prefix']         =       'Warning: Please provide the index prefix.';
$_['error_wk_elastic_index_prefix_invalid'] =       'Warning: Index value must be in lowercase and underscore symbol.';
?>
