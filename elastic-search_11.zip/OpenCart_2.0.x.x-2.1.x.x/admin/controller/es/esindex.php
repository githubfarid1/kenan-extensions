<?php

class ControllerEsEsindex extends Controller {
    private $error;

    private $es_cron_index;

    private $error_products;

    public function __construct($registory) {
      parent::__construct($registory);
      $this->es_cron_index = new EsCronIndex($registory);
    }

    public function index() {
        $data = array();
        $data = array_merge($data, $this->load->language('es/esindex'));

        $this->document->setTitle($this->language->get('heading_title'));

        $url = '';

        if (isset($this->request->get['page'])) {
    			$page = $this->request->get['page'];
    		} else {
    			$page = 1;
    		}

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
          'text' => $this->language->get('text_home'),
          'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
        );

        $data['breadcrumbs'][] = array(
          'text' => $this->language->get('heading_title'),
          'href' => $this->url->link('es/esindex', 'token=' . $this->session->data['token'] . $url, true)
        );

        $this->load->model('es/es');

        $data['total_products']       = $this->model_es_es->getTotalProducts();
        $data['total_categories']     = $this->model_es_es->getTotalCategories();
        $data['total_manufacturers']  = $this->model_es_es->getTotalManufacturers();
        $data['total_informations']   = $this->model_es_es->getTotalInformations();

        $filter_data = array();

        $this->load->library('webkul/es/es');

        $indecies       = $this->es->index->getModelIndices($filter_data);
        $total_indecies = $this->es->index->getTotalModelIndices($filter_data);

        $data['indices'] = array();
        if ($indecies) {
            $checkServerStatus = $this->es->esserver->checkStatus();

            foreach ($indecies as $key => $index) {
                switch($index['type']) {
                  case 'product':
                    $totals = $this->model_es_es->getTotalProducts();
                  break;
                  case 'category':
                    $totals = $this->model_es_es->getTotalCategories();
                  break;
                  case 'manufacturer':
                    $totals = $this->model_es_es->getTotalManufacturers();
                  break;
                  case 'information':
                    $totals = $this->model_es_es->getTotalInformations();
                  break;
                }
                try {
                    $status = $this->es->index->Exist($index['index_prefix'] . $index['name']);

                     if ($status) {
                         $data['indices'][] = array(
                             'id'           => $index['id'],
                             'es_uuid'      => $index['es_uuid'],
                             'name'         => $index['name'],
                             'index_prefix' => $index['index_prefix'],
                             'type'         => $index['type'],
                             'shards'       => $index['shards'],
                             'replica'      => $index['replica'],
                             'status'       => $index['status'] ? '<span class="text-success"><b>' . $this->language->get('text_enabled') . '</b></span>' : '<span class="text-danger"><b>' . $this->language->get('text_disabled') . '</b></span>',
                             'edit'         => $this->url->link('es/esindex/edit' , 'token=' . $this->session->data['token'] . '&id=' . $index['id'], true),
                             'totals'       => $totals,
                         );
                     }
                } catch(Throwable $e) {
                    if (!is_array($e->getMessage())) {
                        if (isset(json_decode($e->getMessage(),true)['error'])) {
                            $this->error['warning'] = $this->language->get('error_warning');
                            $error_result = json_decode($e->getMessage(), true)['error'];

                            if (isset($error_result['type']) && !is_array($error_result['type']) && isset($error_result['reason']) && !is_array($error_result['reason'])) {
                                $this->error['error_warning_name'] = '<b>' . $error_result['type'] . ': </b>' . $error_result['reason'];
                            }
                        } else {
                            if (!isset($checkServerStatus['status']) || (isset($checkServerStatus['status']) && !$checkServerStatus['status'])) {
                                $this->error['warning'] = $this->language->get('error_server_stop');
                            }
                        }
                    }
                } catch (Exception $e) {
                    if (!is_array($e->getMessage())) {
                        if (isset(json_decode($e->getMessage(),true)['error'])) {
                            $this->error['warning'] = $this->language->get('error_warning');
                            $error_result = json_decode($e->getMessage(), true)['error'];

                            if (isset($error_result['type']) && !is_array($error_result['type']) && isset($error_result['reason']) && !is_array($error_result['reason'])) {
                                $this->error['error_warning_name'] = '<b>' . $error_result['type'] . ': </b>' . $error_result['reason'];
                            }
                        } else {
                            if (!isset($checkServerStatus['status']) || (isset($checkServerStatus['status']) && !$checkServerStatus['status'])) {
                                $this->error['warning'] = $this->language->get('error_server_stop');
                            }
                        }
                    }
                }
            }
        }

        $url = '';
        $data['sort_index_name'] = $this->url->link('es/esindex', 'token=' . $this->session->data['token'] . '&sort=dd.name' . $url, true);
        $data['sort_index_type'] = $this->url->link('es/esindex', 'token=' . $this->session->data['token'] . '&sort=dd.type' . $url, true);
        $data['sort_shards'] = $this->url->link('es/esindex', 'token=' . $this->session->data['token'] . '&sort=dd.shards' . $url, true);
        $data['sort_replica'] = $this->url->link('es/esindex', 'token=' . $this->session->data['token'] . '&sort=dd.replica' . $url, true);

        $url = '';
        $pagination = new Pagination();
    		$pagination->total = $total_indecies;
    		$pagination->page = $page;
    		$pagination->limit = $this->config->get('config_limit_admin');
    		$pagination->url = $this->url->link('es/esindex', 'token=' . $this->session->data['token'] . $url . '&page={page}', true);

    		$data['pagination'] = $pagination->render();

    		$data['results'] = sprintf($this->language->get('text_pagination'), ($total_indecies) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($total_indecies - $this->config->get('config_limit_admin'))) ? $total_indecies : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $total_indecies, ceil($total_indecies / $this->config->get('config_limit_admin')));

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if (isset($this->session->data['success'])) {
            $data['success'] = $this->session->data['success'];
            unset($this->session->data['success']);
        } else {
            $data['success'] = '';
        }

        if (isset($this->session->data['error'])) {
            $data['error_warning'] = $this->session->data['error'];
            unset($this->session->data['error']);
        }

        $data['token']  = $this->session->data['token'];
        $data['add']    = $this->url->link('es/esindex/add', 'token=' . $this->session->data['token'] . $url, true);
        $data['delete'] = $this->url->link('es/esindex/delete', 'token=' . $this->session->data['token'] . $url, true);

        $data['sort'] = '';
		    $data['order'] = '';

        $data['header'] = $this->load->controller('common/header');
        $data['footer'] = $this->load->controller('common/footer');
        $data['column_left'] = $this->load->controller('common/column_left');
        $this->response->setOutput($this->load->view('es/esindex.tpl', $data));

    }

    public function add() {
        $data = array();
        $data = array_merge($data, $this->load->language('es/esindex'));
        $this->document->setTitle($this->language->get('text_add'));

        if ($this->request->server['REQUEST_METHOD'] == 'POST' && $this->validateForm()) {
            if ($this->createIndex()) {
                $this->load->model('es/es');
                $data = $this->request->post;
                $this->load->library('webkul/es/es');
                $exception = false;
                try {
                    $status = $this->es->index->get($data['index_prefix'] . $data['name']);
                    $data['es_uuid'] = $status->response[$data['index_prefix'] . $data['name']]['settings']['index']['uuid'];
                    $this->model_es_es->addIndex($data);
                } catch (Throwable $e) {
                    $exception = true;
                    echo $e->getMessage();
                } catch (Exception $e) {
                    $exception = true;
                    echo $e->getMessage();
                }
                $this->session->data['success'] = $this->language->get('success_index_add');
                $this->response->redirect($this->url->link('es/esindex', 'token=' . $this->session->data['token'], true));
            }
        }
        $this->getForm($data);
    }

    public function edit() {
        $data = array();
        $data = array_merge($data, $this->load->language('es/esindex'));
        $this->document->setTitle($this->language->get('text_update'));

        if ($this->request->server['REQUEST_METHOD'] == 'POST' && $this->validateForm()) {
            if ($this->updateIndex()) {
                $this->load->model('es/es');
                $data = $this->request->post;
                $this->model_es_es->editIndex($data);
                $this->session->data['success'] = $this->language->get('success_index_edit');
                $this->response->redirect($this->url->link('es/esindex', 'token=' . $this->session->data['token'], true));
            }
        }

        $this->getForm($data);
    }

    public function getForm($data) {
        $data['breadcrumbs'] = array();
        $url = '';
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('es/esindex', 'token=' . $this->session->data['token'] . $url, true)
        );

        $index = array();
        if (isset($this->request->get['id'])) {
            $data['id'] = $this->request->get['id'];
            $data['text_heading'] = $this->language->get('text_update');
            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('text_update'),
                'href' => $this->url->link('es/esindex/edit', 'token=' . $this->session->data['token'] . '&id=' . $this->request->get['id'], true)
            );
            $data['action'] = $this->url->link('es/esindex/edit', 'token=' . $this->session->data['token'] . '&id=' . $this->request->get['id'], true);
            $this->load->model('es/es');
            $index = $this->model_es_es->getIndex($this->request->get['id']);
            if (empty($index)) {
              $this->response->redirect($this->url->link('es/esindex/add', 'token=' . $this->session->data['token'], true));
            }
        } else {
            $data['text_heading'] = $this->language->get('text_add');
            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('text_add'),
                'href' => $this->url->link('es/esindex/add', 'token=' . $this->session->data['token'] . $url, true)
            );
            $data['action'] = $this->url->link('es/esindex/add', 'token=' . $this->session->data['token'], true);
        }

        if ($index) {
            $data = array_merge($data, $index);
        }

        if (isset($index['index_prefix']) && $index['index_prefix']) {
            $data['index_prefix'] = $index['index_prefix'];
        } else if ($this->config->get('wk_elastic_index_prefix') && !isset($this->request->get['id'])) {
            $data['index_prefix'] = $this->config->get('wk_elastic_index_prefix');
        }

        if (isset($this->request->post['name'])) {
            $data['name'] = $this->request->post['name'];
        }

        if (isset($this->request->post['type'])) {
            $data['type'] = $this->request->post['type'];
        }

        if (isset($this->request->post['shards'])) {
            $data['shards'] = $this->request->post['shards'];
        }

        if (isset($this->request->post['replica'])) {
            $data['replica'] = $this->request->post['replica'];
        }

        if (isset($this->request->post['status'])) {
            $data['status'] = $this->request->post['status'];
        }

        if (isset($this->error['warning'])) {
            $warning_string = '';
            if (is_array($this->error['warning']) && isset($this->error['warning']['root_cause'])) {
                foreach ($this->error['warning']['root_cause'] as $key => $error_detail) {
                    if (isset($error_detail['type']) && isset($error_detail['reason'])) {
                        $warning_string .= '<b>' . $error_detail['type'] . ': </b>' . $error_detail['reason'] . '</br>';
                    }
                }
                $data['warning']   = $warning_string;
            } else if (!is_array($this->error['warning'])) {
                $data['warning']   = $this->error['warning'];
            }
        } else {
            $this->error['warning'] = '';
        }

        $error_index = array(
          'error_warning_type',
          'error_warning_shards',
          'error_warning_replica',
          'error_warning_name',
        );

        foreach ($error_index as $error_key) {
            if (isset($this->error[$error_key])) {
                $data[$error_key] = $this->error[$error_key];
            }
        }

        $data['back'] = $this->url->link('es/esindex', 'token=' . $this->session->data['token'], true);

        $data['types'] = array(
            $data['text_catalog'] => array(
                'product'       => $data['text_product'],
                'category'      => $data['text_category'],
                'manufacturer'  => $data['text_manufacturer'],
                'information'   => $data['text_information'],
            )
        );

        $this->load->model('localisation/language');
        $data['languages'] = $this->model_localisation_language->getLanguages();

        $data['header'] = $this->load->controller('common/header');
        $data['footer'] = $this->load->controller('common/footer');
        $data['column_left'] = $this->load->controller('common/column_left');

        $this->response->setOutput($this->load->view('es/esindex_form.tpl', $data));
    }

    public function delete() {
        $this->language->load('es/es_index');
        if ($this->request->server['REQUEST_METHOD'] == 'POST' && $this->valdateDelete()) {
            if (isset($this->request->post['selected']) && $this->request->post['selected']) {
                $this->load->model('es/es');
                foreach ($this->request->post['selected'] as $key => $value) {
                    $this->model_es_es->deleteIndex($value);
                }
                $this->session->data['success'] = $this->language->get('success_index_delete');
            } else {
                $this->session->data['error'] = $this->language->get('error_index_delete');
            }
        } else {
            $this->session->data['error'] = $this->language->get('error_general');
        }
        $this->response->redirect($this->url->link('es/esindex', 'token=' . $this->session->data['token'], true));
    }

    public function valdateDelete() {
        $this->load->language('es/esindex');
        if (!$this->user->hasPermission('modify', 'es/esindex')) {
			       $this->error['warning'] = $this->language->get('error_permission');
        }
        return !$this->error;
    }

    public function validateForm() {
        $this->load->language('es/esindex');
        $this->load->model('es/es');
        if (!$this->user->hasPermission('modify', 'es/esindex')) {
			       $this->error['warning'] = $this->language->get('error_permission');
        }

        $post_data = $this->request->post;

        if (strlen($post_data['name']) < 3 || strlen($post_data['name']) > 100) {
            $this->error['error_warning_name'] = $this->language->get('error_name');
        } else if (!$post_data['id']) {
            $result = $this->model_es_es->getIndexByNameType($post_data['index_prefix'] . $post_data['name'], $post_data['type']);

            if ($result) {
                $this->error['warning']             = $this->language->get('error_same_value');
                $this->error['error_warning_name']  = $this->language->get('error_name_unique');
                $this->error['error_warning_type']  = $this->language->get('error_type_unique');
            }
        }

        if ($post_data['type'] == '') {
            $this->error['error_warning_type'] = $this->language->get('error_type');
        }

        if (!is_numeric($post_data['shards']) || ($post_data['shards'] < 0)) {
            $this->error['error_warning_shards'] = $this->language->get('error_shards');
        }

        if (!is_numeric($post_data['replica']) || ($post_data['replica'] < 0)) {
            $this->error['error_warning_replica'] = $this->language->get('error_replica');
        }

        if (!empty($this->error) && !isset($this->error['warning'])) {
          $this->error['warning'] = $this->language->get('error_warning');
        }
        return !$this->error;
    }

    public function getSettings($data) {
        switch ($data['type']) {
            case 'product':
                return $this->getProductIndexSetting($data);
            case 'category':
                return $this->getCategoryIndexSetting($data);
            case 'manufacturer':
                return $this->getManufacturerIndexSetting($data);
            case 'information':
                return $this->getInformationIndexSetting($data);
        }
    }

    public function createIndex() {
        $this->load->library('webkul/es/es');
        $this->load->language('es/esindex');

        try {
            $data   = $this->request->post;
            $data   = array_merge($data, $this->getSettings($data));

            $index  = $this->es->index->create($data);
            if ($index->response && isset($this->response['acknowledged']) && !$this->response['acknowledged']) {
                $this->error['warning'] = $this->language->get('error_general');
            }
        } catch(Throwable $e) {
            if (!is_array($e->getMessage())) {
                if (isset(json_decode($e->getMessage(),true)['error'])) {
                    $error_result = json_decode($e->getMessage(), true)['error'];

                    if (isset($error_result['type']) && !is_array($error_result['type']) && isset($error_result['reason']) && !is_array($error_result['reason'])) {
                        $this->error['warning'] = '<b>' . $error_result['type'] . ': </b>' . $error_result['reason'];
                    } else {
                      $this->error['warning'] = $this->language->get('error_warning');
                    }
                } else {
                  $getServerStatus = $this->es->esserver->checkStatus();
                  if (!isset($getServerStatus['status']) || (isset($getServerStatus['status']) && !$getServerStatus['status'])) {
                      $this->error['warning'] = $this->language->get('error_server_stop');
                  }
                }
            }
        } catch (Exception $e) {
            if (!is_array($e->getMessage())) {
                if (isset(json_decode($e->getMessage(),true)['error'])) {
                    $error_result = json_decode($e->getMessage(), true)['error'];

                    if (isset($error_result['type']) && !is_array($error_result['type']) && isset($error_result['reason']) && !is_array($error_result['reason'])) {
                        $this->error['warning'] = '<b>' . $error_result['type'] . ': </b>' . $error_result['reason'];
                    } else {
                      $this->error['warning']   = $this->language->get('error_warning');
                    }
                } else {
                  $getServerStatus = $this->es->esserver->checkStatus();
                  if (!isset($getServerStatus['status']) || (isset($getServerStatus['status']) && !$getServerStatus['status'])) {
                      $this->error['warning'] = $this->language->get('error_server_stop');
                  }
                }
            }
        }
        return !$this->error;
    }

    public function updateIndex() {
        $this->load->library('webkul/es/es');
        $data = $this->request->post;
        $data = array_merge($data, $this->getSettings($data));
        unset($data['setting']['number_of_shards']);
        try {
            $status = $this->es->index->update($data);
        } catch (Throwable $e) {
            $this->error['warning'] = json_decode($e->getMessage(), true)['error'];
        } catch (Exception $e) {
            $this->error['warning'] = json_decode($e->getMessage(), true)['error'];
        }
        return !$this->error;
    }

    public function deleteIndex() {
        $this->load->library('webkul/es/es');
        $this->load->language('es/esindex');
        $this->load->model('es/es');
        try {
            $index = $this->es->index->delete($this->request->post['name']);
            $result = $this->model_es_es->deleteIndex($this->request->post['id']);
            if ($index->response && isset($this->response['acknowledged']) && !$this->response['acknowledged']) {
                $this->error['warning'] = $this->language->get('error_general');
            }
        } catch(Throwable $e) {
            if (!is_array($e->getMessage()) && isset(json_decode($e->getMessage(),true)['error'])) {
                $this->error['warning'] = $this->language->get('error_warning');
                $this->error['error_warning_name'] = json_decode($e->getMessage(), true)['error'];
            }
        } catch (Exception $e) {
            if (!is_array($e->getMessage()) && isset(json_decode($e->getMessage(),true)['error'])) {
                $this->error['warning'] = $this->language->get('error_warning');
                $this->error['error_warning_name'] = json_decode($e->getMessage(), true)['error'];
            }
        }
        return !$this->error;
    }

    public function getProductIndexSetting($data) {
        $ignore_keywords = '';
        if ($this->config->get('wk_elastic_ignore_keyword')) {
            $ignore_keywords = str_replace(',','|', $this->config->get('wk_elastic_ignore_keyword'));
        }

        $synonyms = '';
        if ($this->config->get('wk_elastic_synonym_keyword')) {
            foreach ($this->config->get('wk_elastic_synonym_keyword') as $key => $value) {
                $synonyms[] = trim($value['synonym'],',') . ',' . $value['keyword'];
            }
        }

        $setting['setting'] = array(
            'number_of_shards'                  => $data['shards'],
            'number_of_replicas'                => $data['replica'],
            'index.mapping.total_fields.limit'  => 200000,
            'analysis' => [
                'analyzer' => [
                    'suggestion_index' => [
                            'type'          => 'custom',
                            'tokenizer'     => 'standard',
                            'filter'        => [
                                                'standard',
                                                'shingle',
                                               ]
                                          ]
                              ],
                'filter' => [
                    'shingle' => [
                        'type'              => 'shingle',
                        'min_shingle_size'  => 2,
                        'max_shingle_size'  => 3,
                                 ]
                            ]
                          ]
        );

        $setting['mappings'] = array(
            'product' => [
                'properties' => [
                    'product_id' => [
                        'type' => 'integer',
                    ],
                    'model_autocomplete' => [
                        'type' => 'completion',
                    ],
                    'price' => [
                        'type' => 'double',
                    ],
                    'special' => [
                        'type' => 'double',
                    ],
                    'tax_class_id' => [
                        'type' => 'integer',
                    ],
                    'minimum' => [
                        'type' => 'integer',
                    ],
                    'quantity' => [
                        'type' => 'integer',
                    ],
                    'status' => [
                        'type' => 'integer',
                    ],
                    'rating' => [
                        'type' => 'float',
                    ],
                    'menufacturer' => [
                        'properties'  => [
                            'menufacturer_id' => [
                                'type' => 'integer',
                            ],
                            'name'     => [
                                'type' => 'completion',
                            ]
                        ]
                    ]
                ]
            ]
        );

        $this->load->model('localisation/language');
        $languages = $this->model_localisation_language->getLanguages();
        foreach ($languages as $key => $language) {
            $setting['mappings']['product']['properties'][$language['name'] . '_name_autocomplete'] = array(
                'type' => 'completion',
            );
            $setting['mappings']['product']['properties'][$language['name'] . '_name_suggest'] = array(
                  'type'              => 'text',
                  'analyzer'          => 'suggestion_index',
                  'search_analyzer'   => 'standard',
                  'fielddata'         => true
            );
            $setting['mappings']['product']['properties'][$language['name'] . '_product_tags'] = array(
                  'type'              => 'text',
                  'analyzer'          => 'suggestion_index',
                  'search_analyzer'   => 'standard',
                  'fielddata'         => true
            );
        }
        return $setting;
    }

    public function getCategoryIndexSetting($data) {
        $this->load->model('localisation/language');
        $languages = $this->model_localisation_language->getLanguages();

        $ignore_keywords = '';
        if ($this->config->get('wk_elastic_ignore_keyword')) {
            $ignore_keywords = str_replace(',','|', $this->config->get('wk_elastic_ignore_keyword'));
        }

        $setting['setting'] = array(
            'number_of_shards'    => $data['shards'],
            'number_of_replicas'  => $data['replica'],
        );

        $setting['mappings'] = array(
            'category' => [
                'properties' => [
                    'category_id' => [
                        'type' => 'integer',
                    ],
                    'status' => [
                        'type' => 'integer',
                    ],
                ],
            ],
        );

        return $setting;
    }

    public function getManufacturerIndexSetting($data) {
        $ignore_keywords = '';
        if ($this->config->get('wk_elastic_ignore_keyword')) {
            $ignore_keywords = str_replace(',','|', $this->config->get('wk_elastic_ignore_keyword'));
        }

        $setting['setting'] = array(
            'number_of_shards'    => $data['shards'],
            'number_of_replicas'  => $data['replica'],
        );

        $setting['mappings'] = array(
            'manufacturer' => [
                'properties' => [
                    'manufacturer_id' => [
                        'type' => 'integer',
                    ],
                    'manufacturer_name' => [
                        'type' => 'completion',
                    ],
                    'sort_order' => [
                        'type' => 'integer',
                    ],
                ],
            ],
        );

        return $setting;
    }

    public function getInformationIndexSetting($data) {
        $this->load->model('localisation/language');
        $languages = $this->model_localisation_language->getLanguages();
        $ignore_keywords = '';
        if ($this->config->get('wk_elastic_ignore_keyword')) {
            $ignore_keywords = str_replace(',','|', $this->config->get('wk_elastic_ignore_keyword'));
        }

        $setting['setting'] = array(
            'number_of_shards'    => $data['shards'],
            'number_of_replicas'  => $data['replica'],
        );

        $setting['mappings'] = array(
            'information' => [
                'properties' => [
                    'information_id' => [
                        'type' => 'integer',
                    ],
                    'status' => [
                        'type' => 'integer',
                    ],
                    'sort_order' => [
                        'type' => 'integer',
                    ],
                ],
            ],
        );

        return $setting;
    }

    public function reIndex() {
        $json = array();
        $post_data = $this->request->post;

        if ($this->request->server['REQUEST_METHOD'] == 'POST') {
            $id     = $post_data['id'];
            $this->load->model('es/es');
            $es_index = $this->model_es_es->getIndex($id);

            $es_index['start']   = $post_data['start'];
            $es_index['page']    = $post_data['page'];
            $es_index['limit']   = $post_data['limit'];

            if ($es_index) {
                $json = $this->es_cron_index->reIndexProcess($es_index);
            }
        }
        $this->response->setOutput(json_encode($json));
    }
}
?>
