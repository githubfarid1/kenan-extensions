<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

define('VERSION', '2.3.0.2');

require 'admin/config.php';

require_once(DIR_SYSTEM . 'startup.php');

$registry = new Registry();

/**
 * @version [1.0.0.0] [Supported opencart version 2.3.x.x.]
 * @category Webkul
 * @package Opencart-Webkul-ElasticSearch
 * @author [Webkul] <[<http://webkul.com/>]>
 * @copyright Copyright (c) 2010-2017 Webkul Software Private Limited (https://webkul.com)
 * @license https://store.webkul.com/license.html
 */
class CronIndex {

    public function __construct($registry) {
      $this->loader = new Loader($registry);
      $registry->set('load', $this->loader);
      $this->event = new Event($registry);
      $registry->set('event', $this->event);
      $this->config = new Config();
      $registry->set('config', $this->config);
      $this->cache = new Cache('file', 3600);
      $registry->set('cache', $this->cache);
      $language = new Language();
      $registry->set('language', $language);
      $this->request = new Request();
      $registry->set('request', $this->request);
      $this->db = new DB(DB_DRIVER, DB_HOSTNAME, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
      $registry->set('db', $this->db);
    }

    public function storeConfig(){
      $this->config->set('config_store_id', 0);
      $this->config->set('config_url', HTTP_SERVER);
      $this->config->set('config_ssl', HTTPS_SERVER);
    }

    public function setDefaultConfigurations() {
      if (isset($_SERVER['HTTPS']) && (($_SERVER['HTTPS'] == 'on') || ($_SERVER['HTTPS'] == '1'))) {
      	$store_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "store WHERE REPLACE(`ssl`, 'www.', '') = '" . $this->db->escape('https://' . str_replace('www.', '', $_SERVER['HTTP_HOST']) . rtrim(dirname($_SERVER['PHP_SELF']), '/.\\') . '/') . "'");
      } else {
      	$store_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "store WHERE REPLACE(`url`, 'www.', '') = '" . $this->db->escape('http://' . str_replace('www.', '', $_SERVER['HTTP_HOST']) . rtrim(dirname($_SERVER['PHP_SELF']), '/.\\') . '/') . "'");
      }
      $store_query->num_rows ? $this->config->set('config_store_id', $store_query->row['store_id']) : $this->storeConfig();

      return true;
    }

    public function setConfigKeys() {
      $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "setting` WHERE store_id = '0' OR store_id = '" . (int)$this->config->get('config_store_id') . "' ORDER BY store_id ASC");

      foreach ($query->rows as $result) {
        !$result['serialized'] ? $this->config->set($result['key'], $result['value']) :$this->config->set($result['key'], json_decode($result['value'], true));
      }
      return true;
    }

}

$cronindex = new CronIndex($registry);

$cronindex->setDefaultConfigurations();

$cronindex->setConfigKeys();

$escronindex = new EsCronIndex($registry);

$escronindex->runIndexShcedule();

?>
