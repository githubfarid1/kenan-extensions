<?php

class ModelSettingEs extends Model {

    public function getLanguageName($code) {
        $result = $this->db->query("SELECT name FROM ".DB_PREFIX."language WHERE code = '".$this->db->escape($code)."' ")->row;
        if($result) {
            return $result['name'];
        } else {
            return false;
        }
    }

    public function getIndexName($type) {
        $result = $this->db->query("SELECT * FROM ".DB_PREFIX."es_index WHERE type = '".$this->db->escape($type)."' ")->row;
        if(!empty($result) && isset($result['index_prefix'])) {
            return $result['index_prefix'].$result['name'];
        } else {
            return false;
        }
    }
}
?>
