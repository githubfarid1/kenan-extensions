<?php

class ControllerCommonEssearch extends Controller {

    public function index() {
        $this->load->language('common/search');

        $data['text_search'] = $this->language->get('text_search');

        if (isset($this->request->get['search'])) {
            $data['search'] = $this->request->get['search'];
        } else {
            $data['search'] = '';
        }

        $data['wk_elastic_search_box_detail']       = $this->config->get('wk_elastic_search_box_detail');
        $data['wk_elastic_text_box_placeholder']    = $this->config->get('wk_elastic_text_box_placeholder');
        $data['wk_elastic_minimum_character']       = $this->config->get('wk_elastic_minimum_character');
        $data['wk_elastic_single_result_redirect']  = $this->config->get('wk_elastic_single_result_redirect');

        if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/common/essearch.tpl')) {
          return $this->load->view($this->config->get('config_template') . '/template/common/essearch.tpl', $data);
        } else {
          return $this->load->view('default/template/common/essearch.tpl', $data);
        }
    }

    public function search() {
        $json =  $json['suggestions'] = array();
        $this->load->library('webkul/es/es');
        $this->load->model('setting/es');
        $language_name    = $this->model_setting_es->getLanguageName($this->session->data['language']);
        $data = array();

        if(is_array($this->config->get('wk_elastic_search_in')) && in_array('product', $this->config->get('wk_elastic_search_in'))) {
            $args = array();
            $field_name = 'name';
            if($language_name) {
                $field_name .= '.'.$language_name;
            }
            $args['keyword']          = $this->request->get['search'];
            $args['field']            = $field_name;
            $args['suggestionfield']  = $language_name.'_name_autocomplete';
            $args['type']             = 'product';
            $args['name']             = $this->model_setting_es->getIndexName($args['type']);
            $args['fields']           = array();

            if($this->config->get('wk_elastic_search_in_for_product')) {
    					$product_fields         = array();
    					foreach ($this->config->get('wk_elastic_search_in_for_product') as $key => $wk_elastic_search_in_for_product) {
      						if($wk_elastic_search_in_for_product == 'model' || $wk_elastic_search_in_for_product == 'manufacturer.name') {
      							 $product_fields[]= $wk_elastic_search_in_for_product;
      						} else {
      							 $product_fields[]= $wk_elastic_search_in_for_product.$language_name;
      						}
    					}
    					$args['fields']         = array_merge($product_fields, $args['fields']);
            }

            $args['source']['include'] = [ 'product_id', 'model', 'price', 'special', 'rating', 'minimum', 'tax_class_id', 'name','description', 'meta_tag_description', 'image', 'categories' ];
            $args['source']['exclude'] = $result = array();

            if(isset($args['name']) && $args['name']) {
                $result = $this->es->search->getData($args);

                if($result['suggestions']) {
                    foreach ($result['suggestions'] as $key => $suggestion) {
                        $json['suggestions'][] = array(
                          'item_id'     => $suggestion['_source']['product_id'],
                          'item_url'    => $this->url->link('product/product', 'product_id=' . $suggestion['_source']['product_id'], true),
                          'item_name'   => $suggestion['_source']['name'][$language_name],
                        );
                    }
                    $json['success'] = true;
                }
            }

            if(isset($result['success']) && $result['success']) {
                if(isset($result['items']) && $result['items']) {
                    $json['data']['products'] = array();
                    $json['items'] = array();
                    $this->load->model('tool/image');
                    $json['total'] = $result['total'];
                    foreach ($result['items'] as $key => $value) {
                        if($value['_source']['image'] && file_exists(DIR_IMAGE.$value['_source']['image'])) {
                            $image = $this->model_tool_image->resize($value['_source']['image'], 100, 100);
                        } else {
                            $image = $this->model_tool_image->resize('no_image.png', 100, 100);
                        }
                        $json['data']['products'][] = array(
                            'index'       => $key,
                            'score'       => $value['_score'],
                            'product_id'  => $value['_source']['product_id'],
                            'rating'      => $value['_source']['rating'],
                            'product_url' => $this->url->link('product/product', 'product_id=' . $value['_source']['product_id'], true),
                            'model'       => $value['_source']['model'],
                            'price'       => $this->currency->format($value['_source']['price'], $this->session->data['currency']),
                            'name'        => $value['_source']['name'][$language_name],
                            'description' => '',
                            'meta_description' => $value['_source']['meta_tag_description'][$language_name],
                            'image'       => $image,
                        );

                        if(!in_array('category', $this->config->get('wk_elastic_search_in'))) {
                            if(isset($value['_source']['categories']) && $value['_source']['categories']) {
                                foreach ($value['_source']['categories'] as $index => $category) {
                                    $json['data']['categories'][$index] = array(
                                        'category_id'   => $index,
                                        'category_url'  => $this->url->link('product/category', 'path=' . $index, true),
                                        'name'          => $category[$language_name]['name'],
                                    );
                                }
                            }
                        }
                        if($key == 9) {
                            break;
                        }
                    }
                    $json['success'] = true;
                }
            } else {
                $json = $result;
            }
        }

        if(is_array($this->config->get('wk_elastic_search_in')) && in_array('category', $this->config->get('wk_elastic_search_in'))) {
            $args = array();
            $args['keyword']  = $this->request->get['search'];
            $args['field']    = 'name';
            $args['fields']   = array('name');
            $args['type']     = 'category';
            $args['name']     = $this->model_setting_es->getIndexName($args['type']);
            $args['source']['include'] = [ 'category_id', 'name', 'parent_id' ];
            $args['source']['exclude'] = array();
            $result = array();
            if(isset($args['name']) && $args['name']) {
                $result = $this->es->search->getData($args);
            }

            if(isset($result['success']) && $result['success']) {
                if(isset($result['items']) && $result['items']) {
                    $json['items']    = array();
                    $this->load->model('tool/image');
                    foreach ($result['items'] as $key => $value) {
                        $cats = explode('>', html_entity_decode($value['_source']['name']));
                        if(isset($json['data']['categories']) && array_key_exists($value['_source']['category_id'], $json['data']['categories'])) {
                            continue;
                        }
                        if(count($cats) == 1) {
                          $json['data']['categories'][$value['_source']['category_id']] = array(
                            'category_id'   => $value['_source']['category_id'],
                            'category_url'  => $this->url->link('product/category', 'path=' . $value['_source']['category_id'], true),
                            'name'          => $value['_source']['name'],
                            'parent'        => $value['_source']['parent_id'],
                          );
                        } else {
                          if(isset($json['data']['categories']) && !in_array(trim($value['_source']['category_id']), $json['data']['categories'])) {
                            $json['data']['categories'][$value['_source']['category_id']] = array(
                              'category_id'   => $value['_source']['category_id'],
                              'category_url'  => $this->url->link('product/category', 'path=' . $value['_source']['parent_id'].'_'.$value['_source']['category_id'] , true),
                              'name'          => trim($cats[1]),
                              'c_name'        => $value['_source']['name'],
                              'parent'        => $value['_source']['parent_id'],
                            );
                          }
                          if(isset($json['data']['categories']) && !in_array(trim($value['_source']['parent_id']), $json['data']['categories'])) {
                            $json['data']['categories'][$value['_source']['parent_id']] = array(
                              'category_id'   => $value['_source']['parent_id'],
                              'category_url'  => $this->url->link('product/category', 'path=' . $value['_source']['parent_id'], true),
                              'name'          => trim($cats[0]),
                              'parent'        => $value['_source']['parent_id'],
                            );
                          }
                        }
                    }
                }
                $json['success'] = true;
            }
        }

        if (is_array($this->config->get('wk_elastic_search_in')) && in_array('manufacturer', $this->config->get('wk_elastic_search_in'))) {
            $args = array();
            $args['keyword']          = $this->request->get['search'];
            $args['field']            = 'name';
            $args['suggestionfield']  = 'manufacturer_name';
            $args['fields']           = array('name');
            $args['type']             = 'manufacturer';
            $args['name']             = $this->model_setting_es->getIndexName($args['type']);
            $args['source']['include']= [ 'manufacturer_id', 'manufacturer_name', 'name' ];
            $args['source']['exclude']= array();
            $result = array();

            if(isset($args['name']) && $args['name']) {
                $result = $this->es->search->getData($args);

                if($result['suggestions']) {
                    foreach ($result['suggestions'] as $key => $suggestion) {
                        $json['suggestions'][] = array(
                          'item_id'  => $suggestion['_source']['manufacturer_id'],
                          'item_url' => $this->url->link('product/manufacturer/info', 'manufacturer_id=' . $suggestion['_source']['manufacturer_id'], true),
                          'item_name'=> $suggestion['_source']['name'],
                        );
                    }
                    $json['success'] = true;
                }
            }

            if(isset($result['success']) && $result['success']) {
                if(isset($result['items']) && $result['items']) {
                    $json['items'] = array();
                    $this->load->model('tool/image');
                    foreach ($result['items'] as $key => $value) {
                        $json['data']['manufacturers'][$value['_source']['manufacturer_id']] = array(
                            'manufacturer_id'     => $value['_source']['manufacturer_id'],
                            'manufacturer_url'    => $this->url->link('product/manufacturer/info', 'manufacturer_id=' . $value['_source']['manufacturer_id'], true),
                            'name'                => $value['_source']['name'],
                        );
                    }
                }
                $json['success'] = true;
            }
        }

        if (is_array($this->config->get('wk_elastic_search_in')) && in_array('information', $this->config->get('wk_elastic_search_in'))) {
            $args = array();
            $field_name = 'name';
            if($language_name) {
                $field_name .= '.'.$language_name;
            }
            $args['keyword']  = $this->request->get['search'];
            $args['field']    = $field_name;
            // $args['suggestionfield']  = $language_name.'_name_autocomplete';
            $args['type']     = 'information';
            $args['name']     = $this->model_setting_es->getIndexName($args['type']);
            $args['fields']   = array();

            if($this->config->get('wk_elastic_search_in_for_information')) {
    					$product_fields         = array();
    					foreach ($this->config->get('wk_elastic_search_in_for_information') as $key => $wk_elastic_search_in_for_information) {
      						$product_fields[]= $wk_elastic_search_in_for_information.$language_name;
    					}
    					$args['fields']         = array_merge($product_fields, $args['fields']);
            }

            $args['source']['include'] = [ 'information_id', 'name', 'title', 'meta_title', 'meta_keyword' ];
            $args['source']['exclude'] = array();
            $result = array();

            if(isset($args['name']) && $args['name']) {
                $result = $this->es->search->getData($args);
            }

            if(isset($result['success']) && $result['success']) {
                if(isset($result['items']) && $result['items']) {
                    $json['items'] = array();
                    foreach ($result['items'] as $key => $value) {
                        $json['data']['informations'][$value['_source']['information_id']] = array(
                            'information_id'     => $value['_source']['information_id'],
                            'information_url'    => $this->url->link('information/information', 'information_id=' . $value['_source']['information_id'], true),
                            'name'                => $value['_source']['name'][$language_name],
                        );
                    }
                }
                $json['success'] = true;
            }
        }
        $this->response->setOutput(json_encode($json));
    }

    public function didYouMean($suggest_result = '')
    {
        $result = array();
        $get_data = $this->request->get;
        if ($suggest_result) {
            if (isset($get_data['search']) && ($suggest_result !== $get_data['search'])) {
                $result['search_instead'] = $this->language->get('test_search_instead') ? sprintf($this->language->get('test_search_instead'), $get_data['search']) : 'Search instead for: <i>'.$get_data['search'].'</i>';
                $result['heading_title'] = $this->language->get('heading_title') .  ' - ' . $suggest_result;
            }
            if (isset($get_data['tag']) && ($suggest_result !== $get_data['tag'])) {
                $result['search_instead'] = $this->language->get('test_tags_instead') ? sprintf($this->language->get('test_tags_instead'), $get_data['tag']) : 'Tags instead for: <i>'.$get_data['tag'].'</i>';
                $result['heading_title']  = $this->language->get('test_tags_search') .  ' - ' . $suggest_result;
            }
        }
        return $result;
    }

    public function searchSortOrders($url = '')
    {
        $sort_data = array();

        $sort_data[] = array(
          'text'  => $this->language->get('text_default'),
          'value' => 'sort_order-ASC',
          'href'  => $this->url->link('product/search', 'sort=sort_order&order=ASC' . $url)
        );

        $sort_data[] = array(
          'text'  => $this->language->get('text_price_asc'),
          'value' => 'price-ASC',
          'href'  => $this->url->link('product/search', 'sort=price&order=ASC' . $url)
        );

        $sort_data[] = array(
          'text'  => $this->language->get('text_price_desc'),
          'value' => 'price-DESC',
          'href'  => $this->url->link('product/search', 'sort=price&order=DESC' . $url)
        );

        if ($this->config->get('config_review_status')) {
            $sort_data[] = array(
              'text'  => $this->language->get('text_rating_desc'),
              'value' => 'rating-DESC',
              'href'  => $this->url->link('product/search', 'sort=rating&order=DESC' . $url)
            );
            $sort_data[] = array(
              'text'  => $this->language->get('text_rating_asc'),
              'value' => 'rating-ASC',
              'href'  => $this->url->link('product/search', 'sort=rating&order=ASC' . $url)
            );
        }
        return $sort_data;
    }

    public function getEsData($filter_data = array()) {
        $args['keyword'] = $filter_data['filter_name'];

        if (!$filter_data['filter_name'] && $filter_data['filter_tag']) {
          $args['keyword'] = $filter_data['filter_tag'];
        }

        if($filter_data['sort'] == 'sort_order') {
          $args['sort'] = '_score';
          $args['order'] = 'desc';
        }

        $json = array();
        if($args['keyword']) {
          $this->load->library('webkul/es/es');
          $this->load->model('setting/es');

          $language_name = $this->model_setting_es->getLanguageName($this->session->data['language']);

          $data = $json['data']['categories'] = array();

          if(is_array($this->config->get('wk_elastic_search_in')) && in_array('product', $this->config->get('wk_elastic_search_in'))) {
              $field_name = 'name';
              if($language_name) {
                  $field_name .= '.'.$language_name;
              }
              $args['field'] = $field_name;

              $args['suggestionfield']  = $language_name.'_name_autocomplete';

              if ($filter_data['filter_name']) {
                $args['name_suggestion']  = $language_name.'_name_suggest';
              }

              if ($filter_data['filter_tag'] && !$filter_data['filter_name']) {
                  $args['tag_suggestion']  	= $language_name.'_product_tags';
              }

              $args['type'] 						= 'product';
              $args['name'] 						= $this->model_setting_es->getIndexName($args['type']);
              $args['fields'] 					= array();

              if($this->config->get('wk_elastic_search_in_for_product')) {
                  $product_fields = array();
                  foreach ($this->config->get('wk_elastic_search_in_for_product') as $key => $wk_elastic_search_in_for_product) {
                      if($wk_elastic_search_in_for_product == 'model' || $wk_elastic_search_in_for_product == 'manufacturer.name') {
                          $product_fields[] = $wk_elastic_search_in_for_product;
                      } else {
                          $product_fields[] = $wk_elastic_search_in_for_product.$language_name;
                      }
                  }
                  $args['fields'] = array_merge($product_fields, $args['fields']);
              }

              $args['source']['include'] = [ 'product_id', 'model', 'price', 'special', 'rating', 'minimum', 'tax_class_id', 'name','description', 'meta_tag_description', 'product_tags', 'image', 'categories' ];

              $args['source']['exclude'] = array();

              $args['start'] = $filter_data['start'];
              $args['limit'] = $filter_data['limit'];

              $result = array();
              if(isset($args['name']) && $args['name']) {
                $result = $this->es->search->getData($args);
              }

              if(isset($result['success']) && $result['success']) {
                  $product_return_array = array();

                  $json['data']['products'] 	= array();
                  $json['items'] 							= array();
                  if(isset($result['items']) && $result['items']) {
                      $this->load->model('tool/image');
                      $json['total'] = $result['total'];
                      $product_return_array = $result['items'];
                  }
                  if(isset($result['suggestions']) && $result['suggestions'] && empty($product_return_array)) {
                    $this->load->model('tool/image');
                    $json['total'] = 0;
                    foreach ($result['suggestions'] as $key => $product_detail) {
                      if (isset($product_detail['_id'])) {
                        $json['total'] += 1;
                        array_push($product_return_array, $product_detail);
                      }
                    }
                  }
                  if (!empty($product_return_array)) {
                    foreach ($product_return_array as $key => $value) {
                        if($value['_source']['image'] && file_exists(DIR_IMAGE.$value['_source']['image'])) {
                            $image = $this->model_tool_image->resize($value['_source']['image'], 100, 100);
                        } else {
                            $image = $this->model_tool_image->resize('no_image.png', 100, 100);
                        }
                        $json['data']['products'][] = array(
                          'index' 					=> $key,
                          'score' 					=> $value['_score'],
                          'product_id' 			=> $value['_source']['product_id'],
                          'product_url' 		=> $this->url->link('product/product', 'product_id=' . $value['_source']['product_id'], true),
                          'model' 					=> $value['_source']['model'],
                          'price' 					=> $value['_source']['price'],
                          'special' 				=> $value['_source']['special'],
                          'tax_class_id' 		=> $value['_source']['tax_class_id'],
                          'minimum' 				=> $value['_source']['minimum'],
                          'rating' 					=> $value['_source']['rating'],
                          'name' 						=> $value['_source']['name'][$language_name],
                          // 'description' 		=> '',
                          'description'     => utf8_substr(strip_tags(html_entity_decode($value['_source']['description'][$language_name], ENT_QUOTES, 'UTF-8')), 0, $this->config->get($this->config->get('config_theme') . '_product_description_length')) . '..',
                          'meta_description'=> $value['_source']['meta_tag_description'][$language_name],
                          'image_url' 			=> $image,
                          'image' 					=> $value['_source']['image'],
                        );
                        if(isset($value['_source']['categories']) && $value['_source']['categories']) {
                            foreach ($value['_source']['categories'] as $index => $category) {
                                $json['data']['categories'][$index] = array(
                                    'category_id' 	=> $index,
                                    'category_url' 	=> $this->url->link('product/category', 'path=' . $index, true),
                                    'name' 					=> $category[$language_name]['name'],
                                );
                            }
                        }
                    }
                    $json['success'] = true;
                  }
                  if (isset($result['suggestions']) ) {
                      foreach ($result['suggestions'] as $key => $value) {
                          if (!isset($value['_id']) && isset($value['text'])) {
                              $json['data']['suggestion'] = $value['text'];
                          }
                      }
                  }
              } else {
                $json['success'] = false;
              }
        }
    }
    return $json;
  }
}

?>
