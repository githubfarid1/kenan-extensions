<?php
$_['heading_title'] = 'SuperDruid - Premium DB Indexes v1.5';
$_['text_module'] = 'Extensions';
?>
