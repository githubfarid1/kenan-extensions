<?php
class ControllerExtensionAccountSerialkeys extends Controller {
	public function index() {
		if (!$this->customer->isLogged()) {
			$this->session->data['redirect'] = $this->url->link('extension/account/serial_keys', '', true);

			$this->response->redirect($this->url->link('account/login', '', true));
		}
         		
		$this->language->load('extension/account/serial_keys');

		$this->document->setTitle($this->language->get('heading_title'));

      	$data['breadcrumbs'] = array();

      	$data['breadcrumbs'][] = array(
        	'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home'),        	
        	'separator' => false
      	); 

      	$data['breadcrumbs'][] = array(
        	'text'      => $this->language->get('text_account'),
			'href'      => $this->url->link('account/account', '', true),
        	'separator' => $this->language->get('text_separator')
      	);
		
      	$data['breadcrumbs'][] = array(
        	'text'      => $this->language->get('text_serial_keys'),
			'href'      => $this->url->link('extension/account/serial_keys', '', true),
        	'separator' => $this->language->get('text_separator')
      	);
		
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}


		$this->load->model('extension/account/serial_keys');
		$serialkey_total = $this->model_extension_account_serial_keys->getTotalSerialkeys();
		$data['sct'] = $serialkey_total;
		$data['heading_title'] = $this->language->get('heading_title');
		$data['text_orderid'] = $this->language->get('text_orderid');
		$data['text_productname'] = $this->language->get('text_productname');
		$data['text_serialkey'] = $this->language->get('text_serialkey');
		$data['text_downloadlink'] = $this->language->get('text_downloadlink');
		$data['text_dateoforder'] = $this->language->get('text_dateoforder');

			$data['serialkeys'] = array();
			
			$results = $this->model_extension_account_serial_keys->getSerialkeys(0, 100);
			
			foreach ($results as $result) {

				$data['serialkeys'][] = array(
					'order_id'   => $result['order_id'],
					'date_added' => date($this->language->get('date_format_short'), strtotime($result['date_added'])),
					'productname'       => $result['productname'],
					'serialkey'       => $result['serialkey'],
					'downloadlink'       => $result['downloadlink']
				);

			}
		
		
		
		
			$pagination = new Pagination();
			$pagination->limit = $this->config->get('config_catalog_limit');
			$pagination->text = $this->language->get('text_pagination');
			$pagination->url = $this->url->link('extension/account/serial_keys', 'page={page}', true);
			 
			$data['pagination'] = $pagination->render();
			
			$data['continue'] = $this->url->link('account/account', '', true);
			
		
    	$data['button_continue'] = $this->language->get('button_continue');

		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');

		$this->response->setOutput($this->load->view('extension/account/serial_keys', $data));
  	}
	
	public function serialkey() {
		if (!$this->customer->isLogged()) {
			$this->session->data['redirect'] = $this->url->link('extension/account/serial_keys', '', true);

			$this->response->redirect($this->url->link('account/login', '', true));
		}
		$this->load->model('extension/account/serial_keys');
		
		if (isset($this->request->get['order_serialkey_id'])) {
			$order_serialkey_id = $this->request->get['order_serialkey_id'];
		} else {
			$order_serialkey_id = 0;
		}
	}
}
?>