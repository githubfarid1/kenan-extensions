<?php
// Heading
$_['heading_title']     = 'Specials Sales Report';

// Text
$_['text_list']         = 'Sales List';
$_['text_all_status']   = 'All Statuses';


// Entry
$_['entry_date_start']  = 'Date Start';
$_['entry_date_end']    = 'Date End';
$_['entry_products']       = 'Products';
$_['entry_status']      = 'Order Status';
$_['button_export']         = 'Export';
