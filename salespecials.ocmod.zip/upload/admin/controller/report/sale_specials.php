<?php
class ControllerReportSaleSpecials extends Controller {
	public function index() {
		$this->load->language('report/sale_specials');

		$this->document->setTitle($this->language->get('heading_title'));

		if (isset($this->request->get['filter_date_from'])) {
			$filter_date_from = $this->request->get['filter_date_from'];
		} else {
			$filter_date_from = date('Y-m-d', strtotime(date('Y') . '-' . date('m') . '-01'));
		}

		if (isset($this->request->get['filter_date_to'])) {
			$filter_date_to = $this->request->get['filter_date_to'];
		} else {
			$filter_date_to = date('Y-m-d');
		}

		if (isset($this->request->get['filter_products'])) {
			$filter_products = $this->request->get['filter_products'];
		} else {
			$filter_products = '';
		}

		if (isset($this->request->get['filter_order_status'])) {
			$filter_order_status = $this->request->get['filter_order_status'];
		} else {
		  $filter_order_status = '';				  
		}


		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('report/sale_specials', 'token=' . $this->session->data['token'], true)
		);

		$this->load->model('report/sale_specials');
        
     if (isset($this->request->get['action']) && $this->request->get['action'] == 'export') {
        $this->load->model('report/sale_specials');
		$filter_data = array(
			'filter_date_from'	     => $filter_date_from,
			'filter_date_to'	     => $filter_date_to,
			'filter_products'           => $filter_products,
			'filter_order_status' => $filter_order_status
		);

		$results = $this->model_report_sale_specials->getOrders($filter_data);
        $this->exportcsv($results);
        return;

       }

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_confirm'] = $this->language->get('text_confirm');
		$data['text_all_status'] = $this->language->get('text_all_status');


		$data['entry_date_start'] = $this->language->get('entry_date_start');
		$data['entry_date_end'] = $this->language->get('entry_date_end');
		$data['entry_products'] = $this->language->get('entry_products');
		$data['entry_status'] = $this->language->get('entry_status');

		$data['button_export'] = $this->language->get('button_export');

		$data['token'] = $this->session->data['token'];

		$this->load->model('localisation/order_status');

		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

		$this->load->model('catalog/product');
        
        $filter_data['sort'] = 'pd.name';
        $results = $this->model_catalog_product->getProducts($filter_data);
        
        $data['products'] = array();
        
		foreach ($results as $result) {

		 $data['products'][] = array(
			'text'  => $result['product_id'],
			'value' => $result['name'],
		);
       }


		$data['filter_date_from'] = $filter_date_from;
		$data['filter_date_to'] = $filter_date_to;
		$data['filter_products'] = $filter_products;
		$data['filter_order_status'] = $filter_order_status;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('report/sale_specials', $data));
	}
    
    protected function exportcsv($data) { 
		/* CSV Header Starts Here */
		 
		header("Content-Type: text/csv");
		header("Content-Disposition: attachment; filename=SaleSpecials-".date('d-m-Y').".txt");
		// Disable caching
		header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1
		header("Pragma: no-cache"); // HTTP 1.0
		header("Expires: 0"); // Proxies
		 
		/* CSV Header Ends Here */
		 
		$output = fopen("php://output", "w"); //Opens and clears the contents of file; or creates a new file if it doesn't exist		
		foreach($data as $row)
		{
		    fputcsv($output, $row, "\t"); // here you can change delimiter/enclosure
		}
		 
		fclose($output); // Closing the File

	}
}