<?php
class ModelReportSaleSpecials extends Model {
	
	public function getOrders($data = array()) {
        
        $sql = "SELECT distinct o.customer_id, GROUP_CONCAT(distinct op.name SEPARATOR ',') AS products, o.payment_company, o.payment_firstname, o.telephone, op.name, o.email, o.payment_zone, o.payment_country from `" . DB_PREFIX . "order_product` op left join `" . DB_PREFIX . "order` o on op.order_id = o.order_id ";

		
		if (!empty($data['filter_order_status'])) {
		   $sql .= " WHERE o.order_status_id = '" . (int)$data['filter_order_status'] . "'";
		} else {
			$sql .= " WHERE o.order_status_id > '0'";
		}

		if (!empty($data['filter_date_from'])) {
			$sql .= " AND DATE(o.date_added) >= DATE('" . $this->db->escape($data['filter_date_from']) . "')";
		}

		if (!empty($data['filter_date_to'])) {
			$sql .= " AND DATE(o.date_added) <= DATE('" . $this->db->escape($data['filter_date_to']) . "')";
		}
        
        if (!empty($data['filter_products'])) {
			$sql .= " AND op.product_id in (" . $this->db->escape($data['filter_products']) . ")";
		}


       $sql .= " group by o.customer_id ORDER BY o.payment_company";
		
      $query = $this->db->query($sql);
      
      $header =array(
      'company' => 'Client Company Name', 
      'firstname' => 'Client First Name',
      'email'=> 'Email',
      'phone' => 'Phone',
      'products' => 'Products',
  	  'payment_zone' => 'Payment Zone',
  	  'Payment_country' => 'Payment Country');
      $returndata[] = $header;
	  foreach ($query->rows as $row) {
	   $returndata[] = array(
                       'company' => $row['payment_company'],
                       'firstname' => $row['payment_firstname'],
                       'email' => $row['email'],
                       'phone' => $row['telephone'],
                       'products' => $row['products'],
                   	   'payment_zone' => $row['payment_zone'],
                   	   'Payment_country' => $row['payment_country']);
	  }
      return $returndata;
	}
}
