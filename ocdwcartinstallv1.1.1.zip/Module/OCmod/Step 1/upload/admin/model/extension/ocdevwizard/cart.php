<?php
##==========================================##
## @author    : OCdevWizard                 ##
## @contact   : ocdevwizard@gmail.com       ##
## @support   : http://help.ocdevwizard.com ##
## @copyright : (c) OCdevWizard. Cart, 2017 ##
##==========================================##
libxml_use_internal_errors(true);

class ModelExtensionOcdevwizardCart extends Model {
  private $_name = 'cart';
  private $_code = 'ocdw_cart';
  private $_version;

  public function __construct($registry) {
    parent::__construct($registry);

    if (file_exists(DIR_SYSTEM.'library/ocdevwizard/'.$this->_name) && is_dir(DIR_SYSTEM.'library/ocdevwizard/'.$this->_name)) {
      if (file_exists(DIR_SYSTEM.'library/ocdevwizard/'.$this->_name.'/module.ocdw')) {
        $version_array = json_decode(file_get_contents(DIR_SYSTEM.'library/ocdevwizard/'.$this->_name.'/module.ocdw'),true);

        if ($version_array) {
          $this->_version = $version_array['module'];
        }
      }
    }
  }

  public function createDBTables() {
    $sql = [];

    $sql[] = "CREATE TABLE IF NOT EXISTS `".DB_PREFIX."ocdevwizard_setting` ("
             ."`setting_id` int(11) NOT NULL AUTO_INCREMENT,"
             ."`store_id` int(11) NOT NULL DEFAULT '0',"
             ."`code` text NOT NULL,"
             ."`key` text NOT NULL,"
             ."`value` text NOT NULL,"
             ."`serialized` tinyint(1) NOT NULL,"
             ."PRIMARY KEY (`setting_id`)"
             .") ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci AUTO_INCREMENT=1;";

    $sql[] = "CREATE TABLE IF NOT EXISTS `".DB_PREFIX.$this->_code."_record` ("
             ."`record_id` int(11) NOT NULL AUTO_INCREMENT,"
             ."`customer_id` int(11) NOT NULL,"
             ."`field_data` text NOT NULL,"
             ."`email` text NOT NULL,"
             ."`token` text NOT NULL,"
             ."`access_key` varchar(40) COLLATE utf8_general_ci NOT NULL,"
             ."`salt` varchar(9) NOT NULL,"
             ."`currency_code` varchar(3) NOT NULL,"
             ."`currency_value` decimal(15,8) NOT NULL DEFAULT '1.00000000',"
             ."`ip` varchar(40) NOT NULL,"
             ."`referer` text NOT NULL,"
             ."`user_agent` varchar(255) NOT NULL,"
             ."`accept_language` varchar(255) NOT NULL,"
             ."`user_language_id` int(11) NOT NULL,"
             ."`user_currency_id` int(11) NOT NULL,"
             ."`user_customer_group_id` int(11) NOT NULL,"
             ."`store_name` text NOT NULL,"
             ."`store_url` text NOT NULL,"
             ."`store_id` int(11) NOT NULL DEFAULT '0',"
             ."`status` tinyint(1) NOT NULL DEFAULT '0',"
             ."`date_added` datetime NOT NULL,"
             ."`date_notified` datetime NOT NULL,"
             ."PRIMARY KEY (`record_id`) "
             .") ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci AUTO_INCREMENT=1;";

    $sql[] = "CREATE TABLE IF NOT EXISTS `".DB_PREFIX.$this->_code."_record_product` ("
             ."`record_product_id` int(11) NOT NULL AUTO_INCREMENT,"
             ."`record_id` int(11) NOT NULL,"
             ."`product_id` int(11) NOT NULL,"
             ."`quantity` int(5) NOT NULL,"
             ."`options` text NOT NULL,"
             ."PRIMARY KEY (`record_product_id`)"
             .") ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci AUTO_INCREMENT=1;";

    $sql[] = "CREATE TABLE IF NOT EXISTS `".DB_PREFIX.$this->_code."_field` ("
             ."`field_id` int(11) NOT NULL AUTO_INCREMENT,"
             ."`status` tinyint(1) NOT NULL DEFAULT '0',"
             ."`system_name` text NOT NULL,"
             ."`field_type` varchar(255) NOT NULL,"
             ."`css_id` text NOT NULL,"
             ."`css_class` text NOT NULL,"
             ."`field_mask` text NOT NULL,"
             ."`regex_rule` text NOT NULL,"
             ."`min_length_rule` int(11) NOT NULL,"
             ."`max_length_rule` int(11) NOT NULL,"
             ."`validation_type` int(1) NOT NULL,"
             ."`description_status` tinyint(1) NOT NULL DEFAULT '0',"
             ."`title_status` int(1) NOT NULL DEFAULT '0',"
             ."`placeholder_status` int(1) NOT NULL DEFAULT '0',"
             ."`icon_status` int(1) NOT NULL DEFAULT '0',"
             ."`icon` text NOT NULL,"
             ."`sort_order` int(3) NOT NULL,"
             ."`date_added` datetime NOT NULL,"
             ."`date_modified` datetime NOT NULL,"
             ."PRIMARY KEY (`field_id`)"
             .") ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci AUTO_INCREMENT=1;";

    $sql[] = "CREATE TABLE IF NOT EXISTS `".DB_PREFIX.$this->_code."_field_description` ("
             ."`field_id` int(11) NOT NULL,"
             ."`language_id` int(11) NOT NULL,"
             ."`name` text NOT NULL,"
             ."`error_text` text NOT NULL,"
             ."`description` text NOT NULL,"
             ."`placeholder` text NOT NULL,"
             ."PRIMARY KEY (`field_id`,`language_id`)"
             .") ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;";

    $sql[] = "CREATE TABLE IF NOT EXISTS `".DB_PREFIX.$this->_code."_banned` ("
             ."`banned_id` int(11) NOT NULL AUTO_INCREMENT,"
             ."`status` tinyint(1) NOT NULL DEFAULT '0',"
             ."`ip` text NOT NULL,"
             ."`email` text NOT NULL,"
             ."`date_added` datetime NOT NULL,"
             ."`date_modified` datetime NOT NULL,"
             ."PRIMARY KEY (`banned_id`)"
             .") ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE utf8_general_ci AUTO_INCREMENT=1;";

    $sql[] = "CREATE TABLE IF NOT EXISTS ".DB_PREFIX.$this->_code."_email_template ( "
             ."`template_id` int(11) NOT NULL AUTO_INCREMENT,"
             ."`system_name` text NOT NULL,"
             ."`status` tinyint(1) NOT NULL DEFAULT '0',"
             ."`assignment` int(11) NOT NULL,"
             ."`related_product_status` tinyint(1) NOT NULL DEFAULT '0',"
             ."`related_limit` int(11) NOT NULL DEFAULT '4',"
             ."`related_show_image` tinyint(1) NOT NULL DEFAULT '1',"
             ."`related_image_width` int(11) NOT NULL DEFAULT '200',"
             ."`related_image_height` int(11) NOT NULL DEFAULT '200',"
             ."`related_show_price` tinyint(1) NOT NULL DEFAULT '1',"
             ."`related_show_name` tinyint(1) NOT NULL DEFAULT '1',"
             ."`related_show_description` tinyint(1) NOT NULL DEFAULT '0',"
             ."`related_description_limit` int(11) NOT NULL DEFAULT '200',"
             ."`related_randomize` tinyint(1) NOT NULL DEFAULT '1',"
             ."`main_show_image` tinyint(1) NOT NULL DEFAULT '1',"
             ."`main_image_width` int(11) NOT NULL DEFAULT '200',"
             ."`main_image_height` int(11) NOT NULL DEFAULT '200',"
             ."`main_show_price` tinyint(1) NOT NULL DEFAULT '1',"
             ."`main_show_name` tinyint(1) NOT NULL DEFAULT '1',"
             ."`main_show_description` tinyint(1) NOT NULL DEFAULT '0',"
             ."`main_description_limit` int(11) NOT NULL DEFAULT '200',"
             ."`date_added` datetime NOT NULL,"
             ."`date_modified` datetime NOT NULL,"
             ."PRIMARY KEY (`template_id`)"
             .") ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci AUTO_INCREMENT=1;";

    $sql[] = "CREATE TABLE IF NOT EXISTS ".DB_PREFIX.$this->_code."_email_template_description ("
             ."`template_id` int(11) NOT NULL AUTO_INCREMENT,"
             ."`language_id` int(11) NOT NULL,"
             ."`subject` varchar(255) NOT NULL,"
             ."`template` text NOT NULL,"
             ."PRIMARY KEY (`template_id`,`language_id`),"
             ."KEY `subject` (`subject`)"
             .") ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci AUTO_INCREMENT=1;";

    $sql[] = "CREATE TABLE IF NOT EXISTS `".DB_PREFIX.$this->_code."_email_template_related_product` ("
             ."`template_id` int(11) NOT NULL,"
             ."`product_id` int(11) NOT NULL,"
             ."PRIMARY KEY (`template_id`,`product_id`)"
             .") ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;";

    $sql[] = "CREATE TABLE IF NOT EXISTS `".DB_PREFIX.$this->_code."_email_template_related_category` ("
             ."`template_id` int(11) NOT NULL,"
             ."`category_id` int(11) NOT NULL,"
             ."PRIMARY KEY (`template_id`,`category_id`)"
             .") ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;";

    $sql[] = "CREATE TABLE IF NOT EXISTS `".DB_PREFIX.$this->_code."_email_template_related_manufacturer` ("
             ."`template_id` int(11) NOT NULL,"
             ."`manufacturer_id` int(11) NOT NULL,"
             ."PRIMARY KEY (`template_id`,`manufacturer_id`)"
             .") ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;";

    foreach ($sql as $query) {
      $this->db->query($query);
    }
  }

  public function deleteDBTables() {
    $this->db->query("DROP TABLE IF EXISTS ".DB_PREFIX.$this->_code."_field;");
    $this->db->query("DROP TABLE IF EXISTS ".DB_PREFIX.$this->_code."_field_description;");
    $this->db->query("DROP TABLE IF EXISTS ".DB_PREFIX.$this->_code."_record;");
    $this->db->query("DROP TABLE IF EXISTS ".DB_PREFIX.$this->_code."_record_product;");
    $this->db->query("DROP TABLE IF EXISTS ".DB_PREFIX.$this->_code."_banned;");
    $this->db->query("DROP TABLE IF EXISTS ".DB_PREFIX.$this->_code."_email_template;");
    $this->db->query("DROP TABLE IF EXISTS ".DB_PREFIX.$this->_code."_email_template_description;");
    $this->db->query("DROP TABLE IF EXISTS ".DB_PREFIX.$this->_code."_email_template_related_product;");
    $this->db->query("DROP TABLE IF EXISTS ".DB_PREFIX.$this->_code."_email_template_related_category;");
    $this->db->query("DROP TABLE IF EXISTS ".DB_PREFIX.$this->_code."_email_template_related_manufacturer;");
  }

  public function getField($field_id) {
    return $this->db->query("SELECT * FROM ".DB_PREFIX.$this->_code."_field WHERE field_id = '".(int)$field_id."'")->row;
  }

  public function getFields($data = []) {
    $sql = "SELECT DISTINCT * FROM ".DB_PREFIX.$this->_code."_field f WHERE f.field_id IS NOT NULL";

    if (isset($data['filter_name']) && !empty($data['filter_name'])) {
      $sql .= " AND f.system_name LIKE '%".$this->db->escape($data['filter_name'])."%'";
    }

    if (isset($data['filter_date_added']) && !empty($data['filter_date_added'])) {
      $sql .= " AND DATE(f.date_added) = DATE('".$this->db->escape($data['filter_date_added'])."')";
    }

    if (isset($data['filter_date_modified']) && !empty($data['filter_date_modified'])) {
      $sql .= " AND DATE(f.date_modified) = DATE('".$this->db->escape($data['filter_date_modified'])."')";
    }

    if (isset($data['filter_status']) && $data['filter_status'] != '*') {
      $sql .= " AND f.status = '".(int)$data['filter_status']."'";
    }

    $sql .= " GROUP BY f.field_id";

    $sort_data = [
      'f.system_name',
      'f.date_added',
      'f.date_modified',
      'f.sort_order',
      'f.status'
    ];

    if (isset($data['sort']) && in_array($data['sort'],$sort_data)) {
      if ($data['sort'] == 'f.system_name') {
        $sql .= " ORDER BY LCASE(".$data['sort'].")";
      } else {
        $sql .= " ORDER BY ".$data['sort'];
      }
    } else {
      $sql .= " ORDER BY f.sort_order";
    }

    if (isset($data['order']) && ($data['order'] == 'DESC')) {
      $sql .= " DESC, LCASE(f.system_name) DESC";
    } else {
      $sql .= " ASC, LCASE(f.system_name) ASC";
    }

    if (isset($data['start']) || isset($data['limit'])) {
      if ($data['start'] < 0) {
        $data['start'] = 0;
      }

      if ($data['limit'] < 1) {
        $data['limit'] = 20;
      }

      $sql .= " LIMIT ".(int)$data['start'].",".(int)$data['limit'];
    }

    return $this->db->query($sql)->rows;
  }

  public function getFieldDescription($field_id) {
    $results = [];

    $query = $this->db->query("SELECT * FROM ".DB_PREFIX.$this->_code."_field_description WHERE field_id = '".(int)$field_id."'")->rows;

    if ($query) {
      foreach ($query as $row) {
        $results[$row['language_id']] = [
          'name'        => $row['name'],
          'description' => $row['description'],
          'placeholder' => $row['placeholder'],
          'error_text'  => $row['error_text']
        ];
      }
    }

    return $results;
  }

  public function getExportFields() {
    $query = $this->db->query("SELECT DISTINCT * FROM ".DB_PREFIX.$this->_code."_field")->rows;

    $results = [];

    if ($query) {
      foreach ($query as $row) {
        $data = [];

        $data = $row;

        $data = array_merge($data,['field_description' => $this->getFieldDescription($row['field_id'])]);

        $results[] = $data;
      }
    }

    return $results;
  }

  public function getTotalFields($data = []) {
    $sql = "
      SELECT 
        COUNT(*) AS total 
      FROM ".DB_PREFIX.$this->_code."_field f 
      WHERE 
        f.field_id IS NOT NULL
    ";

    if (isset($data['filter_name']) && !empty($data['filter_name'])) {
      $sql .= " AND f.system_name LIKE '%".$this->db->escape($data['filter_name'])."%'";
    }

    if (isset($data['filter_date_added']) && !empty($data['filter_date_added'])) {
      $sql .= " AND DATE(f.date_added) = DATE('".$this->db->escape($data['filter_date_added'])."')";
    }

    if (isset($data['filter_date_modified']) && !empty($data['filter_date_modified'])) {
      $sql .= " AND DATE(f.date_modified) = DATE('".$this->db->escape($data['filter_date_modified'])."')";
    }

    if (isset($data['filter_status']) && $data['filter_status'] != '*') {
      $sql .= " AND f.status = '".(int)$data['filter_status']."'";
    }

    return $this->db->query($sql)->row['total'];
  }

  public function getSortOrderValues($sort_order,$type,$id) {
    if ($id) {
      return $this->db->query("SELECT * FROM ".DB_PREFIX.$this->_code."_".$this->db->escape($type)." WHERE sort_order = '".(int)$sort_order."' AND ".$this->db->escape($type)."_id != '".(int)$id."'");
    } else {
      return $this->db->query("SELECT * FROM ".DB_PREFIX.$this->_code."_".$this->db->escape($type)." WHERE sort_order = '".(int)$sort_order."'");
    }
  }

  public function getSeoKeywordValues($keyword,$type,$id) {
    if ($id) {
      if (version_compare(VERSION,'3.0.0.0','>=')) {
        return $this->db->query("SELECT * FROM ".DB_PREFIX."seo_url WHERE keyword = '".$this->db->escape($keyword)."' AND `query` != '".$this->_code."_".$this->db->escape($type)."_id=".(int)$id."'");
      } else {
        return $this->db->query("SELECT * FROM ".DB_PREFIX."url_alias WHERE keyword = '".$this->db->escape($keyword)."' AND `query` != '".$this->_code."_".$this->db->escape($type)."_id=".(int)$id."'");
      }
    } else {
      if (version_compare(VERSION,'3.0.0.0','>=')) {
        return $this->db->query("SELECT * FROM ".DB_PREFIX."seo_url WHERE keyword = '".$this->db->escape($keyword)."'");
      } else {
        return $this->db->query("SELECT * FROM ".DB_PREFIX."url_alias WHERE keyword = '".$this->db->escape($keyword)."'");
      }
    }
  }

  public function getRecord($record_id) {
    $query = $this->db->query("
      SELECT 
        DISTINCT *
      FROM ".DB_PREFIX.$this->_code."_record r
      WHERE 
        r.record_id = '".(int)$record_id."'
    ");

    if ($query->num_rows) {
      return [
        'record_id'        => $query->row['record_id'],
        'banned_status'    => $this->checkBanned($query->row['email'],$query->row['ip']),
        'currency_code'    => $query->row['currency_code'],
        'currency_value'   => $query->row['currency_value'],
        'email'            => $query->row['email'],
        'field_data'       => $query->row['field_data'],
        'ip'               => $query->row['ip'],
        'referer'          => $query->row['referer'],
        'user_agent'       => $query->row['user_agent'],
        'accept_language'  => $query->row['accept_language'],
        'user_language_id' => $query->row['user_language_id'],
        'store_url'        => $query->row['store_url'],
        'store_name'       => $query->row['store_name'],
        'store_id'         => $query->row['store_id'],
        'status'           => $query->row['status'],
        'date_added'       => $query->row['date_added'],
        'date_notified'    => $query->row['date_notified']
      ];
    } else {
      return false;
    }
  }

  public function getRecords($data = []) {
    $sql = "SELECT DISTINCT * FROM ".DB_PREFIX.$this->_code."_record r WHERE r.record_id > '0'";

    if (isset($data['filter_email']) && !empty($data['filter_email'])) {
      $sql .= " AND r.email LIKE '%".$this->db->escape($data['filter_email'])."%'";
    }

    if (isset($data['filter_date_added']) && !empty($data['filter_date_added'])) {
      $sql .= " AND DATE(r.date_added) = DATE('".$this->db->escape($data['filter_date_added'])."')";
    }

    if (isset($data['filter_status']) && $data['filter_status'] != '*') {
      $sql .= " AND r.status = '".(int)$data['filter_status']."'";
    }

    $sql .= " GROUP BY r.record_id";

    $sort_data = [
      'r.email',
      'r.date_added',
      'r.status'
    ];

    if (isset($data['sort']) && in_array($data['sort'],$sort_data)) {
      $sql .= " ORDER BY ".$data['sort'];
    } else {
      $sql .= " ORDER BY r.date_added";
    }

    if (isset($data['order']) && ($data['order'] == 'DESC')) {
      $sql .= " DESC";
    } else {
      $sql .= " ASC";
    }

    if (isset($data['start']) || isset($data['limit'])) {
      if ($data['start'] < 0) {
        $data['start'] = 0;
      }

      if ($data['limit'] < 1) {
        $data['limit'] = 20;
      }

      $sql .= " LIMIT ".(int)$data['start'].",".(int)$data['limit'];
    }

    $query = $this->db->query($sql)->rows;

    $records = [];

    if ($query) {
      foreach ($query as $row) {
        $records[$row['record_id']] = $this->getRecord($row['record_id']);
      }
    }

    return $records;
  }

  public function getRecordProducts($record_id) {
    return $this->db->query("SELECT rp.*, p.image FROM ".DB_PREFIX.$this->_code."_record_product rp LEFT JOIN ".DB_PREFIX."product p ON (rp.product_id = p.product_id) WHERE rp.record_id = '".(int)$record_id."'")->rows;
  }

  public function getExportRecords() {
    $results = [];

    $query = $this->db->query("SELECT DISTINCT * FROM ".DB_PREFIX.$this->_code."_record")->rows;

    if ($query) {
      foreach ($query as $row) {
        $data = [];

        $data = $row;

        $data = array_merge($data,['cart' => $this->getRecordProducts($row['record_id'])]);

        $results[] = $data;
      }
    }

    return $results;
  }

  public function getTotalRecords($data = []) {
    $sql = "
      SELECT 
        COUNT(DISTINCT r.record_id) AS total 
      FROM ".DB_PREFIX.$this->_code."_record r
      WHERE 
        r.record_id > '0'
    ";

    if (isset($data['filter_email']) && !empty($data['filter_email'])) {
      $sql .= " AND r.email LIKE '%".$this->db->escape($data['filter_email'])."%'";
    }

    if (isset($data['filter_date_added']) && !empty($data['filter_date_added'])) {
      $sql .= " AND DATE(r.date_added) = DATE('".$this->db->escape($data['filter_date_added'])."')";
    }

    if (isset($data['filter_status']) && $data['filter_status'] != '*') {
      $sql .= " AND r.status = '".(int)$data['filter_status']."'";
    }

    return $this->db->query($sql)->row['total'];
  }

  public function getBanned($banned_id) {
    return $this->db->query("SELECT DISTINCT * FROM ".DB_PREFIX.$this->_code."_banned b WHERE b.banned_id = '".(int)$banned_id."'")->row;
  }

  public function getBannedByEmail($email) {
    return $this->db->query("SELECT DISTINCT * FROM ".DB_PREFIX.$this->_code."_banned b WHERE b.email = '".$this->db->escape($email)."'")->rows;
  }

  public function getBanneds($data = []) {
    $sql = "SELECT DISTINCT * FROM ".DB_PREFIX.$this->_code."_banned b WHERE b.banned_id > '0'";

    if (isset($data['filter_ip']) && !empty($data['filter_ip'])) {
      $sql .= " AND b.ip LIKE '%".$this->db->escape($data['filter_ip'])."%'";
    }

    if (isset($data['filter_email']) && !empty($data['filter_email'])) {
      $sql .= " AND b.email LIKE '%".$this->db->escape($data['filter_email'])."%'";
    }

    if (isset($data['filter_date_added']) && !empty($data['filter_date_added'])) {
      $sql .= " AND DATE(b.date_added) = DATE('".$this->db->escape($data['filter_date_added'])."')";
    }

    if (isset($data['filter_date_modified']) && !empty($data['filter_date_modified'])) {
      $sql .= " AND DATE(b.date_modified) = DATE('".$this->db->escape($data['filter_date_modified'])."')";
    }

    if (isset($data['filter_status']) && $data['filter_status'] != '*') {
      $sql .= " AND b.status = '".(int)$data['filter_status']."'";
    }

    $sql .= " GROUP BY b.banned_id";

    $sort_data = [
      'b.ip',
      'b.email',
      'b.date_added',
      'b.date_modified',
      'b.status'
    ];

    if (isset($data['sort']) && in_array($data['sort'],$sort_data)) {
      $sql .= " ORDER BY ".$data['sort'];
    } else {
      $sql .= " ORDER BY b.date_added";
    }

    if (isset($data['order']) && ($data['order'] == 'DESC')) {
      $sql .= " DESC, LCASE(b.ip) DESC";
    } else {
      $sql .= " ASC, LCASE(b.ip) ASC";
    }

    if (isset($data['start']) || isset($data['limit'])) {
      if ($data['start'] < 0) {
        $data['start'] = 0;
      }

      if ($data['limit'] < 1) {
        $data['limit'] = 20;
      }

      $sql .= " LIMIT ".(int)$data['start'].",".(int)$data['limit'];
    }

    return $this->db->query($sql)->rows;
  }

  public function getTotalBanneds($data = []) {
    $sql = "SELECT COUNT(DISTINCT b.banned_id) AS total FROM ".DB_PREFIX.$this->_code."_banned b WHERE b.banned_id > '0'";

    if (isset($data['filter_ip']) && !empty($data['filter_ip'])) {
      $sql .= " AND b.ip LIKE '%".$this->db->escape($data['filter_ip'])."%'";
    }

    if (isset($data['filter_email']) && !empty($data['filter_email'])) {
      $sql .= " AND b.email LIKE '%".$this->db->escape($data['filter_email'])."%'";
    }

    if (isset($data['filter_date_added']) && !empty($data['filter_date_added'])) {
      $sql .= " AND DATE(b.date_added) = DATE('".$this->db->escape($data['filter_date_added'])."')";
    }

    if (isset($data['filter_date_modified']) && !empty($data['filter_date_modified'])) {
      $sql .= " AND DATE(b.date_modified) = DATE('".$this->db->escape($data['filter_date_modified'])."')";
    }

    if (isset($data['filter_status']) && $data['filter_status'] != '*') {
      $sql .= " AND b.status = '".(int)$data['filter_status']."'";
    }

    return $this->db->query($sql)->row['total'];
  }

  public function getExportBanneds() {
    $results = [];

    $query = $this->db->query("SELECT DISTINCT * FROM ".DB_PREFIX.$this->_code."_banned")->rows;

    if ($query) {
      foreach ($query as $row) {
        $data = [];

        $data = $row;

        $results[] = $data;
      }
    }

    return $results;
  }

  public function getEmailTemplate($template_id,$language_id = 0) {
    $sql = "SELECT DISTINCT * FROM ".DB_PREFIX.$this->_code."_email_template et";

    if ($language_id) {
      $sql .= " LEFT JOIN ".DB_PREFIX.$this->_code."_email_template_description etd ON (et.template_id = etd.template_id)";
    }

    $sql .= " WHERE et.template_id = '".(int)$template_id."'";

    if ($language_id) {
      $sql .= " AND etd.language_id = '".(int)$language_id."'";
    }

    return $this->db->query($sql)->row;
  }

  public function getEmailTemplateRelatedProduct($template_id) {
    $results = [];

    $query = $this->db->query("SELECT * FROM ".DB_PREFIX.$this->_code."_email_template_related_product WHERE template_id = '".(int)$template_id."'")->rows;

    if ($query) {
      foreach ($query as $row) {
        $results[] = $row['product_id'];
      }
    }

    return $results;
  }

  public function getEmailTemplateRelatedCategory($template_id) {
    $results = [];

    $query = $this->db->query("SELECT * FROM ".DB_PREFIX.$this->_code."_email_template_related_category WHERE template_id = '".(int)$template_id."'")->rows;

    if ($query) {
      foreach ($query as $row) {
        $results[] = $row['category_id'];
      }
    }

    return $results;
  }

  public function getEmailTemplateRelatedManufacturer($template_id) {
    $results = [];

    $query = $this->db->query("SELECT * FROM ".DB_PREFIX.$this->_code."_email_template_related_manufacturer WHERE template_id = '".(int)$template_id."'")->rows;

    if ($query) {
      foreach ($query as $row) {
        $results[] = $row['manufacturer_id'];
      }
    }

    return $results;
  }

  public function getEmailTemplates($data = []) {
    $sql = "SELECT DISTINCT * FROM ".DB_PREFIX.$this->_code."_email_template et WHERE et.template_id IS NOT NULL";

    if (isset($data['filter_name']) && !empty($data['filter_name'])) {
      $sql .= " AND et.system_name LIKE '%".$this->db->escape($data['filter_name'])."%'";
    }

    if (isset($data['filter_date_added']) && !empty($data['filter_date_added'])) {
      $sql .= " AND DATE(et.date_added) = DATE('".$this->db->escape($data['filter_date_added'])."')";
    }

    if (isset($data['filter_date_modified']) && !empty($data['filter_date_modified'])) {
      $sql .= " AND DATE(et.date_modified) = DATE('".$this->db->escape($data['filter_date_modified'])."')";
    }

    if (isset($data['filter_assignment']) && $data['filter_assignment']) {
      $sql .= " AND et.assignment = '".(int)$data['filter_assignment']."'";
    }

    if (isset($data['filter_status']) && $data['filter_status'] != '*') {
      $sql .= " AND et.status = '".(int)$data['filter_status']."'";
    }

    $sql .= " GROUP BY et.template_id";

    $sort_data = [
      'et.system_name',
      'et.date_added',
      'et.date_modified',
      'et.status'
    ];

    if (isset($data['sort']) && in_array($data['sort'],$sort_data)) {
      if ($data['sort'] == 'et.system_name') {
        $sql .= " ORDER BY LCASE(".$data['sort'].")";
      } else {
        $sql .= " ORDER BY ".$data['sort'];
      }
    } else {
      $sql .= " ORDER BY et.date_added";
    }

    if (isset($data['order']) && ($data['order'] == 'DESC')) {
      $sql .= " DESC, LCASE(et.system_name) DESC";
    } else {
      $sql .= " ASC, LCASE(et.system_name) ASC";
    }

    if (isset($data['start']) || isset($data['limit'])) {
      if ($data['start'] < 0) {
        $data['start'] = 0;
      }

      if ($data['limit'] < 1) {
        $data['limit'] = 20;
      }

      $sql .= " LIMIT ".(int)$data['start'].",".(int)$data['limit'];
    }

    return $this->db->query($sql)->rows;
  }

  public function getEmailTemplateDescription($template_id) {
    $results = [];

    $query = $this->db->query("SELECT * FROM ".DB_PREFIX.$this->_code."_email_template_description WHERE template_id = '".(int)$template_id."'")->rows;

    if ($query) {
      foreach ($query as $row) {
        $results[$row['language_id']] = [
          'subject'  => $row['subject'],
          'template' => $row['template']
        ];
      }
    }

    return $results;
  }

  public function getExportEmailTemplates() {
    $query = $this->db->query("SELECT DISTINCT * FROM ".DB_PREFIX.$this->_code."_email_template")->rows;

    $results = [];

    if ($query) {
      foreach ($query as $row) {
        $data = [];

        $data = $row;

        $data = array_merge($data,['template_description' => $this->getEmailTemplateDescription($row['template_id'])]);
        $data = array_merge($data,['product_related' => $this->getEmailTemplateRelatedProduct($row['template_id'])]);
        $data = array_merge($data,['category_related' => $this->getEmailTemplateRelatedCategory($row['template_id'])]);
        $data = array_merge($data,['manufacturer_related' => $this->getEmailTemplateRelatedManufacturer($row['template_id'])]);

        $results[] = $data;
      }
    }

    return $results;
  }

  public function getTotalEmailTemplates($data = []) {
    $sql = "SELECT COUNT(DISTINCT et.template_id) AS total FROM ".DB_PREFIX.$this->_code."_email_template et WHERE et.template_id IS NOT NULL";

    if (isset($data['filter_name']) && !empty($data['filter_name'])) {
      $sql .= " AND et.system_name LIKE '%".$this->db->escape($data['filter_name'])."%'";
    }

    if (isset($data['filter_date_added']) && !empty($data['filter_date_added'])) {
      $sql .= " AND DATE(et.date_added) = DATE('".$this->db->escape($data['filter_date_added'])."')";
    }

    if (isset($data['filter_date_modified']) && !empty($data['filter_date_modified'])) {
      $sql .= " AND DATE(et.date_modified) = DATE('".$this->db->escape($data['filter_date_modified'])."')";
    }

    if (isset($data['filter_status']) && $data['filter_status'] != '*') {
      $sql .= " AND et.status = '".(int)$data['filter_status']."'";
    }

    return $this->db->query($sql)->row['total'];
  }

  public function getSeoUrl($data,$type,$result_status) {
    if ($result_status == 1) {
      if (version_compare(VERSION,'3.0.0.0','>=')) {
        return $this->db->query("SELECT * FROM ".DB_PREFIX."seo_url WHERE ".$this->db->escape($type)." = '".$this->db->escape($data)."'")->rows;
      } else {
        return $this->db->query("SELECT * FROM ".DB_PREFIX."url_alias WHERE ".$this->db->escape($type)." = '".$this->db->escape($data)."'")->row;
      }
    } else {
      if (version_compare(VERSION,'3.0.0.0','>=')) {
        return $this->db->query("SELECT * FROM ".DB_PREFIX."seo_url WHERE ".$this->db->escape($type)." = '".$this->db->escape($data)."'");
      } else {
        return $this->db->query("SELECT * FROM ".DB_PREFIX."url_alias WHERE ".$this->db->escape($type)." = '".$this->db->escape($data)."'");
      }
    }
  }

  public function getCustomerGroups($data = []) {
    $sql = "
      SELECT
        *
      FROM ".DB_PREFIX."customer_group cg
      LEFT JOIN ".DB_PREFIX."customer_group_description cgd ON (cg.customer_group_id = cgd.customer_group_id)
      WHERE
        cgd.language_id = '".(int)$this->config->get('config_language_id')."'
    ";

    $sort_data = [
      'cgd.name'
    ];

    if (isset($data['sort']) && in_array($data['sort'],$sort_data)) {
      $sql .= " ORDER BY ".$data['sort'];
    } else {
      $sql .= " ORDER BY cgd.name";
    }

    if (isset($data['order']) && ($data['order'] == 'DESC')) {
      $sql .= " DESC";
    } else {
      $sql .= " ASC";
    }

    if (isset($data['start']) || isset($data['limit'])) {
      if ($data['start'] < 0) {
        $data['start'] = 0;
      }

      if ($data['limit'] < 1) {
        $data['limit'] = 20;
      }

      $sql .= " LIMIT ".(int)$data['start'].",".(int)$data['limit'];
    }

    return $this->db->query($sql)->rows;
  }

  public function getStoreSetting($store_id) {
    $query = $this->db->query("SELECT `key`, `value` FROM ".DB_PREFIX."setting WHERE store_id = '".(int)$store_id."'")->rows;

    $results = [];

    if ($query) {
      foreach ($query as $row) {
        $results[$row['key']] = $row['value'];
      }
    }

    return $results;
  }

  public function getStore($store_id) {
    return $this->db->query("SELECT DISTINCT * FROM ".DB_PREFIX."store WHERE store_id = '".(int)$store_id."'")->row;
  }

  public function getMultiLanguageValue($filename,$value) {
    $models = [
      'localisation/language'
    ];

    foreach ($models as $model) {
      $this->load->model($model);
    }

    $_      = [];
    $result = [];

    foreach ($this->model_localisation_language->getLanguages() as $language) {
      $file = DIR_LANGUAGE.$language['directory'].'/'.$filename.'.php';

      if (file_exists($file)) {
        require($file);
      }

      if (isset($_[$value]) && $_[$value]) {
        $result[$language['language_id']] = $_[$value];
      }
    }

    return $result;
  }

  public function getRecordFieldData($record_id) {
    $results = '';

    $query = $this->db->query("SELECT field_data FROM ".DB_PREFIX.$this->_code."_record WHERE record_id = '".(int)$record_id."'");

    if ($query->num_rows) {
      if ($query->row['field_data']) {
        $results = unserialize($query->row['field_data']);
      }
    }

    return $results;
  }

  public function getCoupons() {
    return $this->db->query("SELECT coupon_id, `name`, code, discount, date_start, date_end, status FROM ".DB_PREFIX."coupon ORDER BY `name` ASC")->rows;
  }

  public function getVouchers() {
    return $this->db->query("SELECT v.voucher_id, v.code, v.from_name, v.from_email, v.to_name, v.to_email, (SELECT vtd.name FROM ".DB_PREFIX."voucher_theme_description vtd WHERE vtd.voucher_theme_id = v.voucher_theme_id AND vtd.language_id = '".(int)$this->config->get('config_language_id')."') AS theme, v.amount, v.status, v.date_added FROM ".DB_PREFIX."voucher v")->rows;
  }

  public function checkBanned($email,$ip) {
    $sql = "SELECT DISTINCT * FROM ".DB_PREFIX.$this->_code."_banned WHERE (";

    if ($email) {
      $sql .= "LCASE(email) = '".$this->db->escape(utf8_strtolower($email))."' OR ";
    }

    $sql .= "ip = '".$this->db->escape($ip)."') AND status = '1'";

    $query = $this->db->query($sql)->row;

    if ($query) {
      return true;
    } else {
      return false;
    }
  }

  public function getProduct($product_id) {
    return $this->db->query("SELECT DISTINCT * FROM ".DB_PREFIX."product p LEFT JOIN ".DB_PREFIX."product_description pd ON (p.product_id = pd.product_id) WHERE p.product_id = '".(int)$product_id."' AND pd.language_id = '".(int)$this->config->get('config_language_id')."' AND p.status = '1'")->row;
  }

  public function getProducts($data = []) {
    $sql = "SELECT DISTINCT * FROM ".DB_PREFIX."product p LEFT JOIN ".DB_PREFIX."product_description pd ON (p.product_id = pd.product_id) WHERE pd.language_id = '".(int)$this->config->get('config_language_id')."' AND p.status = '1'";

    if (isset($data['filter_name']) && !empty($data['filter_name'])) {
      $sql .= " AND pd.name LIKE '%".$this->db->escape($data['filter_name'])."%' OR p.model LIKE '%".$this->db->escape($data['filter_name'])."%' OR p.sku LIKE '%".$this->db->escape($data['filter_name'])."%'";
    }

    $sql .= " GROUP BY p.product_id";

    $sort_data = [
      'pd.name'
    ];

    if (isset($data['sort']) && in_array($data['sort'],$sort_data)) {
      $sql .= " ORDER BY ".$data['sort'];
    } else {
      $sql .= " ORDER BY pd.name";
    }

    if (isset($data['order']) && ($data['order'] == 'DESC')) {
      $sql .= " DESC";
    } else {
      $sql .= " ASC";
    }

    if (isset($data['start']) || isset($data['limit'])) {
      if ($data['start'] < 0) {
        $data['start'] = 0;
      }

      if ($data['limit'] < 1) {
        $data['limit'] = 5;
      }

      $sql .= " LIMIT ".(int)$data['start'].",".(int)$data['limit'];
    }

    return $this->db->query($sql)->rows;
  }

  public function getCategory($category_id) {
    return $this->db->query("SELECT DISTINCT * FROM ".DB_PREFIX."category c LEFT JOIN ".DB_PREFIX."category_description cd2 ON (c.category_id = cd2.category_id) WHERE c.category_id = '".(int)$category_id."' AND cd2.language_id = '".(int)$this->config->get('config_language_id')."' AND c.status = '1'")->row;
  }

  public function getCategories($data = []) {
    $sql = "SELECT cp.category_id AS category_id, GROUP_CONCAT(cd1.name ORDER BY cp.level SEPARATOR '&nbsp;&nbsp;&gt;&nbsp;&nbsp;') AS name FROM ".DB_PREFIX."category_path cp LEFT JOIN ".DB_PREFIX."category c1 ON (cp.category_id = c1.category_id) LEFT JOIN ".DB_PREFIX."category c2 ON (cp.path_id = c2.category_id) LEFT JOIN ".DB_PREFIX."category_description cd1 ON (cp.path_id = cd1.category_id) LEFT JOIN ".DB_PREFIX."category_description cd2 ON (cp.category_id = cd2.category_id) WHERE cd1.language_id = '".(int)$this->config->get('config_language_id')."' AND cd2.language_id = '".(int)$this->config->get('config_language_id')."' AND c2.status = '1'";

    if (isset($data['filter_name']) && !empty($data['filter_name'])) {
      $sql .= " AND cd2.name LIKE '%".$this->db->escape($data['filter_name'])."%'";
    }

    $sql .= " GROUP BY cp.category_id";

    $sort_data = [
      'name'
    ];

    if (isset($data['sort']) && in_array($data['sort'],$sort_data)) {
      $sql .= " ORDER BY ".$data['sort'];
    } else {
      $sql .= " ORDER BY name";
    }

    if (isset($data['order']) && ($data['order'] == 'DESC')) {
      $sql .= " DESC";
    } else {
      $sql .= " ASC";
    }

    if (isset($data['start']) || isset($data['limit'])) {
      if ($data['start'] < 0) {
        $data['start'] = 0;
      }

      if ($data['limit'] < 1) {
        $data['limit'] = 20;
      }

      $sql .= " LIMIT ".(int)$data['start'].",".(int)$data['limit'];
    }

    return $this->db->query($sql)->rows;
  }

  public function getManufacturer($manufacturer_id) {
    return $this->db->query("SELECT DISTINCT * FROM ".DB_PREFIX."manufacturer WHERE manufacturer_id = '".(int)$manufacturer_id."'")->row;
  }

  public function getManufacturers($data = []) {
    $sql = "SELECT * FROM ".DB_PREFIX."manufacturer";

    if (isset($data['filter_name']) && !empty($data['filter_name'])) {
      $sql .= " WHERE name LIKE '%".$this->db->escape($data['filter_name'])."%'";
    }

    $sort_data = [
      'name'
    ];

    if (isset($data['sort']) && in_array($data['sort'],$sort_data)) {
      $sql .= " ORDER BY ".$data['sort'];
    } else {
      $sql .= " ORDER BY name";
    }

    if (isset($data['order']) && ($data['order'] == 'DESC')) {
      $sql .= " DESC";
    } else {
      $sql .= " ASC";
    }

    if (isset($data['start']) || isset($data['limit'])) {
      if ($data['start'] < 0) {
        $data['start'] = 0;
      }

      if ($data['limit'] < 1) {
        $data['limit'] = 20;
      }

      $sql .= " LIMIT ".(int)$data['start'].",".(int)$data['limit'];
    }

    return $this->db->query($sql)->rows;
  }

  public function getLanguageByCode($code) {
    return $this->db->query("SELECT language_id FROM ".DB_PREFIX."language WHERE code = '".$this->db->escape($code)."'")->row['language_id'];
  }

  private function checkIfColumnExist($table,$table_column) {
    return $this->db->query("SELECT COUNT(*) as total FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = '".DB_DATABASE."' AND TABLE_NAME = '".$table."' AND COLUMN_NAME  = '".$table_column."'")->row['total'];
  }
}