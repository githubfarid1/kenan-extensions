<?php
##==========================================##
## @author    : OCdevWizard                 ##
## @contact   : ocdevwizard@gmail.com       ##
## @support   : http://help.ocdevwizard.com ##
## @copyright : (c) OCdevWizard. Cart, 2017 ##
##==========================================##

// Main
$_['heading_title']                                 = 'Кошик';
$_['button_save']                                   = 'Зберегти';
$_['button_save_and_stay']                          = 'Зберегти і залишитися';
$_['button_uninstall']                              = 'Видалити модуль';
$_['button_uninstall_and_remove']                   = 'Видалити модуль разом з його файлами';
$_['button_restore']                                = 'Відновити налаштування за замовчуванням';
$_['button_cache']                                  = 'Видалити кеш модуля';
$_['button_cache_backup']                           = 'Видалити файли відновлення';
$_['button_need_help']                              = 'Допомога';
$_['button_need_help_email']                        = 'Через email повідомлення';
$_['button_need_help_ticket']                       = 'Через сайт підтримки';
$_['button_cancel']                                 = 'Назад';
$_['tab_control_panel']                             = 'Панель управління';
$_['tab_layout_setting']                            = 'Налаштування відображення';
$_['tab_field_setting']                             = 'Налаштування полів';
$_['tab_language_setting']                          = 'Налаштування перекладу';
$_['tab_record_setting']                            = 'Список запитів';
$_['tab_banned_setting']                            = 'Заблоковані';
$_['tab_email_template_setting']                    = 'Налаштування E-mail шаблонів';
$_['tab_marketing_tools_setting']                   = 'Маркетинг';
$_['tab_license_setting']                           = 'Ліцензія';
$_['text_setting_left_menu']                        = 'Головні налаштування';
$_['text_select_store']                             = 'Виберіть магазин';
$_['text_menu_button']                              = 'Меню';
$_['text_page_extensions']                          = 'Список розширень';
$_['button_fix']                                    = 'Виправити';

// Assistance
$_['text_make_a_choice']                            = '-- Виберіть --';
$_['text_none']                                     = '-- Ні --';
$_['button_view_more']                              = 'Докладніше'; // for widget only
$_['text_records']                                  = 'Запити'; // for widget only
$_['text_yes']                                      = 'Так';
$_['text_no']                                       = 'Ні';
$_['text_select_all']                               = 'Вибрати все';
$_['text_unselect_all']                             = 'Скасувати всі';
$_['text_processing']                               = 'Виконання';
$_['text_success_processing']                       = 'Успіх';
$_['button_filter']                                 = 'Фільтр';
$_['button_clear_filter']                           = 'Очистити';
$_['text_enter_email']                              = 'E-mail';
$_['text_enter_email_template']                     = 'Назва E-mail шаблону';
$_['entry_limit']                                   = 'Ліміт';
$_['placeholder_product']                           = 'Назва товару';
$_['placeholder_category']                          = 'Назва категориЇ';
$_['placeholder_manufacturer']                      = 'Назва бренду';
$_['placeholder_field']                             = 'Назва поля';
$_['text_no_results']                               = 'Результатів немає!';
$_['button_update']                                 = 'Оновити';
$_['text_image_width_ph']                           = 'Ширина, (px)';
$_['text_image_height_ph']                          = 'Висота, (px)';
$_['text_are_you_sure']                             = 'Ви впевнені?';
$_['button_close']                                  = 'Закрити';
$_['text_open_example']                             = 'Відкрити зразок';
$_['text_open_explanation']                         = 'Відкрити пояснення';
$_['button_loading']                                = 'Завантаження ...';
$_['text_px']                                       = 'px';
$_['button_submit']                                 = 'Зберегти';
$_['button_edit']                                   = 'Редагувати';
$_['button_open']                                   = 'Відкрити';
$_['button_delete']                                 = 'Видалити';
$_['button_copy']                                   = 'Копіювати';
$_['text_not_changed']                              = 'Нема змін';
$_['text_open_texteditor']                          = 'Відкрити WYSIWYG редагувач';
$_['text_save_texteditor']                          = 'Зберегти зміни';
$_['text_width_indicator']                          = 'width=';
$_['text_height_indicator']                         = 'height=';
$_['column_heading']                                = 'Назва';
$_['button_delete_menu']                            = 'Видалити';
$_['button_delete_selected']                        = 'Видалити вибрані';
$_['button_delete_all']                             = 'Видалити всі';
$_['button_copy_menu']                              = 'Копіювати';
$_['button_copy_selected']                          = 'Копіювати вибрані';
$_['button_copy_all']                               = 'Копіювати всі';
$_['button_add_banned']                             = 'Додати блокування';
$_['button_remove_banned']                          = 'Розблокувати';
$_['button_add_field']                              = 'Додати поле';
$_['button_add_email_template']                     = 'Додати E-mail шаблон';
$_['button_preview_result']                         = 'Перегляд результату';
$_['button_full_width']                             = 'На всю ширину';
$_['button_limit']                                  = 'Ліміт';
$_['column_date_added']                             = 'Доданий';
$_['column_date_modified']                          = 'Змінений';
$_['column_sort_order']                             = 'Порядок сортування';
$_['column_processed']                              = 'Опрацьовано';
$_['text_processed_yes']                            = '<span class="label label-success text-uppercase special-label">Так%s</span>';
$_['text_processed_no']                             = '<span class="label label-danger text-uppercase special-label">Ні</span>';
$_['column_field_name']                             = 'Назва поля';
$_['column_status']                                 = 'Стан';
$_['text_status_enabled']                           = '<span class="label label-success text-uppercase">Включений</span>';
$_['text_status_disabled']                          = '<span class="label label-danger text-uppercase">Відключений</span>';
$_['column_action']                                 = 'Дія';
$_['text_alert_error_heading']                      = 'Помилка!';
$_['text_alert_success_heading']                    = 'Успіх!';
$_['button_generate']                               = 'Генерувати';
$_['text_store_id_indicator']                       = 'store_id=';
$_['text_css_id_indicator']                         = 'id=';
$_['text_css_class_indicator']                      = 'class=';
$_['text_onclick_indicator']                        = 'onclick=';
$_['text_route_indicator']                          = '?route=';
$_['text_js_indicator']                             = 'JS';
$_['text_mixed_indicator']                          = '[id|class]=';
$_['text_products_indicator']                       = 'товар(ів)';

// Tab - General setting
$_['tab_general_setting']                           = 'Головні налаштування';
$_['text_activate_module']                          = 'Активувати модуль';
$_['text_customer_groups']                          = 'Група покупців';
$_['text_customer_groups_faq']                      = 'Виберіть групу покупців з якими буде працювати модуль.';
$_['text_display_type']                             = 'Тип відображення';
$_['text_display_type_1']                           = 'Спливаюче вікно';
$_['text_display_type_2']                           = 'Бічна панель';
$_['text_display_type_3']                           = 'Статичний модуль';
$_['text_display_type_faq']                         = '<b>Спливаюче вікно</b> - відображення модуля у спливаючому вікні.<br><b>Бічна панель</b> - відображення модуля в лівій або правій бічній панелі.<br><b>Статичний модуль</b> - цей тип забезпечує можливість виводити модуль на макети OpenCart (лівий / правий стовпець, верхнє / нижнє розташування). У цьому випадку покупець побачить системне повідомлення при додаванні товару в кошик. Не відображайте статичний модуль на сторінці кошика модуля.';
$_['text_shopping_cart_type']                       = 'Сторінка кошика';
$_['text_shopping_cart_type_1']                     = 'Використовувати сторінку кошика від модуля';
$_['text_shopping_cart_type_2']                     = 'Використовувати системну сторінку кошика';
$_['text_shopping_cart_type_faq']                   = 'Ви можете використовувати сторінку кошика модуля замість системної сторінки.';
$_['text_action_on_product_with_options']           = 'Якщо товар має обов`язкові опції';
$_['text_action_on_product_with_options_1']         = 'Відображати спливаюче вікно з вибором опцій товару';
$_['text_action_on_product_with_options_2']         = 'Перенаправляти на сторінку товару';
$_['text_action_on_product_with_options_faq']       = '<b>Відображати спливаюче вікно з вибором опцій товару</b> - цей тип надає можливість відображати спливаюче вікно з вибором опцій товару, клієнт може вибрати ці опції без перенаправлення на сторінку продукту.<br><b>Перенаправляти на сторінку товару</b> - якщо у продукту є обов`язкові опції, клієнт буде перенаправлено на сторінку товару.';
$_['text_action_on_product_in_cart']                = 'Якщо товар вже в кошику';
$_['text_action_on_product_in_cart_1']              = 'Додати повторно товар в корзину і показати модуль';
$_['text_action_on_product_in_cart_2']              = 'Показати модуль без повторного додавання товару';
$_['text_action_on_product_in_cart_faq']            = '<b>Додати повторно товар в корзину і показати модуль</b> - цей тип надає можливість додати товар до кошику і відкрити модуль кошика, незалежно від того, чи був цей товар вже доданий в кошик.<br><b>Показати модуль без повторного додавання товару</b> - якщо товар уже доданий в кошик, то буде відображатися тільки модуль кошика, без додавання цього продукту до кошика.';
$_['text_add_function_selector']                    = 'Селектор для функції додавання "В кошик"';
$_['text_add_function_selector_faq']                = 'Цей селектор допоможе знайти системну функцію додавання товару до кошику. Ви можете ввести декілька значень, для цього розділяйте їх комами.';
$_['text_add_id_selector']                          = 'ID селектор для кнопки "В кошик"';
$_['text_add_id_selector_faq']                      = 'Цей селектор допоможе знайти кнопку додавання товару до кошику тільки на сторінці товару. Ви можете ввести декілька значень, для цього розділяйте їх комами.';
$_['text_main_product_id_selector']                 = 'Селектор ID товару на його сторінці';
$_['text_main_product_id_selector_faq']             = 'Цей селектор допоможе знайти ID товару на його сторінці.';
$_['text_route_to_system_add_method']               = 'Системний URL до функції додавання товару "В кошик"';
$_['text_route_to_system_add_method_faq']           = 'Цей селектор допоможе отримати системний URL (шлях) до функції додавання товару в корзину.';
$_['text_selector_module_call_status']              = 'Викликати модуль при натисканні на елементи';
$_['text_selector_module_call_status_faq']          = 'Ви можете налаштувати події кліка, які можуть викликати модуль.';
$_['text_selector_module_call']                     = 'Селектор для виклику модуля';
$_['text_selector_module_call_faq']                 = 'Цей селектор допоможе додати функцію виклику на обрані елементи. Ви можете ввести декілька значень, кожен запис має бути на новому рядку.';
$_['text_route_module_call_status']                 = 'Замінювати посилання на виклик модуля';
$_['text_route_module_call_status_faq']             = 'Ви можете викликати модуль при натисканні на посилання в вашому шаблоні.';
$_['text_route_module_call']                        = 'Селектор посилання на сторінку кошика';
$_['text_route_module_call_faq']                    = 'Цей селектор допоможе знайти html тег "a" і додати до нього функцію виклику модуля. Ви можете ввести декілька значень, кожен запис має бути на новому рядку.';
$_['text_selector_cart_update']                     = 'Селектор для поновлення блоку кошика';
$_['text_selector_cart_update_faq']                 = 'Цей селектор допоможе оновлювати блок кошика. Ви можете ввести декілька значень, кожен запис має бути інановой рядку.';
$_['text_sidebar_type']                             = 'Позиція бічної панелі';
$_['text_sidebar_left_side']                        = 'Ліва';
$_['text_sidebar_right_side']                       = 'Права';
$_['text_collapsible_show_type']                    = 'Стан статичного модуля за замовчуванням';
$_['text_collapsible_show_type_1']                  = 'Відкритий';
$_['text_collapsible_show_type_2']                  = 'Закритий';
$_['text_layout']                                   = 'Макет';
$_['text_layout_faq']                               = 'Ви можете вибрати макет, де буде відображатися модуль.';
$_['text_static_position']                          = 'Розташування на макеті';
$_['text_static_position_1']                        = 'Ліва колонка';
$_['text_static_position_2']                        = 'Права колонка';
$_['text_static_position_3']                        = 'Позиція зверху';
$_['text_static_position_4']                        = 'Позиція знизу';
$_['text_static_position_faq']                      = 'Ви можете вибрати розташування для макета, де буде відображатися модуль.';
$_['entry_sort_order']                              = 'Порядок сортування';
$_['text_sort_order_faq']                           = 'Ви можете вибрати порядок сортування.';

// Tab - Basic setting
$_['tab_basic_setting']                             = 'Базові налаштування';
$_['text_captcha_status']                           = 'Увімкнути Google reCAPTCHA';
$_['text_captcha_status_faq']                       = 'Вам необхідно зареєструвати віджет на <a href="https://www.google.com/recaptcha/intro/index.html" target="_blank"><u>Google reCAPTCHA сторінці</u></a>';
$_['text_captcha_site_key']                         = 'Google reCAPTCHA site key';
$_['text_captcha_secret_key']                       = 'Google reCAPTCHA secret key';
$_['text_declension_status']                        = 'Включити відмінювання слів для блоку кошика';
$_['text_declension_status_faq']                    = 'Ви можете відмінювати слова для блоку кошика, наприклад (1 товар, 2 товари, 10 товарів).';
$_['text_admin_alert_status']                       = 'Надіслати повідомлення адміністратору про новий запис';
$_['text_admin_email_for_notification']             = 'Email адміністратора';
$_['text_admin_email_for_notification_faq']         = 'Ви можете написати більш одного значення, в цьому випадку вони повинні бути розділені комою.';
$_['text_admin_email_template']                     = 'E-mail HTML-шаблон для повідомлень адміністратора про новий запис';
$_['text_admin_email_template_faq']                 = 'Ви можете відправити повідомлення по електронній пошті адміністратору про новий запис. Якщо вам потрібно показати індивідуальність, тоді ви повинні перейти на <b><a style="cursor:pointer;" onclick="$(\'[href=#email-template-constructor-block]\').click();">Конструктор html шаблонів</a></b> і створити свій шаблон.';
$_['text_user_alert_status']                        = 'Надіслати повідомлення користувачеві коли він зберіг кошик';
$_['entry_field_related']                           = 'Набір полів';
$_['entry_field_related_faq']                       = 'Вам необхідно налаштувати модуль, додавши поля.';
$_['text_user_email_template']                      = 'E-mail HTML-шаблон для повідомлень користувачеві коли він зберіг кошик';
$_['text_user_email_template_faq']                  = 'Ви можете відправити повідомлення по електронній пошті користувачу коли він зберіг кошик. Якщо вам потрібно показати індивідуальність, тоді ви повинні перейти на <b><a style="cursor:pointer;" onclick="$(\'[href=#email-template-constructor-block]\').click();">Конструктор html шаблонів</a></b> і створити свій шаблон.';
$_['text_user_email_template_reminder']             = 'E-mail HTML-шаблон для нагадувань користувачеві про збереженый кошик';
$_['text_user_email_template_reminder_faq']         = 'Ви можете відправити нагадування по електронній пошті користувачу про збережений кошик. Якщо вам потрібно показати індивідуальність, тоді ви повинні перейти на <b><a style="cursor:pointer;" onclick="$(\'[href=#email-template-constructor-block]\').click();">Конструктор html шаблонів</a></b> і створити свій шаблон.';
$_['text_module_checkout_popup']                    = 'Інтегрувати оформлення замовлення в спливаючий модуль';
$_['text_module_checkout_sidebar']                  = 'Інтегрувати оформлення замовлення в бічну панель';
$_['text_module_checkout_static']                   = 'Інтегрувати оформлення замовлення в статичний модуль';
$_['text_module_checkout_cart_page']                = 'Інтегрувати оформлення замовлення в сторінку кошика модуля';
$_['text_module_checkout_faq']                      = 'Ви можете інтегрувати оформлення замовлення з модуля «OCdevWizard Checkout», якщо він встановлений і налаштований у вашому магазині. Модуль «OCdevWizard Checkout» повинен бути встановлений, активований, включений і мати як мінімум один модуль зі значенням «Тип відображення» в положенні «Віджет для модуля OCdevWizard Cart».';
$_['text_direction_type']                           = 'Виберіть орієнтацію тексту в модулі';
$_['text_direction_type_1']                         = 'LTR (з ліва на право)';
$_['text_direction_type_2']                         = 'RTL (з права на ліво)';
$_['text_use_module_flatpickr_close_type']          = 'Як закривати віджет "Flatpickr"?';
$_['text_flatpickr_close_type_1']                   = 'Після вибору значення дати/часу';
$_['text_flatpickr_close_type_2']                   = 'Після кліка за межами блоку віджета';
$_['text_flatpickr_close_type_3']                   = 'При обох подій';
$_['text_minify_main_js']                           = 'Зменшувати/стискати основний JS файл модуля';
$_['text_minify_main_js_1']                         = 'Легкий рівень';
$_['text_minify_main_js_2']                         = 'Середній рівень';

// Tab - Layout setting
$_['text_show_on_dashboard']                        = 'Показати віджет на панелі управління адміністратора';
$_['text_show_on_top_notification']                 = 'Показати віджет у верхньому списку повідомлень адміністратора';
$_['tab_main_module_setting']                       = 'Основні налаштування';
$_['tab_popup_with_options_setting']                = 'Спливаюче вікно з опціями товару';
$_['tab_cart_page_setting']                         = 'Сторінка кошика';
$_['text_product_list_status']                      = 'Приховувати частину товарів в модулі';
$_['text_product_list_limit']                       = 'Приховувати частину товарів починаючи від';
$_['text_show_product_model_status']                = 'Відображати поле Model';
$_['text_show_product_ean']                         = 'Відображати поле EAN';
$_['text_show_product_jan']                         = 'Відображати поле JAN';
$_['text_show_product_isbn']                        = 'Відображати поле ISBN';
$_['text_show_product_mpn']                         = 'Відображати поле MPN';
$_['text_show_product_location']                    = 'Відображати поле Location';
$_['text_show_product_reward']                      = 'Відображати поле бонусні бали';
$_['text_show_product_stock']                       = 'Відображати поле наявність';
$_['text_show_product_tax']                         = 'Відображати поле ПДВ';
$_['text_show_product_option']                      = 'Відображати опції';
$_['text_show_main_product_image']                  = 'Відображати картинку товару';
$_['text_dementions_of_main_image']                 = 'Розміри картинки товару';
$_['text_warning_dementions_of_main_image']         = 'Якщо ви зміните ці розміри то вам потрібно додатково виконати стилізацію модуля під нові розміри.';
$_['text_show_save_record_button']                  = 'Відображати кнопку "Зберегти кошик"';
$_['text_select_terms']                             = 'Умови для форми';
$_['text_select_terms_faq']                         = 'Вимагати підтвердження з правилами перед відправкою форми.';
$_['text_show_checkout_button']                     = 'Відображати кнопку "Оформити"';
$_['text_route_to_chekout_page']                    = 'Системний URL для сторінки оформлення замовлення';
$_['text_cart_weight']                              = 'Відображати загальну вагу товарів';
$_['text_show_coupon']                              = 'Відображати блок Купонів';
$_['text_show_voucher']                             = 'Відображати блок Сертифікатів';
$_['text_show_reward']                              = 'Відображати блок Бонусних балів';
$_['text_show_shipping']                            = 'Відображати блок Розрахунку доставки';
$_['text_totals_status']                            = 'Відображати блок Разом';
$_['text_totals_status_1']                          = 'Після списку товарів';
$_['text_totals_status_2']                          = 'Перед кнопками в підвалі';
$_['text_extension_totals']                         = 'Що відображати в блоці Разом';
$_['text_description_status']                       = 'Показати опис';
$_['text_description_status_1']                     = 'Перед списком товарів';
$_['text_description_status_2']                     = 'Після списку товарів';
$_['text_description_status_3']                     = 'Перед кнопками в підвалі';
$_['text_option_image_status']                      = 'Відображати картинку опції товару';
$_['text_dementions_of_option_images']              = 'Розміри картинки опції товару';
$_['text_warning_dementions_of_option_images']      = 'Якщо ви зміните ці розміри то вам потрібно додатково виконати стилізацію модуля під нові розміри.';
$_['text_select_options']                           = 'Виберіть опції товару';
$_['text_select_options_faq']                       = 'Виберіть ті опції які хочете виводити в спливаючому вікні модуля.';
$_['text_show_go_to_product_button']                = 'Відображати кнопку "Відкрити товар"';
$_['text_popup_options_description_status']         = 'Показати опис';
$_['text_popup_options_description_status_1']       = 'Перед списком опцій товару';
$_['text_popup_options_description_status_2']       = 'Після списку опцій товару';

// Tab - Css setting
$_['tab_css_setting']                               = 'Налаштування CSS';
$_['text_edit_css']                                 = 'Редагувати головный файл стилів модуля';
$_['text_edit_css_rtl']                             = 'Редагувати файл стилів RTL';
$_['button_save_css']                               = 'Зберегти CSS';
$_['button_restore_css']                            = 'Відновити CSS за замовчуванням';

// Tab - Popup setting
$_['tab_popup_setting']                             = 'Налаштування спливаючого вікна';
$_['text_popup_animation_type']                     = 'Ефект анімації';
$_['text_popup_animation_type_1']                   = 'Без ефекту';
$_['text_popup_animation_type_2']                   = 'Zoom-in';
$_['text_popup_animation_type_3']                   = 'Zoom-out';
$_['text_popup_animation_type_4']                   = 'Move from left';
$_['text_popup_animation_type_5']                   = 'Move from top';
$_['text_popup_animation_type_6']                   = '3d flip';
$_['text_popup_animation_type_7']                   = 'Newspaper';
$_['text_popup_animation_type_faq']                 = 'Ефект анімації для спливаючого вікна.';
$_['text_popup_close_on_content_click']             = 'Закрити спливаюче вікно при натисканні на саме вікно';
$_['text_popup_close_on_bg_click']                  = 'Закрити спливаюче вікно при натисканні на задній фон';
$_['text_popup_close_btn_inside']                   = 'Закрити спливаюче вікно при натисканні на кнопку "Закрити" вгорі';
$_['text_popup_close_on_escape_key']                = 'Закрити спливаюче вікно на кнопку ESC';
$_['text_popup_align_top']                          = 'Відобразити спливаюче вікно у верхній частині екрану';
$_['text_popup_background_type']                    = 'Тип заднього фону';
$_['text_popup_background_type_1']                  = 'Відображати картинку';
$_['text_popup_background_type_2']                  = 'Відображати колір';
$_['text_background_color']                         = 'Колір фону';
$_['text_background_images']                        = 'Картинка для фону';
$_['text_loader_color']                             = 'Колір елемента завантаження';
$_['text_background_opacity']                       = 'Прозорість фону';
$_['text_background_opacity_faq']                   = '0 - абсолютно прозорий, 1 - абсолютно видимий.';

// Tab - Cron setting block
$_['tab_cron_setting']                              = 'Налаштування cron завдань';
$_['text_cron_task']                                = 'Виберіть завдання';
$_['text_cron_task_1']                              = 'Повідомити всіх, хто не сповіщений';
$_['text_cron_info_faq']                            = 'Для ефективних повідомлень вам потрібно використовувати завдання cron. Якщо ви не можете налаштувати cron - зверніться до служби технічної підтримки вашого сервера.';
$_['entry_technical_url_for_cron']                  = 'Технічний URL для завдання cron';
$_['entry_technical_url_for_cron_faq']              = 'Це технічний URL. Ви можете використовувати його, якщо розумієте, для чого воно і що з ним робити.';
$_['entry_cron_token']                              = 'Ключ доступу для cron';
$_['entry_cron_token_faq']                          = 'Вам необхідно створити ключ доступу для виконання завдань через cron. Не показувати цей ключ нікому.';

// Tab - Import/Export config setting
$_['tab_config_import_export_setting']              = 'Імпорт/Експорт головних налаштувань';
$_['button_export']                                 = 'Експорт';
$_['button_import']                                 = 'Імпорт';
$_['text_restore_from_external_file']               = 'Відновити з зовнішнього файлу';
$_['text_restore_from_local_file']                  = 'Відновити з локального сховища';
$_['text_export']                                   = 'Експортувати налаштування модуля';
$_['text_select_file']                              = 'Виберіть файл';

// Tab - Field constructor setting
$_['tab_field_constructor_setting']                 = 'Конструктор полів';
$_['text_add_field']                                = 'Додати поле';
$_['text_edit_field']                               = 'Редагувати поле';
$_['text_field_type']                               = 'Тип поля';
$_['text_field_type_group_2']                       = 'Поле введення';
$_['text_field_type_group_2_t_3']                   = 'Email';
$_['text_field_type_group_2_t_4']                   = 'Телефон';
$_['text_field_type_group_2_t_5']                   = 'Ім`я';
$_['text_field_type_group_2_t_6']                   = 'Прізвище';
$_['text_field_type_group_5']                       = 'Роздільник';
$_['text_field_type_group_5_t_1']                   = 'Заголовок блока';
$_['text_field_type_faq']                           = '<b>Email, Телефон, Ім`я, Прізвище</b> - ви можете використовувати цей тип поля, якщо вам потрібно автозаповнення даних від зареєстрованого користувача.';
$_['entry_title_status']                            = 'Відображати заголовок для поля';
$_['entry_placeholder_status']                      = 'Відображати placeholder для поля';
$_['entry_icon_status']                             = 'Відображати іконку для поля';
$_['entry_icon']                                    = 'Ікона для поля';
$_['entry_field_name']                              = 'Заголовок поля';
$_['entry_field_error_text']                        = 'Текст про помилку';
$_['entry_field_error_text_faq']                    = 'Введіть текст для повідомлення про помилку. Цей текст буде відображатися, коли поле не минуло перевірку.';
$_['entry_field_error_text_default']                = 'Це поле не повинно бути порожнім!';
$_['entry_field_placeholder']                       = 'Placeholder';
$_['entry_field_mask']                              = 'Маска для поля';
$_['text_field_mask_faq']                           = 'Маска для поля допомагає користувачеві з введенням, забезпечуючи визначений формат. Це може бути корисно для дат, чисел, телефонних номерів. Число «9» використовується для масковання значення. Наприклад, ви можете створити маску для поля телефон, для цього вам потрібно написати +38 (099) 999-99-99, в результаті користувач побачить це +38 (0__) ___-__-__';
$_['entry_css_id']                                  = 'CSS id';
$_['text_css_id_faq']                               = 'Введіть ім`я id CSS для своєї стилізації - наприклад, my_id';
$_['entry_css_class']                               = 'CSS class';
$_['text_css_class_faq']                            = 'Введіть ім`я класу CSS для своєї стилізації - наприклад, my_class';
$_['entry_description_status']                      = 'Відображати опис для поля';
$_['entry_validation_type']                         = 'Тип перевірки';
$_['entry_validation_type_1']                       = 'Без валидации';
$_['entry_validation_type_2']                       = 'Проверка на пустое значення';
$_['entry_validation_type_3']                       = 'Регулярное выражение';
$_['entry_validation_type_4']                       = 'Перевірка на хв і макс величину (тільки для чисел)';
$_['text_regex_rule_faq']                           = 'Ви можете використовувати регулярний вираз на основі функції PHP preg_match().';
$_['text_min_max_length_rule_faq']                  = 'Ви можете використовувати мінімальний і максимальний діапазон.';

// Tab - Import/Export field setting
$_['tab_field_import_export_setting']               = 'Імпорт/Експорт полів';

// Tab - Language basic setting
$_['tab_basic_language_setting']                    = 'Базові налаштування перекладу';
$_['text_cart_declension']                          = 'Свій текст для блоку кошика';
$_['text_cart_declension_faq']                      = '<kbd>{count_products}</kbd> - відображати кількість товарів<br/><kbd>{total}</kbd> - відображати разом<br/><kbd>{declension}товар|товара|товарів{/declension}</kbd> - конструкція для відмінювання слів';
$_['default_cart_declension']                       = '{count_products} {declension}товар|товара|товарів{/declension} - {total}';
$_['entry_name']                                    = 'Назва';
$_['default_name']                                  = 'Корзина покупок';
$_['text_module_call_button']                       = 'Свій текст для кнопки "В кошику"';
$_['text_module_call_button_faq']                   = 'Введіть свій текст для кнопки коли товар вже в кошику.';
$_['default_call_button']                           = '<i class=\'fa fa-check\'></i> <span class=\'hidden-xs hidden-sm hidden-md\'>В кошику</span>';
$_['default_call_button_for_oc1']                   = 'В кошику';
$_['text_module_call_button_product_page']          = 'Свій текст для кнопки "В кошику" на сторінці товару';
$_['text_module_call_button_product_page_faq']      = 'Введіть свій текст для кнопки на сторінці товару коли товар вже в кошику.';
$_['default_call_button_product_page']              = 'В кошику';
$_['text_module_add_to_button']                     = 'Свій текст для кнопки "Купити"';
$_['default_add_to_button']                         = '<i class=\'fa fa-shopping-cart\'></i> <span class=\'hidden-xs hidden-sm hidden-md\'>Купити</span>';
$_['default_add_to_button_for_oc1']                 = 'Купити';
$_['text_module_add_to_button_product_page']        = 'Свій текст для кнопки "Купити" на сторінці товару';
$_['default_add_to_button_product_page']            = 'Купити';
$_['text_module_save_button']                       = 'Свій текст для кнопки "Зберегти кошик"';
$_['text_module_save_button_faq']                   = 'Введіть свій текст для кнопки "Зберегти кошик".';
$_['default_save_button']                           = 'Зберегти кошик';
$_['text_module_checkout_button']                   = 'Свій текст для кнопки "Оформити"';
$_['text_module_checkout_button_faq']               = 'Введіть свій текст для кнопки "Оформити".';
$_['default_checkout_button']                       = 'Оформити';
$_['text_module_close_button']                      = 'Свій текст для кнопки "Продовжити покупки".';
$_['text_module_close_button_faq']                  = 'Введіть свій текст для кнопки "Продовжити покупки".';
$_['default_close_button']                          = 'Продовжити покупки';
$_['text_empty_message']                            = 'Свій текст коли кошик порожній';
$_['text_empty_message_faq']                        = 'Введіть свій текст для покупця коли кошик порожній.';
$_['default_empty_message']                         = 'На жаль, ваш кошик порожній';
$_['entry_description']                             = 'Опис';
$_['default_description']                           = 'Тут може бути ваш текст.';
$_['default_popup_options_name']                    = 'Опції товару';
$_['text_module_popup_options_checkout_button']     = 'Свій текст для кнопки "До товару"';
$_['text_module_popup_options_checkout_button_faq'] = 'Введіть свій текст для кнопки "До товару".';
$_['default_popup_options_checkout_button']         = 'До товару';
$_['text_module_popup_options_save_button']         = 'Свій текст для кнопки "Застосувати"';
$_['text_module_popup_options_save_button_faq']     = 'Введіть свій текст для кнопки "Застосувати".';
$_['default_popup_options_save_button']             = 'Застосувати';
$_['text_module_popup_options_close_button']        = 'Свій текст для кнопки "Продовжити покупки"';
$_['text_module_popup_options_close_button_faq']    = 'Введіть свій текст для кнопки "Продовжити покупки".';
$_['default_popup_options_close_button']            = 'Продовжити покупки';
$_['text_popup_options_description']                = 'Опис';
$_['default_popup_options_description']             = 'Тут може бути ваш текст.';
$_['default_cart_page_name']                        = 'Корзина покупок';
$_['default_cart_page_checkout_button']             = 'Оформити';
$_['default_cart_page_close_button']                = 'Продовжити покупки';
$_['default_cart_page_description']                 = 'Тут може бути ваш текст.';

// Tab - Record constructor setting
$_['tab_record_constructor_setting']                = 'Список запитів';
$_['text_info_record']                              = 'Інформація по запиту';
$_['text_autocomplete_faq']                         = 'Будь ласка, введіть пару букв, які відповідають першими літерами початку пошукового слова.';
$_['text_email_not_provided']                       = 'Email не вказано';
$_['text_store']                                    = 'Магазин';
$_['text_user_agent']                               = 'User agent';
$_['text_accept_language']                          = 'Accept language';
$_['text_referer']                                  = 'Referer';
$_['column_product_id']                             = 'ID';
$_['column_product_image']                          = 'Картинка';
$_['column_product_name']                           = 'Назва товару';
$_['column_product_quantity']                       = 'Кількість';
$_['column_product_model']                          = 'Модель';

// Tab - Import/Export record setting
$_['tab_record_import_export_setting']              = 'Импорт/Экспорт запитів';

// Tab - Banned constructor setting
$_['tab_banned_constructor_setting']                = 'Список блокувань';
$_['text_add_banned']                               = 'Додати блокування';
$_['text_edit_banned']                              = 'Редагувати блокування';
$_['entry_ip']                                      = 'IP';
$_['entry_email']                                   = 'Email';
$_['placeholder_ip']                                = 'Введіть ip';
$_['placeholder_email']                             = 'Введіть email';
$_['column_ip']                                     = 'IP';
$_['column_email']                                  = 'Email';

// Tab - Import/Export banned list setting
$_['tab_banned_import_export_setting']              = 'Импорт/Экспорт список блокувань';

// Tab - Email template constructor setting
$_['tab_email_template_constructor_setting']        = 'Конструктор email шаблонів';

// Tab - Modal email template general setting
$_['text_edit_email_template']                      = 'Редагувати email шаблон';
$_['text_add_email_template']                       = 'Додати email шаблон';
$_['text_assignment_email_template']                = 'Призначення';
$_['text_assignment_email_template_1']              = 'Для повідомлень адміністратору про новой запис';
$_['text_assignment_email_template_2']              = 'Для повідомлень користувачеві при збереженні кошика';
$_['text_assignment_email_template_3']              = 'Нагадування користувачу про збережений кошик';
$_['text_assignment_email_template_faq']            = '<b>Для повідомлень адміністратору про новой запис</b> - виберіть його для повідомлення по електронній пошті для адміністратора, коли клієнт зберіг свій кошик.<br><b>Для повідомлень користувачеві при збереженні кошика</b> - виберіть його для повідомлення по електронній пошті користувачу, коли він зберіг свій кошик.<br><b>Нагадування користувачу про збережений кошик</b> - виберіть його для повідомлення по електронній пошті користувачу, ви можете нагадати клієнту про його збережений кошик.';
$_['default_email_template_name']                   = 'Власний шаблон';
$_['text_email_template_subject']                   = 'Введіть заголовок';
$_['default_email_template_subject']                = '{store_name}';
$_['text_email_template_html']                      = 'Html шаблон';
$_['text_assignment_email_template_1_subject']      = '<b>Код-маска користувача</b><br>{email} - e-mail користувача<br>{firstname} - ім`я користувача<br>{lastname} - прізвище користувача<br>{telephone} - телефон користувача<br><b>Код-маска запису</b><br>{record_id} - id запису<br>{date_added} - дата створення запису<br><b>Код-маска магазину</b><br>{store_name} - назва магазину';
$_['text_assignment_email_template_1_template']     = '<b>Код-маска користувача</b><br>{email} - e-mail користувача<br>{firstname} - ім`я користувача<br>{lastname} - прізвище користувача<br>{telephone} - телефон користувача<br>{ip} - IP користувача<br><b>Код-маска запису</b><br>{record_id} - id запису<br>{fields} - значення з форми<br>{date_added} - дата створення запису<br>{products_list} - список продуктів, які були збережені користувачем<br>{referer} - посилання referer<br>{user_agent} - значення user_agent<br>{accept_language} - значення accept_language<br><b>Код-маска магазину</b><br>{store_name} - назва магазину<br>{store_address} - адреса магазину<br>{store_email} - e-mail магазина<br>{store_telephone} - телефон магазину<br>{store_fax} - факс магазину<br>{store_url} - посилання магазину';
$_['text_assignment_email_template_2_subject']      = '<b>Код-маска користувача</b><br>{email} - e-mail користувача<br>{firstname} - ім`я користувача<br>{lastname} - прізвище користувача<br>{telephone} - телефон користувача<br><b>Код-маска запису</b><br>{record_id} - id запису<br>{date_added} - дата створення запису<br><b>Код-маска магазину</b><br>{store_name} - назва магазину';
$_['text_assignment_email_template_2_template']     = '<b>Код-маска користувача</b><br>{email} - e-mail користувача<br>{firstname} - ім`я користувача<br>{lastname} - прізвище користувача<br>{telephone} - телефон користувача<br><b>Код-маска запису</b><br>{record_id} - id запису<br>{fields} - значення з форми<br>{date_added} - дата створення запису<br>{products_list} - список продуктів, які були збережені користувачем<br>{unsubscribe_url} - посилання для відписки від повідомлень<br><b>Код-маска для маркетинга</b><br>{selected_products} - ви можете використовувати товари, які ви вибрали<br>{products_from_category} - ви можете отримати товари з обраних категорій<br>{latest_products} - ви можете використовувати нові (недавно додані в магазин) товари<br>{bestseller_products} - ви можете використовувати товари які більш за всіх продано (з завершеним статусом замовлення)<br>{special_products} - ви можете використовувати акції (з активною спеціальної ціною) товари<br>{popular_products} - ви можете використовувати популярні (які переглядалися найбільше) товари<br>{products_from_brand} - ви можете використовувати товари від обраних брендів.<br><b>Код-маска магазину</b><br>{store_name} - назва магазину<br>{store_address} - адреса магазину<br>{store_email} - e-mail магазина<br>{store_telephone} - телефон магазину<br>{store_fax} - факс магазину<br>{store_url} - посилання магазину';
$_['text_assignment_email_template_3_subject']      = '<b>Код-маска користувача</b><br>{email} - e-mail користувача<br>{firstname} - ім`я користувача<br>{lastname} - прізвище користувача<br>{telephone} - телефон користувача<br><b>Код-маска запису</b><br>{record_id} - id запису<br>{date_added} - дата створення запису<br><b>Код-маска магазину</b><br>{store_name} - назва магазину';
$_['text_assignment_email_template_3_template']     = '<b>Код-маска користувача</b><br>{email} - e-mail користувача<br>{firstname} - ім`я користувача<br>{lastname} - прізвище користувача<br>{telephone} - телефон користувача<br><b>Код-маска запису</b><br>{record_id} - id запису<br>{fields} - значення з форми<br>{date_added} - дата створення запису<br>{products_list} - список продуктів, які були збережені користувачем<br>{unsubscribe_url} - посилання для відписки від повідомлень<br><b>Код-маска для маркетинга</b><br>{selected_products} - ви можете використовувати товари, які ви вибрали<br>{products_from_category} - ви можете отримати товари з обраних категорій<br>{latest_products} - ви можете використовувати нові (недавно додані в магазин) товари<br>{bestseller_products} - ви можете використовувати товари які більш за всіх продано (з завершеним статусом замовлення)<br>{special_products} - ви можете використовувати акції (з активною спеціальної ціною) товари<br>{popular_products} - ви можете використовувати популярні (які переглядалися найбільше) товари<br>{products_from_brand} - ви можете використовувати товари від обраних брендів.<br><b>Код-маска магазину</b><br>{store_name} - назва магазину<br>{store_address} - адреса магазину<br>{store_email} - e-mail магазина<br>{store_telephone} - телефон магазину<br>{store_fax} - факс магазину<br>{store_url} - посилання магазину';
$_['text_legend_related_product']                   = 'Налаштування для рекомендованих продуктів';
$_['text_legend_main_product']                      = 'Налаштування для головного товару';
$_['text_template_related_product_status']          = 'Відображати товари';
$_['text_template_related_product_status_1']        = 'З вибраних категорій';
$_['text_template_related_product_status_2']        = 'З обраних брендів';
$_['text_template_related_product_status_3']        = 'Вибрані';
$_['text_template_related_product_status_4']        = 'Новинки';
$_['text_template_related_product_status_5']        = 'Хіти продажів';
$_['text_template_related_product_status_6']        = 'Товари по акції';
$_['text_template_related_product_status_7']        = 'Популярні';
$_['text_template_related_product_status_faq']      = 'Ви можете відобразити рекомендовані товари в шаблоні, для цього вам потрібно додати спеціальний короткий код в поле "Html шаблон" і вибрати товари.';
$_['entry_product_related']                         = 'Вибрати товари';
$_['entry_category_related']                        = 'Вибрати категорії';
$_['entry_manufacturer_related']                    = 'Вибрати бренди';
$_['text_related_dementions_of_image']              = 'Розмір картинки';
$_['text_related_limit']                            = 'Ліміт рекомендованих товарів';
$_['text_related_description_limit']                = 'Довжина опису товару';
$_['text_related_show_image']                       = 'Показати картинку товару';
$_['text_related_show_price']                       = 'Показати ціну товару';
$_['text_related_show_name']                        = 'Показати назву товару';
$_['text_related_show_description']                 = 'Показати опис товару';
$_['text_related_randomize']                        = 'Виводити рекомендовані товари в випадковому порядку';
$_['entry_status']                                  = 'Статус';
$_['entry_system_name']                             = 'Системна назва';
$_['text_edit_template']                            = 'редагувати';
$_['text_no_email_templates']                       = 'Доступних шаблонів не виявлено. Вам потрібно <b><a style="cursor:pointer;" onclick="open_email_template(0);">створити хоча б один Email шаблон</a></b>.';

// Tab - Import/Export email template setting
$_['tab_email_template_import_export_setting']      = 'Імпорт/Експорт Email шаблонів';

// Tab - Marketing Tools setting
$_['tab_marketing_tools_main_setting']              = 'Маркетинг налаштування';
$_['text_module_recommended_products_popup']        = 'Інтегрувати рекомендовані товари в спливаючий модуль';
$_['text_module_recommended_products_sidebar']      = 'Інтегруваті рекомендовані товари в бічну панель';
$_['text_module_recommended_products_static']       = 'Інтегрувати рекомендовані товари в статичний модуль';
$_['text_module_recommended_products_cart_page']    = 'Інтегрувати рекомендовані товари в сторінку кошика';
$_['text_module_recommended_products_faq']          = 'Ви можете інтегрувати рекомендовані товари з модуля «OCdevWizard Recommended Products», якщо він встановлений і налаштований у вашому магазині. Модуль «OCdevWizard Recommended Products» повинен бути встановлений, активований, включений і мати принаймні один модуль зі значенням «Тип відображення» в положенні «Віджет для модуля OCdevWizard Cart».';

// Tab - License information
$_['tab_license_extension_setting']                 = 'Інформація про ліцензію';
$_['text_license_key']                              = 'Код активації';
$_['button_apply_license_code']                     = 'Застосувати ключ активації';
$_['text_license_text']                             = 'Тип ліцензії';
$_['text_license_holder']                           = 'Тримач ліцензії';
$_['text_license_expires']                          = 'Закінчується через';
$_['text_license_date_end']                         = '%s (%s залишилося)';
$_['text_license_expire_day_1']                     = 'день';
$_['text_license_expire_day_2']                     = 'днів';
$_['text_license_expire_forever']                   = 'Необмежено';
$_['text_license_end']                              = 'Закінчилася';
$_['button_renew_license']                          = 'Перевипустити';
$_['text_request_license_code']                     = 'Запросити код активації';
$_['text_license_expire_ended']                     = 'Ви використовуєте неліцензовану версію цього модуля! Ви не можете отримати безкоштовну технічну підтримку і використовувати свіжі оновлення, поки не активуєте цю ліцензію!';
$_['text_request_license_code_left_side']           = '<p>З кодом активації ви можете активувати модуль і використовувати його на своєму сайті відповідно до Ліцензійної угоди* на модуль.</p><p>Якщо у вас немає коду активації, натисніть кнопку нижче, щоб отримати його.</p><p>Будь ласка, не треба повторювати запит занадто часто, якщо ви відправили один з них раніше. Дочекайтеся відповіді від служби підтримки, зазвичай це займає пару хвилин, але в деяких випадках це може зайняти більше часу. Через 24 години можна надіслати запит ще раз.</p><p><button type="button" onclick="open_license_code_request();" class="btn btn-warning btn-sm"><i class="fa fa-envelope-o"></i> Запросити ключ активації</button></p><hr><div style="font-size: 11px;">* - ви можете знайти файл Ліцензійної угоди в ZIP-архіві модуля.</div>';
$_['text_request_license_code_right_side_1']        = '<p>Ось список офіційних сайтів, на яких ви можете купити модуль. Купуючи модуль тут, ви автоматично отримаєте безкоштовну технічну підтримку від розробника модуля протягом одного року.</p>';
$_['text_request_license_code_right_side_2']        = '<div style="font-size: 11px;">* - технічна підтримка надається безкоштовно. Зверніть увагу, що платна технічна підтримка виконується у випадках, коли існує конфлікт з сторонніми модулями/продуктами/шаблонами.</div>';

// Success
$_['text_success']                                  = 'Налаштування модуля '.$_['heading_title'].' змінені!';
$_['text_success_install']                          = 'Модуль '.$_['heading_title'].' успішно встановлений!';
$_['text_success_uninstall']                        = 'Модуль '.$_['heading_title'].' успішно видалено!';
$_['text_success_config_restored']                  = 'Налаштування модуля '.$_['heading_title'].' відновлені!';
$_['text_success_field_restored']                   = 'Список полів модуля '.$_['heading_title'].' відновлений!';
$_['text_success_record_restored']                  = 'Список повідомлень модуля '.$_['heading_title'].' відновлений!';
$_['text_success_banned_restored']                  = 'Список блокувань модуля '.$_['heading_title'].' відновлений!';
$_['text_success_email_template_restored']          = 'Email шаблони модуля '.$_['heading_title'].' відновлені!';
$_['text_success_cache']                            = 'Кеш модуля успішно очищений!';
$_['text_success_cache_backup']                     = 'Файли для відновлення успішно видалені!';
$_['text_success_task']                             = 'Завдання виконане успішно!';
$_['text_success_field_add']                        = 'Поле успішно створене!';
$_['text_success_field_edit']                       = 'Поле успішно змінене!';
$_['text_success_banned_add']                       = 'Блокування успішно створене!';
$_['text_success_banned_edit']                      = 'Блокування успішно змінене!';
$_['text_success_email_template_add']               = 'Email шаблон успішно створений!';
$_['text_success_email_template_edit']              = 'Email шаблон успішно змінений!';
$_['text_success_generate_sort_order']              = 'Порядок сортування успішно згенеровано!';
$_['text_success_generate_cron_token']              = 'Ключ доступу для cron успішно згенеровано!';
$_['text_success_css_saved']                        = 'Файл CSS успішно збережений!';
$_['text_success_css_restored']                     = 'Файл CSS успішно відновлено!';

// Error
$_['error_warning']                                 = 'Налаштування модуля не будуть збережені до тих пір, поки ви не виправите помилки. Будь ласка, уважно перевірте форму на наявність помилок!';
$_['error_permission']                              = 'У вас немає доступу змінювати модуль '.$_['heading_title'].'!';
$_['error_for_all_field']                           = 'Це поле не повинно бути порожнім!';
$_['error_for_all_field_1']                         = 'Це поле повинно бути менше ніж %s символів!';
$_['error_for_all_field_2']                         = 'Це поле повинно бути між %s і %s символами!';
$_['error_for_all_field_2_1_6']                     = 'Це поле повинно бути між 1 і 6 символами!';
$_['error_for_all_field_2_1_255']                   = 'Це поле повинно бути між 1 і 255 символами!';
$_['error_for_all_field_2_1_5000']                  = 'Це поле повинно бути між 1 і 5000 символами!';
$_['error_for_all_field_1_255']                     = 'Це поле повинно бути меньше ніж 255 символів!';
$_['error_for_all_field_1_5000']                    = 'Це поле повинно бути меньше ніж 5000 символів!';
$_['error_not_isset_field']                         = 'Вам потрібно додати хоча б одне поле!';
$_['error_not_isset_email_template']                = 'Вам потрібно додати хоча б один Email шаблон!';
$_['error_not_isset_email_field']                   = 'Вам необхідно додати поле Email!';
$_['error_generate_sort_order']                     = 'Поле "Порядок сортування" не повинно бути порожнім!';
$_['error_compatible_version']                      = 'Ви встановили несумісну версію модуля з вашим магазином!';
$_['error_task']                                    = 'Не вдалося виконати завдання!';
$_['error_failed_load_stylesheet']                  = 'Файл стилів не вдалося завантажити!';
$_['error_license_key']                             = 'Введіть ключ активації!';
$_['error_license_key_not_valid']                   = 'Ліцензійний ключ недійсний!';
$_['error_empty_email_template']                    = 'Потрібно <a style="cursor:pointer;" onclick="$(\'[href=#email-template-constructor-block]\').click();">створити</a>/<a style="cursor:pointer;" onclick="$(\'[href=#basic-block]\').click();">вибрати</a> Html шаблон!';
$_['error_template_preview']                        = 'Html шаблон не знанайдено!';
$_['error_for_field_data']                          = 'Ви повинні додати хоча б одне поле! Вам потрібно вибрати або <b><a style="cursor:pointer;" onclick="open_field(0);">спочатку створити одне поле</a></b>.';
$_['error_license_server']                          = 'На сервері ліцензування виконуються тимчасові технічні роботи. Функція збереження налаштувань модуля тимчасово відключена, для забезпечення цілісності цих даних. Спробуйте відновити роботу з цією сторінкою трохи пізніше. Дякуємо за розуміння і терпіння.';
$_['error_technical_url']                           = 'Технічний URL буде доступний після збереження налаштувань!';
$_['error_field_check_in_forms']                    = 'Це поле не можна видалити, так як воно використовується в модулі!';
$_['error_too_meny_type_fields']                    = 'Деякі поля мають однакові типи полів в «Наборі полів». Будь ласка, використовуйте поля з унікальним типом поля в наборі полів!';
$_['error_connection_waiting_limit_exceeded']       = 'Перевищено ліміт очікування з`єднання!';