<?php
##==========================================##
## @author    : OCdevWizard                 ##
## @contact   : ocdevwizard@gmail.com       ##
## @support   : http://help.ocdevwizard.com ##
## @copyright : (c) OCdevWizard. Cart, 2017 ##
##==========================================##
class ControllerExtensionOcdevwizardCart extends Controller {
  private $_name = 'cart';
  private $_code = 'ocdw_cart';
  private $_session_currency;
  private $_currency_code;

  public function __construct($registry) {
    parent::__construct($registry);

    if (version_compare(VERSION,'2.1.0.2.1','<=')) {
      $this->_session_currency = '';
      $this->_currency_code    = $this->currency->getCode();
    } else {
      $this->_session_currency = $this->_currency_code = $this->session->data['currency'];
    }
  }

  public function index() {
    if (isset($this->request->server['HTTP_X_REQUESTED_WITH']) && !empty($this->request->server['HTTP_X_REQUESTED_WITH']) && strtolower($this->request->server['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
      $data = [];

      $models = [
        'catalog/product',
        'tool/image',
        'extension/ocdevwizard/'.$this->_name,
        'extension/ocdevwizard/helper'
      ];

      if (version_compare(VERSION,'2.0.0.0','>=')) {
        $models[] = 'tool/upload';
      }

      if (version_compare(VERSION,'2.0.0.0','<') || version_compare(VERSION,'3.0.0.0','>=')) {
        $models[] = 'setting/extension';
      } else {
        $models[] = 'extension/extension';
      }

      foreach ($models as $model) {
        $this->load->model($model);
      }

      $display_type = (isset($this->request->post['display_type'])) ? (int)$this->request->post['display_type'] : die();

      $form_data = $this->model_extension_ocdevwizard_helper->getSettingData($this->_name.'_form_data',(int)$this->config->get('config_store_id'));
      $text_data = $this->model_extension_ocdevwizard_helper->getSettingData($this->_name.'_text_data',(int)$this->config->get('config_store_id'));

      $data = array_merge($data,$this->language->load('extension/ocdevwizard/'.$this->_name),$text_data,$form_data);

      if (!$form_data) {
        die();
      }

      $language_id = $this->{'model_extension_ocdevwizard_'.$this->_name}->getLanguageIdByCode($this->session->data['language']);

      $data['heading_title']              = (isset($text_data[$language_id])) ? html_entity_decode($text_data[$language_id]['name'],ENT_QUOTES,'UTF-8') : '';
      $data['text_empty']                 = (isset($text_data[$language_id])) ? html_entity_decode($text_data[$language_id]['empty_message'],ENT_QUOTES,'UTF-8') : '';
      $data['description']                = (isset($text_data[$language_id])) ? html_entity_decode($text_data[$language_id]['description'],ENT_QUOTES,'UTF-8') : '';
      $data['button_go_to_page']          = (isset($text_data[$language_id])) ? html_entity_decode($text_data[$language_id]['checkout_button'],ENT_QUOTES,'UTF-8') : '';
      $data['button_go_back']             = (isset($text_data[$language_id])) ? html_entity_decode($text_data[$language_id]['close_button'],ENT_QUOTES,'UTF-8') : '';
      $data['text_add_cart']              = (isset($text_data[$language_id])) ? html_entity_decode($text_data[$language_id]['add_to_button'],ENT_QUOTES,'UTF-8') : '';
      $data['text_add_cart_product_page'] = (isset($text_data[$language_id])) ? html_entity_decode($text_data[$language_id]['add_to_button_product_page'],ENT_QUOTES,'UTF-8') : '';
      $data['is_opencart_1']              = (version_compare(VERSION,'2.0.0.0','<')) ? 1 : 0;

      $data['_name']          = $this->_name;
      $data['_code']          = $this->_code;
      $data['_language_code'] = substr($this->session->data['language'],0,2);

      if (isset($this->request->post['remove'])) {
        $this->cart->remove($this->request->post['remove']);
        unset($this->session->data['vouchers'][$this->request->post['remove']]);
      }

      if (isset($this->request->post['update'])) {
        $this->cart->update($this->request->post['update'],$this->request->post['quantity']);
      }

      if (isset($this->request->post['add'])) {
        $this->cart->add($this->request->post['add'],$this->request->post['quantity']);
      }

      $data['page_link'] = $this->url->link($form_data['route_to_chekout_page'],'','SSL');

      $data['add_function_selectors'] = [];

      $add_function_selectors = explode(',',$form_data['add_function_selector']);

      if ($add_function_selectors) {
        foreach ($add_function_selectors as $add_function_selector) {
          $data['add_function_selectors'][] = html_entity_decode($add_function_selector);
        }
      }

      $data['add_id_selectors'] = [];

      $add_id_selectors = explode(',',$form_data['add_id_selector']);

      if ($add_id_selectors) {
        foreach ($add_id_selectors as $add_id_selector) {
          $data['add_id_selectors'][] = html_entity_decode($add_id_selector);
        }
      }

      $points                    = $this->customer->getRewardPoints();
      $data['text_reward_title'] = sprintf($this->language->get('text_reward_title_heading'),$points);

      // cart products
      if (!$this->cart->hasStock() && (!$this->config->get('config_stock_checkout') || $this->config->get('config_stock_warning'))) {
        $data['error_warning'] = $this->language->get('error_stock');
      } else if (isset($this->session->data['error'])) {
        $data['error_warning'] = $this->session->data['error'];

        unset($this->session->data['error']);
      } else {
        $data['error_warning'] = '';
      }

      $data['products']       = [];
      $data['total_products'] = count($this->cart->getProducts());

      $tag_codes = [
        '{count_products}',
      ];

      $tag_codes_replace = [
        count($this->cart->getProducts()) - $form_data['product_list_limit']
      ];

      $text_items = html_entity_decode($this->language->get('text_show_more_products'),ENT_QUOTES,'UTF-8');

      preg_match_all('/{declension}(.*?){\/declension}/',$this->language->get('text_show_more_products'),$text_items_matches,PREG_SET_ORDER);

      if ($text_items_matches) {
        foreach ($text_items_matches as $text_items_match) {
          preg_match('/{declension}(.*?){\/declension}/',$text_items_match[0],$text_items_match_item);

          if ((isset($text_items_match_item[0]) && $text_items_match_item[0]) && (isset($text_items_match_item[1]) && $text_items_match_item[1])) {
            $declension_words = explode("|",$text_items_match_item[1]);

            $declension_data = [
              'number' => (count($this->cart->getProducts()) > $form_data['product_list_limit']) ? (count($this->cart->getProducts()) - $form_data['product_list_limit']) : count($this->cart->getProducts()),
              'words'  => $declension_words
            ];

            if (version_compare(VERSION,'2.0.0.0','<')) {
              $text_items = str_replace($text_items_match_item[0],$this->getChild('extension/ocdevwizard/'.$this->_name.'/make_declension',$declension_data),$text_items);
            } else {
              $text_items = str_replace($text_items_match_item[0],$this->load->controller('extension/ocdevwizard/'.$this->_name.'/make_declension',$declension_data),$text_items);
            }
          }
        }
      }

      $data['button_show_more_products'] = html_entity_decode(str_replace($tag_codes,$tag_codes_replace,$text_items),ENT_QUOTES,'UTF-8');

      foreach ($this->cart->getProducts() as $product) {
        $product_info = $this->model_catalog_product->getProduct($product['product_id']);

        if ($product_info['quantity'] <= 0) {
          $stock_text = $product_info['stock_status'];
        } else if ($this->config->get('config_stock_display')) {
          $stock_text = $product['quantity'];
        } else {
          $stock_text = $this->language->get('text_instock');
        }

        $image = ($product['image']) ? $this->model_tool_image->resize($product['image'],$form_data['main_image_width'],$form_data['main_image_height']) : $this->model_tool_image->resize("no_image.png",$form_data['main_image_width'],$form_data['main_image_height']);

        $option_data = [];

        foreach ($product['option'] as $option) {
          if ($option['type'] != 'file') {
            if (version_compare(VERSION,'2.0.0.0','<')) {
              $value = $option['option_value'];
            } else {
              $value = $option['value'];
            }
          } else {
            if (version_compare(VERSION,'2.0.0.0','<')) {
              $filename = $this->encryption->decrypt($option['option_value']);
              $value    = utf8_substr($filename,0,utf8_strrpos($filename,'.'));
            } else {
              $upload_info = $this->model_tool_upload->getUploadByCode($option['value']);
              $value       = ($upload_info) ? $upload_info['name'] : '';
            }
          }

          $option_data[] = [
            'name'  => $option['name'],
            'value' => (utf8_strlen($value) > 20 ? utf8_substr($value,0,20).'..' : $value)
          ];
        }

        // display price
        $price = (($this->config->get('config_customer_price') && $this->customer->isLogged()) || !$this->config->get('config_customer_price')) ? $this->currency->format($this->tax->calculate($product['price'],$product['tax_class_id'],$this->config->get('config_tax')),$this->_session_currency) : false;

        // display tax
        if ($this->config->get('config_tax')) {
          $tax       = $this->currency->format((float)$product['price'],$this->_session_currency);
          $tax_total = $this->currency->format($product['price'] * $product['quantity'],$this->_session_currency);
        } else {
          $tax       = false;
          $tax_total = false;
        }

        // display unit total
        $product_total = (($this->config->get('config_customer_price') && $this->customer->isLogged()) || !$this->config->get('config_customer_price')) ? $this->currency->format($this->tax->calculate($product['price'],$product['tax_class_id'],$this->config->get('config_tax')) * $product['quantity'],$this->_session_currency) : false;

        if (version_compare(VERSION,'2.0.3.1','<=')) {
          $_product_key = $product['key'];
        } else {
          $_product_key = $product['cart_id'];
        }

        $data['products'][] = [
          'key'        => $_product_key,
          'product_id' => $product['product_id'],
          'thumb'      => $image,
          'name'       => $product['name'],
          'model'      => $product['model'],
          'ean'        => $product_info['ean'],
          'jan'        => $product_info['jan'],
          'isbn'       => $product_info['isbn'],
          'mpn'        => $product_info['mpn'],
          'location'   => $product_info['location'],
          'option'     => $option_data,
          'quantity'   => $product['quantity'],
          'minimum'    => $product['minimum'] > 0 ? $product['minimum'] : 1,
          'stock_text' => $stock_text,
          'stock'      => $product['stock'] ? true : !(!$this->config->get('config_stock_checkout') || $this->config->get('config_stock_warning')),
          'reward'     => $product['reward'] ? $product['reward'] : '',
          'price'      => $price,
          'tax'        => $tax,
          'tax_total'  => $tax_total,
          'total'      => $product_total,
          'href'       => $this->url->link('product/product','product_id='.$product['product_id']),
          'voucher'    => false
        ];
      }

      // gift voucher
      if (!empty($this->session->data['vouchers'])) {
        foreach ($this->session->data['vouchers'] as $key => $voucher) {
          $data['products'][] = [
            'key'        => $key,
            'product_id' => 0,
            'thumb'      => false,
            'name'       => $voucher['description'],
            'model'      => false,
            'ean'        => false,
            'jan'        => false,
            'isbn'       => false,
            'mpn'        => false,
            'location'   => false,
            'option'     => [],
            'quantity'   => 1,
            'stock_text' => false,
            'stock'      => true,
            'reward'     => '',
            'price'      => $this->currency->format($voucher['amount'],$this->_session_currency),
            'tax'        => false,
            'tax_total'  => false,
            'total'      => $this->currency->format($voucher['amount'],$this->_session_currency),
            'href'       => false,
            'voucher'    => true
          ];
        }
      }

      // totals
      if (version_compare(VERSION,'2.1.0.2.1','<=')) {
        $total_data = [];
        $total      = 0;
        $taxes      = $this->cart->getTaxes();
      } else {
        $totals = [];
        $taxes  = $this->cart->getTaxes();
        $total  = 0;

        // Because __call can not keep var references so we put them into an array.
        $total_data = [
          'totals' => &$totals,
          'taxes'  => &$taxes,
          'total'  => &$total
        ];
      }

      // display prices
      if (($this->config->get('config_customer_price') && $this->customer->isLogged()) || !$this->config->get('config_customer_price')) {
        $sort_order = [];

        if (version_compare(VERSION,'2.0.0.0','<') || version_compare(VERSION,'3.0.0.0','>=')) {
          $results = $this->model_setting_extension->getExtensions('total');
        } else {
          $results = $this->model_extension_extension->getExtensions('total');
        }

        foreach ($results as $key => $value) {
          if (version_compare(VERSION,'3.0.0.0','>=')) {
            $sort_order[$key] = $this->config->get('total_'.$value['code'].'_sort_order');
          } else {
            $sort_order[$key] = $this->config->get($value['code'].'_sort_order');
          }
        }

        array_multisort($sort_order,SORT_ASC,$results);

        foreach ($results as $result) {
          if (version_compare(VERSION,'3.0.0.0','>=')) {
            $_total_status = $this->config->get('total_'.$result['code'].'_status');
          } else {
            $_total_status = $this->config->get($result['code'].'_status');
          }

          if (version_compare(VERSION,'2.1.0.2.1','<=')) {
            $this->load->model('total/'.$result['code']);
            $this->{'model_total_'.$result['code']}->getTotal($total_data,$total,$taxes);
          } else {
            $this->load->model('extension/total/'.$result['code']);
            $this->{'model_extension_total_'.$result['code']}->getTotal($total_data);
          }

          $sort_order = [];

          if (version_compare(VERSION,'2.1.0.2.1','<=')) {
            foreach ($total_data as $key => $value) {
              $sort_order[$key] = $value['sort_order'];
            }

            array_multisort($sort_order,SORT_ASC,$total_data);
          } else {
            foreach ($totals as $key => $value) {
              $sort_order[$key] = $value['sort_order'];
            }

            array_multisort($sort_order,SORT_ASC,$totals);
          }
        }

        $data['totals'] = [];

        if (version_compare(VERSION,'2.1.0.2.1','<=')) {
          foreach ($total_data as $total) {
            if (isset($form_data['extension_totals']) && in_array($total['code'],$form_data['extension_totals'])) {
              $data['totals'][] = [
                'title' => $total['title'],
                'text'  => $this->currency->format($total['value'],$this->_session_currency)
              ];
            }
          }
        } else {
          foreach ($totals as $total) {
            if (isset($form_data['extension_totals']) && in_array($total['code'],$form_data['extension_totals'])) {
              $data['totals'][] = [
                'title' => $total['title'],
                'text'  => $this->currency->format($total['value'],$this->_session_currency)
              ];
            }
          }
        }
      }

      if ($form_data['cart_weight_status']) {
        $data['totals'][] = [
          'title' => $this->language->get('text_cart_weight'),
          'text'  => $this->weight->format($this->cart->getWeight(),$this->config->get('config_weight_class_id'),$this->language->get('decimal_point'),$this->language->get('thousand_point'))
        ];
      }

      $data['module_recommended_products'] = '';

      $recommended_products_form_data = (array)$this->model_extension_ocdevwizard_helper->getSettingData('recommended_products_form_data',(int)$this->config->get('config_store_id'));

      if (isset($recommended_products_form_data['activate']) && $recommended_products_form_data['activate'] && ($form_data['module_recommended_products_popup'] || $form_data['module_recommended_products_sidebar'])) {
        $this->load->model('extension/ocdevwizard/recommended_products');

        if ($display_type == 1) {
          $recommended_product_module_id = $form_data['module_recommended_products_popup'];
        } else if ($display_type == 2) {
          $recommended_product_module_id = $form_data['module_recommended_products_sidebar'];
        } else {
          $recommended_product_module_id = 0;
        }

        if (version_compare(VERSION,'2.0.0.0','<')) {
          $data['module_recommended_products'] = $this->getChild('extension/ocdevwizard/recommended_products/module',$this->model_extension_ocdevwizard_recommended_products->getModule($recommended_product_module_id));
        } else {
          $data['module_recommended_products'] = $this->load->controller('extension/ocdevwizard/recommended_products/module',$this->model_extension_ocdevwizard_recommended_products->getModule($recommended_product_module_id));
        }
      }

      $data['module_checkout'] = '';

      $checkout_form_data = (array)$this->model_extension_ocdevwizard_helper->getSettingData('checkout_form_data',(int)$this->config->get('config_store_id'));

      if (isset($checkout_form_data['activate']) && $checkout_form_data['activate'] && ($form_data['module_checkout_popup'] || $form_data['module_checkout_sidebar'])) {
        $this->load->model('extension/ocdevwizard/checkout');

        if ($display_type == 1) {
          $checkout_module_id = $form_data['module_checkout_popup'];
        } else if ($display_type == 2) {
          $checkout_module_id = $form_data['module_checkout_sidebar'];
        } else {
          $checkout_module_id = 0;
        }

        if (version_compare(VERSION,'2.0.0.0','<')) {
          $data['module_checkout'] = $this->getChild('extension/ocdevwizard/checkout/module',$this->model_extension_ocdevwizard_checkout->getModule($checkout_module_id));
        } else {
          $data['module_checkout'] = $this->load->controller('extension/ocdevwizard/checkout/module',$this->model_extension_ocdevwizard_checkout->getModule($checkout_module_id));
        }
      }

      if (version_compare(VERSION,'2.0.0.0','<')) {
        $data['coupon']        = $this->getChild('extension/ocdevwizard/'.$this->_name.'/coupon_index');
        $data['voucher']       = $this->getChild('extension/ocdevwizard/'.$this->_name.'/voucher_index');
        $data['reward']        = $this->getChild('extension/ocdevwizard/'.$this->_name.'/reward_index');
        $data['shipping']      = $this->getChild('extension/ocdevwizard/'.$this->_name.'/shipping_index');
        $data['save_products'] = $this->getChild('extension/ocdevwizard/'.$this->_name.'/save_products_index');
      } else {
        $data['coupon']        = $this->load->controller('extension/ocdevwizard/'.$this->_name.'/coupon_index');
        $data['voucher']       = $this->load->controller('extension/ocdevwizard/'.$this->_name.'/voucher_index');
        $data['reward']        = $this->load->controller('extension/ocdevwizard/'.$this->_name.'/reward_index');
        $data['shipping']      = $this->load->controller('extension/ocdevwizard/'.$this->_name.'/shipping_index');
        $data['save_products'] = $this->load->controller('extension/ocdevwizard/'.$this->_name.'/save_products_index');
      }

      if (version_compare(VERSION,'2.0.0.0','>=') && version_compare(VERSION,'2.1.0.2','<=')) {
        if ($display_type == 1) {
          if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/popup.tpl')) {
            $view = $this->load->view($this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/popup.tpl',$data);
          } else {
            $view = $this->load->view('default/template/extension/ocdevwizard/'.$this->_name.'/popup.tpl',$data);
          }
        } else if ($display_type == 2) {
          if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/sidebar.tpl')) {
            $view = $this->load->view($this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/sidebar.tpl',$data);
          } else {
            $view = $this->load->view('default/template/extension/ocdevwizard/'.$this->_name.'/sidebar.tpl',$data);
          }
        }

        $this->response->setOutput($view);
      } else if (version_compare(VERSION,'3.0.0.0','>=')) {
        if ($display_type == 1) {
          $this->response->setOutput($this->load->view('extension/ocdevwizard/'.$this->_name.'/popup',$data));
        } else if ($display_type == 2) {
          $this->response->setOutput($this->load->view('extension/ocdevwizard/'.$this->_name.'/sidebar',$data));
        }
      } else if (version_compare(VERSION,'2.0.0.0','<')) {
        $this->data = $data;

        if ($display_type == 1) {
          if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/popup.tpl')) {
            $this->template = $this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/popup.tpl';
          } else {
            $this->template = 'default/template/extension/ocdevwizard/'.$this->_name.'/popup.tpl';
          }
        } else if ($display_type == 2) {
          if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/sidebar.tpl')) {
            $this->template = $this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/sidebar.tpl';
          } else {
            $this->template = 'default/template/extension/ocdevwizard/'.$this->_name.'/sidebar.tpl';
          }
        }

        $this->response->setOutput($this->render());
      } else {
        if ($display_type == 1) {
          $this->response->setOutput($this->load->view('extension/ocdevwizard/'.$this->_name.'/popup.tpl',$data));
        } else if ($display_type == 2) {
          $this->response->setOutput($this->load->view('extension/ocdevwizard/'.$this->_name.'/sidebar.tpl',$data));
        }
      }
    }
  }

  public function module() {
    $data = [];

    $models = [
      'catalog/product',
      'tool/image',
      'extension/ocdevwizard/'.$this->_name,
      'extension/ocdevwizard/helper'
    ];

    if (version_compare(VERSION,'2.0.0.0','>=')) {
      $models[] = 'tool/upload';
    }

    if (version_compare(VERSION,'2.0.0.0','<') || version_compare(VERSION,'3.0.0.0','>=')) {
      $models[] = 'setting/extension';
    } else {
      $models[] = 'extension/extension';
    }

    foreach ($models as $model) {
      $this->load->model($model);
    }

    $form_data = $this->model_extension_ocdevwizard_helper->getSettingData($this->_name.'_form_data',(int)$this->config->get('config_store_id'));
    $text_data = $this->model_extension_ocdevwizard_helper->getSettingData($this->_name.'_text_data',(int)$this->config->get('config_store_id'));

    $data = array_merge($data,$this->language->load('extension/ocdevwizard/'.$this->_name),$text_data,$form_data);

    if (!$form_data) {
      die();
    }

    $language_id = $this->{'model_extension_ocdevwizard_'.$this->_name}->getLanguageIdByCode($this->session->data['language']);

    $data['heading_title']              = (isset($text_data[$language_id])) ? html_entity_decode($text_data[$language_id]['name'],ENT_QUOTES,'UTF-8') : '';
    $data['text_empty']                 = (isset($text_data[$language_id])) ? html_entity_decode($text_data[$language_id]['empty_message'],ENT_QUOTES,'UTF-8') : '';
    $data['description']                = (isset($text_data[$language_id])) ? html_entity_decode($text_data[$language_id]['description'],ENT_QUOTES,'UTF-8') : '';
    $data['button_go_to_page']          = (isset($text_data[$language_id])) ? html_entity_decode($text_data[$language_id]['checkout_button'],ENT_QUOTES,'UTF-8') : '';
    $data['button_go_back']             = (isset($text_data[$language_id])) ? html_entity_decode($text_data[$language_id]['close_button'],ENT_QUOTES,'UTF-8') : '';
    $data['text_add_cart']              = (isset($text_data[$language_id])) ? html_entity_decode($text_data[$language_id]['add_to_button'],ENT_QUOTES,'UTF-8') : '';
    $data['text_add_cart_product_page'] = (isset($text_data[$language_id])) ? html_entity_decode($text_data[$language_id]['add_to_button_product_page'],ENT_QUOTES,'UTF-8') : '';
    $data['is_opencart_1']              = (version_compare(VERSION,'2.0.0.0','<')) ? 1 : 0;

    $data['_name']          = $this->_name;
    $data['_code']          = $this->_code;
    $data['_language_code'] = substr($this->session->data['language'],0,2);

    if (isset($this->request->post['remove'])) {
      $this->cart->remove($this->request->post['remove']);
      unset($this->session->data['vouchers'][$this->request->post['remove']]);
    }

    if (isset($this->request->post['update'])) {
      $this->cart->update($this->request->post['update'],$this->request->post['quantity']);
    }

    if (isset($this->request->post['add'])) {
      $this->cart->add($this->request->post['add'],$this->request->post['quantity']);
    }

    $data['page_link'] = $this->url->link($form_data['route_to_chekout_page'],'','SSL');

    $data['add_function_selectors'] = [];

    $add_function_selectors = explode(',',$form_data['add_function_selector']);

    if ($add_function_selectors) {
      foreach ($add_function_selectors as $add_function_selector) {
        $data['add_function_selectors'][] = html_entity_decode($add_function_selector);
      }
    }

    $data['add_id_selectors'] = [];

    $add_id_selectors = explode(',',$form_data['add_id_selector']);

    if ($add_id_selectors) {
      foreach ($add_id_selectors as $add_id_selector) {
        $data['add_id_selectors'][] = html_entity_decode($add_id_selector);
      }
    }

    $points                    = $this->customer->getRewardPoints();
    $data['text_reward_title'] = sprintf($this->language->get('text_reward_title_heading'),$points);

    // cart products
    if (!$this->cart->hasStock() && (!$this->config->get('config_stock_checkout') || $this->config->get('config_stock_warning'))) {
      $data['error_warning'] = $this->language->get('error_stock');
    } else if (isset($this->session->data['error'])) {
      $data['error_warning'] = $this->session->data['error'];

      unset($this->session->data['error']);
    } else {
      $data['error_warning'] = '';
    }

    $data['products']       = [];
    $data['total_products'] = count($this->cart->getProducts());

    $tag_codes = [
      '{count_products}',
    ];

    $tag_codes_replace = [
      count($this->cart->getProducts()) - $form_data['product_list_limit']
    ];

    $text_items = html_entity_decode($this->language->get('text_show_more_products'),ENT_QUOTES,'UTF-8');

    preg_match_all('/{declension}(.*?){\/declension}/',$this->language->get('text_show_more_products'),$text_items_matches,PREG_SET_ORDER);

    if ($text_items_matches) {
      foreach ($text_items_matches as $text_items_match) {
        preg_match('/{declension}(.*?){\/declension}/',$text_items_match[0],$text_items_match_item);

        if ((isset($text_items_match_item[0]) && $text_items_match_item[0]) && (isset($text_items_match_item[1]) && $text_items_match_item[1])) {
          $declension_words = explode("|",$text_items_match_item[1]);

          $declension_data = [
            'number' => (count($this->cart->getProducts()) > $form_data['product_list_limit']) ? (count($this->cart->getProducts()) - $form_data['product_list_limit']) : count($this->cart->getProducts()),
            'words'  => $declension_words
          ];

          if (version_compare(VERSION,'2.0.0.0','<')) {
            $text_items = str_replace($text_items_match_item[0],$this->getChild('extension/ocdevwizard/'.$this->_name.'/make_declension',$declension_data),$text_items);
          } else {
            $text_items = str_replace($text_items_match_item[0],$this->load->controller('extension/ocdevwizard/'.$this->_name.'/make_declension',$declension_data),$text_items);
          }
        }
      }
    }

    $data['button_show_more_products'] = html_entity_decode(str_replace($tag_codes,$tag_codes_replace,$text_items),ENT_QUOTES,'UTF-8');

    foreach ($this->cart->getProducts() as $product) {
      $product_info = $this->model_catalog_product->getProduct($product['product_id']);

      if ($product_info['quantity'] <= 0) {
        $stock_text = $product_info['stock_status'];
      } else if ($this->config->get('config_stock_display')) {
        $stock_text = $product['quantity'];
      } else {
        $stock_text = $this->language->get('text_instock');
      }

      $image = ($product['image']) ? $this->model_tool_image->resize($product['image'],$form_data['main_image_width'],$form_data['main_image_height']) : $this->model_tool_image->resize("no_image.png",$form_data['main_image_width'],$form_data['main_image_height']);

      $option_data = [];

      foreach ($product['option'] as $option) {
        if ($option['type'] != 'file') {
          if (version_compare(VERSION,'2.0.0.0','<')) {
            $value = $option['option_value'];
          } else {
            $value = $option['value'];
          }
        } else {
          if (version_compare(VERSION,'2.0.0.0','<')) {
            $filename = $this->encryption->decrypt($option['option_value']);
            $value    = utf8_substr($filename,0,utf8_strrpos($filename,'.'));
          } else {
            $upload_info = $this->model_tool_upload->getUploadByCode($option['value']);
            $value       = ($upload_info) ? $upload_info['name'] : '';
          }
        }

        $option_data[] = [
          'name'  => $option['name'],
          'value' => (utf8_strlen($value) > 20 ? utf8_substr($value,0,20).'..' : $value)
        ];
      }

      // display price
      $price = (($this->config->get('config_customer_price') && $this->customer->isLogged()) || !$this->config->get('config_customer_price')) ? $this->currency->format($this->tax->calculate($product['price'],$product['tax_class_id'],$this->config->get('config_tax')),$this->_session_currency) : false;

      // display tax
      if ($this->config->get('config_tax')) {
        $tax       = $this->currency->format((float)$product['price'],$this->_session_currency);
        $tax_total = $this->currency->format($product['price'] * $product['quantity'],$this->_session_currency);
      } else {
        $tax       = false;
        $tax_total = false;
      }

      // display unit total
      $product_total = (($this->config->get('config_customer_price') && $this->customer->isLogged()) || !$this->config->get('config_customer_price')) ? $this->currency->format($this->tax->calculate($product['price'],$product['tax_class_id'],$this->config->get('config_tax')) * $product['quantity'],$this->_session_currency) : false;

      if (version_compare(VERSION,'2.0.3.1','<=')) {
        $_product_key = $product['key'];
      } else {
        $_product_key = $product['cart_id'];
      }

      $data['products'][] = [
        'key'        => $_product_key,
        'product_id' => $product['product_id'],
        'thumb'      => $image,
        'name'       => $product['name'],
        'model'      => $product['model'],
        'ean'        => $product_info['ean'],
        'jan'        => $product_info['jan'],
        'isbn'       => $product_info['isbn'],
        'mpn'        => $product_info['mpn'],
        'location'   => $product_info['location'],
        'option'     => $option_data,
        'quantity'   => $product['quantity'],
        'minimum'    => $product['minimum'] > 0 ? $product['minimum'] : 1,
        'stock_text' => $stock_text,
        'stock'      => $product['stock'] ? true : !(!$this->config->get('config_stock_checkout') || $this->config->get('config_stock_warning')),
        'reward'     => $product['reward'] ? $product['reward'] : '',
        'price'      => $price,
        'tax'        => $tax,
        'tax_total'  => $tax_total,
        'total'      => $product_total,
        'href'       => $this->url->link('product/product','product_id='.$product['product_id']),
        'voucher'    => false
      ];
    }

    // gift voucher
    if (!empty($this->session->data['vouchers'])) {
      foreach ($this->session->data['vouchers'] as $key => $voucher) {
        $data['products'][] = [
          'key'        => $key,
          'product_id' => 0,
          'thumb'      => false,
          'name'       => $voucher['description'],
          'model'      => false,
          'ean'        => false,
          'jan'        => false,
          'isbn'       => false,
          'mpn'        => false,
          'location'   => false,
          'option'     => [],
          'quantity'   => 1,
          'stock_text' => false,
          'stock'      => true,
          'reward'     => '',
          'price'      => $this->currency->format($voucher['amount'],$this->_session_currency),
          'tax'        => false,
          'tax_total'  => false,
          'total'      => $this->currency->format($voucher['amount'],$this->_session_currency),
          'href'       => false,
          'voucher'    => true
        ];
      }
    }

    // totals
    if (version_compare(VERSION,'2.1.0.2.1','<=')) {
      $total_data = [];
      $total      = 0;
      $taxes      = $this->cart->getTaxes();
    } else {
      $totals = [];
      $taxes  = $this->cart->getTaxes();
      $total  = 0;

      // Because __call can not keep var references so we put them into an array.
      $total_data = [
        'totals' => &$totals,
        'taxes'  => &$taxes,
        'total'  => &$total
      ];
    }

    $data['text_cart_items'] = '';

    // display prices
    if (($this->config->get('config_customer_price') && $this->customer->isLogged()) || !$this->config->get('config_customer_price')) {
      $sort_order = [];

      if (version_compare(VERSION,'2.0.0.0','<') || version_compare(VERSION,'3.0.0.0','>=')) {
        $results = $this->model_setting_extension->getExtensions('total');
      } else {
        $results = $this->model_extension_extension->getExtensions('total');
      }

      foreach ($results as $key => $value) {
        if (version_compare(VERSION,'3.0.0.0','>=')) {
          $sort_order[$key] = $this->config->get('total_'.$value['code'].'_sort_order');
        } else {
          $sort_order[$key] = $this->config->get($value['code'].'_sort_order');
        }
      }

      array_multisort($sort_order,SORT_ASC,$results);

      foreach ($results as $result) {
        if (version_compare(VERSION,'3.0.0.0','>=')) {
          $_total_status = $this->config->get('total_'.$result['code'].'_status');
        } else {
          $_total_status = $this->config->get($result['code'].'_status');
        }

        if (version_compare(VERSION,'2.1.0.2.1','<=')) {
          $this->load->model('total/'.$result['code']);
          $this->{'model_total_'.$result['code']}->getTotal($total_data,$total,$taxes);
        } else {
          $this->load->model('extension/total/'.$result['code']);
          $this->{'model_extension_total_'.$result['code']}->getTotal($total_data);
        }

        $sort_order = [];

        if (version_compare(VERSION,'2.1.0.2.1','<=')) {
          foreach ($total_data as $key => $value) {
            $sort_order[$key] = $value['sort_order'];
          }

          array_multisort($sort_order,SORT_ASC,$total_data);
        } else {
          foreach ($totals as $key => $value) {
            $sort_order[$key] = $value['sort_order'];
          }

          array_multisort($sort_order,SORT_ASC,$totals);
        }
      }

      if ($form_data['declension_status']) {
        if (isset($text_data[$language_id])) {
          $tag_codes = [
            '{count_products}',
            '{total}'
          ];

          $tag_codes_replace = [
            $this->cart->countProducts() + (isset($this->session->data['vouchers']) ? count($this->session->data['vouchers']) : 0),
            $this->currency->format($total,$this->_session_currency)
          ];

          $text_items = html_entity_decode($text_data[$language_id]['cart_declension'],ENT_QUOTES,'UTF-8');

          preg_match_all('/{declension}(.*?){\/declension}/',$text_items,$text_items_matches,PREG_SET_ORDER);

          if ($text_items_matches) {
            foreach ($text_items_matches as $text_items_match) {
              preg_match('/{declension}(.*?){\/declension}/',$text_items_match[0],$text_items_match_item);

              if ((isset($text_items_match_item[0]) && $text_items_match_item[0]) && (isset($text_items_match_item[1]) && $text_items_match_item[1])) {
                $declension_words = explode("|",$text_items_match_item[1]);

                $declension_data = [
                  'number' => $this->cart->countProducts() + (isset($this->session->data['vouchers']) ? count($this->session->data['vouchers']) : 0),
                  'words'  => $declension_words
                ];

                if (version_compare(VERSION,'2.0.0.0','<')) {
                  $text_items = str_replace($text_items_match_item[0],$this->getChild('extension/ocdevwizard/'.$this->_name.'/make_declension',$declension_data),$text_items);
                } else {
                  $text_items = str_replace($text_items_match_item[0],$this->load->controller('extension/ocdevwizard/'.$this->_name.'/make_declension',$declension_data),$text_items);
                }
              }
            }
          }

          $data['text_cart_items'] = html_entity_decode(str_replace($tag_codes,$tag_codes_replace,$text_items),ENT_QUOTES,'UTF-8');
        } else {
          $data['text_cart_items'] = sprintf($this->language->get('text_cart_items'),$this->cart->countProducts() + (isset($this->session->data['vouchers']) ? count($this->session->data['vouchers']) : 0),$this->currency->format($total,$this->_session_currency));
        }
      } else {
        $data['text_cart_items'] = sprintf($this->language->get('text_cart_items'),$this->cart->countProducts() + (isset($this->session->data['vouchers']) ? count($this->session->data['vouchers']) : 0),$this->currency->format($total,$this->_session_currency));
      }

      $data['totals'] = [];

      if (version_compare(VERSION,'2.1.0.2.1','<=')) {
        foreach ($total_data as $total) {
          if (isset($form_data['extension_totals']) && in_array($total['code'],$form_data['extension_totals'])) {
            $data['totals'][] = [
              'title' => $total['title'],
              'text'  => $this->currency->format($total['value'],$this->_session_currency)
            ];
          }
        }
      } else {
        foreach ($totals as $total) {
          if (isset($form_data['extension_totals']) && in_array($total['code'],$form_data['extension_totals'])) {
            $data['totals'][] = [
              'title' => $total['title'],
              'text'  => $this->currency->format($total['value'],$this->_session_currency)
            ];
          }
        }
      }
    }

    if ($form_data['cart_weight_status']) {
      $data['totals'][] = [
        'title' => $this->language->get('text_cart_weight'),
        'text'  => $this->weight->format($this->cart->getWeight(),$this->config->get('config_weight_class_id'),$this->language->get('decimal_point'),$this->language->get('thousand_point'))
      ];
    }

    $data['module_recommended_products'] = '';

    $recommended_products_form_data = (array)$this->model_extension_ocdevwizard_helper->getSettingData('recommended_products_form_data',(int)$this->config->get('config_store_id'));

    if (isset($recommended_products_form_data['activate']) && $recommended_products_form_data['activate'] && $form_data['module_recommended_products_static']) {
      $this->load->model('extension/ocdevwizard/recommended_products');

      if (version_compare(VERSION,'2.0.0.0','<')) {
        $data['module_recommended_products'] = $this->getChild('extension/ocdevwizard/recommended_products/module',$this->model_extension_ocdevwizard_recommended_products->getModule($form_data['module_recommended_products_static']));
      } else {
        $data['module_recommended_products'] = $this->load->controller('extension/ocdevwizard/recommended_products/module',$this->model_extension_ocdevwizard_recommended_products->getModule($form_data['module_recommended_products_static']));
      }
    }

    $data['module_checkout'] = '';

    $checkout_form_data = (array)$this->model_extension_ocdevwizard_helper->getSettingData('checkout_form_data',(int)$this->config->get('config_store_id'));

    if (isset($checkout_form_data['activate']) && $checkout_form_data['activate'] && $form_data['module_checkout_static']) {
      $this->load->model('extension/ocdevwizard/checkout');

      if (version_compare(VERSION,'2.0.0.0','<')) {
        $data['module_checkout'] = $this->getChild('extension/ocdevwizard/checkout/module',$this->model_extension_ocdevwizard_checkout->getModule($form_data['module_checkout_static']));
      } else {
        $data['module_checkout'] = $this->load->controller('extension/ocdevwizard/checkout/module',$this->model_extension_ocdevwizard_checkout->getModule($form_data['module_checkout_static']));
      }
    }

    if (version_compare(VERSION,'2.0.0.0','<')) {
      $data['coupon']        = $this->getChild('extension/ocdevwizard/'.$this->_name.'/coupon_index');
      $data['voucher']       = $this->getChild('extension/ocdevwizard/'.$this->_name.'/voucher_index');
      $data['reward']        = $this->getChild('extension/ocdevwizard/'.$this->_name.'/reward_index');
      $data['shipping']      = $this->getChild('extension/ocdevwizard/'.$this->_name.'/shipping_index');
      $data['save_products'] = $this->getChild('extension/ocdevwizard/'.$this->_name.'/save_products_index');
    } else {
      $data['coupon']        = $this->load->controller('extension/ocdevwizard/'.$this->_name.'/coupon_index');
      $data['voucher']       = $this->load->controller('extension/ocdevwizard/'.$this->_name.'/voucher_index');
      $data['reward']        = $this->load->controller('extension/ocdevwizard/'.$this->_name.'/reward_index');
      $data['shipping']      = $this->load->controller('extension/ocdevwizard/'.$this->_name.'/shipping_index');
      $data['save_products'] = $this->load->controller('extension/ocdevwizard/'.$this->_name.'/save_products_index');
    }

    if (isset($this->request->post['remove']) || isset($this->request->post['update']) || isset($this->request->post['add']) || isset($this->request->post['static_load'])) {
      if (version_compare(VERSION,'2.0.0.0','>=') && version_compare(VERSION,'2.1.0.2.1','<=')) {
        if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/static.tpl')) {
          $view = $this->load->view($this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/static.tpl',$data);
        } else {
          $view = $this->load->view('default/template/extension/ocdevwizard/'.$this->_name.'/static.tpl',$data);
        }

        $this->response->setOutput($view);
      } else if (version_compare(VERSION,'3.0.0.0','>=')) {
        $this->response->setOutput($this->load->view('extension/ocdevwizard/'.$this->_name.'/static',$data));
      } else if (version_compare(VERSION,'2.0.0.0','<')) {
        $this->data = $data;

        if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/static.tpl')) {
          $this->template = $this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/static.tpl';
        } else {
          $this->template = 'default/template/extension/ocdevwizard/'.$this->_name.'/static.tpl';
        }

        $this->response->setOutput($this->render());
      } else {
        $this->response->setOutput($this->load->view('extension/ocdevwizard/'.$this->_name.'/static.tpl',$data));
      }
    } else {
      if (version_compare(VERSION,'2.0.0.0','>=') && version_compare(VERSION,'2.1.0.2.1','<=')) {
        if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/static.tpl')) {
          return $this->load->view($this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/static.tpl',$data);
        } else {
          return $this->load->view('default/template/extension/ocdevwizard/'.$this->_name.'/static.tpl',$data);
        }
      } else if (version_compare(VERSION,'3.0.0.0','>=')) {
        return $this->load->view('extension/ocdevwizard/'.$this->_name.'/static',$data);
      } else if (version_compare(VERSION,'2.0.0.0','<')) {
        $this->data = $data;

        if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/static.tpl')) {
          $this->template = $this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/static.tpl';
        } else {
          $this->template = 'default/template/extension/ocdevwizard/'.$this->_name.'/static.tpl';
        }

        $this->render();
      } else {
        return $this->load->view('extension/ocdevwizard/'.$this->_name.'/static.tpl',$data);
      }
    }
  }

  public function options() {
    if (isset($this->request->server['HTTP_X_REQUESTED_WITH']) && !empty($this->request->server['HTTP_X_REQUESTED_WITH']) && strtolower($this->request->server['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
      $data = [];

      if (isset($this->request->post['product_id']) && !empty($this->request->post['product_id'])) {
        $data['product_id'] = $product_id = $this->request->post['product_id'];
      } else {
        $data['product_id'] = $product_id = 0;
      }

      $models = [
        'catalog/product',
        'tool/image',
        'extension/ocdevwizard/'.$this->_name,
        'extension/ocdevwizard/helper'
      ];

      foreach ($models as $model) {
        $this->load->model($model);
      }

      $product_info = $this->model_catalog_product->getProduct($product_id);

      if (!$product_info) {
        die();
      }

      if ($product_info) {
        $text_data = (array)$this->model_extension_ocdevwizard_helper->getSettingData($this->_name.'_text_data',(int)$this->config->get('config_store_id'));
        $form_data = (array)$this->model_extension_ocdevwizard_helper->getSettingData($this->_name.'_form_data',(int)$this->config->get('config_store_id'));

        $data = array_merge($data,$this->language->load('extension/ocdevwizard/'.$this->_name),$text_data,$form_data);

        $language_id = $this->{'model_extension_ocdevwizard_'.$this->_name}->getLanguageIdByCode($this->session->data['language']);

        $data['heading_title']     = (isset($text_data[$language_id])) ? html_entity_decode($text_data[$language_id]['popup_options_name'],ENT_QUOTES,'UTF-8') : '';
        $data['description']       = (isset($text_data[$language_id])) ? html_entity_decode($text_data[$language_id]['popup_options_description'],ENT_QUOTES,'UTF-8') : '';
        $data['button_save']       = (isset($text_data[$language_id])) ? html_entity_decode($text_data[$language_id]['popup_options_save_button'],ENT_QUOTES,'UTF-8') : '';
        $data['button_go_to_page'] = (isset($text_data[$language_id])) ? html_entity_decode($text_data[$language_id]['popup_options_checkout_button'],ENT_QUOTES,'UTF-8') : '';
        $data['button_go_back']    = (isset($text_data[$language_id])) ? html_entity_decode($text_data[$language_id]['popup_options_close_button'],ENT_QUOTES,'UTF-8') : '';
        $data['is_opencart_1']     = (version_compare(VERSION,'2.0.0.0','<')) ? 1 : 0;

        $data['_name']          = $this->_name;
        $data['_code']          = $this->_code;
        $data['_language_code'] = substr($this->session->data['language'],0,2);
        $data['date_today']     = date("Y-m-d H:i");

        $data['page_link'] = $this->url->link('product/product','product_id='.$product_id);

        $data['options'] = [];

        if (isset($form_data['product_options_array'])) {
          foreach ((array)$this->model_catalog_product->getProductOptions($product_id) as $option) {
            if (in_array($option['option_id'],$form_data['product_options_array'])) {
              if (version_compare(VERSION,'2.0.0.0','<')) {
                if ($option['type'] == 'select' || $option['type'] == 'radio' || $option['type'] == 'checkbox' || $option['type'] == 'image') {
                  $option_value_data = [];

                  foreach ($option['option_value'] as $option_value) {
                    if (!$option_value['subtract'] || ($option_value['quantity'] > 0)) {
                      $price = ((($this->config->get('config_customer_price') && $this->customer->isLogged()) || !$this->config->get('config_customer_price')) && (float)$option_value['price']) ? $this->currency->format($this->tax->calculate($option_value['price'],$product_info['tax_class_id'],$this->config->get('config_tax'))) : false;

                      $option_image = ($option_value['image']) ? $this->model_tool_image->resize($option_value['image'],$form_data['option_images_width'],$form_data['option_images_height']) : $this->model_tool_image->resize("no_image.png",$form_data['option_images_width'],$form_data['option_images_height']);

                      $option_value_data[] = [
                        'product_option_value_id' => $option_value['product_option_value_id'],
                        'option_value_id'         => $option_value['option_value_id'],
                        'name'                    => $option_value['name'],
                        'image'                   => $option_image,
                        'price'                   => $price,
                        'price_prefix'            => $option_value['price_prefix']
                      ];
                    }
                  }

                  $data['options'][] = [
                    'product_option_id' => $option['product_option_id'],
                    'option_value'      => $option_value_data,
                    'option_id'         => $option['option_id'],
                    'name'              => $option['name'],
                    'type'              => $option['type'],
                    'required'          => $option['required']
                  ];
                } else if ($option['type'] == 'text' || $option['type'] == 'textarea' || $option['type'] == 'file' || $option['type'] == 'date' || $option['type'] == 'datetime' || $option['type'] == 'time') {
                  $data['options'][] = [
                    'product_option_id' => $option['product_option_id'],
                    'option_value'      => $option['option_value'],
                    'option_id'         => $option['option_id'],
                    'name'              => $option['name'],
                    'type'              => $option['type'],
                    'required'          => $option['required']
                  ];
                }
              } else {
                $option_value_data = [];

                foreach ($option['product_option_value'] as $option_value) {
                  if (!$option_value['subtract'] || ($option_value['quantity'] > 0)) {
                    $price = ((($this->config->get('config_customer_price') && $this->customer->isLogged()) || !$this->config->get('config_customer_price')) && (float)$option_value['price']) ? $this->currency->format($this->tax->calculate($option_value['price'],$product_info['tax_class_id'],$this->config->get('config_tax') ? 'P' : false),$this->_session_currency) : false;

                    $option_image = ($option_value['image']) ? $this->model_tool_image->resize($option_value['image'],$form_data['option_images_width'],$form_data['option_images_height']) : $this->model_tool_image->resize("no_image.png",$form_data['option_images_width'],$form_data['option_images_height']);

                    $option_value_data[] = [
                      'product_option_value_id' => $option_value['product_option_value_id'],
                      'option_value_id'         => $option_value['option_value_id'],
                      'name'                    => $option_value['name'],
                      'image'                   => $option_image,
                      'price'                   => $price,
                      'price_prefix'            => $option_value['price_prefix']
                    ];
                  }
                }

                $data['options'][] = [
                  'product_option_id'    => $option['product_option_id'],
                  'product_option_value' => $option_value_data,
                  'option_id'            => $option['option_id'],
                  'name'                 => $option['name'],
                  'type'                 => $option['type'],
                  'value'                => $option['value'],
                  'required'             => $option['required']
                ];
              }
            }
          }
        }
      }

      if (version_compare(VERSION,'2.0.0.0','>=') && version_compare(VERSION,'2.1.0.2.1','<=')) {
        if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/options.tpl')) {
          $view = $this->load->view($this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/options.tpl',$data);
        } else {
          $view = $this->load->view('default/template/extension/ocdevwizard/'.$this->_name.'/options.tpl',$data);
        }

        $this->response->setOutput($view);
      } else if (version_compare(VERSION,'3.0.0.0','>=')) {
        $this->response->setOutput($this->load->view('extension/ocdevwizard/'.$this->_name.'/options',$data));
      } else if (version_compare(VERSION,'2.0.0.0','<')) {
        $this->data = $data;

        if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/options_for_oc1.tpl')) {
          $this->template = $this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/options_for_oc1.tpl';
        } else {
          $this->template = 'default/template/extension/ocdevwizard/'.$this->_name.'/options_for_oc1.tpl';
        }

        $this->response->setOutput($this->render());
      } else {
        $this->response->setOutput($this->load->view('extension/ocdevwizard/'.$this->_name.'/options.tpl',$data));
      }
    }
  }

  public function coupon_index() {
    $data = [];

    $models = [
      'extension/ocdevwizard/helper'
    ];

    $form_data = (array)$this->model_extension_ocdevwizard_helper->getSettingData($this->_name.'_form_data',(int)$this->config->get('config_store_id'));

    $data = array_merge($data,$this->language->load('extension/ocdevwizard/'.$this->_name),$form_data);

    $data['_name'] = $this->_name;
    $data['_code'] = $this->_code;

    $data['coupon'] = (isset($this->session->data['coupon'])) ? $this->session->data['coupon'] : '';

    if (version_compare(VERSION,'2.0.0.0','>=') && version_compare(VERSION,'2.1.0.2.1','<=')) {
      if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/coupon.tpl')) {
        return $this->load->view($this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/coupon.tpl',$data);
      } else {
        return $this->load->view('default/template/extension/ocdevwizard/'.$this->_name.'/coupon.tpl',$data);
      }
    } else if (version_compare(VERSION,'3.0.0.0','>=')) {
      return $this->load->view('extension/ocdevwizard/'.$this->_name.'/coupon',$data);
    } else if (version_compare(VERSION,'2.0.0.0','<')) {
      $this->data = $data;

      if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/coupon.tpl')) {
        $this->template = $this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/coupon.tpl';
      } else {
        $this->template = 'default/template/extension/ocdevwizard/'.$this->_name.'/coupon.tpl';
      }

      $this->render();
    } else {
      return $this->load->view('extension/ocdevwizard/'.$this->_name.'/coupon.tpl',$data);
    }
  }

  public function coupon() {
    if (isset($this->request->server['HTTP_X_REQUESTED_WITH']) && !empty($this->request->server['HTTP_X_REQUESTED_WITH']) && strtolower($this->request->server['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
      $json = [];

      $this->language->load('extension/ocdevwizard/'.$this->_name);

      $models = [];

      if (version_compare(VERSION,'2.0.3.1','<=')) {
        $models[]      = 'checkout/coupon';
        $_model_coupon = 'model_checkout_coupon';
      } else if (version_compare(VERSION,'2.3.0.2','>=')) {
        $models[]      = 'extension/total/coupon';
        $_model_coupon = 'model_extension_total_coupon';
      } else {
        $models[]      = 'total/coupon';
        $_model_coupon = 'model_total_coupon';
      }

      foreach ($models as $model) {
        $this->load->model($model);
      }

      $coupon = (isset($this->request->post['value'])) ? $this->request->post['value'] : '';

      $coupon_info = $this->{$_model_coupon}->getCoupon($coupon);

      if (empty($this->request->post['value'])) {
        $json['error']['field']['1'] = $this->language->get('error_coupon_empty');

        unset($this->session->data['coupon']);
      } else if ($coupon_info) {
        $this->session->data['coupon'] = $this->request->post['value'];
        $json['output']                = $this->language->get('text_success_coupon');
      } else {
        $json['error']['field']['1'] = $this->language->get('error_coupon');
      }

      $this->response->addHeader('Content-Type: application/json');
      $this->response->setOutput(json_encode($json));
    }
  }

  public function remove_coupon() {
    if (isset($this->request->server['HTTP_X_REQUESTED_WITH']) && !empty($this->request->server['HTTP_X_REQUESTED_WITH']) && strtolower($this->request->server['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
      $json = [];

      if (isset($this->session->data['coupon'])) {
        unset($this->session->data['coupon']);
      }

      $this->response->addHeader('Content-Type: application/json');
      $this->response->setOutput(json_encode($json));
    }
  }

  public function voucher_index() {
    $data = [];

    $models = [
      'extension/ocdevwizard/helper'
    ];

    $form_data = (array)$this->model_extension_ocdevwizard_helper->getSettingData($this->_name.'_form_data',(int)$this->config->get('config_store_id'));

    $data = array_merge($data,$this->language->load('extension/ocdevwizard/'.$this->_name),$form_data);

    $data['_name'] = $this->_name;
    $data['_code'] = $this->_code;

    $data['voucher'] = (isset($this->session->data['voucher'])) ? $this->session->data['voucher'] : '';

    if (version_compare(VERSION,'2.0.0.0','>=') && version_compare(VERSION,'2.1.0.2.1','<=')) {
      if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/voucher.tpl')) {
        return $this->load->view($this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/voucher.tpl',$data);
      } else {
        return $this->load->view('default/template/extension/ocdevwizard/'.$this->_name.'/voucher.tpl',$data);
      }
    } else if (version_compare(VERSION,'3.0.0.0','>=')) {
      return $this->load->view('extension/ocdevwizard/'.$this->_name.'/voucher',$data);
    } else if (version_compare(VERSION,'2.0.0.0','<')) {
      $this->data = $data;

      if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/voucher.tpl')) {
        $this->template = $this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/voucher.tpl';
      } else {
        $this->template = 'default/template/extension/ocdevwizard/'.$this->_name.'/voucher.tpl';
      }

      $this->render();
    } else {
      return $this->load->view('extension/ocdevwizard/'.$this->_name.'/voucher.tpl',$data);
    }
  }

  public function voucher() {
    if (isset($this->request->server['HTTP_X_REQUESTED_WITH']) && !empty($this->request->server['HTTP_X_REQUESTED_WITH']) && strtolower($this->request->server['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
      $json = [];

      $this->language->load('extension/ocdevwizard/'.$this->_name);

      $models = [];

      if (version_compare(VERSION,'2.0.3.1','<=')) {
        $models[]       = 'checkout/voucher';
        $_model_voucher = 'model_checkout_voucher';
      } else if (version_compare(VERSION,'2.3.0.2','>=')) {
        $models[]       = 'extension/total/voucher';
        $_model_voucher = 'model_extension_total_voucher';
      } else {
        $models[]       = 'total/voucher';
        $_model_voucher = 'model_total_voucher';
      }

      foreach ($models as $model) {
        $this->load->model($model);
      }

      $voucher = (isset($this->request->post['value'])) ? $this->request->post['value'] : '';

      $voucher_info = $this->{$_model_voucher}->getVoucher($voucher);

      if (empty($this->request->post['value'])) {
        $json['error']['field']['1'] = $this->language->get('error_voucher_empty');
      } else if ($voucher_info) {
        $this->session->data['voucher'] = $this->request->post['value'];
        $json['output']                 = $this->language->get('text_success_voucher');
      } else {
        $json['error']['field']['1'] = $this->language->get('error_voucher');
      }

      $this->response->addHeader('Content-Type: application/json');
      $this->response->setOutput(json_encode($json));
    }
  }

  public function remove_voucher() {
    if (isset($this->request->server['HTTP_X_REQUESTED_WITH']) && !empty($this->request->server['HTTP_X_REQUESTED_WITH']) && strtolower($this->request->server['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
      $json = [];

      if (isset($this->session->data['voucher'])) {
        unset($this->session->data['voucher']);
      }

      $this->response->addHeader('Content-Type: application/json');
      $this->response->setOutput(json_encode($json));
    }
  }

  public function reward_index() {
    $data = [];

    $models = [
      'extension/ocdevwizard/helper'
    ];

    $form_data = (array)$this->model_extension_ocdevwizard_helper->getSettingData($this->_name.'_form_data',(int)$this->config->get('config_store_id'));

    $data = array_merge($data,$this->language->load('extension/ocdevwizard/'.$this->_name),$form_data);

    $data['_name'] = $this->_name;
    $data['_code'] = $this->_code;

    $points = $this->customer->getRewardPoints();

    $points_total = 0;

    foreach ($this->cart->getProducts() as $product) {
      if ($product['points']) {
        $points_total += $product['points'];
      }
    }

    if ($points && $points_total) {
      $data['text_loading'] = $this->language->get('text_loading');
      $data['entry_reward'] = sprintf($this->language->get('entry_reward'),$points_total);
      $data['reward']       = isset($this->session->data['reward']) ? $this->session->data['reward'] : '';

      if (version_compare(VERSION,'2.0.0.0','>=') && version_compare(VERSION,'2.1.0.2.1','<=')) {
        if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/reward.tpl')) {
          return $this->load->view($this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/reward.tpl',$data);
        } else {
          return $this->load->view('default/template/extension/ocdevwizard/'.$this->_name.'/reward.tpl',$data);
        }
      } else if (version_compare(VERSION,'3.0.0.0','>=')) {
        return $this->load->view('extension/ocdevwizard/'.$this->_name.'/reward',$data);
      } else if (version_compare(VERSION,'2.0.0.0','<')) {
        $this->data = $data;

        if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/reward.tpl')) {
          $this->template = $this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/reward.tpl';
        } else {
          $this->template = 'default/template/extension/ocdevwizard/'.$this->_name.'/reward.tpl';
        }

        $this->render();
      } else {
        return $this->load->view('extension/ocdevwizard/'.$this->_name.'/reward.tpl',$data);
      }
    }
  }

  public function reward() {
    if (isset($this->request->server['HTTP_X_REQUESTED_WITH']) && !empty($this->request->server['HTTP_X_REQUESTED_WITH']) && strtolower($this->request->server['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
      $json = [];

      $this->language->load('extension/ocdevwizard/'.$this->_name);

      $points = $this->customer->getRewardPoints();

      $points_total = 0;

      foreach ($this->cart->getProducts() as $product) {
        if ($product['points']) {
          $points_total += $product['points'];
        }
      }

      if (empty($this->request->post['value'])) {
        $json['error']['field']['1'] = $this->language->get('error_reward');
      }

      if ($this->request->post['value'] > $points) {
        $json['error']['field']['1'] = sprintf($this->language->get('error_points'),$this->request->post['value']);
      }

      if ($this->request->post['value'] > $points_total) {
        $json['error']['field']['1'] = sprintf($this->language->get('error_maximum'),$points_total);
      }

      if (!$json) {
        $this->session->data['reward'] = abs($this->request->post['value']);
        $json['output']                = $this->language->get('text_success_reward');
      }

      $this->response->addHeader('Content-Type: application/json');
      $this->response->setOutput(json_encode($json));
    }
  }

  public function remove_reward() {
    if (isset($this->request->server['HTTP_X_REQUESTED_WITH']) && !empty($this->request->server['HTTP_X_REQUESTED_WITH']) && strtolower($this->request->server['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
      $json = [];

      if (isset($this->session->data['reward'])) {
        unset($this->session->data['reward']);
      }

      $this->response->addHeader('Content-Type: application/json');
      $this->response->setOutput(json_encode($json));
    }
  }

  public function shipping_index() {
    $data = [];

    $models = [
      'extension/ocdevwizard/helper'
    ];

    $form_data = (array)$this->model_extension_ocdevwizard_helper->getSettingData($this->_name.'_form_data',(int)$this->config->get('config_store_id'));

    $data = array_merge($data,$this->language->load('extension/ocdevwizard/'.$this->_name),$form_data);

    $data['_name'] = $this->_name;
    $data['_code'] = $this->_code;

    if (version_compare(VERSION,'3.0.0.0','>=')) {
      $_shipping_status    = $this->config->get('total_shipping_status');
      $_shipping_estimator = $this->config->get('total_shipping_estimator');
    } else {
      $_shipping_status    = $this->config->get('shipping_status');
      $_shipping_estimator = $this->config->get('shipping_estimator');
    }

    if ($_shipping_status && $_shipping_estimator && $this->cart->hasShipping()) {
      $data['country_id'] = (isset($this->session->data['shipping_address']['country_id'])) ? $this->session->data['shipping_address']['country_id'] : $this->config->get('config_country_id');

      $models = [
        'localisation/country'
      ];

      foreach ($models as $model) {
        $this->load->model($model);
      }

      $data['countries']       = $this->model_localisation_country->getCountries();
      $data['zone_id']         = (isset($this->session->data['shipping_address']['zone_id'])) ? $this->session->data['shipping_address']['zone_id'] : '';
      $data['postcode']        = (isset($this->session->data['shipping_address']['postcode'])) ? $this->session->data['shipping_address']['postcode'] : '';
      $data['shipping_method'] = (isset($this->session->data['shipping_method'])) ? $this->session->data['shipping_method']['code'] : '';

      if (version_compare(VERSION,'2.0.0.0','>=') && version_compare(VERSION,'2.1.0.2.1','<=')) {
        if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/shipping.tpl')) {
          return $this->load->view($this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/shipping.tpl',$data);
        } else {
          return $this->load->view('default/template/extension/ocdevwizard/'.$this->_name.'/shipping.tpl',$data);
        }
      } else if (version_compare(VERSION,'3.0.0.0','>=')) {
        return $this->load->view('extension/ocdevwizard/'.$this->_name.'/shipping',$data);
      } else if (version_compare(VERSION,'2.0.0.0','<')) {
        $this->data = $data;

        if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/shipping.tpl')) {
          $this->template = $this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/shipping.tpl';
        } else {
          $this->template = 'default/template/extension/ocdevwizard/'.$this->_name.'/shipping.tpl';
        }

        $this->render();
      } else {
        return $this->load->view('extension/ocdevwizard/'.$this->_name.'/shipping.tpl',$data);
      }
    }
  }

  public function shipping_quote() {
    if (isset($this->request->server['HTTP_X_REQUESTED_WITH']) && !empty($this->request->server['HTTP_X_REQUESTED_WITH']) && strtolower($this->request->server['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
      $json = [];

      $this->language->load('extension/ocdevwizard/'.$this->_name);

      $models = [
        'localisation/country',
        'localisation/zone'
      ];

      if (version_compare(VERSION,'2.0.0.0','<') || version_compare(VERSION,'3.0.0.0','>=')) {
        $models[] = 'setting/extension';
      } else {
        $models[] = 'extension/extension';
      }

      foreach ($models as $model) {
        $this->load->model($model);
      }

      if (!$this->cart->hasProducts()) {
        $json['error']['field']['3'] = $this->language->get('error_product');
      }

      if (!$this->cart->hasShipping()) {
        $json['error']['field']['3'] = sprintf($this->language->get('error_no_shipping'),$this->url->link('information/contact'));
      }

      if ($this->request->post['country_id'] == '') {
        $json['error']['field']['1'] = $this->language->get('error_country');
      }

      if (!isset($this->request->post['zone_id']) || $this->request->post['zone_id'] == '') {
        $json['error']['field']['2'] = $this->language->get('error_zone');
      }

      $country_info = $this->model_localisation_country->getCountry($this->request->post['country_id']);

      if ($country_info && $country_info['postcode_required'] && (utf8_strlen(trim($this->request->post['postcode'])) < 2 || utf8_strlen(trim($this->request->post['postcode'])) > 10)) {
        $json['error']['field']['3'] = $this->language->get('error_postcode');
      }

      if (!$json) {
        $this->tax->setShippingAddress($this->request->post['country_id'],$this->request->post['zone_id']);

        if ($country_info) {
          $country        = $country_info['name'];
          $iso_code_2     = $country_info['iso_code_2'];
          $iso_code_3     = $country_info['iso_code_3'];
          $address_format = $country_info['address_format'];
        } else {
          $country        = '';
          $iso_code_2     = '';
          $iso_code_3     = '';
          $address_format = '';
        }

        $zone_info = $this->model_localisation_zone->getZone($this->request->post['zone_id']);

        if ($zone_info) {
          $zone      = $zone_info['name'];
          $zone_code = $zone_info['code'];
        } else {
          $zone      = '';
          $zone_code = '';
        }

        $this->session->data['shipping_address'] = [
          'firstname'      => '',
          'lastname'       => '',
          'company'        => '',
          'address_1'      => '',
          'address_2'      => '',
          'postcode'       => $this->request->post['postcode'],
          'city'           => '',
          'zone_id'        => $this->request->post['zone_id'],
          'zone'           => $zone,
          'zone_code'      => $zone_code,
          'country_id'     => $this->request->post['country_id'],
          'country'        => $country,
          'iso_code_2'     => $iso_code_2,
          'iso_code_3'     => $iso_code_3,
          'address_format' => $address_format
        ];

        $quote_data = [];

        if (version_compare(VERSION,'2.0.0.0','<') || version_compare(VERSION,'3.0.0.0','>=')) {
          $results = $this->model_setting_extension->getExtensions('shipping');
        } else {
          $results = $this->model_extension_extension->getExtensions('shipping');
        }

        foreach ($results as $result) {
          if (version_compare(VERSION,'3.0.0.0','>=')) {
            $_shipping_status = $this->config->get('shipping_'.$result['code'].'_status');
          } else {
            $_shipping_status = $this->config->get($result['code'].'_status');
          }

          if ($_shipping_status) {
            if (version_compare(VERSION,'2.2.0.0','<=')) {
              $this->load->model('shipping/'.$result['code']);
              $quote = $this->{'model_shipping_'.$result['code']}->getQuote($this->session->data['shipping_address']);
            } else {
              $this->load->model('extension/shipping/'.$result['code']);
              $quote = $this->{'model_extension_shipping_'.$result['code']}->getQuote($this->session->data['shipping_address']);
            }

            if ($quote) {
              $quote_data[$result['code']] = [
                'title'      => $quote['title'],
                'quote'      => $quote['quote'],
                'sort_order' => $quote['sort_order'],
                'error'      => $quote['error']
              ];
            }
          }
        }

        $sort_order = [];

        foreach ($quote_data as $key => $value) {
          $sort_order[$key] = $value['sort_order'];
        }

        array_multisort($sort_order,SORT_ASC,$quote_data);

        $this->session->data['shipping_methods'] = $quote_data;

        if ($this->session->data['shipping_methods']) {
          $json['shipping_method'] = $this->session->data['shipping_methods'];
        } else {
          $json['error']['field']['3'] = sprintf($this->language->get('error_no_shipping'),$this->url->link('information/contact'));
        }
      }

      $this->response->addHeader('Content-Type: application/json');
      $this->response->setOutput(json_encode($json));
    }
  }

  public function shipping() {
    if (isset($this->request->server['HTTP_X_REQUESTED_WITH']) && !empty($this->request->server['HTTP_X_REQUESTED_WITH']) && strtolower($this->request->server['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
      $json = [];

      $this->language->load('extension/ocdevwizard/'.$this->_name);

      if (!empty($this->request->post['shipping_method'])) {
        $shipping = explode('.',$this->request->post['shipping_method']);

        if (!isset($shipping[0]) || !isset($shipping[1]) || !isset($this->session->data['shipping_methods'][$shipping[0]]['quote'][$shipping[1]])) {
          $json['error']['field']['1'] = $this->language->get('error_shipping');
        }
      } else {
        $json['error']['field']['1'] = $this->language->get('error_shipping');
      }

      if (!$json) {
        $shipping                               = explode('.',$this->request->post['shipping_method']);
        $json['output']                         = $this->language->get('text_success_shipping');
        $this->session->data['shipping_method'] = $this->session->data['shipping_methods'][$shipping[0]]['quote'][$shipping[1]];
      }

      $this->response->addHeader('Content-Type: application/json');
      $this->response->setOutput(json_encode($json));
    }
  }

  public function save_products_index() {
    $data = [];

    $models = [
      'catalog/information',
      'extension/ocdevwizard/'.$this->_name,
      'extension/ocdevwizard/helper'
    ];

    foreach ($models as $model) {
      $this->load->model($model);
    }

    $this->language->load('extension/ocdevwizard/'.$this->_name);

    $text_data = $this->model_extension_ocdevwizard_helper->getSettingData($this->_name.'_text_data',(int)$this->config->get('config_store_id'));
    $form_data = (array)$this->model_extension_ocdevwizard_helper->getSettingData($this->_name.'_form_data',(int)$this->config->get('config_store_id'));

    $data = array_merge($data,$this->language->load('extension/ocdevwizard/'.$this->_name),$form_data);

    $data['_name']     = $this->_name;
    $data['_code']     = $this->_code;
    $data['field_row'] = mt_rand(1000,10000);

    $language_id = $this->{'model_extension_ocdevwizard_'.$this->_name}->getLanguageIdByCode($this->session->data['language']);

    $data['button_save'] = (isset($text_data[$language_id])) ? html_entity_decode($text_data[$language_id]['save_button'],ENT_QUOTES,'UTF-8') : '';

    $data['fields_data'] = [];

    if (isset($form_data['fields']) && $form_data['fields']) {
      foreach ($form_data['fields'] as $field_id) {
        $field_info = $this->{'model_extension_ocdevwizard_'.$this->_name}->getField($field_id);

        if ($field_info) {
          $icon = ($field_info['icon']) ? $this->model_tool_image->resize($field_info['icon'],25,25) : '';

          if ($field_info['field_type'] == 'firstname') {
            $value = $this->customer->getFirstname();
          } else if ($field_info['field_type'] == 'lastname') {
            $value = $this->customer->getLastname();
          } else if ($field_info['field_type'] == 'email') {
            $value = $this->customer->getEmail();
          } else if ($field_info['field_type'] == 'telephone') {
            $value = $this->customer->getTelephone();
          } else {
            $value = '';
          }

          $data['fields_data'][] = [
            'field_id'     => $field_info['field_id'],
            'name'         => html_entity_decode($field_info['name'],ENT_QUOTES,'UTF-8'),
            'placeholder'  => ($field_info['placeholder_status']) ? $field_info['placeholder'] : '',
            'field_type'   => $field_info['field_type'],
            'required'     => ($field_info['validation_type'] > 0) ? 1 : 0,
            'field_mask'   => $field_info['field_mask'],
            'icon'         => $icon,
            'value'        => $value,
            'error_text'   => html_entity_decode($field_info['error_text'],ENT_QUOTES,'UTF-8'),
            'description'  => ($field_info['description_status']) ? html_entity_decode($field_info['description'],ENT_QUOTES,'UTF-8') : '',
            'css_id'       => $field_info['css_id'],
            'css_class'    => $field_info['css_class'],
            'title_status' => $field_info['title_status'],
            'sort_order'   => $field_info['sort_order']
          ];
        }
      }

      if ($data['fields_data']) {
        $sort_order = [];

        foreach ($data['fields_data'] as $key => $value) {
          $sort_order[$key] = $value['sort_order'];
        }

        array_multisort($sort_order,SORT_ASC,$data['fields_data']);
      }
    }

    $data['informations'] = [];

    if (isset($form_data['require_information']) && $form_data['require_information']) {
      $informations         = $this->model_catalog_information->getInformation((int)$form_data['require_information']);
      $data['informations'] = sprintf($this->language->get('text_require_information'),$this->url->link('information/information','information_id='.$form_data['require_information']),$informations['title']);
    }

    if (version_compare(VERSION,'2.0.0.0','>=') && version_compare(VERSION,'2.1.0.2.1','<=')) {
      if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/save_products.tpl')) {
        return $this->load->view($this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/save_products.tpl',$data);
      } else {
        return $this->load->view('default/template/extension/ocdevwizard/'.$this->_name.'/save_products.tpl',$data);
      }
    } else if (version_compare(VERSION,'3.0.0.0','>=')) {
      return $this->load->view('extension/ocdevwizard/'.$this->_name.'/save_products',$data);
    } else if (version_compare(VERSION,'2.0.0.0','<')) {
      $this->data = $data;

      if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/save_products.tpl')) {
        $this->template = $this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/save_products.tpl';
      } else {
        $this->template = 'default/template/extension/ocdevwizard/'.$this->_name.'/save_products.tpl';
      }

      $this->render();
    } else {
      return $this->load->view('extension/ocdevwizard/'.$this->_name.'/save_products.tpl',$data);
    }
  }

  public function record_action() {
    if (isset($this->request->server['HTTP_X_REQUESTED_WITH']) && !empty($this->request->server['HTTP_X_REQUESTED_WITH']) && strtolower($this->request->server['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
      $json = [];

      $this->language->load('extension/ocdevwizard/'.$this->_name);

      $models = [
        'catalog/information',
        'extension/ocdevwizard/'.$this->_name,
        'extension/ocdevwizard/helper'
      ];

      foreach ($models as $model) {
        $this->load->model($model);
      }

      $form_data = $this->model_extension_ocdevwizard_helper->getSettingData($this->_name.'_form_data',(int)$this->config->get('config_store_id'));

      $field_data = (isset($this->request->post['field'])) ? $this->request->post['field'] : die();

      if (!$form_data) {
        die();
      }

      foreach ($field_data as $field_row => $field) {
        foreach ($field as $field_id => $value) {
          $field_info = $this->{'model_extension_ocdevwizard_'.$this->_name}->getField($field_id);

          if ($field_info) {
            if ($field_info['validation_type'] == 1) {
              if (empty($value)) {
                $json['error']['field'][$field_row] = $field_info['error_text'];
              }
            } else if ($field_info['validation_type'] == 2 && !preg_match($field_info['regex_rule'],$value)) {
              $json['error']['field'][$field_row] = $field_info['error_text'];
            } else if ($field_info['validation_type'] == 3 && (utf8_strlen(str_replace(['_','-','+','(',')'],'',$value)) < $field_info['min_length_rule'] || utf8_strlen(str_replace(['_','-','+','(',')'],'',$value)) > $field_info['max_length_rule'])) {
              $json['error']['field'][$field_row] = $field_info['error_text'];
            } else {
              unset($json['error']['field'][$field_row]);
            }

            if ($field_info['field_type'] == 'email') {
              if ($this->{'model_extension_ocdevwizard_'.$this->_name}->checkBannedByEmail($value,$this->request->server['REMOTE_ADDR'])) {
                $json['error']['field'][$field_row] = $this->language->get('error_banned_record_by_email');
              }
            }
          }
        }
      }

      if (!isset($this->request->post['require_information']) || empty($this->request->post['require_information'])) {
        if (isset($form_data['require_information']) && $form_data['require_information']) {
          $information_info = $this->model_catalog_information->getInformation((int)$form_data['require_information']);

          if ($information_info) {
            $json['error']['field']['require_information'] = sprintf($this->language->get('error_require_information'),$information_info['title']);
          }
        }
      }

      if ($form_data['captcha_status'] && (!isset($this->session->data[$this->_code.'_gcapcha']) || empty($this->session->data[$this->_code.'_gcapcha']))) {
        $recaptcha = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.urlencode($form_data['captcha_secret_key']).'&response='.$this->request->request['g-recaptcha-response'].'&remoteip='.$this->request->server['REMOTE_ADDR']);

        $recaptcha = json_decode($recaptcha,true);

        if ($recaptcha['success']) {
          $this->session->data[$this->_code.'_gcapcha'] = true;
        } else {
          $json['error']['field']['recaptcha'] = $this->language->get('error_recaptcha');
        }
      }

      if (!isset($json['error'])) {
        $ip                = (!empty($this->request->server['REMOTE_ADDR'])) ? $this->request->server['REMOTE_ADDR'] : '';
        $referer           = (!empty($this->request->server['HTTP_REFERER'])) ? $this->request->server['HTTP_REFERER'] : '';
        $user_agent        = (isset($this->request->server['HTTP_USER_AGENT'])) ? $this->request->server['HTTP_USER_AGENT'] : '';
        $accept_language   = (isset($this->request->server['HTTP_ACCEPT_LANGUAGE'])) ? $this->request->server['HTTP_ACCEPT_LANGUAGE'] : '';
        $customer_group_id = $this->customer->isLogged() ? ((version_compare(VERSION,'2.0.0.0','<')) ? (int)$this->customer->getCustomerGroupId() : (int)$this->customer->getGroupId()) : (int)$this->config->get('config_customer_group_id');
        $customer_id       = $this->customer->getId();
        $store_id          = $this->config->get('config_store_id');
        $store_name        = $this->config->get('config_name');
        $store_url         = (isset($this->request->server['HTTPS']) && (($this->request->server['HTTPS'] == 'on') || ($this->request->server['HTTPS'] == '1'))) ? $this->config->get('config_ssl') : $this->config->get('config_url');

        if ($store_id != 0) {
          $store_info = $this->{'model_extension_ocdevwizard_'.$this->_name}->getStore($store_id);

          if ($store_info) {
            $store_name = $store_info['name'];
            $store_url  = (isset($this->request->server['HTTPS']) && (($this->request->server['HTTPS'] == 'on') || ($this->request->server['HTTPS'] == '1'))) ? $store_info['ssl'] : $store_info['url'];
          }
        }

        $language_id = $this->{'model_extension_ocdevwizard_'.$this->_name}->getLanguageIdByCode($this->session->data['language']);
        $currency_id = $this->{'model_extension_ocdevwizard_'.$this->_name}->getCurrencyIdByCode($this->session->data['currency']);

        $email = '';

        $field_data_result = [];

        foreach ($field_data as $field_row => $field) {
          foreach ($field as $field_id => $value) {
            $field_info = $this->{'model_extension_ocdevwizard_'.$this->_name}->getField($field_id);

            if ($field_info) {
              $field_data_result[] = [
                'name'  => $field_info['name'],
                'type'  => $field_info['field_type'],
                'value' => $value
              ];

              if ($field_info['field_type'] == 'email') {
                $email = $value;
              }
            }
          }
        }

        if (version_compare(VERSION,'2.0.3.1','<=')) {
          $salt = substr(md5(uniqid(rand(),true)),0,9);
        } else {
          $salt = token(9);
        }

        $token = md5(sha1($salt.sha1($salt.sha1($ip))));

        $filter_data = [
          'customer_id'            => $customer_id,
          'currency_code'          => $this->_session_currency,
          'currency_value'         => $this->currency->getValue($this->_session_currency),
          'field_data'             => $field_data_result,
          'token'                  => $token,
          'cart'                   => $this->cart->getProducts(),
          'ip'                     => $ip,
          'referer'                => $referer,
          'user_agent'             => $user_agent,
          'accept_language'        => $accept_language,
          'user_language_id'       => $language_id,
          'user_currency_id'       => $currency_id,
          'user_customer_group_id' => $customer_group_id,
          'store_name'             => $store_name,
          'store_url'              => $store_url,
          'store_id'               => $store_id,
          'form_data'              => $form_data
        ];

        $this->{'model_extension_ocdevwizard_'.$this->_name}->addRecord($filter_data);

        $json['output'] = $this->language->get('text_success_save_products');

        $this->session->data[$this->_code.'_gcapcha'] = false;
      }

      $this->response->addHeader('Content-Type: application/json');
      $this->response->setOutput(json_encode($json));
    }
  }

  public function get_products() {
    if (isset($this->request->server['HTTP_X_REQUESTED_WITH']) && !empty($this->request->server['HTTP_X_REQUESTED_WITH']) && strtolower($this->request->server['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
      $json = [];

      $json['products'] = [];

      $models = [
        'extension/ocdevwizard/'.$this->_name,
        'extension/ocdevwizard/helper'
      ];

      if (version_compare(VERSION,'2.0.0.0','<') || version_compare(VERSION,'3.0.0.0','>=')) {
        $models[] = 'setting/extension';
      } else {
        $models[] = 'extension/extension';
      }

      foreach ($models as $model) {
        $this->load->model($model);
      }

      $form_data = (array)$this->model_extension_ocdevwizard_helper->getSettingData($this->_name.'_form_data',(int)$this->config->get('config_store_id'));
      $text_data = (array)$this->model_extension_ocdevwizard_helper->getSettingData($this->_name.'_text_data',(int)$this->config->get('config_store_id'));

      $language_id = $this->{'model_extension_ocdevwizard_'.$this->_name}->getLanguageIdByCode($this->session->data['language']);

      $json['text_in_cart']              = (isset($text_data[$language_id])) ? html_entity_decode($text_data[$language_id]['call_button'],ENT_QUOTES,'UTF-8') : '';
      $json['text_in_cart_product_page'] = (isset($text_data[$language_id])) ? html_entity_decode($text_data[$language_id]['call_button_product_page'],ENT_QUOTES,'UTF-8') : '';

      $products_in_cart = $this->cart->getProducts();

      if (empty($products_in_cart) && empty($this->session->data['vouchers'])) {
        $json['error'] = html_entity_decode($text_data[$language_id]['empty_message'],ENT_QUOTES,'UTF-8');
      }

      if (!isset($json['error'])) {
        foreach ($products_in_cart as $product) {
          $json['products'][] = $product['product_id'];
        }
      }

      $this->load->language('checkout/cart');

      // totals
      if (version_compare(VERSION,'2.1.0.2.1','<=')) {
        $total_data = [];
        $total      = 0;
        $taxes      = $this->cart->getTaxes();
      } else {
        $totals = [];
        $taxes  = $this->cart->getTaxes();
        $total  = 0;

        // Because __call can not keep var references so we put them into an array.
        $total_data = [
          'totals' => &$totals,
          'taxes'  => &$taxes,
          'total'  => &$total
        ];
      }

      // display prices
      if (($this->config->get('config_customer_price') && $this->customer->isLogged()) || !$this->config->get('config_customer_price')) {
        $sort_order = [];

        if (version_compare(VERSION,'2.0.0.0','<') || version_compare(VERSION,'3.0.0.0','>=')) {
          $results = $this->model_setting_extension->getExtensions('total');
        } else {
          $results = $this->model_extension_extension->getExtensions('total');
        }

        foreach ($results as $key => $value) {
          $sort_order[$key] = $this->config->get($value['code'].'_sort_order');
        }

        array_multisort($sort_order,SORT_ASC,$results);

        foreach ($results as $result) {
          if (version_compare(VERSION,'3.0.0.0','>=')) {
            $_total_status = $this->config->get('total_'.$result['code'].'_status');
          } else {
            $_total_status = $this->config->get($result['code'].'_status');
          }
          if ($_total_status) {
            if (version_compare(VERSION,'2.1.0.2.1','<=')) {
              $this->load->model('total/'.$result['code']);
              $this->{'model_total_'.$result['code']}->getTotal($total_data,$total,$taxes);
            } else {
              $this->load->model('extension/total/'.$result['code']);
              $this->{'model_extension_total_'.$result['code']}->getTotal($total_data);
            }
          }
        }

        $sort_order = [];

        if (version_compare(VERSION,'2.1.0.2.1','<=')) {
          foreach ($total_data as $key => $value) {
            $sort_order[$key] = $value['sort_order'];
          }

          array_multisort($sort_order,SORT_ASC,$total_data);
        } else {
          foreach ($totals as $key => $value) {
            $sort_order[$key] = $value['sort_order'];
          }

          array_multisort($sort_order,SORT_ASC,$totals);
        }
      }

      if ($form_data['declension_status']) {
        if (isset($text_data[$language_id])) {
          $tag_codes = [
            '{count_products}',
            '{total}'
          ];

          $tag_codes_replace = [
            $this->cart->countProducts() + (isset($this->session->data['vouchers']) ? count($this->session->data['vouchers']) : 0),
            $this->currency->format($total,$this->_session_currency)
          ];

          $text_items = html_entity_decode($text_data[$language_id]['cart_declension'],ENT_QUOTES,'UTF-8');

          preg_match_all('/{declension}(.*?){\/declension}/',$text_items,$text_items_matches,PREG_SET_ORDER);

          if ($text_items_matches) {
            foreach ($text_items_matches as $text_items_match) {
              preg_match('/{declension}(.*?){\/declension}/',$text_items_match[0],$text_items_match_item);

              if ((isset($text_items_match_item[0]) && $text_items_match_item[0]) && (isset($text_items_match_item[1]) && $text_items_match_item[1])) {
                $declension_words = explode("|",$text_items_match_item[1]);

                $declension_data = [
                  'number' => $this->cart->countProducts() + (isset($this->session->data['vouchers']) ? count($this->session->data['vouchers']) : 0),
                  'words'  => $declension_words
                ];

                $text_items = str_replace($text_items_match_item[0],$this->make_declension($declension_data),$text_items);
              }
            }
          }

          $json['total'] = html_entity_decode(str_replace($tag_codes,$tag_codes_replace,$text_items),ENT_QUOTES,'UTF-8');
        } else {
          $json['total'] = sprintf($this->language->get('text_items'),$this->cart->countProducts() + (isset($this->session->data['vouchers']) ? count($this->session->data['vouchers']) : 0),$this->currency->format($total,$this->_session_currency));
        }
      } else {
        $json['total'] = sprintf($this->language->get('text_items'),$this->cart->countProducts() + (isset($this->session->data['vouchers']) ? count($this->session->data['vouchers']) : 0),$this->currency->format($total,$this->_session_currency));
      }

      $this->response->addHeader('Content-Type: application/json');
      $this->response->setOutput(json_encode($json));
    }
  }

  public function make_declension($data) {
    if ($data) {
      $indexes = [2,0,1,1,1,2];

      return $data['words'][($data['number'] % 100 > 4 && $data['number'] % 100 < 20) ? 2 : $indexes[min($data['number'] % 10,5)]];
    } else {
      return '';
    }
  }

  public function add() {
    if (isset($this->request->server['HTTP_X_REQUESTED_WITH']) && !empty($this->request->server['HTTP_X_REQUESTED_WITH']) && strtolower($this->request->server['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
      $json = [];

      $this->language->load('extension/ocdevwizard/'.$this->_name);

      $models = [
        'catalog/product'
      ];

      foreach ($models as $model) {
        $this->load->model($model);
      }

      if (isset($this->request->post['product_id'])) {
        $product_id = (int)$this->request->post['product_id'];
      } else {
        $product_id = 0;
      }

      $product_info = $this->model_catalog_product->getProduct($product_id);

      if ($product_info) {
        if (isset($this->request->post['quantity']) && ((int)$this->request->post['quantity'] >= $product_info['minimum'])) {
          $quantity = (int)$this->request->post['quantity'];
        } else {
          $quantity = $product_info['minimum'] ? $product_info['minimum'] : 1;
        }

        if (isset($this->request->post['option'])) {
          $option = array_filter($this->request->post['option']);
        } else {
          $option = [];
        }

        $product_options = $this->model_catalog_product->getProductOptions($this->request->post['product_id']);

        foreach ($product_options as $product_option) {
          if ($product_option['required'] && empty($option[$product_option['product_option_id']])) {
            $json['error']['option'][$product_option['product_option_id']] = sprintf($this->language->get('error_required'),$product_option['name']);
          }
        }

        if (!$json) {
          $this->cart->add($this->request->post['product_id'],$quantity,$option,0);

          $json['success'] = true;

          unset($this->session->data['shipping_method']);
          unset($this->session->data['shipping_methods']);
          unset($this->session->data['payment_method']);
          unset($this->session->data['payment_methods']);
        }
      }

      $this->response->addHeader('Content-Type: application/json');
      $this->response->setOutput(json_encode($json));
    }
  }

  public function re_add() {
    $this->language->load('extension/ocdevwizard/'.$this->_name);

    if (isset($this->request->get['record_product_id'])) {
      $record_product_id = $this->request->get['record_product_id'];
    } else {
      $record_product_id = 0;
    }

    $models = [
      'extension/ocdevwizard/'.$this->_name,
      'catalog/product'
    ];

    foreach ($models as $model) {
      $this->load->model($model);
    }

    $record_product_info = $this->{'model_extension_ocdevwizard_'.$this->_name}->getRecordByRecordProductId($record_product_id);

    if ($record_product_info) {
      $product_info = $this->model_catalog_product->getProduct($record_product_info['product_id']);

      if ($product_info) {
        $option_data = [];

        $filter_data = [
          'product_id' => $product_info['product_id'],
          'record_id'  => $record_product_info['record_id']
        ];

        $options = unserialize($this->{'model_extension_ocdevwizard_'.$this->_name}->getRecordProductInfo($filter_data));

        foreach ($options as $option) {
          if ($option['type'] == 'select' || $option['type'] == 'radio' || $option['type'] == 'image') {
            $option_data[$option['product_option_id']] = $option['product_option_value_id'];
          } else if ($option['type'] == 'checkbox') {
            $option_data[$option['product_option_id']][] = $option['product_option_value_id'];
          } else if ($option['type'] == 'text' || $option['type'] == 'textarea' || $option['type'] == 'date' || $option['type'] == 'datetime' || $option['type'] == 'time') {
            $option_data[$option['product_option_id']] = $option['value'];
          } else if ($option['type'] == 'file') {
            $option_data[$option['product_option_id']] = $this->encryption->encrypt($option['value']);
          }
        }

        $this->cart->add($record_product_info['product_id'],$record_product_info['quantity'],$option_data);

        $this->session->data['success'] = sprintf($this->language->get('text_page_success'),$this->url->link('product/product','product_id='.$product_info['product_id']),$product_info['name'],$this->url->link('checkout/cart'));

        unset($this->session->data['shipping_method']);
        unset($this->session->data['shipping_methods']);
        unset($this->session->data['payment_method']);
        unset($this->session->data['payment_methods']);
      }
    }

    $this->response->redirect($this->url->link('extension/ocdevwizard/'.$this->_name.'/account_page','','SSL'));
  }

  public function country() {
    if (isset($this->request->server['HTTP_X_REQUESTED_WITH']) && !empty($this->request->server['HTTP_X_REQUESTED_WITH']) && strtolower($this->request->server['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
      $json = [];

      $models = [
        'localisation/country',
        'localisation/zone'
      ];

      foreach ($models as $model) {
        $this->load->model($model);
      }

      $country_info = $this->model_localisation_country->getCountry($this->request->get['country_id']);

      if ($country_info) {
        $json = [
          'country_id'        => $country_info['country_id'],
          'name'              => $country_info['name'],
          'iso_code_2'        => $country_info['iso_code_2'],
          'iso_code_3'        => $country_info['iso_code_3'],
          'address_format'    => $country_info['address_format'],
          'postcode_required' => $country_info['postcode_required'],
          'zone'              => $this->model_localisation_zone->getZonesByCountryId($this->request->get['country_id']),
          'status'            => $country_info['status']
        ];
      }

      $this->response->addHeader('Content-Type: application/json');
      $this->response->setOutput(json_encode($json));
    }
  }

  public function cron() {
    $access_key = (isset($this->request->get['access_key']) && $this->request->get['access_key']) ? $this->request->get['access_key'] : '';

    if ($access_key) {
      $models = [
        'extension/ocdevwizard/'.$this->_name,
        'extension/ocdevwizard/helper'
      ];

      foreach ($models as $model) {
        $this->load->model($model);
      }

      $form_data = $this->model_extension_ocdevwizard_helper->getSettingData($this->_name.'_form_data',(int)$this->config->get('config_store_id'));

      if (isset($form_data['activate']) && $form_data['activate']) {
        if ($form_data['cron_token'] == $access_key && isset($form_data['cron_task'])) {
          foreach ($form_data['cron_task'] as $cron_task) {
            if ($cron_task == 1) {
              $results = $this->{'model_extension_ocdevwizard_'.$this->_name}->getRecordForCron(1);

              if ($results) {
                foreach ($results as $row) {
                  $this->db->query("UPDATE ".DB_PREFIX.$this->_code."_record SET status = '1', date_notified = NOW() WHERE record_id = '".(int)$row['record_id']."'");

                  $filter_data = [
                    'record_id' => $row['record_id'],
                    'form_data' => $form_data
                  ];

                  $this->{'model_extension_ocdevwizard_'.$this->_name}->mailing($filter_data,['to_user_on_reminder']);
                }
              }
            }
          }
        }
      }
    } else {
      header('HTTP/1.0 403 Forbidden');
      die();
    }
  }

  public function actions() {
    $data = [];

    $models = [
      'extension/ocdevwizard/'.$this->_name,
      'extension/ocdevwizard/helper'
    ];

    foreach ($models as $model) {
      $this->load->model($model);
    }

    $data = array_merge($data,$this->language->load('extension/ocdevwizard/'.$this->_name));

    $data['breadcrumbs'] = [];

    $data['breadcrumbs'][] = [
      'text'      => $this->language->get('text_home'),
      'href'      => $this->url->link('common/home'),
      'separator' => false
    ];

    $form_data = $this->model_extension_ocdevwizard_helper->getSettingData($this->_name.'_form_data',(int)$this->config->get('config_store_id'));

    $token = (isset($this->request->get['token']) && $this->request->get['token']) ? $this->request->get['token'] : '';

    $record_status = $this->{'model_extension_ocdevwizard_'.$this->_name}->getRecordByToken($token);

    if (isset($form_data['activate']) && $form_data['activate'] && $record_status) {
      $this->document->setTitle($this->language->get('heading_title_actions'));

      $data['breadcrumbs'][] = [
        'text'      => $this->language->get('heading_title_actions'),
        'href'      => $this->url->link('extension/ocdevwizard/'.$this->_name.'/actions'),
        'separator' => (version_compare(VERSION,'2.0.0.0','<')) ? $this->language->get('text_separator') : ''
      ];

      $data['heading_title'] = $this->language->get('heading_title_actions');

      $data['_name'] = $this->_name;
      $data['_code'] = $this->_code;

      $data['text_result_message'] = $this->language->get('text_record_unsubscribe_success');

      $this->{'model_extension_ocdevwizard_'.$this->_name}->unSubscribe($token);

      if (version_compare(VERSION,'2.0.0.0','<')) {
        $data['column_left']    = $this->getChild('common/column_left');
        $data['column_right']   = $this->getChild('common/column_right');
        $data['content_top']    = $this->getChild('common/content_top');
        $data['content_bottom'] = $this->getChild('common/content_bottom');
        $data['footer']         = $this->getChild('common/footer');
        $data['header']         = $this->getChild('common/header');
      } else {
        $data['column_left']    = $this->load->controller('common/column_left');
        $data['column_right']   = $this->load->controller('common/column_right');
        $data['content_top']    = $this->load->controller('common/content_top');
        $data['content_bottom'] = $this->load->controller('common/content_bottom');
        $data['footer']         = $this->load->controller('common/footer');
        $data['header']         = $this->load->controller('common/header');
      }

      if (version_compare(VERSION,'2.0.0.0','>=') && version_compare(VERSION,'2.1.0.2','<=')) {
        if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/actions.tpl')) {
          $view = $this->load->view($this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/actions.tpl',$data);
        } else {
          $view = $this->load->view('default/template/extension/ocdevwizard/'.$this->_name.'/actions.tpl',$data);
        }

        $this->response->setOutput($view);
      } else if (version_compare(VERSION,'3.0.0.0','>=')) {
        $this->response->setOutput($this->load->view('extension/ocdevwizard/'.$this->_name.'/actions',$data));
      } else if (version_compare(VERSION,'2.0.0.0','<')) {
        $this->data = $data;

        if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/actions_for_oc1.tpl')) {
          $this->template = $this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/actions_for_oc1.tpl';
        } else {
          $this->template = 'default/template/extension/ocdevwizard/'.$this->_name.'/actions_for_oc1.tpl';
        }

        $this->response->setOutput($this->render());
      } else {
        $this->response->setOutput($this->load->view('extension/ocdevwizard/'.$this->_name.'/actions.tpl',$data));
      }
    } else {
      $data['breadcrumbs'][] = [
        'text'      => $this->language->get('error_actions'),
        'href'      => $this->url->link('extension/ocdevwizard/'.$this->_name.'/actions'),
        'separator' => (version_compare(VERSION,'2.0.0.0','<')) ? $this->language->get('text_separator') : ''
      ];

      $this->document->setTitle($this->language->get('error_actions'));

      $data['heading_title'] = $this->language->get('error_actions');

      $data['text_error'] = $this->language->get('error_actions');

      $data['button_continue'] = $this->language->get('button_continue');

      $data['continue'] = $this->url->link('common/home');

      if (version_compare(VERSION,'2.0.0.0','<')) {
        $data['column_left']    = $this->getChild('common/column_left');
        $data['column_right']   = $this->getChild('common/column_right');
        $data['content_top']    = $this->getChild('common/content_top');
        $data['content_bottom'] = $this->getChild('common/content_bottom');
        $data['footer']         = $this->getChild('common/footer');
        $data['header']         = $this->getChild('common/header');
      } else {
        $data['column_left']    = $this->load->controller('common/column_left');
        $data['column_right']   = $this->load->controller('common/column_right');
        $data['content_top']    = $this->load->controller('common/content_top');
        $data['content_bottom'] = $this->load->controller('common/content_bottom');
        $data['footer']         = $this->load->controller('common/footer');
        $data['header']         = $this->load->controller('common/header');
      }

      if (version_compare(VERSION,'2.0.0.0','>=') && version_compare(VERSION,'2.1.0.2','<=')) {
        if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/error/not_found.tpl')) {
          $view = $this->load->view($this->config->get('config_template').'/template/error/not_found.tpl',$data);
        } else {
          $view = $this->load->view('default/template/error/not_found.tpl',$data);
        }

        $this->response->setOutput($view);
      } else if (version_compare(VERSION,'3.0.0.0','>=')) {
        $this->response->setOutput($this->load->view('error/not_found',$data));
      } else if (version_compare(VERSION,'2.0.0.0','<')) {
        $this->data = $data;

        if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/error/not_found.tpl')) {
          $this->template = $this->config->get('config_template').'/template/error/not_found.tpl';
        } else {
          $this->template = 'default/template/error/not_found.tpl';
        }

        $this->response->setOutput($this->render());
      } else {
        $this->response->setOutput($this->load->view('error/not_found.tpl',$data));
      }
    }
  }

  public function account_page() {
    if (!$this->customer->isLogged()) {
      $this->session->data['redirect'] = $this->url->link('extension/ocdevwizard/'.$this->_name.'/account_page','','SSL');

      $this->response->redirect($this->url->link('account/login','','SSL'));
    }

    $data = [];

    $models = [
      'tool/image',
      'extension/ocdevwizard/'.$this->_name,
      'extension/ocdevwizard/helper'
    ];

    foreach ($models as $model) {
      $this->load->model($model);
    }

    $data = array_merge($data,$this->language->load('extension/ocdevwizard/'.$this->_name));

    $data['breadcrumbs'] = [];

    $data['breadcrumbs'][] = [
      'text'      => $this->language->get('text_home'),
      'href'      => $this->url->link('common/home'),
      'separator' => false
    ];

    $data['breadcrumbs'][] = [
      'text'      => $this->language->get('text_account'),
      'href'      => $this->url->link('account/account','','SSL'),
      'separator' => (version_compare(VERSION,'2.0.0.0','<')) ? $this->language->get('text_separator') : ''
    ];

    $form_data = $this->model_extension_ocdevwizard_helper->getSettingData($this->_name.'_form_data',(int)$this->config->get('config_store_id'));

    if (isset($form_data['activate']) && $form_data['activate']) {
      $this->document->setTitle($this->language->get('heading_title_account_page'));

      $data['breadcrumbs'][] = [
        'text'      => $this->language->get('heading_title_account_page'),
        'href'      => $this->url->link('extension/ocdevwizard/'.$this->_name.'/account_page','','SSL'),
        'separator' => (version_compare(VERSION,'2.0.0.0','<')) ? $this->language->get('text_separator') : ''
      ];

      $data['heading_title'] = $this->language->get('heading_title_account_page');

      $data['_name'] = $this->_name;
      $data['_code'] = $this->_code;

      if (isset($this->request->get['page'])) {
        $page = $this->request->get['page'];
      } else {
        $page = 1;
      }

      if (isset($this->session->data['error'])) {
        $data['error_warning'] = $this->session->data['error'];

        unset($this->session->data['error']);
      } else {
        $data['error_warning'] = '';
      }

      if (isset($this->session->data['success'])) {
        $data['success'] = $this->session->data['success'];

        unset($this->session->data['success']);
      } else {
        $data['success'] = '';
      }

      $data['products'] = [];

      $filter_data = [
        'customer_id' => $this->customer->getId(),
        'start'       => ($page - 1) * 10,
        'limit'       => 10
      ];

      $product_total = $this->{'model_extension_ocdevwizard_'.$this->_name}->getTotalRecordsForPage($filter_data);

      $results = $this->{'model_extension_ocdevwizard_'.$this->_name}->getRecordsForPage($filter_data);

      if ($results) {
        foreach ($results as $result) {
          $product_info = $this->{'model_extension_ocdevwizard_'.$this->_name}->getProductForPage($result['product_id']);

          if ($product_info) {
            $image = $product_info['image'] ? $this->model_tool_image->resize($product_info['image'],50,50) : $this->model_tool_image->resize("no_image.png",50,50);

            $option_data = [];

            $filter_data = [
              'product_id' => $product_info['product_id'],
              'record_id'  => $result['record_id']
            ];

            $options = unserialize($this->{'model_extension_ocdevwizard_'.$this->_name}->getRecordProductInfo($filter_data));

            foreach ($options as $option) {
              $option_data[] = [
                'name'  => $option['name'],
                'value' => $option['value']
              ];
            }

            $data['products'][] = [
              'record_product_id' => $result['record_product_id'],
              'image'             => $image,
              'options'           => $option_data,
              'name'              => $product_info['name'],
              'quantity'          => $result['quantity'],
              'href'              => $this->url->link('product/product','product_id='.$product_info['product_id']),
              'add'               => $this->url->link('extension/ocdevwizard/'.$this->_name.'/re_add','record_product_id='.$result['record_product_id'],'SSL')
            ];
          }
        }
      }

      $pagination        = new Pagination();
      $pagination->total = $product_total;
      $pagination->page  = $page;
      $pagination->limit = 10;
      $pagination->url   = $this->url->link('extension/ocdevwizard/'.$this->_name.'/account_page','page={page}','SSL');

      $data['pagination'] = $pagination->render();

      $data['results'] = sprintf($this->language->get('text_pagination'),($product_total) ? (($page - 1) * 10) + 1 : 0,((($page - 1) * 10) > ($product_total - 10)) ? $product_total : ((($page - 1) * 10) + 10),$product_total,ceil($product_total / 10));

      if (version_compare(VERSION,'2.0.0.0','<')) {
        $data['column_left']    = $this->getChild('common/column_left');
        $data['column_right']   = $this->getChild('common/column_right');
        $data['content_top']    = $this->getChild('common/content_top');
        $data['content_bottom'] = $this->getChild('common/content_bottom');
        $data['footer']         = $this->getChild('common/footer');
        $data['header']         = $this->getChild('common/header');
      } else {
        $data['column_left']    = $this->load->controller('common/column_left');
        $data['column_right']   = $this->load->controller('common/column_right');
        $data['content_top']    = $this->load->controller('common/content_top');
        $data['content_bottom'] = $this->load->controller('common/content_bottom');
        $data['footer']         = $this->load->controller('common/footer');
        $data['header']         = $this->load->controller('common/header');
      }

      if (version_compare(VERSION,'2.0.0.0','>=') && version_compare(VERSION,'2.1.0.2','<=')) {
        if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/account_page.tpl')) {
          $view = $this->load->view($this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/account_page.tpl',$data);
        } else {
          $view = $this->load->view('default/template/extension/ocdevwizard/'.$this->_name.'/account_page.tpl',$data);
        }

        $this->response->setOutput($view);
      } else if (version_compare(VERSION,'3.0.0.0','>=')) {
        $this->response->setOutput($this->load->view('extension/ocdevwizard/'.$this->_name.'/account_page',$data));
      } else if (version_compare(VERSION,'2.0.0.0','<')) {
        $this->data = $data;

        if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/account_page_for_oc1.tpl')) {
          $this->template = $this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/account_page_for_oc1.tpl';
        } else {
          $this->template = 'default/template/extension/ocdevwizard/'.$this->_name.'/account_page_for_oc1.tpl';
        }

        $this->response->setOutput($this->render());
      } else {
        $this->response->setOutput($this->load->view('extension/ocdevwizard/'.$this->_name.'/account_page.tpl',$data));
      }
    } else {
      $data['breadcrumbs'][] = [
        'text'      => $this->language->get('error_page'),
        'href'      => $this->url->link('extension/ocdevwizard/'.$this->_name.'/account_page','','SSL'),
        'separator' => (version_compare(VERSION,'2.0.0.0','<')) ? $this->language->get('text_separator') : ''
      ];

      $this->document->setTitle($this->language->get('error_page'));

      $data['heading_title'] = $this->language->get('error_page');

      $data['text_error'] = $this->language->get('error_page');

      $data['button_continue'] = $this->language->get('button_continue');

      $data['continue'] = $this->url->link('common/home');

      if (version_compare(VERSION,'2.0.0.0','<')) {
        $data['column_left']    = $this->getChild('common/column_left');
        $data['column_right']   = $this->getChild('common/column_right');
        $data['content_top']    = $this->getChild('common/content_top');
        $data['content_bottom'] = $this->getChild('common/content_bottom');
        $data['footer']         = $this->getChild('common/footer');
        $data['header']         = $this->getChild('common/header');
      } else {
        $data['column_left']    = $this->load->controller('common/column_left');
        $data['column_right']   = $this->load->controller('common/column_right');
        $data['content_top']    = $this->load->controller('common/content_top');
        $data['content_bottom'] = $this->load->controller('common/content_bottom');
        $data['footer']         = $this->load->controller('common/footer');
        $data['header']         = $this->load->controller('common/header');
      }

      if (version_compare(VERSION,'2.0.0.0','>=') && version_compare(VERSION,'2.1.0.2','<=')) {
        if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/error/not_found.tpl')) {
          $view = $this->load->view($this->config->get('config_template').'/template/error/not_found.tpl',$data);
        } else {
          $view = $this->load->view('default/template/error/not_found.tpl',$data);
        }

        $this->response->setOutput($view);
      } else if (version_compare(VERSION,'3.0.0.0','>=')) {
        $this->response->setOutput($this->load->view('error/not_found',$data));
      } else if (version_compare(VERSION,'2.0.0.0','<')) {
        $this->data = $data;

        if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/error/not_found.tpl')) {
          $this->template = $this->config->get('config_template').'/template/error/not_found.tpl';
        } else {
          $this->template = 'default/template/error/not_found.tpl';
        }

        $this->response->setOutput($this->render());
      } else {
        $this->response->setOutput($this->load->view('error/not_found.tpl',$data));
      }
    }
  }

  public function cart_page() {
    $data = [];

    $models = [
      'catalog/product',
      'tool/image',
      'extension/ocdevwizard/'.$this->_name,
      'extension/ocdevwizard/helper'
    ];

    if (version_compare(VERSION,'2.0.0.0','>=')) {
      $models[] = 'tool/upload';
    }

    if (version_compare(VERSION,'2.0.0.0','<') || version_compare(VERSION,'3.0.0.0','>=')) {
      $models[] = 'setting/extension';
    } else {
      $models[] = 'extension/extension';
    }

    foreach ($models as $model) {
      $this->load->model($model);
    }

    $form_data = $this->model_extension_ocdevwizard_helper->getSettingData($this->_name.'_form_data',(int)$this->config->get('config_store_id'));
    $text_data = $this->model_extension_ocdevwizard_helper->getSettingData($this->_name.'_text_data',(int)$this->config->get('config_store_id'));

    $data = array_merge($data,$this->language->load('extension/ocdevwizard/'.$this->_name),$text_data,$form_data);

    if (!isset($form_data['activate']) || (isset($form_data['activate']) && !$form_data['activate'])) {
      $this->response->redirect($this->url->link('common/home'));
    }

    $data['breadcrumbs'] = [];

    $data['breadcrumbs'][] = [
      'text'      => $this->language->get('text_home'),
      'href'      => $this->url->link('common/home'),
      'separator' => false
    ];

    $language_id = $this->{'model_extension_ocdevwizard_'.$this->_name}->getLanguageIdByCode($this->session->data['language']);

    $this->document->setTitle((isset($text_data[$language_id])) ? html_entity_decode($text_data[$language_id]['cart_page_name'],ENT_QUOTES,'UTF-8') : '');

    $data['breadcrumbs'][] = [
      'text'      => (isset($text_data[$language_id])) ? html_entity_decode($text_data[$language_id]['cart_page_name'],ENT_QUOTES,'UTF-8') : '',
      'href'      => $this->url->link('extension/ocdevwizard/'.$this->_name.'/cart_page','','SSL'),
      'separator' => (version_compare(VERSION,'2.0.0.0','<')) ? $this->language->get('text_separator') : ''
    ];

    $data['heading_title'] = (isset($text_data[$language_id])) ? html_entity_decode($text_data[$language_id]['cart_page_name'],ENT_QUOTES,'UTF-8') : '';

    $data['_name'] = $this->_name;
    $data['_code'] = $this->_code;

    $data['text_empty']        = (isset($text_data[$language_id])) ? html_entity_decode($text_data[$language_id]['empty_message'],ENT_QUOTES,'UTF-8') : '';
    $data['description']       = (isset($text_data[$language_id])) ? html_entity_decode($text_data[$language_id]['cart_page_description'],ENT_QUOTES,'UTF-8') : '';
    $data['button_go_to_page'] = (isset($text_data[$language_id])) ? html_entity_decode($text_data[$language_id]['cart_page_checkout_button'],ENT_QUOTES,'UTF-8') : '';
    $data['button_go_back']    = (isset($text_data[$language_id])) ? html_entity_decode($text_data[$language_id]['cart_page_close_button'],ENT_QUOTES,'UTF-8') : '';
    $data['is_opencart_1']     = (version_compare(VERSION,'2.0.0.0','<')) ? 1 : 0;

    $data['_name']          = $this->_name;
    $data['_code']          = $this->_code;
    $data['_language_code'] = substr($this->session->data['language'],0,2);
    $data['continue']       = $this->url->link('common/home');

    if (isset($this->request->post['remove'])) {
      $this->cart->remove($this->request->post['remove']);
      unset($this->session->data['vouchers'][$this->request->post['remove']]);
    }

    if (isset($this->request->post['update'])) {
      $this->cart->update($this->request->post['update'],$this->request->post['quantity']);
    }

    if (isset($this->request->post['add'])) {
      $this->cart->add($this->request->post['add'],$this->request->post['quantity']);
    }

    $data['page_link'] = $this->url->link($form_data['cart_page_route_to_chekout_page'],'','SSL');
    $data['continue']  = $this->url->link('common/home');

    $points                    = $this->customer->getRewardPoints();
    $data['text_reward_title'] = sprintf($this->language->get('text_reward_title_heading'),$points);

    // cart products
    if (!$this->cart->hasStock() && (!$this->config->get('config_stock_checkout') || $this->config->get('config_stock_warning'))) {
      $data['error_warning'] = $this->language->get('error_stock');
    } else if (isset($this->session->data['error'])) {
      $data['error_warning'] = $this->session->data['error'];

      unset($this->session->data['error']);
    } else {
      $data['error_warning'] = '';
    }

    if ($this->config->get('config_customer_price') && !$this->customer->isLogged()) {
      $data['attention'] = sprintf($this->language->get('text_login'),$this->url->link('account/login'),$this->url->link('account/register'));
    } else {
      $data['attention'] = '';
    }

    if (isset($this->session->data['success'])) {
      $data['success'] = $this->session->data['success'];

      unset($this->session->data['success']);
    } else {
      $data['success'] = '';
    }

    $data['products']       = [];
    $data['total_products'] = count($this->cart->getProducts());

    $tag_codes = [
      '{count_products}',
    ];

    $tag_codes_replace = [
      count($this->cart->getProducts()) - $form_data['cart_page_product_list_limit']
    ];

    $text_items = html_entity_decode($this->language->get('text_show_more_products'),ENT_QUOTES,'UTF-8');

    preg_match_all('/{declension}(.*?){\/declension}/',$this->language->get('text_show_more_products'),$text_items_matches,PREG_SET_ORDER);

    if ($text_items_matches) {
      foreach ($text_items_matches as $text_items_match) {
        preg_match('/{declension}(.*?){\/declension}/',$text_items_match[0],$text_items_match_item);

        if ((isset($text_items_match_item[0]) && $text_items_match_item[0]) && (isset($text_items_match_item[1]) && $text_items_match_item[1])) {
          $declension_words = explode("|",$text_items_match_item[1]);

          $declension_data = [
            'number' => (count($this->cart->getProducts()) > $form_data['cart_page_product_list_limit']) ? (count($this->cart->getProducts()) - $form_data['cart_page_product_list_limit']) : count($this->cart->getProducts()),
            'words'  => $declension_words
          ];

          if (version_compare(VERSION,'2.0.0.0','<')) {
            $text_items = str_replace($text_items_match_item[0],$this->getChild('extension/ocdevwizard/'.$this->_name.'/make_declension',$declension_data),$text_items);
          } else {
            $text_items = str_replace($text_items_match_item[0],$this->load->controller('extension/ocdevwizard/'.$this->_name.'/make_declension',$declension_data),$text_items);
          }
        }
      }
    }

    $data['button_show_more_products'] = html_entity_decode(str_replace($tag_codes,$tag_codes_replace,$text_items),ENT_QUOTES,'UTF-8');

    foreach ($this->cart->getProducts() as $product) {
      $product_info = $this->model_catalog_product->getProduct($product['product_id']);

      if ($product_info['quantity'] <= 0) {
        $stock_text = $product_info['stock_status'];
      } else if ($this->config->get('config_stock_display')) {
        $stock_text = $product['quantity'];
      } else {
        $stock_text = $this->language->get('text_instock');
      }

      $image = ($product['image']) ? $this->model_tool_image->resize($product['image'],$form_data['cart_page_main_image_width'],$form_data['cart_page_main_image_height']) : $this->model_tool_image->resize("no_image.png",$form_data['cart_page_main_image_width'],$form_data['cart_page_main_image_height']);

      $option_data = [];

      foreach ($product['option'] as $option) {
        if ($option['type'] != 'file') {
          if (version_compare(VERSION,'2.0.0.0','<')) {
            $value = $option['option_value'];
          } else {
            $value = $option['value'];
          }
        } else {
          if (version_compare(VERSION,'2.0.0.0','<')) {
            $filename = $this->encryption->decrypt($option['option_value']);
            $value    = utf8_substr($filename,0,utf8_strrpos($filename,'.'));
          } else {
            $upload_info = $this->model_tool_upload->getUploadByCode($option['value']);
            $value       = ($upload_info) ? $upload_info['name'] : '';
          }
        }

        $option_data[] = [
          'name'  => $option['name'],
          'value' => (utf8_strlen($value) > 20 ? utf8_substr($value,0,20).'..' : $value)
        ];
      }

      // display price
      $price = (($this->config->get('config_customer_price') && $this->customer->isLogged()) || !$this->config->get('config_customer_price')) ? $this->currency->format($this->tax->calculate($product['price'],$product['tax_class_id'],$this->config->get('config_tax')),$this->_session_currency) : false;

      // display tax
      if ($this->config->get('config_tax')) {
        $tax       = $this->currency->format((float)$product['price'],$this->_session_currency);
        $tax_total = $this->currency->format($product['price'] * $product['quantity'],$this->_session_currency);
      } else {
        $tax       = false;
        $tax_total = false;
      }

      // display unit total
      $product_total = (($this->config->get('config_customer_price') && $this->customer->isLogged()) || !$this->config->get('config_customer_price')) ? $this->currency->format($this->tax->calculate($product['price'],$product['tax_class_id'],$this->config->get('config_tax')) * $product['quantity'],$this->_session_currency) : false;

      if (version_compare(VERSION,'2.0.3.1','<=')) {
        $_product_key = $product['key'];
      } else {
        $_product_key = $product['cart_id'];
      }

      $data['products'][] = [
        'key'        => $_product_key,
        'product_id' => $product['product_id'],
        'thumb'      => $image,
        'name'       => $product['name'],
        'model'      => $product['model'],
        'ean'        => $product_info['ean'],
        'jan'        => $product_info['jan'],
        'isbn'       => $product_info['isbn'],
        'mpn'        => $product_info['mpn'],
        'location'   => $product_info['location'],
        'option'     => $option_data,
        'quantity'   => $product['quantity'],
        'minimum'    => $product['minimum'] > 0 ? $product['minimum'] : 1,
        'stock_text' => $stock_text,
        'stock'      => $product['stock'] ? true : !(!$this->config->get('config_stock_checkout') || $this->config->get('config_stock_warning')),
        'reward'     => $product['reward'] ? $product['reward'] : '',
        'price'      => $price,
        'tax'        => $tax,
        'tax_total'  => $tax_total,
        'total'      => $product_total,
        'href'       => $this->url->link('product/product','product_id='.$product['product_id']),
        'voucher'    => false
      ];
    }

    // gift voucher
    if (!empty($this->session->data['vouchers'])) {
      foreach ($this->session->data['vouchers'] as $key => $voucher) {
        $data['products'][] = [
          'key'        => $key,
          'product_id' => 0,
          'thumb'      => false,
          'name'       => $voucher['description'],
          'model'      => false,
          'ean'        => false,
          'jan'        => false,
          'isbn'       => false,
          'mpn'        => false,
          'location'   => false,
          'option'     => [],
          'quantity'   => 1,
          'stock_text' => false,
          'stock'      => true,
          'reward'     => '',
          'price'      => $this->currency->format($voucher['amount'],$this->_session_currency),
          'tax'        => false,
          'tax_total'  => false,
          'total'      => $this->currency->format($voucher['amount'],$this->_session_currency),
          'href'       => false,
          'voucher'    => true
        ];
      }
    }

    // totals
    if (version_compare(VERSION,'2.1.0.2.1','<=')) {
      $total_data = [];
      $total      = 0;
      $taxes      = $this->cart->getTaxes();
    } else {
      $totals = [];
      $taxes  = $this->cart->getTaxes();
      $total  = 0;

      // Because __call can not keep var references so we put them into an array.
      $total_data = [
        'totals' => &$totals,
        'taxes'  => &$taxes,
        'total'  => &$total
      ];
    }

    // display prices
    if (($this->config->get('config_customer_price') && $this->customer->isLogged()) || !$this->config->get('config_customer_price')) {
      $sort_order = [];

      if (version_compare(VERSION,'2.0.0.0','<') || version_compare(VERSION,'3.0.0.0','>=')) {
        $results = $this->model_setting_extension->getExtensions('total');
      } else {
        $results = $this->model_extension_extension->getExtensions('total');
      }

      foreach ($results as $key => $value) {
        if (version_compare(VERSION,'3.0.0.0','>=')) {
          $sort_order[$key] = $this->config->get('total_'.$value['code'].'_sort_order');
        } else {
          $sort_order[$key] = $this->config->get($value['code'].'_sort_order');
        }
      }

      array_multisort($sort_order,SORT_ASC,$results);

      foreach ($results as $result) {
        if (version_compare(VERSION,'3.0.0.0','>=')) {
          $_total_status = $this->config->get('total_'.$result['code'].'_status');
        } else {
          $_total_status = $this->config->get($result['code'].'_status');
        }

        if (version_compare(VERSION,'2.1.0.2.1','<=')) {
          $this->load->model('total/'.$result['code']);
          $this->{'model_total_'.$result['code']}->getTotal($total_data,$total,$taxes);
        } else {
          $this->load->model('extension/total/'.$result['code']);
          $this->{'model_extension_total_'.$result['code']}->getTotal($total_data);
        }

        $sort_order = [];

        if (version_compare(VERSION,'2.1.0.2.1','<=')) {
          foreach ($total_data as $key => $value) {
            $sort_order[$key] = $value['sort_order'];
          }

          array_multisort($sort_order,SORT_ASC,$total_data);
        } else {
          foreach ($totals as $key => $value) {
            $sort_order[$key] = $value['sort_order'];
          }

          array_multisort($sort_order,SORT_ASC,$totals);
        }
      }

      $data['totals'] = [];

      if (version_compare(VERSION,'2.1.0.2.1','<=')) {
        foreach ($total_data as $total) {
          if (isset($form_data['cart_page_extension_totals']) && in_array($total['code'],$form_data['cart_page_extension_totals'])) {
            $data['totals'][] = [
              'title' => $total['title'],
              'text'  => $this->currency->format($total['value'],$this->_session_currency)
            ];
          }
        }
      } else {
        foreach ($totals as $total) {
          if (isset($form_data['cart_page_extension_totals']) && in_array($total['code'],$form_data['cart_page_extension_totals'])) {
            $data['totals'][] = [
              'title' => $total['title'],
              'text'  => $this->currency->format($total['value'],$this->_session_currency)
            ];
          }
        }
      }
    }

    if ($form_data['cart_page_cart_weight_status']) {
      $data['totals'][] = [
        'title' => $this->language->get('text_cart_weight'),
        'text'  => $this->weight->format($this->cart->getWeight(),$this->config->get('config_weight_class_id'),$this->language->get('decimal_point'),$this->language->get('thousand_point'))
      ];
    }

    $data['module_recommended_products'] = '';

    $recommended_products_form_data = (array)$this->model_extension_ocdevwizard_helper->getSettingData('recommended_products_form_data',(int)$this->config->get('config_store_id'));

    if (isset($recommended_products_form_data['activate']) && $recommended_products_form_data['activate'] && $form_data['module_recommended_products_cart_page']) {
      $this->load->model('extension/ocdevwizard/recommended_products');

      if (version_compare(VERSION,'2.0.0.0','<')) {
        $data['module_recommended_products'] = $this->getChild('extension/ocdevwizard/recommended_products/module',$this->model_extension_ocdevwizard_recommended_products->getModule($form_data['module_recommended_products_cart_page']));
      } else {
        $data['module_recommended_products'] = $this->load->controller('extension/ocdevwizard/recommended_products/module',$this->model_extension_ocdevwizard_recommended_products->getModule($form_data['module_recommended_products_cart_page']));
      }
    }

    $data['module_checkout'] = '';

    $checkout_form_data = (array)$this->model_extension_ocdevwizard_helper->getSettingData('checkout_form_data',(int)$this->config->get('config_store_id'));

    if (isset($checkout_form_data['activate']) && $checkout_form_data['activate'] && $form_data['module_checkout_cart_page']) {
      $this->load->model('extension/ocdevwizard/checkout');

      if (version_compare(VERSION,'2.0.0.0','<')) {
        $data['module_checkout'] = $this->getChild('extension/ocdevwizard/checkout/module',$this->model_extension_ocdevwizard_checkout->getModule($form_data['module_checkout_cart_page']));
      } else {
        $data['module_checkout'] = $this->load->controller('extension/ocdevwizard/checkout/module',$this->model_extension_ocdevwizard_checkout->getModule($form_data['module_checkout_cart_page']));
      }
    }

    if (version_compare(VERSION,'2.0.0.0','<')) {
      $data['coupon']        = $this->getChild('extension/ocdevwizard/'.$this->_name.'/coupon_index');
      $data['voucher']       = $this->getChild('extension/ocdevwizard/'.$this->_name.'/voucher_index');
      $data['reward']        = $this->getChild('extension/ocdevwizard/'.$this->_name.'/reward_index');
      $data['shipping']      = $this->getChild('extension/ocdevwizard/'.$this->_name.'/shipping_index');
      $data['save_products'] = $this->getChild('extension/ocdevwizard/'.$this->_name.'/save_products_index');

      $data['column_left']    = $this->getChild('common/column_left');
      $data['column_right']   = $this->getChild('common/column_right');
      $data['content_top']    = $this->getChild('common/content_top');
      $data['content_bottom'] = $this->getChild('common/content_bottom');
      $data['footer']         = $this->getChild('common/footer');
      $data['header']         = $this->getChild('common/header');
    } else {
      $data['coupon']        = $this->load->controller('extension/ocdevwizard/'.$this->_name.'/coupon_index');
      $data['voucher']       = $this->load->controller('extension/ocdevwizard/'.$this->_name.'/voucher_index');
      $data['reward']        = $this->load->controller('extension/ocdevwizard/'.$this->_name.'/reward_index');
      $data['shipping']      = $this->load->controller('extension/ocdevwizard/'.$this->_name.'/shipping_index');
      $data['save_products'] = $this->load->controller('extension/ocdevwizard/'.$this->_name.'/save_products_index');

      $data['column_left']    = $this->load->controller('common/column_left');
      $data['column_right']   = $this->load->controller('common/column_right');
      $data['content_top']    = $this->load->controller('common/content_top');
      $data['content_bottom'] = $this->load->controller('common/content_bottom');
      $data['footer']         = $this->load->controller('common/footer');
      $data['header']         = $this->load->controller('common/header');
    }

    if (version_compare(VERSION,'2.0.0.0','>=') && version_compare(VERSION,'2.1.0.2','<=')) {
      if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/cart_page.tpl')) {
        $view = $this->load->view($this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/cart_page.tpl',$data);
      } else {
        $view = $this->load->view('default/template/extension/ocdevwizard/'.$this->_name.'/cart_page.tpl',$data);
      }

      $this->response->setOutput($view);
    } else if (version_compare(VERSION,'3.0.0.0','>=')) {
      $this->response->setOutput($this->load->view('extension/ocdevwizard/'.$this->_name.'/cart_page',$data));
    } else if (version_compare(VERSION,'2.0.0.0','<')) {
      $this->data = $data;

      if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/cart_page_for_oc1.tpl')) {
        $this->template = $this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/cart_page_for_oc1.tpl';
      } else {
        $this->template = 'default/template/extension/ocdevwizard/'.$this->_name.'/cart_page_for_oc1.tpl';
      }

      $this->response->setOutput($this->render());
    } else {
      $this->response->setOutput($this->load->view('extension/ocdevwizard/'.$this->_name.'/cart_page.tpl',$data));
    }
  }

  public function delete_record() {
    if (isset($this->request->server['HTTP_X_REQUESTED_WITH']) && !empty($this->request->server['HTTP_X_REQUESTED_WITH']) && strtolower($this->request->server['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
      $json = [];

      if ($this->customer->isLogged()) {
        $this->language->load('extension/ocdevwizard/'.$this->_name);

        $record_product_id = (isset($this->request->post['delete']) && $this->request->post['delete']) ? $this->request->post['delete'] : 0;

        if ($record_product_id) {
          $models = [
            'extension/ocdevwizard/'.$this->_name
          ];

          foreach ($models as $model) {
            $this->load->model($model);
          }

          $this->{'model_extension_ocdevwizard_'.$this->_name}->deleteRecord($record_product_id);
        }
      }

      $this->response->addHeader('Content-Type: application/json');
      $this->response->setOutput(json_encode($json));
    }
  }
}

?>
