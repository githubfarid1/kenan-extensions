<?php
##==========================================##
## @author    : OCdevWizard                 ##
## @contact   : ocdevwizard@gmail.com       ##
## @support   : http://help.ocdevwizard.com ##
## @copyright : (c) OCdevWizard. Cart, 2017 ##
##==========================================##

// Buttons
$_['button_remove']                   = 'Remove';
$_['button_delete']                   = 'Delete';
$_['button_view']                     = 'View';
$_['button_add_to_cart']              = 'Add To Cart';

// Collumns
$_['column_name']                     = 'Product name';
$_['column_image']                    = 'Image';
$_['column_quantity']                 = 'Quantity';
$_['column_price']                    = 'Price';
$_['column_total']                    = 'Total';
$_['column_action']                   = 'Action';

// Text
$_['decimal_point']                   = '.';
$_['thousand_point']                  = ',';
$_['text_require_information']        = 'I have read and agree to the <a target="blank" href="%s">%s</a>';
$_['heading_title_actions']           = 'Your subscription';
$_['heading_title_account_page']      = 'Saved products in shopping cart';
$_['text_record_unsubscribe_success'] = 'Success! You successfully unsubscribed!';
$_['text_account']                    = 'Account';
$_['text_no_results']                 = 'No results!';
$_['text_are_you_sure']               = 'Are you sure?';
$_['text_page_success']               = 'Success: You have added <a href="%s">%s</a> to your <a href="%s">shopping cart</a>!';
$_['text_tax']                        = 'Ex Tax: ';
$_['text_model']                      = 'Model: ';
$_['text_ean']                        = 'EAN: ';
$_['text_jan']                        = 'JAN: ';
$_['text_isbn']                       = 'ISBN: ';
$_['text_mpn']                        = 'MPN: ';
$_['text_location']                   = 'Location: ';
$_['text_instock']                    = 'In stock';
$_['text_availability']               = 'Availability: ';
$_['text_points']                     = 'Reward Points: ';
$_['text_cart_weight']                = 'Weight';
$_['text_coupon_title']               = 'Use Coupon Code';
$_['text_voucher_title']              = 'Use Gift Voucher';
$_['text_shipping_title']             = 'Estimate Shipping &amp; Taxes';
$_['text_reward_title_heading']       = 'Use Reward Points (Available %s)';
$_['text_shipping_help']              = 'Enter your destination to get a shipping estimate.';
$_['text_shipping_method']            = 'Please select the preferred shipping method to use on this order.';
$_['text_save_products_title']        = 'Save shopping cart';
$_['text_show']                       = 'Show';
$_['text_hide']                       = 'Hide';
$_['text_show_more_products']         = 'last {count_products} {declension}product|products|products{/declension}';
$_['text_cart_items']                 = '%s item(s) - %s';
$_['text_make_a_choice']              = '-- Make a choice --';

// Entry
$_['entry_coupon']                    = 'Enter your coupon here';
$_['entry_voucher']                   = 'Enter your gift voucher code here';
$_['entry_reward']                    = 'Points to use (Max %s)';
$_['entry_country']                   = 'Select Country';
$_['entry_zone']                      = 'Select Region / State';
$_['entry_postcode']                  = 'Enter Post Code';

// Success
$_['text_success_save_products']      = 'Success! Your shopping cart has been saved!';
$_['text_success_coupon']             = 'Success! Your coupon discount has been applied!';
$_['text_success_voucher']            = 'Success! Your gift voucher discount has been applied!';
$_['text_success_shipping']           = 'Success! Your shipping estimate has been applied!';
$_['text_success_reward']             = 'Success! Your reward points discount has been applied!';

// Error
$_['error_banned_record_by_email']    = 'Warning! Your email address or IP are currently banned to send request for security reason!';
$_['error_stock']                     = 'Warning! Product(s) with red heading are not available in the desired quantity or not in stock!';
$_['error_coupon_empty']              = 'Warning! Please enter a coupon code!';
$_['error_coupon']                    = 'Warning! Coupon is either invalid, expired or reached its usage limit!';
$_['error_voucher_empty']             = 'Warning! Please enter a voucher code!';
$_['error_voucher']                   = 'Warning! Gift Voucher is either invalid or the balance has been used up!';
$_['error_shipping']                  = 'Warning! Shipping method required!';
$_['error_postcode']                  = 'Warning! Postcode must be between 2 and 10 characters!';
$_['error_country']                   = 'Warning! Please select a country!';
$_['error_zone']                      = 'Warning! Please select a region / state!';
$_['error_no_shipping']               = 'Warning! No Shipping options are available. Please <a href="%s" target="_blank">contact us</a> for assistance!';
$_['error_reward']                    = 'Warning! Please enter the amount of reward points to use!';
$_['error_points']                    = 'Warning! You don`t have %s reward points!';
$_['error_maximum']                   = 'Warning! The maximum number of points that can be applied is %s!';
$_['error_required']                  = 'Warning! %s required!';
$_['error_require_information']       = 'Warning! You must agree to the %s!';
$_['error_recaptcha']                 = 'Warning! Captcha is not valid!';
$_['error_actions']                   = 'Warning! Page not found!';
$_['error_page']                      = 'Warning! Page not found!';
?>