<?php
##==========================================##
## @author    : OCdevWizard                 ##
## @contact   : ocdevwizard@gmail.com       ##
## @support   : http://help.ocdevwizard.com ##
## @copyright : (c) OCdevWizard. Cart, 2017 ##
##==========================================##

// Buttons
$_['button_remove']                   = 'Прибрати';
$_['button_delete']                   = 'Вилучити';
$_['button_view']                     = 'Детальніше';
$_['button_add_to_cart']              = 'В кошик';

// Collumns
$_['column_name']                     = 'Назва';
$_['column_image']                    = 'Картинка';
$_['column_quantity']                 = 'Кількість';
$_['column_price']                    = 'Ціна';
$_['column_total']                    = 'Разом';
$_['column_action']                   = 'Дія';

// Text
$_['decimal_point']                   = '.';
$_['thousand_point']                  = ',';
$_['text_require_information']        = 'Мною прочитані і я даю згоду з документом <a target="_blank" href="%s">%s</a>';
$_['heading_title_actions']           = 'Ваша підписка';
$_['heading_title_account_page']      = 'Збережені товари в кошику';
$_['text_record_unsubscribe_success'] = 'Успіх! Ви успішно скасували підписку!';
$_['text_account']                    = 'Профіль';
$_['text_no_results']                 = 'Немає результатів!';
$_['text_are_you_sure']               = 'Ви впевнені?';
$_['text_page_success']               = 'Товар <a href="%s">%s</a> доданий в ваш <a href="%s">кошик</a>!';
$_['text_tax']                        = 'Без податку: ';
$_['text_model']                      = 'Модель: ';
$_['text_ean']                        = 'EAN: ';
$_['text_jan']                        = 'JAN: ';
$_['text_isbn']                       = 'ISBN: ';
$_['text_mpn']                        = 'MPN: ';
$_['text_location']                   = 'Location: ';
$_['text_instock']                    = 'В наявності';
$_['text_availability']               = 'Наявність: ';
$_['text_points']                     = 'Бонусні бали: ';
$_['text_cart_weight']                = 'Вага';
$_['text_coupon_title']               = 'Використовувати купон на знижку';
$_['text_voucher_title']              = 'Використовувати подарунковий сертифікат';
$_['text_shipping_title']             = 'Дізнатися вартість доставки';
$_['text_reward_title_heading']       = 'Використовувати бонусні бали (доступно: %s)';
$_['text_shipping_help']              = 'Якщо у вас є код купона на знижку або бонусні бали, які ви хочете використовувати, виберіть відповідний пункт. <br> Також, можна (приблизно) дізнатися вартість доставки в ваш регіон.';
$_['text_shipping_method']            = 'Що б дізнатися (приблизну) вартість доставки, вкажіть необхідну інформацію';
$_['text_save_products_title']        = 'Зберегти кошик';
$_['text_show']                       = 'Показати';
$_['text_hide']                       = 'Приховати';
$_['text_show_more_products']         = '{count_products} {declension}останній|останніх|останніх{/declension} {declension}товар|товара|товарів{/declension}';
$_['text_cart_items']                 = '%s товар(а) - %s';
$_['text_make_a_choice']              = '-- Зробіть вибір --';

// Entry
$_['entry_coupon']                    = 'Введіть код купона';
$_['entry_voucher']                   = 'Введіть код сертифіката';
$_['entry_reward']                    = 'Введіть бонусні бали';
$_['entry_country']                   = '-- Країна --';
$_['entry_zone']                      = '-- Регіон / область --';
$_['entry_postcode']                  = 'Індекс';

// Success
$_['text_success_save_products']      = 'Вітаємо! Ваш кошик був збережений.';
$_['text_success_coupon']             = 'Вітаємо! Купон застосований!';
$_['text_success_voucher']            = 'Вітаємо! Сертифікат застосований!';
$_['text_success_shipping']           = 'Вітаємо! Метод доставки застосований!';
$_['text_success_reward']             = 'Вітаємо! Бонусні бали застосовані!';

// Error
$_['error_banned_record_by_email']    = 'Увага! Ваш Email або IP-адреса заблоковані в системі для відправки повідомлень з метою безпеки!';
$_['error_stock']                     = 'Увага! Продукти з червоною назвою відсутні в потрібній кількості або їх немає в наявності!';
$_['error_coupon_empty']              = 'Увага! Введіть код купона!';
$_['error_coupon']                    = 'Увага! Купон недійсний, прострочений або закінчився ліміт його використання!';
$_['error_voucher_empty']             = 'Увага! Введіть код сертифіката!';
$_['error_voucher']                   = 'Увага! Подарунковий сертифікат або недійсний, або його балансу не вистачає для оплати замовлення!';
$_['error_shipping']                  = 'Увага! Будь ласка, вкажіть бажаний спосіб доставки!';
$_['error_postcode']                  = 'Увага! Індекс повинен бути від 2 до 10 символів!';
$_['error_country']                   = 'Увага! Будь ласка, вкажіть Країну!';
$_['error_zone']                      = 'Увага! Будь ласка, вкажіть Регіон / область!';
$_['error_no_shipping']               = 'Увага! Немає жодного доступного способу доставки. Будь ласка, <a href="%s" target="_blank">зв`яжіться з нами</a> для вирішення цього питання!';
$_['error_reward']                    = 'Увага! Будь ласка, вкажіть кількість бонусних балів яке хочете використовувати для цього замовлення!';
$_['error_points']                    = 'Увага! У вас не вистачає бонусних балів, необхідно ще %s!';
$_['error_maximum']                   = 'Увага! Максимальна кількість балів, яку може бути використано для цього замовлення - %s!';
$_['error_required']                  = 'Увага! %s необхідний!';
$_['error_require_information']       = 'Увага! Ви повинні погодитися з %s!';
$_['error_recaptcha']                 = 'Увага! Captcha не дійсна!';
$_['error_actions']                   = 'Увага! Сторінку не знайдено!';
$_['error_page']                      = 'Увага! Сторінку не знайдено!';
?>