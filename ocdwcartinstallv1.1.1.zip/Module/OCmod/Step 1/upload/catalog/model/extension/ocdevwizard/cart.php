<?php
##==========================================##
## @author    : OCdevWizard                 ##
## @contact   : ocdevwizard@gmail.com       ##
## @support   : http://help.ocdevwizard.com ##
## @copyright : (c) OCdevWizard. Cart, 2017 ##
##==========================================##
class ModelExtensionOcdevwizardCart extends Model {
  private $_name      = 'cart';
  private $_code      = 'ocdw_cart';
  private $_session_currency;
  private $_while_max = 100;

  public function __construct($registry) {
    parent::__construct($registry);

    if (version_compare(VERSION,'2.1.0.2.1','<=')) {
      $this->_session_currency = '';
    } else {
      $this->_session_currency = $this->session->data['currency'];
    }
  }

  public function getModules($layout_id,$position) {
    $results = [];

    $this->load->model('extension/ocdevwizard/helper');

    $form_data = $this->model_extension_ocdevwizard_helper->getSettingData($this->_name.'_form_data',(int)$this->config->get('config_store_id'));

    if (isset($form_data['activate']) && $form_data['activate'] && (isset($form_data['layout_for_module']) && $form_data['layout_for_module'])) {
      if ($form_data['display_type'] == 3 && $form_data['position'] == $position && in_array($layout_id,$form_data['layout_for_module'])) {
        $results[] = [
          'layout_module_id' => 1,
          'layout_id'        => $layout_id,
          'code'             => $this->_code.'.1',
          'position'         => $position,
          'sort_order'       => $form_data['sort_order']
        ];
      }
    }

    return $results;
  }

  public function addRecord($data) {
    $models = [];

    if (version_compare(VERSION,'2.0.0.0','>=')) {
      $models[] = 'tool/upload';
    }

    foreach ($models as $model) {
      $this->load->model($model);
    }

    $email = '';

    if (isset($data['field_data']) && $data['field_data']) {
      foreach ($data['field_data'] as $field) {
        if ($field['type'] == 'email') {
          $email = $field['value'];
        }
      }
    }

    if ($this->customer->isLogged()) {
      $record_id = $this->getRecordByCustomerId($data['customer_id']);
    } else {
      $record_id = $this->getRecordByEmail($email);
    }

    if ($record_id) {
      $this->db->query("
        UPDATE ".DB_PREFIX.$this->_code."_record
        SET
          currency_code = '".$this->db->escape($data['currency_code'])."',
          currency_value = '".(float)$data['currency_value']."',
          field_data = '".$this->db->escape(serialize($data['field_data']))."',
          token = '".$this->db->escape($data['token'])."',
          ip = '".$this->db->escape($data['ip'])."',
          referer = '".$this->db->escape($data['referer'])."',
          user_agent = '".$this->db->escape($data['user_agent'])."',
          accept_language = '".$this->db->escape($data['accept_language'])."',
          user_language_id = '".(int)$data['user_language_id']."',
          user_currency_id = '".(int)$data['user_currency_id']."',
          user_customer_group_id = '".(int)$data['user_customer_group_id']."',
          store_name = '".$this->db->escape($data['store_name'])."',
          store_url = '".$this->db->escape($data['store_url'])."',
          store_id = '".(int)$data['store_id']."'
        WHERE record_id = '".(int)$record_id."'
      ");
    } else {
      $this->db->query("
        INSERT INTO ".DB_PREFIX.$this->_code."_record
        SET
          customer_id = '".(int)$data['customer_id']."',
          currency_code = '".$this->db->escape($data['currency_code'])."',
          currency_value = '".(float)$data['currency_value']."',
          field_data = '".$this->db->escape(serialize($data['field_data']))."',
          email = '".$this->db->escape($email)."',
          token = '".$this->db->escape($data['token'])."',
          ip = '".$this->db->escape($data['ip'])."',
          referer = '".$this->db->escape($data['referer'])."',
          user_agent = '".$this->db->escape($data['user_agent'])."',
          accept_language = '".$this->db->escape($data['accept_language'])."',
          user_language_id = '".(int)$data['user_language_id']."',
          user_currency_id = '".(int)$data['user_currency_id']."',
          user_customer_group_id = '".(int)$data['user_customer_group_id']."',
          store_name = '".$this->db->escape($data['store_name'])."',
          store_url = '".$this->db->escape($data['store_url'])."',
          store_id = '".(int)$data['store_id']."',
          date_added = NOW()
      ");

      $record_id = $this->db->getLastId();
    }

    $this->db->query("DELETE FROM ".DB_PREFIX.$this->_code."_record_product WHERE record_id = '".(int)$record_id."'");

    foreach ($data['cart'] as $product) {
      $options = [];

      if ($product['option']) {
        foreach ($product['option'] as $option) {
          if ($option['type'] != 'file') {
            if (version_compare(VERSION,'2.0.0.0','<')) {
              $value = $option['option_value'];
            } else {
              $value = $option['value'];
            }
          } else {
            if (version_compare(VERSION,'2.0.0.0','<')) {
              $value = $this->encryption->decrypt($option['option_value']);
            } else {
              $upload_info = $this->model_tool_upload->getUploadByCode($option['value']);
              $value       = ($upload_info) ? $upload_info['name'] : '';
            }
          }

          $options[] = [
            'record_id'               => $record_id,
            'record_product_id'       => $product['product_id'],
            'product_option_id'       => $option['product_option_id'],
            'product_option_value_id' => $option['product_option_value_id'],
            'name'                    => $option['name'],
            'value'                   => $value,
            'type'                    => $option['type']
          ];
        }
      }

      $this->db->query("
        INSERT INTO ".DB_PREFIX.$this->_code."_record_product 
        SET 
          record_id = '".(int)$record_id."', 
          product_id = '".(int)$product['product_id']."',
          quantity = '".(int)$product['quantity']."',
          options = '".$this->db->escape(serialize($options))."'
      ");
    }

    $data['record_id'] = $record_id;

    $this->mailing($data,['to_admin_on_new_record','to_user_on_new_record']);
  }

  public function getLanguageIdByCode($code) {
    return $this->db->query("SELECT language_id FROM ".DB_PREFIX."language WHERE code = '".$this->db->escape($code)."'")->row['language_id'];
  }

  public function getCurrencyIdByCode($code) {
    return $this->db->query("SELECT currency_id FROM ".DB_PREFIX."currency WHERE code = '".$this->db->escape($code)."'")->row['currency_id'];
  }

  public function getCurrencyById($currency_id) {
    return $this->db->query("SELECT * FROM ".DB_PREFIX."currency WHERE currency_id = '".(int)$currency_id."'")->row;
  }

  public function getStore($store_id) {
    return $this->db->query("SELECT DISTINCT * FROM ".DB_PREFIX."store WHERE store_id = '".(int)$store_id."'")->row;
  }

  public function getField($field_id) {
    $query = $this->db->query("SELECT * FROM ".DB_PREFIX.$this->_code."_field f LEFT JOIN ".DB_PREFIX.$this->_code."_field_description fd ON (f.field_id = fd.field_id) WHERE f.field_id = '".(int)$field_id."' AND f.status = '1' AND fd.language_id = '".(int)$this->config->get('config_language_id')."'");

    if ($query->num_rows) {
      return [
        'field_id'           => $query->row['field_id'],
        'name'               => $query->row['name'],
        'description'        => $query->row['description'],
        'placeholder'        => $query->row['placeholder'],
        'error_text'         => $query->row['error_text'],
        'field_type'         => $query->row['field_type'],
        'validation_type'    => $query->row['validation_type'],
        'min_length_rule'    => $query->row['min_length_rule'],
        'max_length_rule'    => $query->row['max_length_rule'],
        'regex_rule'         => $query->row['regex_rule'],
        'field_mask'         => $query->row['field_mask'],
        'icon'               => $query->row['icon'],
        'css_id'             => $query->row['css_id'],
        'css_class'          => $query->row['css_class'],
        'title_status'       => $query->row['title_status'],
        'placeholder_status' => $query->row['placeholder_status'],
        'description_status' => $query->row['description_status'],
        'sort_order'         => $query->row['sort_order']
      ];
    } else {
      return false;
    }
  }

  public function getEmailTemplate($template_id,$language_id = 0) {
    $sql = "SELECT DISTINCT * FROM ".DB_PREFIX.$this->_code."_email_template et";

    if ($language_id) {
      $sql .= " LEFT JOIN ".DB_PREFIX.$this->_code."_email_template_description etd ON (et.template_id = etd.template_id)";
    }

    $sql .= " WHERE et.template_id = '".(int)$template_id."'";

    if ($language_id) {
      $sql .= " AND etd.language_id = '".(int)$language_id."'";
    }

    return $this->db->query($sql)->row;
  }

  public function getEmailTemplateDescription($template_id) {
    $results = [];

    $query = $this->db->query("SELECT * FROM ".DB_PREFIX.$this->_code."_email_template_description WHERE template_id = '".(int)$template_id."'")->rows;

    if ($query) {
      foreach ($query as $row) {
        $results[$row['language_id']] = [
          'subject'  => $row['subject'],
          'template' => $row['template']
        ];
      }
    }

    return $results;
  }

  public function getRecordFieldData($record_id) {
    $results = '';

    $query = $this->db->query("SELECT field_data FROM ".DB_PREFIX.$this->_code."_record WHERE record_id = '".(int)$record_id."'");

    if ($query->num_rows) {
      if ($query->row['field_data']) {
        $results = unserialize($query->row['field_data']);
      }
    }

    return $results;
  }

  public function getProductForPage($product_id) {
    return $this->db->query("SELECT DISTINCT * FROM ".DB_PREFIX."product p LEFT JOIN ".DB_PREFIX."product_description pd ON (p.product_id = pd.product_id) WHERE p.product_id = '".(int)$product_id."' AND pd.language_id = '".(int)$this->config->get('config_language_id')."'")->row;
  }

  public function getRecord($record_id) {
    $query = $this->db->query("
      SELECT DISTINCT 
        *
      FROM ".DB_PREFIX.$this->_code."_record r 
      WHERE r.record_id = '".(int)$record_id."'
    ");

    if ($query->num_rows) {
      return [
        'record_id'              => $query->row['record_id'],
        'email'                  => $query->row['email'],
        'field_data'             => $query->row['field_data'],
        'currency_code'          => $query->row['currency_code'],
        'currency_value'         => $query->row['currency_value'],
        'ip'                     => $query->row['ip'],
        'referer'                => $query->row['referer'],
        'user_agent'             => $query->row['user_agent'],
        'accept_language'        => $query->row['accept_language'],
        'user_language_id'       => $query->row['user_language_id'],
        'user_currency_id'       => $query->row['user_currency_id'],
        'user_customer_group_id' => $query->row['user_customer_group_id'],
        'store_url'              => $query->row['store_url'],
        'store_name'             => $query->row['store_name'],
        'store_id'               => $query->row['store_id'],
        'status'                 => $query->row['status'],
        'token'                  => $query->row['token'],
        'date_added'             => $query->row['date_added'],
        'date_notified'          => $query->row['date_notified'],
        'banned_status'          => $this->checkBannedByEmail($query->row['email'],$query->row['ip'])
      ];
    } else {
      return false;
    }
  }

  private function getRecordProducts($data) {
    $query = $this->db->query("SELECT product_id FROM ".DB_PREFIX.$this->_code."_record_product WHERE record_id = '".(int)$data['record_id']."'")->rows;

    $products = [];

    if ($query) {
      foreach ($query as $product) {
        $products[] = $this->getProduct($product['product_id'],$data['language_id'],$data['store_id'],$data['customer_group_id']);
      }
    }

    return $products;
  }

  public function getRecordProductInfo($data) {
    return $this->db->query("SELECT options FROM ".DB_PREFIX.$this->_code."_record_product WHERE record_id = '".(int)$data['record_id']."' AND product_id = '".(int)$data['product_id']."'")->row['options'];
  }

  public function getRecordByRecordProductId($record_product_id) {
    $query = $this->db->query("
      SELECT DISTINCT 
        record_product_id,
        record_id,
        product_id,
        quantity,
        options
      FROM ".DB_PREFIX.$this->_code."_record_product
      WHERE record_product_id = '".(int)$record_product_id."'
    ");

    if ($query->num_rows) {
      return [
        'record_product_id' => $query->row['record_product_id'],
        'record_id'         => $query->row['record_id'],
        'product_id'        => $query->row['product_id'],
        'quantity'          => $query->row['quantity'],
        'options'           => $query->row['options']
      ];
    } else {
      return false;
    }
  }

  public function checkBannedByEmail($email,$ip) {
    $sql = "SELECT DISTINCT * FROM ".DB_PREFIX.$this->_code."_banned WHERE (";

    if ($email) {
      $sql .= "LCASE(email) = '".$this->db->escape(utf8_strtolower($email))."' OR ";
    }

    $sql .= "ip = '".$this->db->escape($ip)."') AND status = '1'";

    $query = $this->db->query($sql)->row;

    if ($query) {
      return true;
    } else {
      return false;
    }
  }

  public function getEmailTemplateRelatedProduct($template_id) {
    $results = [];

    $query = $this->db->query("SELECT * FROM ".DB_PREFIX.$this->_code."_email_template_related_product WHERE template_id = '".(int)$template_id."'")->rows;

    if ($query) {
      foreach ($query as $row) {
        $results[] = $row['product_id'];
      }
    }

    return $results;
  }

  public function getEmailTemplateRelatedCategory($template_id) {
    $results = [];

    $query = $this->db->query("SELECT * FROM ".DB_PREFIX.$this->_code."_email_template_related_category WHERE template_id = '".(int)$template_id."'")->rows;

    if ($query) {
      foreach ($query as $row) {
        $results[] = $row['category_id'];
      }
    }

    return $results;
  }

  public function getEmailTemplateRelatedManufacturer($template_id) {
    $results = [];

    $query = $this->db->query("SELECT * FROM ".DB_PREFIX.$this->_code."_email_template_related_manufacturer WHERE template_id = '".(int)$template_id."'")->rows;

    if ($query) {
      foreach ($query as $row) {
        $results[] = $row['manufacturer_id'];
      }
    }

    return $results;
  }

  public function getRecordByToken($token) {
    $query = $this->db->query("SELECT DISTINCT token FROM  ".DB_PREFIX.$this->_code."_record WHERE token = '".$this->db->escape($token)."'");

    if ($query->num_rows) {
      return $query->row['token'];
    } else {
      return false;
    }
  }

  public function getRecordByEmail($email) {
    $query = $this->db->query("SELECT record_id FROM  ".DB_PREFIX.$this->_code."_record WHERE LCASE(email) = '".$this->db->escape(utf8_strtolower($email))."'");

    if ($query->num_rows) {
      return $query->row['record_id'];
    } else {
      return false;
    }
  }

  public function getRecordByCustomerId($customer_id) {
    $query = $this->db->query("SELECT record_id FROM  ".DB_PREFIX.$this->_code."_record WHERE customer_id = '".(int)$customer_id."'");

    if ($query->num_rows) {
      return $query->row['record_id'];
    } else {
      return false;
    }
  }

  public function getRecordsForPage($data) {
    return $this->db->query("SELECT * FROM ".DB_PREFIX.$this->_code."_record_product rp LEFT JOIN ".DB_PREFIX.$this->_code."_record r ON (rp.record_id = r.record_id) WHERE r.customer_id = '".(int)$data['customer_id']."'")->rows;
  }

  public function getTotalRecordsForPage($data) {
    $sql = "SELECT COUNT(DISTINCT rp.record_product_id) AS total FROM ".DB_PREFIX.$this->_code."_record_product rp LEFT JOIN ".DB_PREFIX.$this->_code."_record r ON (rp.record_id = r.record_id) WHERE r.customer_id = '".(int)$data['customer_id']."'";

    return $this->db->query($sql)->row['total'];
  }

  public function getRecordProductsForPage($data = []) {
    $sql = "SELECT product_id FROM ".DB_PREFIX.$this->_code."_record_product WHERE record_id = '".(int)$data['record_id']."'";

    if (isset($data['start']) || isset($data['limit'])) {
      if ($data['start'] < 0) {
        $data['start'] = 0;
      }

      if ($data['limit'] < 1) {
        $data['limit'] = 20;
      }

      $sql .= " LIMIT ".(int)$data['start'].",".(int)$data['limit'];
    }

    $query = $this->db->query($sql)->rows;

    $records = [];

    if ($query) {
      foreach ($query as $row) {
        $records[$row['product_id']] = $this->getProductForPage($row['product_id']);
      }
    }

    return $records;
  }

  public function unSubscribe($token) {
    $this->db->query("DELETE FROM ".DB_PREFIX.$this->_code."_record WHERE token = '".$this->db->escape($token)."'");
  }

  public function getProduct($product_id,$language_id,$store_id,$customer_group_id) {
    $query = $this->db->query("
      SELECT DISTINCT 
        p.product_id,
        p.quantity,
        pd.name,
        p.image,
        pd.description,
        p.price,
        p.tax_class_id,
        (SELECT price FROM ".DB_PREFIX."product_discount pd2 WHERE pd2.product_id = p.product_id AND pd2.customer_group_id = '".(int)$customer_group_id."' AND pd2.quantity = '1' AND ((pd2.date_start = '0000-00-00' OR pd2.date_start < NOW()) AND (pd2.date_end = '0000-00-00' OR pd2.date_end > NOW())) ORDER BY pd2.priority ASC, pd2.price ASC LIMIT 1) AS discount,
        (SELECT price FROM ".DB_PREFIX."product_special ps WHERE ps.product_id = p.product_id AND ps.customer_group_id = '".(int)$customer_group_id."' AND ((ps.date_start = '0000-00-00' OR ps.date_start < NOW()) AND (ps.date_end = '0000-00-00' OR ps.date_end > NOW())) ORDER BY ps.priority ASC, ps.price ASC LIMIT 1) AS special
      FROM ".DB_PREFIX."product p
      LEFT JOIN ".DB_PREFIX."product_description pd ON (p.product_id = pd.product_id)
      LEFT JOIN ".DB_PREFIX."product_to_store p2s ON (p.product_id = p2s.product_id)
      WHERE p.product_id = '".(int)$product_id."'
        AND pd.language_id = '".(int)$language_id."'
        AND p.status = '1'
        AND p.date_available <= NOW()
        AND p2s.store_id = '".(int)$store_id."'
    ");

    if ($query->num_rows) {
      return [
        'product_id'   => $query->row['product_id'],
        'name'         => $query->row['name'],
        'quantity'     => $query->row['quantity'],
        'description'  => $query->row['description'],
        'image'        => $query->row['image'],
        'price'        => ($query->row['discount'] ? $query->row['discount'] : $query->row['price']),
        'special'      => $query->row['special'],
        'tax_class_id' => $query->row['tax_class_id']
      ];
    } else {
      return false;
    }
  }

  private function getProductMarkup($product_info,$template_info,$record_info,$type = 'related') {
    if ($template_info && $product_info && $record_info) {
      $html_data = [];

      $models = ['tool/image'];

      foreach ($models as $model) {
        $this->load->model($model);
      }

      $html_data['products'] = [];

      $currency_info = $this->getCurrencyById($record_info['user_currency_id']);

      if ($currency_info) {
        $image = ($template_info[$type.'_show_image'] && $product_info['image']) ? $this->model_tool_image->resize($product_info['image'],$template_info[$type.'_image_width'],$template_info[$type.'_image_height']) : '';

        if ($template_info[$type.'_show_description']) {
          if (utf8_strlen($product_info['description']) > $template_info[$type.'_description_limit']) {
            $description = utf8_substr(strip_tags(html_entity_decode($product_info['description'],ENT_QUOTES,'UTF-8')),0,$template_info[$type.'_description_limit']).'...';
          } else {
            $description = strip_tags(html_entity_decode($product_info['description'],ENT_QUOTES,'UTF-8'));
          }
        } else {
          $description = '';
        }

        $special = false;
        $price   = false;

        if ($template_info[$type.'_show_price']) {
          $price = $this->currency->format($product_info['price'] + ($this->config->get('config_tax') ? $this->tax->getTax($product_info['price'],$product_info['tax_class_id']) : 0),$currency_info['code'],$currency_info['value']);

          if ((float)$product_info['special']) {
            $special = $this->currency->format($product_info['special'] + ($this->config->get('config_tax') ? $this->tax->getTax($product_info['special'],$product_info['tax_class_id']) : 0),$currency_info['code'],$currency_info['value']);
          } else {
            $special = false;
          }
        }

        $option_data = [];

        if ($type == 'main') {
          $filter_data = [
            'product_id' => $product_info['product_id'],
            'record_id'  => $record_info['record_id']
          ];

          $options = unserialize($this->getRecordProductInfo($filter_data));

          foreach ($options as $option) {
            if ($option['type'] != 'file') {
              $value = $option['value'];
            } else {
              $value = utf8_substr($option['value'],0,utf8_strrpos($option['value'],'.'));
            }

            $option_data[] = [
              'name'  => $option['name'],
              'value' => $value
            ];
          }
        }

        $name = ($template_info[$type.'_show_name']) ? $product_info['name'] : '';

        $html_data['products'][] = [
          'product_id'  => $product_info['product_id'],
          'name'        => $name,
          'description' => $description,
          'price'       => $price,
          'special'     => $special,
          'thumb'       => $image,
          'options'     => $option_data,
          'href'        => $record_info['store_url'].'index.php?route=product/product&product_id='.$product_info['product_id']
        ];
      }

      if (version_compare(VERSION,'2.0.0.0','>=') && version_compare(VERSION,'2.1.0.2.1','<=')) {
        if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/product_markup.tpl')) {
          return $this->load->view($this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/product_markup.tpl',$html_data);
        } else {
          return $this->load->view('default/template/extension/ocdevwizard/'.$this->_name.'/product_markup.tpl',$html_data);
        }
      } else if (version_compare(VERSION,'3.0.0.0','>=')) {
        return $this->load->view('extension/ocdevwizard/'.$this->_name.'/product_markup',$html_data);
      } else if (version_compare(VERSION,'2.0.0.0','<')) {
        $template = new Template();

        $template->data = $html_data;

        if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/product_markup.tpl')) {
          return $template->fetch($this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/product_markup.tpl');
        } else {
          return $template->fetch('default/template/extension/ocdevwizard/'.$this->_name.'/product_markup.tpl');
        }
      } else {
        return $this->load->view('extension/ocdevwizard/'.$this->_name.'/product_markup.tpl',$html_data);
      }
    }
  }

  private function getProductMarkups($index,$template_info,$record_info) {
    $product_data = [];

    // saved_products
    if ($index == 0) {
      $filter_data = [
        'record_id'         => $record_info['record_id'],
        'language_id'       => $record_info['user_language_id'],
        'store_id'          => $record_info['store_id'],
        'customer_group_id' => $record_info['user_customer_group_id']
      ];

      $products = $this->getRecordProducts($filter_data);

      $saved_products = '';

      if ($products) {
        $saved_products .= '<div style="width: 100%;text-align: center;">';
        foreach ($products as $product) {
          $saved_products .= $this->getProductMarkup($product,$template_info,$record_info,'main');
        }
        $saved_products .= '</div>';
      }

      $product_data[0] = $saved_products;
    }

    // products_from_category
    if ($index == 1) {
      $filter_data = [
        'filter_category_id'  => $this->getEmailTemplateRelatedCategory($template_info['template_id']),
        'filter_sub_category' => '1',
        'start'               => '0',
        'limit'               => $template_info['related_limit'],
        'language_id'         => $record_info['user_language_id'],
        'store_id'            => $record_info['store_id'],
        'customer_group_id'   => $record_info['user_customer_group_id'],
        'randomize'           => $template_info['related_randomize']
      ];

      $products = $this->getProductsFromCategories($filter_data);

      $products_from_category = '';

      if ($products) {
        $products_from_category .= '<div style="width: 100%;text-align: center;">';
        foreach ($products as $product) {
          $products_from_category .= $this->getProductMarkup($product,$template_info,$record_info);
        }
        $products_from_category .= '</div>';
      }

      $product_data[1] = $products_from_category;
    }

    // products_from_brand
    if ($index == 2) {
      $filter_data = [
        'filter_manufacturer_id' => $this->getEmailTemplateRelatedManufacturer($template_info['template_id']),
        'start'                  => '0',
        'limit'                  => $template_info['related_limit'],
        'language_id'            => $record_info['user_language_id'],
        'store_id'               => $record_info['store_id'],
        'customer_group_id'      => $record_info['user_customer_group_id'],
        'randomize'              => $template_info['related_randomize']
      ];

      $products = $this->getProductsByMixedFilters($filter_data);

      $products_from_brand = '';

      if ($products) {
        $products_from_brand .= '<div style="width: 100%;text-align: center;">';
        foreach ($products as $product) {
          $products_from_brand .= $this->getProductMarkup($product,$template_info,$record_info);
        }
        $products_from_brand .= '</div>';
      }

      $product_data[2] = $products_from_brand;
    }

    // selected_products
    if ($index == 3) {
      $filter_data = [
        'filter_product_id' => $this->getEmailTemplateRelatedProduct($template_info['template_id']),
        'start'             => '0',
        'limit'             => $template_info['related_limit'],
        'language_id'       => $record_info['user_language_id'],
        'store_id'          => $record_info['store_id'],
        'customer_group_id' => $record_info['user_customer_group_id'],
        'randomize'         => $template_info['related_randomize'],
        'sort'              => 'p.sort_order',
        'order'             => 'DESC'
      ];

      $products = $this->getProductsByMixedFilters($filter_data);

      $selected_products = '';

      if ($products) {
        $selected_products .= '<div style="width: 100%;text-align: center;">';
        foreach ($products as $product) {
          $selected_products .= $this->getProductMarkup($product,$template_info,$record_info);
        }
        $selected_products .= '</div>';
      }

      $product_data[3] = $selected_products;
    }

    // latest_products
    if ($index == 4) {
      $filter_data = [
        'start'             => '0',
        'limit'             => $template_info['related_limit'],
        'language_id'       => $record_info['user_language_id'],
        'store_id'          => $record_info['store_id'],
        'customer_group_id' => $record_info['user_customer_group_id'],
        'randomize'         => $template_info['related_randomize'],
        'sort'              => 'p.date_added',
        'order'             => 'DESC'
      ];

      $products = $this->getProductsByMixedFilters($filter_data);

      $latest_products = '';

      if ($products) {
        $latest_products .= '<div style="width: 100%;text-align: center;">';
        foreach ($products as $product) {
          $latest_products .= $this->getProductMarkup($product,$template_info,$record_info);
        }
        $latest_products .= '</div>';
      }

      $product_data[4] = $latest_products;
    }

    // bestseller_products
    if ($index == 5) {
      $filter_data = [
        'filter_bestseller' => '1',
        'start'             => '0',
        'limit'             => $template_info['related_limit'],
        'language_id'       => $record_info['user_language_id'],
        'store_id'          => $record_info['store_id'],
        'customer_group_id' => $record_info['user_customer_group_id'],
        'randomize'         => $template_info['related_randomize'],
        'sort'              => 'total',
        'order'             => 'DESC'
      ];

      $products = $this->getProductsByMixedFilters($filter_data);

      $bestseller_products = '';

      if ($products) {
        $bestseller_products .= '<div style="width: 100%;text-align: center;">';
        foreach ($products as $product) {
          $bestseller_products .= $this->getProductMarkup($product,$template_info,$record_info);
        }
        $bestseller_products .= '</div>';
      }

      $product_data[5] = $bestseller_products;
    }

    // special_products
    if ($index == 6) {
      $filter_data = [
        'start'             => '0',
        'limit'             => $template_info['related_limit'],
        'language_id'       => $record_info['user_language_id'],
        'store_id'          => $record_info['store_id'],
        'customer_group_id' => $record_info['user_customer_group_id'],
        'randomize'         => $template_info['related_randomize']
      ];

      $products = $this->getSpecialProducts($filter_data);

      $special_products = '';

      if ($products) {
        $special_products .= '<div style="width: 100%;text-align: center;">';
        foreach ($products as $product) {
          $special_products .= $this->getProductMarkup($product,$template_info,$record_info);
        }
        $special_products .= '</div>';
      }

      $product_data[6] = $special_products;
    }

    // popular_products
    if ($index == 7) {
      $filter_data = [
        'start'             => '0',
        'limit'             => $template_info['related_limit'],
        'language_id'       => $record_info['user_language_id'],
        'store_id'          => $record_info['store_id'],
        'customer_group_id' => $record_info['user_customer_group_id'],
        'randomize'         => $template_info['related_randomize'],
        'sort'              => 'p.viewed',
        'order'             => 'DESC'
      ];

      $products = $this->getProductsByMixedFilters($filter_data);

      $popular_products = '';

      if ($products) {
        $popular_products .= '<div style="width: 100%;text-align: center;">';
        foreach ($products as $product) {
          $popular_products .= $this->getProductMarkup($product,$template_info,$record_info);
        }
        $popular_products .= '</div>';
      }

      $product_data[7] = $popular_products;
    }

    if (isset($product_data[$index]) && $product_data[$index]) {
      return $product_data[$index];
    } else {
      return '';
    }
  }

  private function getProductsByMixedFilters($data = []) {
    if (isset($data['filter_bestseller']) && !empty($data['filter_bestseller'])) {
      $sql = "SELECT op.product_id, SUM(op.quantity) AS total";
    } else {
      $sql = "SELECT DISTINCT p.product_id";
    }

    if (isset($data['filter_bestseller']) && !empty($data['filter_bestseller'])) {
      $sql .= " FROM ".DB_PREFIX."order_product op";
      $sql .= " LEFT JOIN ".DB_PREFIX."order o ON (op.order_id = o.order_id)";
      $sql .= " LEFT JOIN ".DB_PREFIX."product p ON (op.product_id = p.product_id)";
    } else {
      $sql .= " FROM ".DB_PREFIX."product p";
    }

    $sql .= " LEFT JOIN ".DB_PREFIX."product_description pd ON (p.product_id = pd.product_id) LEFT JOIN ".DB_PREFIX."product_to_store p2s ON (p.product_id = p2s.product_id) WHERE pd.language_id = '".(int)$data['language_id']."' AND p.status = '1' AND p.quantity IS NOT NULL AND p.date_available <= NOW() AND p2s.store_id = '".(int)$data['store_id']."'";

    if (isset($data['filter_bestseller']) && !empty($data['filter_bestseller'])) {
      $sql .= " AND o.order_status_id IS NOT NULL";
    } else if (isset($data['filter_product_id']) && !empty($data['filter_product_id'])) {
      $sql .= " AND p.product_id IN (".implode(',',$data['filter_product_id']).")";
    } else if (isset($data['filter_manufacturer_id']) && !empty($data['filter_manufacturer_id'])) {
      $sql .= " AND p.manufacturer_id IN (".implode(',',$data['filter_manufacturer_id']).")";
    }

    if (isset($data['filter_bestseller']) && !empty($data['filter_bestseller'])) {
      $sql .= " GROUP BY op.product_id";
    }

    $sort_data = [
      'pd.name',
      'p.date_added',
      'p.sort_order',
      'total',
      'p.viewed'
    ];

    if (isset($data['sort']) && in_array($data['sort'],$sort_data)) {
      $sql .= " ORDER BY ".$data['sort'];

      if (isset($data['order']) && ($data['order'] == 'DESC')) {
        $sql .= " DESC, LCASE(pd.name) DESC";
      } else {
        $sql .= " ASC, LCASE(pd.name) ASC";
      }
    }

    if (isset($data['start']) || isset($data['limit'])) {
      if ($data['start'] < 0) {
        $data['start'] = 0;
      }

      if ($data['limit'] < 1) {
        $data['limit'] = 20;
      }

      $sql .= " LIMIT ".(int)$data['start'].",".(int)$data['limit'];
    }

    $product_data = [];

    $query = $this->db->query($sql);

    if ($query->num_rows) {
      foreach ($query->rows as $row) {
        $product_data[] = $row['product_id'];
      }
    }

    if ($data['randomize']) {
      shuffle($product_data);
    }

    $products = [];

    foreach ($product_data as $product_id) {
      $products[] = $this->getProduct($product_id,$data['language_id'],$data['store_id'],$data['customer_group_id']);
    }

    return $products;
  }

  private function getProductsFromCategories($data) {
    $product_data = [];

    if ($data['randomize']) {
      $sql = "SELECT MIN(p.product_id) as min_id, MAX(p.product_id) as max_id";

      if (!empty($data['filter_sub_category'])) {
        $sql .= " FROM ".DB_PREFIX."category_path cp LEFT JOIN ".DB_PREFIX."product_to_category p2c ON (cp.category_id = p2c.category_id)";
      } else {
        $sql .= " FROM ".DB_PREFIX."product_to_category p2c";
      }

      $sql .= " LEFT JOIN ".DB_PREFIX."product p ON (p2c.product_id = p.product_id) LEFT JOIN ".DB_PREFIX."product_to_store p2s ON (p.product_id = p2s.product_id) WHERE p.status = '1' AND p.quantity IS NOT NULL AND p.date_available <= NOW() AND p2s.store_id = '".(int)$data['store_id']."'";

      if (!empty($data['filter_sub_category'])) {
        $sql .= " AND cp.path_id IN (".implode(',',$data['filter_category_id']).")";
      } else {
        $sql .= " AND p2c.category_id IN (".implode(',',$data['filter_category_id']).")";
      }

      $min_max_id = $this->db->query($sql);

      $while_counter = 0;
      $while_max     = $this->_while_max; // safety catch, so that help the server does not go down

      while ((count($product_data) < $data['limit']) && ($while_counter < $while_max)) {
        $result_product_id = mt_rand($min_max_id->row['min_id'],$min_max_id->row['max_id']);

        $sql = "SELECT DISTINCT p.product_id";

        if (!empty($data['filter_sub_category'])) {
          $sql .= " FROM ".DB_PREFIX."category_path cp LEFT JOIN ".DB_PREFIX."product_to_category p2c ON (cp.category_id = p2c.category_id)";
        } else {
          $sql .= " FROM ".DB_PREFIX."product_to_category p2c";
        }

        $sql .= " LEFT JOIN ".DB_PREFIX."product p ON (p2c.product_id = p.product_id) LEFT JOIN ".DB_PREFIX."product_to_store p2s ON (p.product_id = p2s.product_id) WHERE p.status = '1' AND p.quantity IS NOT NULL AND p.date_available <= NOW() AND p2s.store_id = '".(int)$data['store_id']."' AND p.product_id = '".(int)$result_product_id."'";

        if (!empty($data['filter_sub_category'])) {
          $sql .= " AND cp.path_id IN (".implode(',',$data['filter_category_id']).")";
        } else {
          $sql .= " AND p2c.category_id IN (".implode(',',$data['filter_category_id']).")";
        }

        $query = $this->db->query($sql)->num_rows;

        if ($query) {
          $product_data[] = $result_product_id;
        }

        $product_data = array_unique($product_data);

        $while_counter++;
      }
    } else {
      $sql = "SELECT DISTINCT p.product_id";

      if (!empty($data['filter_sub_category'])) {
        $sql .= " FROM ".DB_PREFIX."category_path cp LEFT JOIN ".DB_PREFIX."product_to_category p2c ON (cp.category_id = p2c.category_id)";
      } else {
        $sql .= " FROM ".DB_PREFIX."product_to_category p2c";
      }

      $sql .= " LEFT JOIN ".DB_PREFIX."product p ON (p2c.product_id = p.product_id) LEFT JOIN ".DB_PREFIX."product_to_store p2s ON (p.product_id = p2s.product_id) WHERE p.status = '1' AND p.quantity IS NOT NULL AND p.date_available <= NOW() AND p2s.store_id = '".(int)$data['store_id']."'";

      if (!empty($data['filter_sub_category'])) {
        $sql .= " AND cp.path_id IN (".implode(',',$data['filter_category_id']).")";
      } else {
        $sql .= " AND p2c.category_id IN (".implode(',',$data['filter_category_id']).")";
      }

      $sql .= " ORDER BY p.sort_order ASC";

      if (isset($data['start']) || isset($data['limit'])) {
        if ($data['start'] < 0) {
          $data['start'] = 0;
        }

        if ($data['limit'] < 1) {
          $data['limit'] = 20;
        }

        $sql .= " LIMIT ".(int)$data['start'].",".(int)$data['limit'];
      }

      $query = $this->db->query($sql);

      if ($query->num_rows) {
        foreach ($query->rows as $row) {
          $product_data[] = $row['product_id'];
        }
      }

      $product_data = array_unique($product_data);
    }

    $products = [];

    foreach ($product_data as $product_id) {
      $products[] = $this->getProduct($product_id,$data['language_id'],$data['store_id'],$data['customer_group_id']);
    }

    return $products;
  }

  private function getSpecialProducts($data) {
    $product_data = [];

    if ($data['randomize']) {
      $min_max_id = $this->db->query("
        SELECT 
          MIN(ps.product_id) as min_id, 
          MAX(ps.product_id) as max_id 
        FROM ".DB_PREFIX."product_special ps 
        LEFT JOIN ".DB_PREFIX."product p ON (ps.product_id = p.product_id) 
        LEFT JOIN ".DB_PREFIX."product_to_store p2s ON (p.product_id = p2s.product_id) 
        WHERE p.status = '1' 
          AND p.quantity IS NOT NULL 
          AND p.date_available <= NOW() 
          AND ps.customer_group_id = '".(int)$data['customer_group_id']."' 
          AND ((ps.date_start = '0000-00-00' OR ps.date_start < NOW()) AND (ps.date_end = '0000-00-00' OR ps.date_end > NOW())) 
          AND p2s.store_id = '".(int)$data['store_id']."'
      ");

      $while_counter = 0;
      $while_max     = $this->_while_max; // safety catch, so that help the server does not go down

      while ((count($product_data) < $data['limit']) && ($while_counter < $while_max)) {
        $result_product_id = mt_rand($min_max_id->row['min_id'],$min_max_id->row['max_id']);

        $query = $this->db->query("
          SELECT DISTINCT 
            ps.product_id 
          FROM ".DB_PREFIX."product_special ps 
          LEFT JOIN ".DB_PREFIX."product p ON (ps.product_id = p.product_id) 
          LEFT JOIN ".DB_PREFIX."product_to_store p2s ON (p.product_id = p2s.product_id) 
          WHERE p.product_id = '".(int)$result_product_id."' 
            AND p.status = '1' 
            AND p.quantity IS NOT NULL 
            AND p.date_available <= NOW() 
            AND ps.customer_group_id = '".(int)$data['customer_group_id']."' 
            AND ((ps.date_start = '0000-00-00' OR ps.date_start < NOW()) AND (ps.date_end = '0000-00-00' OR ps.date_end > NOW())) 
            AND p2s.store_id = '".(int)$data['store_id']."'
        ")->num_rows;

        if ($query) {
          $product_data[] = $result_product_id;
        }

        $product_data = array_unique($product_data);

        $while_counter++;
      }
    } else {
      $sql = "
        SELECT DISTINCT 
          ps.product_id 
        FROM ".DB_PREFIX."product_special ps 
        LEFT JOIN ".DB_PREFIX."product p ON (ps.product_id = p.product_id) 
        LEFT JOIN ".DB_PREFIX."product_to_store p2s ON (p.product_id = p2s.product_id) 
        WHERE p.status = '1' 
          AND p.quantity IS NOT NULL 
          AND p.date_available <= NOW() 
          AND ps.customer_group_id = '".(int)$data['customer_group_id']."' 
          AND ((ps.date_start = '0000-00-00' OR ps.date_start < NOW()) AND (ps.date_end = '0000-00-00' OR ps.date_end > NOW())) 
          AND p2s.store_id = '".(int)$data['store_id']."' 
        ORDER BY p.sort_order ASC
      ";

      if (isset($data['start']) || isset($data['limit'])) {
        if ($data['start'] < 0) {
          $data['start'] = 0;
        }

        if ($data['limit'] < 1) {
          $data['limit'] = 20;
        }

        $sql .= " LIMIT ".(int)$data['start'].",".(int)$data['limit'];
      }

      $query = $this->db->query($sql);

      if ($query->num_rows) {
        foreach ($query->rows as $row) {
          $product_data[] = $row['product_id'];
        }
      }

      $product_data = array_unique($product_data);
    }

    $products = [];

    foreach ($product_data as $product_id) {
      $products[] = $this->getProduct($product_id,$data['language_id'],$data['store_id'],$data['customer_group_id']);
    }

    return $products;
  }

  public function getRecordForCron($type) {
    if ($type == 1) {
      $query = $this->db->query("
        SELECT 
          r.record_id, 
          r.email,
          r.ip,
          r.status
        FROM ".DB_PREFIX.$this->_code."_record r 
        WHERE r.status = '0'
      ");

      $results = [];

      if ($query->num_rows) {
        foreach ($query->rows as $row) {
          $results[] = [
            'record_id'     => $row['record_id'],
            'email'         => $row['email'],
            'ip'            => $row['ip'],
            'status'        => $row['status'],
            'banned_status' => $this->checkBannedByEmail($row['email'],$row['ip'])
          ];
        }
      }

      return $results;
    } else {
      return false;
    }
  }

  public function deleteRecord($record_product_id) {
    $this->db->query("DELETE FROM ".DB_PREFIX.$this->_code."_record_product WHERE record_product_id = '".(int)$record_product_id."'");

    if (!$this->getTotalRecordsForPage(['customer_id' => $this->customer->getId()])) {
      $query = $this->db->query("SELECT * FROM ".DB_PREFIX.$this->_code."_record WHERE customer_id = '".(int)$this->customer->getId()."'")->rows;

      if ($query) {
        foreach ($query as $row) {
          $this->db->query("DELETE FROM ".DB_PREFIX.$this->_code."_record WHERE record_id = '".(int)$row['record_id']."'");
        }
      }
    }
  }

  public function mailing($data,$types) {
    if ($data && $types) {
      $record_info = $this->getRecord($data['record_id']);

      if ($record_info && !$record_info['banned_status']) {
        $form_data = $data['form_data'];

        if ($form_data) {
          $fields_all                      = '';
          $saved_products                  = '';
          $selected_products               = '';
          $products_from_category          = '';
          $latest_products                 = '';
          $bestseller_products             = '';
          $special_products                = '';
          $popular_products                = '';
          $products_from_brand             = '';
          $filter_data                     = $fields = [];
          $field_data                      = $this->getRecordFieldData($record_info['record_id']);
          $filter_data['user_language_id'] = $record_info['user_language_id'];
          $filter_data['store_name']       = $record_info['store_name'];

          if ($field_data) {
            foreach ($field_data as $field) {
              if ($field['value']) {
                $fields[$field['type']][] = $field['value'];
                $fields_all               .= '<b>'.$field['name'].':</b> '.$field['value'].'<br/>';
              }
            }
          }

          foreach ($types as $type) {
            if ($form_data['admin_alert_status']) {
              if ($type == 'to_admin_on_new_record') {
                $filter_data['set_to']       = $form_data['admin_email_for_notification'];
                $filter_data['template_id']  = $template_id = $form_data['admin_email_template'];
                $template_info               = $this->getEmailTemplate($template_id);
                $filter_data['set_to_multi'] = 1;

                // saved_products
                $saved_products = $this->getProductMarkups(0,$template_info,$record_info);

                $filter_data['tag_codes_subject'] = [
                  '{email}',
                  '{firstname}',
                  '{lastname}',
                  '{telephone}',
                  '{record_id}',
                  '{date_added}',
                  '{store_name}'
                ];

                $filter_data['tag_codes_replace_subject'] = [
                  $record_info['email'],
                  (isset($fields['firstname'][0])) ? $fields['firstname'][0] : '',
                  (isset($fields['lastname'][0])) ? $fields['lastname'][0] : '',
                  (isset($fields['telephone'][0])) ? $fields['telephone'][0] : '',
                  $record_info['record_id'],
                  date("Y-m-d H:i:s",strtotime($record_info['date_added'])),
                  $record_info['store_name']
                ];

                $filter_data['tag_codes_template'] = [
                  '{email}',
                  '{firstname}',
                  '{lastname}',
                  '{telephone}',
                  '{password}',
                  '{ip}',
                  '{record_id}',
                  '{fields}',
                  '{date_added}',
                  '{products_list}',
                  '{referer}',
                  '{user_agent}',
                  '{accept_language}',
                  '{store_name}',
                  '{store_address}',
                  '{store_email}',
                  '{store_telephone}',
                  '{store_fax}',
                  '{store_url}'
                ];

                $filter_data['tag_codes_replace_template'] = [
                  $record_info['email'],
                  (isset($fields['firstname'][0])) ? $fields['firstname'][0] : '',
                  (isset($fields['lastname'][0])) ? $fields['lastname'][0] : '',
                  (isset($fields['telephone'][0])) ? $fields['telephone'][0] : '',
                  (isset($fields['password'][0])) ? $fields['password'][0] : '',
                  $record_info['ip'],
                  $record_info['record_id'],
                  $fields_all,
                  date("Y-m-d H:i:s",strtotime($record_info['date_added'])),
                  $saved_products,
                  $record_info['referer'],
                  $record_info['user_agent'],
                  $record_info['accept_language'],
                  $record_info['store_name'],
                  $this->config->get('config_address'),
                  $this->config->get('config_email'),
                  $this->config->get('config_telephone'),
                  ($this->config->get('config_fax') != '') ? $this->config->get('config_fax') : '',
                  $record_info['store_url']
                ];

                $this->mailing_send($filter_data);
              }
            }

            if ($form_data['user_alert_status']) {
              if ($type == 'to_user_on_new_record') {
                $filter_data['set_to']      = $record_info['email'];
                $filter_data['template_id'] = $template_id = $form_data['user_email_template'];
                $template_info              = $this->getEmailTemplate($template_id);

                // saved_products
                $saved_products = $this->getProductMarkups(0,$template_info,$record_info);

                // products_from_category
                if ($template_info['related_product_status'] == 1) {
                  $products_from_category = $this->getProductMarkups(1,$template_info,$record_info);
                }

                // products_from_brand
                if ($template_info['related_product_status'] == 2) {
                  $products_from_brand = $this->getProductMarkups(2,$template_info,$record_info);
                }

                // selected_products
                if ($template_info['related_product_status'] == 3) {
                  $selected_products = $this->getProductMarkups(3,$template_info,$record_info);
                }

                // latest_products
                if ($template_info['related_product_status'] == 4) {
                  $latest_products = $this->getProductMarkups(4,$template_info,$record_info);
                }

                // bestseller_products
                if ($template_info['related_product_status'] == 5) {
                  $bestseller_products = $this->getProductMarkups(5,$template_info,$record_info);
                }

                // special_products
                if ($template_info['related_product_status'] == 6) {
                  $special_products = $this->getProductMarkups(6,$template_info,$record_info);
                }

                // popular_products
                if ($template_info['related_product_status'] == 7) {
                  $popular_products = $this->getProductMarkups(7,$template_info,$record_info);
                }

                $filter_data['tag_codes_subject'] = [
                  '{email}',
                  '{firstname}',
                  '{lastname}',
                  '{telephone}',
                  '{record_id}',
                  '{date_added}',
                  '{store_name}'
                ];

                $filter_data['tag_codes_replace_subject'] = [
                  $record_info['email'],
                  (isset($fields['firstname'][0])) ? $fields['firstname'][0] : '',
                  (isset($fields['lastname'][0])) ? $fields['lastname'][0] : '',
                  (isset($fields['telephone'][0])) ? $fields['telephone'][0] : '',
                  $record_info['record_id'],
                  date("Y-m-d H:i:s",strtotime($record_info['date_added'])),
                  $record_info['store_name']
                ];

                $filter_data['tag_codes_template'] = [
                  '{email}',
                  '{firstname}',
                  '{lastname}',
                  '{telephone}',
                  '{password}',
                  '{record_id}',
                  '{fields}',
                  '{date_added}',
                  '{products_list}',
                  '{unsubscribe_url}',
                  '{selected_products}',
                  '{products_from_category}',
                  '{latest_products}',
                  '{bestseller_products}',
                  '{special_products}',
                  '{popular_products}',
                  '{products_from_brand}',
                  '{store_name}',
                  '{store_address}',
                  '{store_email}',
                  '{store_telephone}',
                  '{store_fax}',
                  '{store_url}'
                ];

                $filter_data['tag_codes_replace_template'] = [
                  $record_info['email'],
                  (isset($fields['firstname'][0])) ? $fields['firstname'][0] : '',
                  (isset($fields['lastname'][0])) ? $fields['lastname'][0] : '',
                  (isset($fields['telephone'][0])) ? $fields['telephone'][0] : '',
                  (isset($fields['password'][0])) ? $fields['password'][0] : '',
                  $record_info['record_id'],
                  $fields_all,
                  date("Y-m-d H:i:s",strtotime($record_info['date_added'])),
                  $saved_products,
                  $record_info['store_url'].'index.php?route=extension/ocdevwizard/'.$this->_name.'/actions&token='.$record_info['token'],
                  $selected_products,
                  $products_from_category,
                  $latest_products,
                  $bestseller_products,
                  $special_products,
                  $popular_products,
                  $products_from_brand,
                  $record_info['store_name'],
                  $this->config->get('config_address'),
                  $this->config->get('config_email'),
                  $this->config->get('config_telephone'),
                  ($this->config->get('config_fax') != '') ? $this->config->get('config_fax') : '',
                  $record_info['store_url']
                ];

                $this->mailing_send($filter_data);
              }

              if ($type == 'to_user_on_reminder') {
                $filter_data['set_to']      = $record_info['email'];
                $filter_data['template_id'] = $template_id = $form_data['user_email_template_reminder'];
                $template_info              = $this->getEmailTemplate($template_id);

                // saved_products
                $saved_products = $this->getProductMarkups(0,$template_info,$record_info);

                // products_from_category
                if ($template_info['related_product_status'] == 1) {
                  $products_from_category = $this->getProductMarkups(1,$template_info,$record_info);
                }

                // products_from_brand
                if ($template_info['related_product_status'] == 2) {
                  $products_from_brand = $this->getProductMarkups(2,$template_info,$record_info);
                }

                // selected_products
                if ($template_info['related_product_status'] == 3) {
                  $selected_products = $this->getProductMarkups(3,$template_info,$record_info);
                }

                // latest_products
                if ($template_info['related_product_status'] == 4) {
                  $latest_products = $this->getProductMarkups(4,$template_info,$record_info);
                }

                // bestseller_products
                if ($template_info['related_product_status'] == 5) {
                  $bestseller_products = $this->getProductMarkups(5,$template_info,$record_info);
                }

                // special_products
                if ($template_info['related_product_status'] == 6) {
                  $special_products = $this->getProductMarkups(6,$template_info,$record_info);
                }

                // popular_products
                if ($template_info['related_product_status'] == 7) {
                  $popular_products = $this->getProductMarkups(7,$template_info,$record_info);
                }

                $filter_data['tag_codes_subject'] = [
                  '{email}',
                  '{firstname}',
                  '{lastname}',
                  '{telephone}',
                  '{record_id}',
                  '{date_added}',
                  '{store_name}'
                ];

                $filter_data['tag_codes_replace_subject'] = [
                  $record_info['email'],
                  (isset($fields['firstname'][0])) ? $fields['firstname'][0] : '',
                  (isset($fields['lastname'][0])) ? $fields['lastname'][0] : '',
                  (isset($fields['telephone'][0])) ? $fields['telephone'][0] : '',
                  $record_info['record_id'],
                  date("Y-m-d H:i:s",strtotime($record_info['date_added'])),
                  $record_info['store_name']
                ];

                $filter_data['tag_codes_template'] = [
                  '{email}',
                  '{firstname}',
                  '{lastname}',
                  '{telephone}',
                  '{password}',
                  '{record_id}',
                  '{fields}',
                  '{date_added}',
                  '{products_list}',
                  '{unsubscribe_url}',
                  '{selected_products}',
                  '{products_from_category}',
                  '{latest_products}',
                  '{bestseller_products}',
                  '{special_products}',
                  '{popular_products}',
                  '{products_from_brand}',
                  '{store_name}',
                  '{store_address}',
                  '{store_email}',
                  '{store_telephone}',
                  '{store_fax}',
                  '{store_url}'
                ];

                $filter_data['tag_codes_replace_template'] = [
                  $record_info['email'],
                  (isset($fields['firstname'][0])) ? $fields['firstname'][0] : '',
                  (isset($fields['lastname'][0])) ? $fields['lastname'][0] : '',
                  (isset($fields['telephone'][0])) ? $fields['telephone'][0] : '',
                  (isset($fields['password'][0])) ? $fields['password'][0] : '',
                  $record_info['record_id'],
                  $fields_all,
                  date("Y-m-d H:i:s",strtotime($record_info['date_added'])),
                  $saved_products,
                  $record_info['store_url'].'index.php?route=extension/ocdevwizard/'.$this->_name.'/actions&token='.$record_info['token'],
                  $selected_products,
                  $products_from_category,
                  $latest_products,
                  $bestseller_products,
                  $special_products,
                  $popular_products,
                  $products_from_brand,
                  $record_info['store_name'],
                  $this->config->get('config_address'),
                  $this->config->get('config_email'),
                  $this->config->get('config_telephone'),
                  ($this->config->get('config_fax') != '') ? $this->config->get('config_fax') : '',
                  $record_info['store_url']
                ];

                $this->mailing_send($filter_data);
              }
            }
          }
        }
      }
    }
  }

  private function mailing_send($data) {
    if ($data) {
      $html_data = [];

      $template_description = $this->getEmailTemplateDescription($data['template_id']);

      if ($template_description) {
        $html_data['title']         = $setSubject = html_entity_decode(str_replace($data['tag_codes_subject'],$data['tag_codes_replace_subject'],$template_description[$data['user_language_id']]['subject']),ENT_QUOTES,'UTF-8');
        $html_data['html_template'] = html_entity_decode(str_replace($data['tag_codes_template'],$data['tag_codes_replace_template'],$template_description[$data['user_language_id']]['template']),ENT_QUOTES,'UTF-8');

        if (version_compare(VERSION,'2.0.0.0','>=') && version_compare(VERSION,'2.1.0.2.1','<=')) {
          if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/email_template.tpl')) {
            $setHtml = $this->load->view($this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/email_template.tpl',$html_data);
          } else {
            $setHtml = $this->load->view('default/template/extension/ocdevwizard/'.$this->_name.'/email_template.tpl',$html_data);
          }
        } else if (version_compare(VERSION,'3.0.0.0','>=')) {
          $setHtml = $this->load->view('extension/ocdevwizard/'.$this->_name.'/email_template',$html_data);
        } else if (version_compare(VERSION,'2.0.0.0','<')) {
          $template = new Template();

          $template->data = $html_data;

          if (file_exists(DIR_TEMPLATE.$this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/email_template.tpl')) {
            $setHtml = $template->fetch($this->config->get('config_template').'/template/extension/ocdevwizard/'.$this->_name.'/email_template.tpl');
          } else {
            $setHtml = $template->fetch('default/template/extension/ocdevwizard/'.$this->_name.'/email_template.tpl');
          }
        } else {
          $setHtml = $this->load->view('extension/ocdevwizard/'.$this->_name.'/email_template.tpl',$html_data);
        }

        // email notification
        if (version_compare(VERSION,'1.5.5.1','>=') && version_compare(VERSION,'2.0.0.0','<')) {
          $mail            = new Mail();
          $mail->protocol  = $this->config->get('config_mail_protocol');
          $mail->parameter = $this->config->get('config_mail_parameter');
          $mail->hostname  = $this->config->get('config_smtp_host');
          $mail->username  = $this->config->get('config_smtp_username');
          $mail->password  = $this->config->get('config_smtp_password');
          $mail->port      = $this->config->get('config_smtp_port');
          $mail->timeout   = $this->config->get('config_smtp_timeout');
        } else if (version_compare(VERSION,'2.0.0.0','>=') && version_compare(VERSION,'2.0.1.1','<=')) {
          $mail = new Mail($this->config->get('config_mail'));
        } else if (version_compare(VERSION,'2.0.2.0','>=') && version_compare(VERSION,'2.0.3.1','<')) {
          $mail                = new Mail();
          $mail->protocol      = $this->config->get('config_mail_protocol');
          $mail->parameter     = $this->config->get('config_mail_parameter');
          $mail->smtp_hostname = $this->config->get('config_mail_smtp_host');
          $mail->smtp_username = $this->config->get('config_mail_smtp_username');
          $mail->smtp_password = html_entity_decode($this->config->get('config_mail_smtp_password'),ENT_QUOTES,'UTF-8');
          $mail->smtp_port     = $this->config->get('config_mail_smtp_port');
          $mail->smtp_timeout  = $this->config->get('config_mail_smtp_timeout');
        } else if (version_compare(VERSION,'3.0.0.0','>=')) {
          $mail                = new Mail($this->config->get('config_mail_engine'));
          $mail->parameter     = $this->config->get('config_mail_parameter');
          $mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
          $mail->smtp_username = $this->config->get('config_mail_smtp_username');
          $mail->smtp_password = html_entity_decode($this->config->get('config_mail_smtp_password'),ENT_QUOTES,'UTF-8');
          $mail->smtp_port     = $this->config->get('config_mail_smtp_port');
          $mail->smtp_timeout  = $this->config->get('config_mail_smtp_timeout');
        } else {
          $mail                = new Mail();
          $mail->protocol      = $this->config->get('config_mail_protocol');
          $mail->parameter     = $this->config->get('config_mail_parameter');
          $mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
          $mail->smtp_username = $this->config->get('config_mail_smtp_username');
          $mail->smtp_password = html_entity_decode($this->config->get('config_mail_smtp_password'),ENT_QUOTES,'UTF-8');
          $mail->smtp_port     = $this->config->get('config_mail_smtp_port');
          $mail->smtp_timeout  = $this->config->get('config_mail_smtp_timeout');
        }

        $mail->setFrom($this->config->get('config_email'));
        $mail->setSender($data['store_name']);
        $mail->setSubject($setSubject);
        $mail->setHtml($setHtml);

        if (isset($data['set_to_multi']) && $data['set_to_multi']) {
          if ($data['set_to']) {
            $emails = explode(',',$data['set_to']);

            foreach ($emails as $email) {
              $mail->setTo($email);
              $mail->send();
            }
          }
        } else {
          $mail->setTo($data['set_to']);
          $mail->send();
        }
      }
    }
  }
}

?>