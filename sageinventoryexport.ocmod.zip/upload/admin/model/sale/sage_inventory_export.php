<?php 
class ModelSaleSageInventoryExport extends Model {
	
	public function getOrders($data = array()) {
		$sql = "SELECT o.order_id, o.payment_company, c.custom_field, CONCAT(o.firstname, ' ', o.lastname) AS customer, (SELECT os.name FROM " . DB_PREFIX . "order_status os WHERE os.order_status_id = o.order_status_id AND os.language_id = '" . (int)$this->config->get('config_language_id') . "') AS order_status, o.shipping_code, o.total, o.currency_code, o.currency_value, o.date_added, o.date_modified FROM `" . DB_PREFIX . "order` o left join " . DB_PREFIX . "customer c on o.customer_id=c.customer_id " ;

		
		if (isset($data['filter_order_status'])) {
		   $sql .= " WHERE o.order_status_id = '" . (int)$data['filter_order_status'] . "'";
		} else {
			$sql .= " WHERE o.order_status_id > '0'";
		}

		if (!empty($data['filter_order_id'])) {
			$sql .= " AND o.order_id = '" . (int)$data['filter_order_id'] . "'";
		}

		if (!empty($data['filter_company'])) {
			$sql .= " AND o.payment_company LIKE '%" . $this->db->escape($data['filter_company']) . "%'";
		}

		if (!empty($data['filter_date_from'])) {
			$sql .= " AND DATE(o.date_added) >= DATE('" . $this->db->escape($data['filter_date_from']) . "')";
		}

		if (!empty($data['filter_date_to'])) {
			$sql .= " AND DATE(o.date_added) <= DATE('" . $this->db->escape($data['filter_date_to']) . "')";
		}


		$sort_data = array(
			'o.order_id',
			'company',
			'o.date_added'
		);

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];
		} else {
			$sql .= " ORDER BY o.order_id";
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}

		$query = $this->db->query($sql);

		return $query->rows;
	}


	public function getExportOrders($data = array(), $filterdata=array()) {
		$newdbconn = mysqli_connect(REMOTE_DB_HOSTNAME, REMOTE_DB_USERNAME, REMOTE_DB_PASSWORD,REMOTE_DB_DATABASE);
		/* check connection */
		if (mysqli_connect_errno()) {
		    printf("Connect failed: %s\n", mysqli_connect_error());
		    exit();
		}

		if(count($filterdata)>0)
		{

			$sql = "SELECT o.order_id FROM `" . DB_PREFIX . "order` o " ;

		
		if (isset($filterdata['filter_order_status'])) {
		   $sql .= " WHERE o.order_status_id = '" . (int)$filterdata['filter_order_status'] . "'";
		} else {
			$sql .= " WHERE o.order_status_id > '0'";
		}

		if (!empty($filterdata['filter_order_id'])) {
			$sql .= " AND o.order_id = '" . (int)$filterdata['filter_order_id'] . "'";
		}

		if (!empty($filterdata['filter_company'])) {
			$sql .= " AND o.payment_company LIKE '%" . $this->db->escape($filterdata['filter_company']) . "%'";
		}

		if (!empty($filterdata['filter_date_from'])) {
			$sql .= " AND DATE(o.date_added) >= DATE('" . $this->db->escape($filterdata['filter_date_from']) . "')";
		}

		if (!empty($filterdata['filter_date_to'])) {
			$sql .= " AND DATE(o.date_added) <= DATE('" . $this->db->escape($filterdata['filter_date_to']) . "')";
		}


		$sort_data = array(
			'o.order_id',
			'company',
			'o.date_added'
		);

		if (isset($filterdata['sort']) && in_array($filterdata['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $filterdata['sort'];
		} else {
			$sql .= " ORDER BY o.order_id";
		}

		if (isset($filterdata['order']) && ($filterdata['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}


		$query = $this->db->query($sql);

		$maindata = $query->rows;

		}else
		{

			$maindata =$data;
		}

		
	$returndata[]=array(
					'itemid'=>'Item ID',
					'alternative'=>'Alternative',
					'date_timeout'=>'Date',
					'reason_to_adjust'=>'Reason to Adjust',
					'amount_adjusted'=>'Amount Adjusted',
					'number_of_distribution'=>'Number of Distributions',
					'source_account'=>'G/L Source Account',
					'quantity'=> 'Quantity',
					'amount'=>'Amount',
					'serial_number'=>'Serial Number'
				);	
	
	
		
 foreach ($maindata as $orderid)
	{
		if(is_array($orderid))
		{
				$orderid =$orderid['order_id'];
		}

		
	
		$sql = "SELECT o.order_id, o.payment_company, o.customer_id, CONCAT(o.firstname, ' ', o.lastname) AS customer,CONCAT(o.payment_firstname, ' ', o.payment_lastname) AS payment_customer,o.payment_address_1,o.payment_address_2,o.payment_city,o.payment_zone,o.payment_postcode,o.payment_country,o.shipping_method, (SELECT os.name FROM " . DB_PREFIX . "order_status os WHERE os.order_status_id = o.order_status_id AND os.language_id = '" . (int)$this->config->get('config_language_id') . "') AS order_status, o.shipping_code, o.total, o.currency_code, o.currency_value, o.date_added, o.date_modified FROM `" . DB_PREFIX . "order` o";

		
		$sql .= " WHERE o.order_id ='" . (int)$orderid . "'";

		$query = $this->db->query($sql);

			
		foreach($query->rows as $val)
		{
		

			
			$query_op = $this->db->query("SELECT op.order_product_id,op.model, op.name, op.quantity,op.price,op.total, p.sku,p.location FROM " . DB_PREFIX . "order_product op LEFT JOIN " . DB_PREFIX . "product p ON op.product_id=p.product_id WHERE order_id = '" . (int)$val['order_id'] . "'");	

			foreach($query_op->rows as $productdata)
			{
            $alternative='';
            
			$querynew = "SELECT jb.TimeOut,jb.quantity,jb.Alternative,pd.product_id FROM job jb left join productdescription pd on jb.Alternative = pd.OID where jb.order_id = '" . (int)$val['order_id'] . "' and jb.model like '" . $productdata['model'] . "'";
			$resultdata = mysqli_query($newdbconn, $querynew);
			if(mysqli_num_rows($resultdata)>0)
			{
				$rowdata=  mysqli_fetch_array($resultdata, MYSQLI_ASSOC);
				
			
				if(!empty($rowdata['TimeOut']))
				{
					$timeout=date('m/d/Y', strtotime($rowdata['TimeOut']));
				}else
				{
					$timeout='';
				}
				
				$quantity = $rowdata['quantity'];
				if (!empty($rowdata['product_id'])) {
				 $sku_query =  $this->db->query("SELECT sku FROM " . DB_PREFIX . "product WHERE product_id = '" . (int)$rowdata['product_id'] . "'");  
                 if ($sku_query->num_rows) {
                    $alternative=$sku_query->row['sku'];
				  }
                }  
			}else
			{
				$timeout='';
				$quantity ='';
				$alternative='';
			}
				$returndata[]=array(
					'itemid'=>$productdata['sku'],
					'alternative'=>$alternative,
					'date_timeout'=>$timeout,
					'reason_to_adjust'=>$val['order_id'],
					'amount_adjusted'=>'-' . $quantity,
					'number_of_distribution'=>'1',
					'source_account'=>$productdata['location'],
					'quantity'=> '-' . $quantity,
					'amount'=>'',
					'serial_number'=>'1'
				);

			}

		}

	}	

		

		return $returndata;
	}


	public function getCompany($data = array()) {
		$sql = "SELECT DISTINCT payment_company FROM " . DB_PREFIX . "order where 1";

		$implode = array();

		if (!empty($data['filter_company'])) {
			$implode[] = "payment_company LIKE '%" . $this->db->escape($data['filter_company']) . "%'";
		}

		if ($implode) {
			$sql .= " AND " . implode(" AND ", $implode);
		}

		$sort_data = array(
			'payment_company'
		);

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];
		} else {
			$sql .= " ORDER BY payment_company";
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}

		$query = $this->db->query($sql);

		return $query->rows;
	}


	public function getTotalOrders($data = array()) {
		$sql = "SELECT COUNT(*) AS total FROM `" . DB_PREFIX . "order`";

		if (isset($data['filter_order_status'])) {
			$implode = array();

			$order_statuses = explode(',', $data['filter_order_status']);

			foreach ($order_statuses as $order_status_id) {
				$implode[] = "order_status_id = '" . (int)$order_status_id . "'";
			}

			if ($implode) {
				$sql .= " WHERE (" . implode(" OR ", $implode) . ")";
			}
		} else {
			$sql .= " WHERE order_status_id > '0'";
		}

		if (!empty($data['filter_order_id'])) {
			$sql .= " AND order_id = '" . (int)$data['filter_order_id'] . "'";
		}

		if (!empty($data['filter_company'])) {
			$sql .= " AND payment_company LIKE '%" . $this->db->escape($data['filter_company']) . "%'";
		}

		if (!empty($data['filter_date_from'])) {
			$sql .= " AND DATE(date_added) >= DATE('" . $this->db->escape($data['filter_date_from']) . "')";
		}

		if (!empty($data['filter_date_to'])) {
			$sql .= " AND DATE(date_added) <= DATE('" . $this->db->escape($data['filter_date_to']) . "')";
		}

		$query = $this->db->query($sql);

		return $query->row['total'];
	}

}
