<?php
// Heading
$_['heading_title']              = 'Sage Inventory Export';

// Text
$_['text_success']               = 'Success: You have modified orders!';
$_['text_list']                  = 'Order List';
$_['text_missing']               = 'Missing Orders';


// Column
$_['column_order_id']            = 'Order ID';
$_['column_company']            = 'Company';
$_['column_customer']            = 'Customer ID';
$_['column_status']              = 'Status';
$_['column_date_from']          = 'Date';


// Entry
$_['entry_order_id']             = 'Order ID';
$_['entry_company']             = 'Company';
$_['entry_order_status']         = 'Order Status';
$_['entry_date_from']           = 'Date From';
$_['entry_date_to']        = 'Date to';


$_['entry_total']                = 'Total';


// Help
$_['help_override']              = 'If the customers order is being blocked from changing the order status due to an anti-fraud extension enable override.';

// Error
$_['error_warning']              = 'Warning: Please check the form carefully for errors!';
$_['error_permission']           = 'Warning: You do not have permission to modify orders!';
$_['error_action']               = 'Warning: Could not complete this action!';
$_['error_filetype']			 = 'Invalid file type!';
$_['error_no_data']			 = 'No data to Export!';

$_['button_export']			 = 'Export';
$_['button_all_export']			 = 'Export All';

