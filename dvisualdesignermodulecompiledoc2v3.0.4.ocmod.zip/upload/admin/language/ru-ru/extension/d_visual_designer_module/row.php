<?php
//text
$_['text_title']                         = 'Ряд';
$_['text_description']                   = 'Ряд';
$_['text_default']                       = 'По умолчания';
$_['text_stretch_row']                   = 'Растянуть ряд';
$_['text_stretch_row_content']           = 'Растянуть ряд и содержимое';
$_['text_stretch_row_content_right']     = 'Растянуть ряд и содержимое в правой части';
$_['text_stretch_row_content_left']      = 'Растянуть ряд и содержимое в левой части';
$_['text_stretch_row_content_no_spaces'] = 'Растянуть ряд и содержимое (без отступов)';
//entry
$_['entry_size']                         = 'Размер';
$_['entry_background_video']             = 'Использовать видео фон';
$_['entry_video_link']                   = 'Ссылка на видео';
$_['entry_row_stretch']                  = 'Растягивание ряда';
$_['text_enabled']                       = 'Включено';
$_['entry_align_items']                  = 'Выравнивание елементов';
$_['entry_container']                    = 'Контейнер';
//Align
$_['text_left']                          = 'По левому краю';
$_['text_center']                        = 'По центру';
$_['text_right']                         = 'По правому краю';
$_['text_start']                         = 'Начало';
$_['text_end']                           = 'Конец';
$_['text_baseline']                      = 'Baseline';
$_['text_stretch']                       = 'Растянуть';
$_['text_fluid']                         = 'Fluid';
$_['text_responsive']                    = 'Responsive';