<?php
//text
$_['text_title']                         = 'Section Wrapper';
$_['text_description']                   = 'Section Wrapper';
$_['text_default']                       = 'По умолчания';
$_['text_stretch_row']                   = 'Растянуть секцию';
$_['text_stretch_row_content']           = 'Растянуть секцию и содержимое';
$_['text_stretch_row_content_right']     = 'Растянуть секцию и содержимое в правой части';
$_['text_stretch_row_content_left']      = 'Растянуть секцию и содержимое в левой части';
$_['text_stretch_row_content_no_spaces'] = 'Растянуть секцию и содержимое (без отступов)';
//entry
$_['entry_size']                         = 'Размер';
$_['entry_background_video']             = 'Использовать видео фон';
$_['entry_video_link']                   = 'Ссылка на видео';
$_['entry_row_stretch']                  = 'Растягивание секции';
$_['text_enabled']                       = 'Включено';
$_['entry_container']                    = 'Контейнер';

$_['text_fluid']                         = 'Fluid';
$_['text_responsive']                    = 'Responsive';