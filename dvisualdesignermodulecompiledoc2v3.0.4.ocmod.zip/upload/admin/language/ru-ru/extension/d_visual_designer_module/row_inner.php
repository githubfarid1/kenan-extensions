<?php
$_['text_title']             = 'Ряд';
$_['text_description']       = 'Ряд';
//entry
$_['entry_size']             = 'Размер';
$_['entry_background_video'] = 'Использовать видео фон';
$_['entry_video_link']       = 'Ссылка на видео';
$_['text_enabled']           = 'Включено';
$_['entry_align']            = 'Выравнивание';
$_['entry_align_items']      = 'Выравнивание елементов';
$_['entry_container']        = 'Контейнер';

//Align
$_['text_left']              = 'По левому краю';
$_['text_center']            = 'По центру';
$_['text_right']             = 'По правому краю';
$_['text_start']             = 'Начало';
$_['text_end']               = 'Конец';
$_['text_baseline']          = 'Baseline';
$_['text_stretch']           = 'Растянуть';
$_['text_fluid']             = 'Fluid';
$_['text_responsive']        = 'Responsive';