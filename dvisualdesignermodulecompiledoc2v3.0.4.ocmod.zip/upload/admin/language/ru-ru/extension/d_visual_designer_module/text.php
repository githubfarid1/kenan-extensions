<?php
$_['text_title']       = 'Текст';
$_['text_description'] = 'Добавить стилизованый текст';

$_['entry_text']       = 'Текст';