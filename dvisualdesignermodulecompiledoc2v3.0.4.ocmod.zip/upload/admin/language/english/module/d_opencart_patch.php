<?php
/*
 *  location: admin/language
 */

//heading
$_['heading_title']             = '<span style="color:#449DD0; font-weight:bold">Installer (click install to start installation)</span><span style="font-size:12px; color:#999"> by <a href="http://www.opencart.com/index.php?route=extension/extension&filter_username=Dreamvention" style="font-size:1em; color:#999" target="_blank">Dreamvention</a></span>';
