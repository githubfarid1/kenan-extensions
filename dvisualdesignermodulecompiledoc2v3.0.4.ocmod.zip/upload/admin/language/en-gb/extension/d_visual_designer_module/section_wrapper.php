<?php
//text
$_['text_title']                         = 'Section Wrapper';
$_['text_description']                   = 'Section Wrapper';
$_['text_default']                       = 'Default';
$_['text_stretch_row']                   = 'Stretch section';
$_['text_stretch_row_content']           = 'Stretch section and content';
$_['text_stretch_row_content_right']     = 'Stretch section and content in Right';
$_['text_stretch_row_content_left']      = 'Stretch section and content in Left';
$_['text_stretch_row_content_no_spaces'] = 'Stretch section and content (no paddings)';
//entry
$_['entry_size']                         = 'Size';
$_['entry_background_video']             = 'Use video background';
$_['entry_video_link']                   = 'Video link';
$_['entry_row_stretch']                  = 'Section stretch';
$_['text_enabled']                       = 'Enabled';
$_['entry_container']                    = 'Container';

$_['text_fluid']                         = 'Fluid';
$_['text_responsive']                    = 'Responsive';


