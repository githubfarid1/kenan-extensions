<?php
//text
$_['text_title']                         = 'Row';
$_['text_description']                   = 'Row';
$_['text_default']                       = 'Default';
$_['text_stretch_row']                   = 'Stretch row';
$_['text_stretch_row_content']           = 'Stretch row and content';
$_['text_stretch_row_content_right']     = 'Stretch row and content in Right';
$_['text_stretch_row_content_left']      = 'Stretch row and content in Left';
$_['text_stretch_row_content_no_spaces'] = 'Stretch row and content (no paddings)';
//entry
$_['entry_size']                         = 'Size';
$_['entry_background_video']             = 'Use video background';
$_['entry_video_link']                   = 'Video link';
$_['entry_row_stretch']                  = 'Row stretch';
$_['text_enabled']                       = 'Enabled';
$_['entry_align']                        = 'Aligns';
$_['entry_align_items']                  = 'Align items';
$_['entry_container']                    = 'Container';
//Align
$_['text_left']                          = 'Left';
$_['text_center']                        = 'Center';
$_['text_right']                         = 'Right';
$_['text_start']                         = 'Start';
$_['text_end']                           = 'End';
$_['text_baseline']                      = 'Baseline';
$_['text_stretch']                       = 'Stretch';
$_['text_fluid']                         = 'Fluid';
$_['text_responsive']                    = 'Responsive';


