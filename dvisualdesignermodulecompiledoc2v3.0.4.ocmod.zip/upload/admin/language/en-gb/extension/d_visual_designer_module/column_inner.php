<?php
$_['text_title']            = 'Column';
$_['text_description']      = 'Column innner';

//Switcher
$_['text_enabled']          = 'Enabled';
$_['text_yes']              = 'Yes';
$_['text_no']               = 'No';

//Align
$_['text_left']             = 'Left';
$_['text_center']           = 'Center';
$_['text_right']            = 'Right';

$_['text_phone']            = 'Phone';
$_['text_tablet']           = 'Tablet';

$_['column_device']         = 'Device';
$_['column_offset']         = 'Offset';
$_['column_order']          = 'Order';
$_['column_size']           = 'Size';

//entry
$_['entry_size']            = 'Size column';
$_['entry_float']           = 'Float';
$_['entry_align']           = 'Align';
$_['entry_offset']          = 'Offset';
$_['entry_order']           = 'Order';
$_['entry_adaptive_design'] = 'Adaptive design';