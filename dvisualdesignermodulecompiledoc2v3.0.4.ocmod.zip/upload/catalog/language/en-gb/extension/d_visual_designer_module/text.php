<?php
$_['text_title']       = 'Text';
$_['text_description'] = 'Add styles text';