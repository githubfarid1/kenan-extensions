<?php
$_['text_title']                      = 'Image';
$_['text_description']                = 'Add images with style';