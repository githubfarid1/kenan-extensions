<?php
$_['text_title']            = 'Column';
$_['text_description']      = 'Column';