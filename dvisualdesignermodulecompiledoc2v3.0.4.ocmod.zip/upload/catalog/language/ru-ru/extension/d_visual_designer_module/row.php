<?php
//text
$_['text_title']                         = 'Ряд';
$_['text_description']                   = 'Ряд';