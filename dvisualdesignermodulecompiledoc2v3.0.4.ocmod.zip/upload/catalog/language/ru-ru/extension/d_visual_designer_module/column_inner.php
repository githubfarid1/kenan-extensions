<?php
$_['text_title']            = 'Колонка';
$_['text_description']      = 'Калонка';