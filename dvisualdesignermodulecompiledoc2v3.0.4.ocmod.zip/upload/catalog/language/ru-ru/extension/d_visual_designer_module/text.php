<?php
$_['text_title']       = 'Текст';
$_['text_description'] = 'Добавить стилизованый текст';