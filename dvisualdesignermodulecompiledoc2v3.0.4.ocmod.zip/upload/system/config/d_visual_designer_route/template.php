<?php
//Название конфига
$_['name']                = 'Visual Designer Template';
//Статус Frontend редатора
$_['frontend_status']     = 0;
//GET параметр route в админке
$_['backend_route']       = 'd_visual_designer/template/edit';
//REGEX для GET параметров route в админке
$_['backend_route_regex'] = 'd_visual_designer/template/*';
//События
$_['events']              = array();