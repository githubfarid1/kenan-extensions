﻿This extension can Upload Multiple Images and Batch selection Images for product.

Support Opencart v2.0.x
Multiple image upload
Multiple image select

PS: This extension only work for product image, and dose not work for product logo. If you want to check the effect, you should to look at Image option of Catalog-> Product Management Interface. If you want to use in other image manager, you can upload by the product image manager at first.


If you like this extension please provide your 5 star rating for it.

If you have any questions please contact me at opencart_service@hotmail.com and I will do what I can to help. 

Thank you for your supporting!
