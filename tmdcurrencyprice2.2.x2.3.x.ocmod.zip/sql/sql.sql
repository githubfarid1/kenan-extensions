--
-- Table structure for table `oc_product_currency_optionvalue`
--

CREATE TABLE `oc_product_currency_optionvalue` (
  `product_id` int(11) NOT NULL,
  `product_option_id` int(11) NOT NULL,
  `product_option_value_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  `option_value_id` int(11) NOT NULL,
  `currency_id` int(11) NOT NULL,
  `price` decimal(15,0) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_currency_price`
--

CREATE TABLE `oc_product_currency_price` (
  `product_id` int(11) NOT NULL,
  `currency_id` int(11) NOT NULL,
  `price` decimal(15,0) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
