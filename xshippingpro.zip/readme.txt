Thanks for buying it. Please check documentation for detail instruction.

Installation:
---------------
Installation file name is  "xshippingpro.ocmod.zip".  It is available inside respective directory for your opencart version.

1. Please Go to Extensions -> Extension Installer
2. Upload "xshippingpro.ocmod.zip" and click on continue.
3. Now install from admin -> Extensions -> Filter by Shipping -> X-shipping pro

Additional steps for OC 2.x & 3.x
-------
4. Please navigate to admin -> Extensions -> Modifications, Now click on Refresh Button. 


Support:
---------------
Please do support request by clicking on "Get Support" in the module page on the opencart.com marketplace.

Or you can send email to opencartmart@gmail.com for quick response.


Please check blog for example and feature details  http://blog.opencartmart.com/