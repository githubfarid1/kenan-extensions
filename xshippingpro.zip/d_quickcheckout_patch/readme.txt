When do you need this patch?
--------------------
1. If you are using quick_checkout module by dreamvention
2. If you want to refresh Shipping method when payment is chagned Or vice versa

You don't need to upload this patch if any of the above item is false.


Installation:
---------------
Upload the file upload/catalog/controller/extension/d_quickcheckout/ocm.php on your server catalog/controller/extension/d_quickcheckout directory

