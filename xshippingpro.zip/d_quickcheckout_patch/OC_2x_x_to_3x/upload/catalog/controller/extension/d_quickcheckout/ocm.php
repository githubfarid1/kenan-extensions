<?php

class ControllerExtensionDQuickcheckoutOcm extends Controller {
    
    public $action = array(
        'shipping_method/update/after',
        'payment_method/update/after'
    );
    
    public function __construct($registry){
        parent::__construct($registry);
        $this->load->model('extension/d_quickcheckout/store');
        $this->load->model('extension/d_quickcheckout/method');
    }
    /**
    * Initialization
    */
    public function index($config){
        $state = $this->model_extension_d_quickcheckout_store->getState();
        $state['action']['ocm'] = $this->action;
        $this->model_extension_d_quickcheckout_store->setState($state);
    }


    /**
    * Receiver
    * Receiver listens to dispatch of events and accepts data array with action and state
    */
    public function receiver($data) {
        $state = $this->model_extension_d_quickcheckout_store->getState('_ocm');
        if (!isset($state['_ocm']) || !$state['_ocm']) {
            $_state = array();
            $_state['_ocm'] = true;
            $this->model_extension_d_quickcheckout_store->setState($_state);
            $this->model_extension_d_quickcheckout_store->dispatch('cart/update/after', $data);
        }
    }
}
