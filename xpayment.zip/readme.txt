Thanks for buying it.



Installation:
---------------

Installation file name is  "xpayment.ocmod.zip". Extract downloaded xpayment.zip and "xpayment.ocmod.zip" is available inside respective directory for your opencart version.


Please Go to Extensions -> Extension Installer
Upload "xpayment.ocmod.zip" and click on continue.


Now install from admin -> Extensions -> Filter by Payment -> X-Payment

Finally, go to admin -> Extensions -> Modifications and now click on "Refresh" button



Support:
---------------
Please do support request by clicking on "Get Support" in the module page on the opencart.com marketplace.

Or you can send email to opencartmart@gmail.com for quick response.


Language issue with PDF Invoice Module:
------------------
If you find Payment title issue with PDF Invoice module,  Please set "Force Invoice Language" is "Same as Order" in the PDF invoice module setting.