<?php
class ModelSaleSageExport extends Model {
	
	public function getOrders($data = array()) {
		$sql = "SELECT o.order_id, o.payment_company, c.custom_field, CONCAT(o.firstname, ' ', o.lastname) AS customer, (SELECT os.name FROM " . DB_PREFIX . "order_status os WHERE os.order_status_id = o.order_status_id AND os.language_id = '" . (int)$this->config->get('config_language_id') . "') AS order_status, o.shipping_code, o.total, o.currency_code, o.currency_value, o.date_added, o.date_modified FROM `" . DB_PREFIX . "order` o left join " . DB_PREFIX . "customer c on o.customer_id=c.customer_id " ;

		
		if (isset($data['filter_order_status'])) {
		   $sql .= " WHERE o.order_status_id = '" . (int)$data['filter_order_status'] . "'";
		} else {
			$sql .= " WHERE o.order_status_id > '0'";
		}

		if (!empty($data['filter_order_id'])) {
			$sql .= " AND o.order_id = '" . (int)$data['filter_order_id'] . "'";
		}

		if (!empty($data['filter_company'])) {
			$sql .= " AND o.payment_company LIKE '%" . $this->db->escape($data['filter_company']) . "%'";
		}

		if (!empty($data['filter_date_from'])) {
			$sql .= " AND DATE(o.date_added) >= DATE('" . $this->db->escape($data['filter_date_from']) . "')";
		}

		if (!empty($data['filter_date_to'])) {
			$sql .= " AND DATE(o.date_added) <= DATE('" . $this->db->escape($data['filter_date_to']) . "')";
		}


		$sort_data = array(
			'o.order_id',
			'company',
			'o.date_added'
		);

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];
		} else {
			$sql .= " ORDER BY o.order_id";
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}

		$query = $this->db->query($sql);

		return $query->rows;
	}


public function getAllExportOrders($data = array()) {
		$sql = "SELECT o.order_id FROM `" . DB_PREFIX . "order` o " ;

		
		if (isset($data['filter_order_status'])) {
		   $sql .= " WHERE o.order_status_id = '" . (int)$data['filter_order_status'] . "'";
		} else {
			$sql .= " WHERE o.order_status_id > '0'";
		}

		if (!empty($data['filter_order_id'])) {
			$sql .= " AND o.order_id = '" . (int)$data['filter_order_id'] . "'";
		}

		if (!empty($data['filter_company'])) {
			$sql .= " AND o.payment_company LIKE '%" . $this->db->escape($data['filter_company']) . "%'";
		}

		if (!empty($data['filter_date_from'])) {
			$sql .= " AND DATE(o.date_added) >= DATE('" . $this->db->escape($data['filter_date_from']) . "')";
		}

		if (!empty($data['filter_date_to'])) {
			$sql .= " AND DATE(o.date_added) <= DATE('" . $this->db->escape($data['filter_date_to']) . "')";
		}


		$sort_data = array(
			'o.order_id',
			'company',
			'o.date_added'
		);

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];
		} else {
			$sql .= " ORDER BY o.order_id";
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}


		$query = $this->db->query($sql);

		$newdbconn = mysqli_connect(REMOTE_DB_HOSTNAME, REMOTE_DB_USERNAME, REMOTE_DB_PASSWORD,REMOTE_DB_DATABASE);
		/* check connection */
		if (mysqli_connect_errno()) {
		    printf("Connect failed: %s\n", mysqli_connect_error());
		    exit();
		}
		
		
	$returndata[] =array('Customer ID', 'Invoice/CM #', 'Date',	'Ship to Name',	'Ship to Address-Line One',	'Ship to Address-Line Two',	'Ship to City',	'Ship to State', 'Ship to Zipcode',	'Ship to Country',	'Customer PO',	'Ship Via',	'Ship Date', 'Date Due', 'Displayed Terms', 'Sales Representative ID', 'Accounts Receivable Account', 'Note Prints After Line Items', 'Stmt Note Prints Before Ref', 'Beginning Balance Transaction', 'Number of Distributions', 'Invoice/CM Distribution','Apply to Invoice Distribution',	'Apply To Sales Order',	'Apply to Proposal', 'Quantity', 'Item ID',	'Serial Number',	'Description', 'G/L Account', 'Unit Price',	'Tax Type',	'Amount', 'Sales Tax Agency ID');
	

 // foreach ($data as $orderid)
	// {
foreach($query->rows as $orderarray)
{
	$orderid =$orderarray['order_id'];
		// print_r($orderarray['order_id']);	
	
	
		$sql = "SELECT o.order_id, o.payment_company, o.customer_id, CONCAT(o.firstname, ' ', o.lastname) AS customer,CONCAT(o.payment_firstname, ' ', o.payment_lastname) AS payment_customer,o.payment_address_1,o.payment_address_2,o.payment_city,o.payment_zone,o.payment_postcode,o.payment_country,o.shipping_method, (SELECT os.name FROM " . DB_PREFIX . "order_status os WHERE os.order_status_id = o.order_status_id AND os.language_id = '" . (int)$this->config->get('config_language_id') . "') AS order_status, o.shipping_code, o.total, o.currency_code, o.currency_value, o.date_added, o.date_modified FROM `" . DB_PREFIX . "order` o";

		
		$sql .= " WHERE o.order_id ='" . (int)$orderid . "'";

		$query = $this->db->query($sql);

			
		foreach($query->rows as $val)
		{
		
			$sqlcustomer = $this->db->query("SELECT custom_field FROM " . DB_PREFIX . "customer WHERE customer_id = '" . (int)$val['customer_id'] . "'");
			if ($sqlcustomer->num_rows) {
				$customerrow =json_decode($sqlcustomer->rows[0]['custom_field'], true);
			}else
			{
				$customerrow =array(1=>'',2=>'',3=>'');
			}
            
            if (empty($customerrow[2])) $customerrow[2] = 0;
			
			$sqloeorder = $this->db->query("SELECT o.ref_no, s.username FROM " . DB_PREFIX . "oe_order o left join " . DB_PREFIX . "oe_sales_agents s on o.sales_agent_id = s.sales_agent_id  WHERE o.order_id = '" . (int)$val['order_id'] . "'");
			if ($sqloeorder->num_rows) {
				$ref_no =$sqloeorder->rows[0]['ref_no'];
                $sales_rep = (!empty($sqloeorder->rows[0]['username']) ? $sqloeorder->rows[0]['username'] : '');
			}else
			{
				$ref_no ='';
                $sales_rep = '';
			}

			
			$query_op = $this->db->query("SELECT op.order_product_id, op.name, op.quantity,op.price,op.total, p.sku FROM " . DB_PREFIX . "order_product op LEFT JOIN " . DB_PREFIX . "product p ON op.product_id=p.product_id WHERE order_id = '" . (int)$val['order_id'] . "'");
            
            $distributions = $query_op->num_rows;	
            $product_count = 1;

			foreach($query_op->rows as $productdata)
			{

			$querynew = "SELECT BATCH FROM job where order_id = '" . (int)$val['order_id'] . "' and order_product_id='" . (int)$productdata['order_product_id'] . "'";
			$resultdata = mysqli_query($newdbconn, $querynew);
			if(mysqli_num_rows($resultdata)>0)
			{
				$rowdata=  mysqli_fetch_array($resultdata, MYSQLI_ASSOC);
				$batch = $rowdata['BATCH'];
			}else
			{
				$batch = '';
			}
				$returndata[]=array(
					'customer'=>$customerrow['1'],
					'invoice'=>date('Y').'-'.$val['order_id'],
					'date'=>date('m/d/Y'),
					'ship_to_name'=>$val['payment_customer'],
					'ship_to_address_1'=>$val['payment_address_1'],
					'ship_to_address_2'=>$val['payment_address_2'],
					'ship_to_city'=>$val['payment_city'],
					'ship_to_state'=>$val['payment_zone'],
					'ship_to_zipcode'=>$val['payment_postcode'],
					'ship_to_country'=>$val['payment_country'],
					'customer_po'=>$ref_no,
					'ship_via'=>$val['shipping_method'],
					'ship_date'=>date('m/d/Y'),
					'date_due'=>date('m/d/Y', strtotime(date('m/d/Y'). ' + '.$customerrow[2].' days')),
					'display_terms'=>'NET ' . $customerrow[2],
					'sales_representative_id'=>$sales_rep,
					'account_recievable_account'=>'11000',
					'note_print_after_line'=>'FALSE',
					'stmt_note_print_before_ref'=>'FALSE',
					'biginning_balance_transaction'=>'FALSE',
					'no_of_distibution'=> $distributions,
					'invoice_cm_distribution'=>  $product_count,
					'apply_to_invoice_distribution'=>0,
					'apply_to_sale_order'=>'FALSE',
					'apply_to_purposal'=>'FALSE',
					'quantity'=>$productdata['quantity'],
					'itemid'=>$productdata['sku'],
					'serialnumber'=>'',
					'description'=>$productdata['name'].' - '.$batch,
					'g_l_account'=>40200,
					'unit_price'=>number_format($productdata['price'],2, '.', ''),
					'text_type'=>1,
					'amount'=>'-'.number_format($productdata['total'],2, '.', ''),
					'sale_tax_agency_id'=>''
				);
                
                 $product_count++;

			}

		}

	}	

		

		return $returndata;
}


	public function getExportOrders($data = array()) {
		$newdbconn = mysqli_connect(REMOTE_DB_HOSTNAME, REMOTE_DB_USERNAME, REMOTE_DB_PASSWORD,REMOTE_DB_DATABASE);
		/* check connection */
		if (mysqli_connect_errno()) {
		    printf("Connect failed: %s\n", mysqli_connect_error());
		    exit();
		}
		
		
	$returndata[] =array('Customer ID', 'Invoice/CM #', 'Date',	'Ship to Name',	'Ship to Address-Line One',	'Ship to Address-Line Two',	'Ship to City',	'Ship to State', 'Ship to Zipcode',	'Ship to Country',	'Customer PO',	'Ship Via',	'Ship Date', 'Date Due', 'Displayed Terms', 'Sales Representative ID', 'Accounts Receivable Account', 'Note Prints After Line Items', 'Stmt Note Prints Before Ref', 'Beginning Balance Transaction', 'Number of Distributions', 'Invoice/CM Distribution','Apply to Invoice Distribution',	'Apply To Sales Order',	'Apply to Proposal', 'Quantity', 'Item ID',	'Serial Number',	'Description', 'G/L Account', 'Unit Price',	'Tax Type',	'Amount', 'Sales Tax Agency ID');
	
		
 foreach ($data as $orderid)
	{
	
		$sql = "SELECT o.order_id, o.payment_company, o.customer_id, CONCAT(o.firstname, ' ', o.lastname) AS customer,CONCAT(o.payment_firstname, ' ', o.payment_lastname) AS payment_customer,o.payment_address_1,o.payment_address_2,o.payment_city,o.payment_zone,o.payment_postcode,o.payment_country,o.shipping_method, (SELECT os.name FROM " . DB_PREFIX . "order_status os WHERE os.order_status_id = o.order_status_id AND os.language_id = '" . (int)$this->config->get('config_language_id') . "') AS order_status, o.shipping_code, o.total, o.currency_code, o.currency_value, o.date_added, o.date_modified FROM `" . DB_PREFIX . "order` o";

		
		$sql .= " WHERE o.order_id ='" . (int)$orderid . "'";

		$query = $this->db->query($sql);

			
		foreach($query->rows as $val)
		{
		
			$sqlcustomer = $this->db->query("SELECT custom_field FROM " . DB_PREFIX . "customer WHERE customer_id = '" . (int)$val['customer_id'] . "'");
			if ($sqlcustomer->num_rows) {
				$customerrow =json_decode($sqlcustomer->rows[0]['custom_field'], true);
			}else
			{
				$customerrow =array(1=>'',2=>'',3=>'');
			}
            
            if (empty($customerrow[2])) $customerrow[2] = 0;
			
			$sqloeorder = $this->db->query("SELECT o.ref_no, s.username FROM " . DB_PREFIX . "oe_order o left join " . DB_PREFIX . "oe_sales_agents s on o.sales_agent_id = s.sales_agent_id  WHERE o.order_id = '" . (int)$val['order_id'] . "'");
			if ($sqloeorder->num_rows) {
				$ref_no =$sqloeorder->rows[0]['ref_no'];
                $sales_rep = (!empty($sqloeorder->rows[0]['username']) ? $sqloeorder->rows[0]['username'] : '');
			}else
			{
				$ref_no ='';
                $sales_rep = '';
			}

			
			$query_op = $this->db->query("SELECT op.order_product_id, op.name, op.quantity,op.price,op.total, p.sku FROM " . DB_PREFIX . "order_product op LEFT JOIN " . DB_PREFIX . "product p ON op.product_id=p.product_id WHERE order_id = '" . (int)$val['order_id'] . "'");
            
            $distributions = $query_op->num_rows;	
            $product_count = 1;

			foreach($query_op->rows as $productdata)
			{

			$querynew = "SELECT BATCH FROM job where order_id = '" . (int)$val['order_id'] . "' and order_product_id='" . (int)$productdata['order_product_id'] . "'";
			$resultdata = mysqli_query($newdbconn, $querynew);
			if(mysqli_num_rows($resultdata)>0)
			{
				$rowdata=  mysqli_fetch_array($resultdata, MYSQLI_ASSOC);
				$batch = $rowdata['BATCH'];
			}else
			{
				$batch = '';
			}
				$returndata[]=array(
					'customer'=>$customerrow['1'],
					'invoice'=>date('Y').'-'.$val['order_id'],
					'date'=>date('m/d/Y'),
					'ship_to_name'=>$val['payment_customer'],
					'ship_to_address_1'=>$val['payment_address_1'],
					'ship_to_address_2'=>$val['payment_address_2'],
					'ship_to_city'=>$val['payment_city'],
					'ship_to_state'=>$val['payment_zone'],
					'ship_to_zipcode'=>$val['payment_postcode'],
					'ship_to_country'=>$val['payment_country'],
					'customer_po'=>$ref_no,
					'ship_via'=>$val['shipping_method'],
					'ship_date'=>date('m/d/Y'),
					'date_due'=>date('m/d/Y', strtotime(date('m/d/Y'). ' + '.$customerrow[2].' days')),
					'display_terms'=>'NET ' . $customerrow[2],
					'sales_representative_id'=>$sales_rep,
					'account_recievable_account'=>'11000',
					'note_print_after_line'=>'FALSE',
					'stmt_note_print_before_ref'=>'FALSE',
					'biginning_balance_transaction'=>'FALSE',
					'no_of_distibution'=> $distributions,
					'invoice_cm_distribution'=>  $product_count,
					'apply_to_invoice_distribution'=>0,
					'apply_to_sale_order'=>'FALSE',
					'apply_to_purposal'=>'FALSE',
					'quantity'=>$productdata['quantity'],
					'itemid'=>$productdata['sku'],
					'serialnumber'=>'',
					'description'=>$productdata['name'].' - '.$batch,
					'g_l_account'=>40200,
					'unit_price'=>number_format($productdata['price'],2, '.', ''),
					'text_type'=>1,
					'amount'=>'-'.number_format($productdata['total'],2, '.', ''),
					'sale_tax_agency_id'=>''
				);
                
                 $product_count++;

			}

		}

	}	

		

		return $returndata;
	}


	public function getCompany($data = array()) {
		$sql = "SELECT DISTINCT payment_company FROM " . DB_PREFIX . "order where 1";

		$implode = array();

		if (!empty($data['filter_company'])) {
			$implode[] = "payment_company LIKE '%" . $this->db->escape($data['filter_company']) . "%'";
		}

		if ($implode) {
			$sql .= " AND " . implode(" AND ", $implode);
		}

		$sort_data = array(
			'payment_company'
		);

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];
		} else {
			$sql .= " ORDER BY payment_company";
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}

		$query = $this->db->query($sql);

		return $query->rows;
	}


	public function getTotalOrders($data = array()) {
		$sql = "SELECT COUNT(*) AS total FROM `" . DB_PREFIX . "order`";

		if (isset($data['filter_order_status'])) {
			$implode = array();

			$order_statuses = explode(',', $data['filter_order_status']);

			foreach ($order_statuses as $order_status_id) {
				$implode[] = "order_status_id = '" . (int)$order_status_id . "'";
			}

			if ($implode) {
				$sql .= " WHERE (" . implode(" OR ", $implode) . ")";
			}
		} else {
			$sql .= " WHERE order_status_id > '0'";
		}

		if (!empty($data['filter_order_id'])) {
			$sql .= " AND order_id = '" . (int)$data['filter_order_id'] . "'";
		}

		if (!empty($data['filter_company'])) {
			$sql .= " AND payment_company LIKE '%" . $this->db->escape($data['filter_company']) . "%'";
		}

		if (!empty($data['filter_date_from'])) {
			$sql .= " AND DATE(date_added) >= DATE('" . $this->db->escape($data['filter_date_from']) . "')";
		}

		if (!empty($data['filter_date_to'])) {
			$sql .= " AND DATE(date_added) <= DATE('" . $this->db->escape($data['filter_date_to']) . "')";
		}

		$query = $this->db->query($sql);

		return $query->row['total'];
	}

}
