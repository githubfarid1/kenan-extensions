<?php
class ControllerSaleSageExport extends Controller {
	private $error = array();

	public function index() {
		// echo "aaaaaa";
		
		$this->load->language('sale/sage_export');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('sale/sage_export');

		$this->getList();
	}
	
	protected function getList() {
		$pagelimitdata =25;
		$datashow = false;
		if (isset($this->request->get['filter_order_id'])) {
			$filter_order_id = $this->request->get['filter_order_id'];
			$datashow = true;
		} else {
			$filter_order_id = null;
		}

		if (isset($this->request->get['filter_company'])) {
			$datashow = true;
			$filter_company = $this->request->get['filter_company'];
		} else {
			$filter_company = null;
		}
        
        if (isset($this->request->get['filter_order_status'])) {
			$filter_order_status = $this->request->get['filter_order_status'];
            $datashow = true;
		} else {
			$filter_order_status = null;
		}

		if (isset($this->request->get['filter_date_from'])) {
			$datashow = true;
			$filter_date_from = $this->request->get['filter_date_from'];
		} else {
			$filter_date_from = null;
		}

		if (isset($this->request->get['filter_date_to'])) {
			$datashow = true;
			$filter_date_to = $this->request->get['filter_date_to'];
		} else {
			$filter_date_to = null;
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'o.order_id';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'DESC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_order_id'])) {
			$url .= '&filter_order_id=' . $this->request->get['filter_order_id'];
		}

		if (isset($this->request->get['filter_company'])) {
			$url .= '&filter_company=' . urlencode(html_entity_decode($this->request->get['filter_company'], ENT_QUOTES, 'UTF-8'));
		}
        
        if (isset($this->request->get['filter_order_status'])) {
			$url .= '&filter_order_status=' . $this->request->get['filter_order_status'];
		}

		if (isset($this->request->get['filter_date_from'])) {
			$url .= '&filter_date_from=' . $this->request->get['filter_date_from'];
		}

		if (isset($this->request->get['filter_date_to'])) {
			$url .= '&filter_date_to=' . $this->request->get['filter_date_to'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('sale/sage_export', 'token=' . $this->session->data['token'] . $url, true)
		);

		$data['action_button_export'] = $this->url->link('sale/sage_export', 'token=' . $this->session->data['token'] . $url, true);

		$data['action_button_all_export'] = $this->url->link('sale/sage_export/exportallcsv', 'token=' . $this->session->data['token'] . $url, true);
		
		$data['orders'] = array();

		$filter_data = array(
			'filter_order_id'      => $filter_order_id,
			'filter_company'	   => $filter_company,
            'filter_order_status'  => $filter_order_status,
			'filter_date_from'    => $filter_date_from,
			'filter_date_to' => $filter_date_to,
			'sort'                 => $sort,
			'order'                => $order,
			'start'                => ($page - 1) * $pagelimitdata,
			'limit'                => $pagelimitdata
		);
		// echo "<pre>";
		// print_r($this->request->post);
		// exit;

		if (isset($this->request->post['selected'])) {
					$this->exportcsv($this->request->post['selected']);
					return;
		}

		if($datashow == true)
		{
			$order_total = $this->model_sale_sage_export->getTotalOrders($filter_data);
			$results = $this->model_sale_sage_export->getOrders($filter_data);

		}else
		{
			$order_total = 0;
			$results = array();

		}
		
		foreach ($results as $result) {
		  if (!empty($result['custom_field'])) {
		      $customerrow =json_decode($result['custom_field'], true);
              $customer = $customerrow['1'];
		  } else {
		      $customer = '';
		  }
			$data['orders'][] = array(
				'order_id'      => $result['order_id'],
				'company'      => $result['payment_company'],
                'customer'     => $customer, 
				'date_added'    => date($this->language->get('date_format_short'), strtotime($result['date_added']))
			);
		}

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_list'] = $this->language->get('text_list');
		$data['text_no_results'] = $this->language->get('text_no_results');
		$data['text_confirm'] = $this->language->get('text_confirm');
		$data['text_missing'] = $this->language->get('text_missing');
		$data['text_loading'] = $this->language->get('text_loading');

		$data['column_order_id'] = $this->language->get('column_order_id');
		$data['column_company'] = $this->language->get('column_company');
        $data['column_customer'] = $this->language->get('column_customer');
        $data['column_status'] = $this->language->get('column_status');
		$data['column_date_from'] = $this->language->get('column_date_from');

		$data['entry_order_id'] = $this->language->get('entry_order_id');
		$data['entry_company'] = $this->language->get('entry_company');
        $data['entry_order_status'] = $this->language->get('entry_order_status');
		$data['entry_date_from'] = $this->language->get('entry_date_from');
		$data['entry_date_to'] = $this->language->get('entry_date_to');

		$data['button_export'] = $this->language->get('button_export');
		$data['button_all_export'] = $this->language->get('button_all_export');
		$data['button_filter'] = $this->language->get('button_filter');
		

		$data['token'] = $this->session->data['token'];

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		
		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if (isset($this->request->get['filter_order_id'])) {
			$url .= '&filter_order_id=' . $this->request->get['filter_order_id'];
		}

		if (isset($this->request->get['filter_company'])) {
			$url .= '&filter_company=' . urlencode(html_entity_decode($this->request->get['filter_company'], ENT_QUOTES, 'UTF-8'));
		}

        if (isset($this->request->get['filter_order_status'])) {
			$url .= '&filter_order_status=' . $this->request->get['filter_order_status'];
		}

		if (isset($this->request->get['filter_date_from'])) {
			$url .= '&filter_date_from=' . $this->request->get['filter_date_from'];
		}

		if (isset($this->request->get['filter_date_to'])) {
			$url .= '&filter_date_to=' . $this->request->get['filter_date_to'];
		}

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}



		$data['sort_order'] = $this->url->link('sale/sage_export', 'token=' . $this->session->data['token'] . '&sort=o.order_id' . $url, true);
		$data['sort_company'] = $this->url->link('sale/sage_export', 'token=' . $this->session->data['token'] . '&sort=payment_company' . $url, true);
	
		$data['sort_date_from'] = $this->url->link('sale/sage_export', 'token=' . $this->session->data['token'] . '&sort=o.date_added' . $url, true);

		$url = '';

		if (isset($this->request->get['filter_order_id'])) {
			$url .= '&filter_order_id=' . $this->request->get['filter_order_id'];
		}

		if (isset($this->request->get['filter_company'])) {
			$url .= '&filter_company=' . urlencode(html_entity_decode($this->request->get['filter_company'], ENT_QUOTES, 'UTF-8'));
		}

       if (isset($this->request->get['filter_order_status'])) {
			$url .= '&filter_order_status=' . $this->request->get['filter_order_status'];
		}
	
		if (isset($this->request->get['filter_date_from'])) {
			$url .= '&filter_date_from=' . $this->request->get['filter_date_from'];
		}

		if (isset($this->request->get['filter_date_to'])) {
			$url .= '&filter_date_to=' . $this->request->get['filter_date_to'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $order_total;
		$pagination->page = $page;
		$pagination->limit = $pagelimitdata;
		
		$pagination->url = $this->url->link('sale/sage_export', 'token=' . $this->session->data['token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($order_total) ? (($page - 1) * $pagelimitdata) + 1 : 0, ((($page - 1) * $pagelimitdata) > ($order_total - $pagelimitdata)) ? $order_total : ((($page - 1) * $pagelimitdata) + $pagelimitdata), $order_total, ceil($order_total / $pagelimitdata));

		$data['filter_order_id'] = $filter_order_id;
		$data['filter_company'] = $filter_company;
        $data['filter_order_status'] = $filter_order_status;
		$data['filter_date_from'] = $filter_date_from;
		$data['filter_date_to'] = $filter_date_to;

		$data['sort'] = $sort;
		$data['order'] = $order;

		 $this->load->model('localisation/order_status');

		 $data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('sale/sage_export_list', $data));
	}

	public function autocomplete() {
		$json = array();

		if (isset($this->request->get['filter_company'])) {
			if (isset($this->request->get['filter_company'])) {
				$filter_company = $this->request->get['filter_company'];
			} else {
				$filter_company = '';
			}

		
			$this->load->model('sale/sage_export');

			$filter_data = array(
				'filter_company'  => $filter_company,
				'start'        => 0,
				'limit'        => 5
			);

			$results = $this->model_sale_sage_export->getCompany($filter_data);

			foreach ($results as $result) {
				$json[] = array(
					'payment_company'       => $result['payment_company']
				);
			}
		}

		$sort_order = array();

		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['payment_company'];
		}

		array_multisort($sort_order, SORT_ASC, $json);

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function exportcsv($selectedorder='') { 
		
		/* CSV Header Starts Here */
		 
		header("Content-Type: text/csv");
		header("Content-Disposition: attachment; filename=OrdersCSV-".date('d-m-Y').".csv");
		// Disable caching
		header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1
		header("Pragma: no-cache"); // HTTP 1.0
		header("Expires: 0"); // Proxies
		 
		/* CSV Header Ends Here */
		 
		$output = fopen("php://output", "w"); //Opens and clears the contents of file; or creates a new file if it doesn't exist		
		 $expdata = $this->model_sale_sage_export->getExportOrders($selectedorder);
		foreach($expdata as $row)
		{
		    fputcsv($output, $row); // here you can change delimiter/enclosure
		}
		 
		fclose($output); // Closing the File

	}


	public function exportallcsv()
	{

		$datashow = false;
		if (isset($this->request->get['filter_order_id'])) {
			$filter_order_id = $this->request->get['filter_order_id'];
			$datashow = true;
		} else {
			$filter_order_id = null;
		}

		if (isset($this->request->get['filter_company'])) {
			$datashow = true;
			$filter_company = $this->request->get['filter_company'];
		} else {
			$filter_company = null;
		}
        
        if (isset($this->request->get['filter_order_status'])) {
			$filter_order_status = $this->request->get['filter_order_status'];
            $datashow = true;
		} else {
			$filter_order_status = null;
		}

		if (isset($this->request->get['filter_date_from'])) {
			$datashow = true;
			$filter_date_from = $this->request->get['filter_date_from'];
		} else {
			$filter_date_from = null;
		}

		if (isset($this->request->get['filter_date_to'])) {
			$datashow = true;
			$filter_date_to = $this->request->get['filter_date_to'];
		} else {
			$filter_date_to = null;
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'o.order_id';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'DESC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}


		$filter_data = array(
			'filter_order_id'      => $filter_order_id,
			'filter_company'	   => $filter_company,
            'filter_order_status'  => $filter_order_status,
			'filter_date_from'    => $filter_date_from,
			'filter_date_to' => $filter_date_to,
			'sort'                 => $sort,
			'order'                => $order
		);
		$this->load->model('sale/sage_export');
		$this->load->language('sale/sage_export');
		$expdata = $this->model_sale_sage_export->getAllExportOrders($filter_data);
		
		if($datashow==false)
		{
			$this->error['warning'] = $this->language->get('error_no_data');
			$this->getList();
			return;
		}

		/* CSV Header Starts Here */
		 
		header("Content-Type: text/csv");
		header("Content-Disposition: attachment; filename=OrdersCSV-".date('d-m-Y').".csv");
		// Disable caching
		header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1
		header("Pragma: no-cache"); // HTTP 1.0
		header("Expires: 0"); // Proxies
		 
		/* CSV Header Ends Here */
		 
		$output = fopen("php://output", "w"); //Opens and clears the contents of file; or creates a new file if it doesn't exist		
		
		foreach($expdata as $row)
		{
		    fputcsv($output, $row); // here you can change delimiter/enclosure
		}
		 
		fclose($output); // Closing the File


	}



	
}
