<?php
class ModelExtensionModuleSerialkeys extends Model {

    public function hasProductSeriakeys($product_id) {
        $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product WHERE product_id='" . (int)$product_id . "' AND sk_status='1'");
        return (bool)$query->num_rows;
    }

    public function bindSerialkeys($order_id, $product_id, $quantity) {
        $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_sk WHERE product_id='" . (int)$product_id . "' AND order_id='" . (int)$order_id . "'");
        $quantity -= $query->num_rows;
        if($quantity) {
            $this->db->query("UPDATE " . DB_PREFIX . "product_sk SET order_id='" . (int)$order_id . "' WHERE product_id='" . (int)$product_id . "' AND order_id='0' LIMIT " . $quantity);
        }
    }

    public function updateStock($product_id) {
        $query = $this->db->query("SELECT COUNT(*) as quantity FROM " . DB_PREFIX . "product_sk WHERE product_id='" . (int)$product_id . "' AND order_id='0'");
        $this->db->query("UPDATE " . DB_PREFIX . "product SET quantity='" . (int)$query->row['quantity'] . "' WHERE product_id='" . (int)$product_id . "'");
        return $query->row['quantity'];
    }

    public function getSerialkeys($customer_id, $start, $limit) {
        $sql = "SELECT o.order_id, o.date_added, op.name, ps.serialkey, pd.link, p.sk_link FROM " . DB_PREFIX . "order o";
        $sql .= " LEFT JOIN " . DB_PREFIX . "order_product op ON (o.order_id = op.order_id)";
        $sql .= " LEFT JOIN " . DB_PREFIX . "product_sk ps ON (ps.product_id = op.product_id AND ps.order_id=o.order_id)";
        $sql .= " LEFT JOIN " . DB_PREFIX . "product_description pd ON (pd.product_id = op.product_id)";
        $sql .= " LEFT JOIN " . DB_PREFIX . "product p ON (p.product_id = op.product_id)";
        $sql .= " WHERE o.customer_id='" . (int)$customer_id . "'";
        $sql .= " AND o.order_status_id IN(" . implode(',', $this->config->get('config_complete_status')) . ")";
        $sql .= " AND pd.language_id='" . $this->config->get('config_language_id') . "'";
        $sql .= " AND ps.serialkey IS NOT NULL";
        $sql .= " ORDER BY o.date_added DESC";
        $sql .= " LIMIT " . $start . "," . $limit;

        $query = $this->db->query($sql);

        return $query->rows;
    }

    public function getTotalSerialkeys($customer_id) {
        $sql = "SELECT COUNT(*) as total FROM " . DB_PREFIX . "order o";
        $sql .= " LEFT JOIN " . DB_PREFIX . "order_product op ON (o.order_id = op.order_id)";
        $sql .= " LEFT JOIN " . DB_PREFIX . "product_sk ps ON (ps.product_id = op.product_id AND ps.order_id=o.order_id)";
        $sql .= " WHERE o.customer_id='" . (int)$customer_id . "'";
        $sql .= " AND o.order_status_id IN(" . implode(',', $this->config->get('config_complete_status')) . ")";

        $query = $this->db->query($sql);

        return $query->row['total'];
    }

    public function getOrderProducts($order_id) {
        $product_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_product WHERE order_id='" . (int)$order_id . "' GROUP BY product_id");
        return $product_query->rows;
    }

    public function getDownloadLink($product_id, $language_id) {
        $query = $this->db->query("SELECT pd.link FROM " . DB_PREFIX . "product p LEFT JOIN " . DB_PREFIX . "product_description pd ON (p.product_id = pd.product_id) WHERE p.product_id='" . (int)$product_id . "' AND pd.language_id='" . (int)$language_id . "' AND p.sk_link='1'");
        if($query->num_rows) {
            return $query->row['link'];
        } else {
            return false;
        }
    }

    public function getSerialKeysText($order_info) {
        $text = '';

        $products = $this->getOrderProducts($order_info['order_id']);
        foreach($products as $product) {
            $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_sk WHERE order_id='" . $order_info['order_id'] . "' AND product_id='" . (int)$product['product_id'] . "'");

            $serialkeys = array();
            foreach($query->rows as $row) {
                $serialkeys[] = $row['serialkey'];
            }

            if($serialkeys) {
                $keys = implode("\r\n", $serialkeys);
                $text .= $this->config->get('module_serialkeys_subject')[$order_info['language_id']];
                $text .= " " . $product['name'] . " - " . $keys . " " . $this->getDownloadLink($product['product_id'],$order_info['language_id']);
                $text .= "\r\n";
            }
        }

        if($text) {
            $text = "\r\n" . $text;
        }

        return $text;
    }

    public function getSerialKeysHTML($order_info) {
        $data['products'] = array();

        $products = $this->getOrderProducts($order_info['order_id']);

        foreach($products as $product) {
            $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_sk WHERE order_id='" . $order_info['order_id'] . "' AND product_id='" . (int)$product['product_id'] . "'");

            $keys = array();
            foreach($query->rows as $row) {
                $keys[] = $row['serialkey'];
            }

            $data['products'][] = array(
                'name' => $product['name'],
                'link' => $this->getDownloadLink($product['product_id'],$order_info['language_id']),
                'keys' => $keys
            );
        }

        $language = new Language($order_info['language_code']);
        $language->load($order_info['language_code']);
        $language->load('extension/module/serialkeys');

        $data['column_product'] = $language->get('column_product');
        $data['column_key'] = $language->get('column_key');
        $data['column_link'] = $language->get('column_link');

        return $this->load->view('extension/module/serialkeys_table', $data);
    }
}
