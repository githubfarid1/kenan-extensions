<?php
class ControllerExtensionModuleSerialkeys extends Controller {

    public function index() {
        if (!$this->customer->isLogged()) {
            $this->session->data['redirect'] = $this->url->link('account/account', '', true);

            $this->response->redirect($this->url->link('account/login', '', true));
        }

        $this->load->language('extension/module/serialkeys');

        $this->document->setTitle($this->config->get('module_serialkeys_title')[$this->config->get('config_language_id')]);
        $data['heading_title'] = $this->config->get('module_serialkeys_title')[$this->config->get('config_language_id')];

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/home')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_account'),
            'href' => $this->url->link('account/account', '', true)
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->config->get('module_serialkeys_title')[$this->config->get('config_language_id')],
            'href' => $this->url->link('extension/module/serialkeys', '', true)
        );

        if (isset($this->request->get['page'])) {
            $page = $this->request->get['page'];
        } else {
            $page = 1;
        }

        if (isset($this->request->get['limit'])) {
            $limit = (int)$this->request->get['limit'];
        } else {
            $limit = $this->config->get('theme_' . $this->config->get('config_theme') . '_product_limit');
        }

        $this->load->model('extension/module/serialkeys');

        $total = $this->model_extension_module_serialkeys->getTotalSerialkeys($this->customer->getId());
        $serialkeys = $this->model_extension_module_serialkeys->getSerialkeys($this->customer->getId(), ($page - 1) * $limit, $limit);

        $data['serialkeys'] = array();

        foreach($serialkeys as $serialkey) {
            $data['serialkeys'][] = array(
                'order_id' => $serialkey['order_id'],
                'date_added' => date($this->language->get('date_format_short'), strtotime($serialkey['date_added'])),
                'name' => $serialkey['name'],
                'serialkey' => $serialkey['serialkey'],
                'link' => $serialkey['sk_link'] ? $serialkey['link'] : ''
            );
        }

        $url = '';

        if (isset($this->request->get['limit'])) {
            $url .= '&limit=' . $this->request->get['limit'];
        }

        $pagination = new Pagination();
        $pagination->total = $total;
        $pagination->page = $page;
        $pagination->limit = $limit;
        $pagination->url = $this->url->link('extension/module/serialkeys', $url . '&page={page}');

        $data['pagination'] = $pagination->render();

        $data['results'] = sprintf($this->language->get('text_pagination'), ($total) ? (($page - 1) * $limit) + 1 : 0, ((($page - 1) * $limit) > ($total - $limit)) ? $total : ((($page - 1) * $limit) + $limit), $total, ceil($total / $limit));

        $data['column_left'] = $this->load->controller('common/column_left');
        $data['column_right'] = $this->load->controller('common/column_right');
        $data['content_top'] = $this->load->controller('common/content_top');
        $data['content_bottom'] = $this->load->controller('common/content_bottom');
        $data['footer'] = $this->load->controller('common/footer');
        $data['header'] = $this->load->controller('common/header');

        $this->response->setOutput($this->load->view('extension/module/serialkeys', $data));
    }

    public function addOrderHistory(&$route, &$args) {
        if (isset($args[0])) {
            $order_id = $args[0];
        } else {
            $order_id = 0;
        }

        if (isset($args[1])) {
            $order_status_id = $args[1];
        } else {
            $order_status_id = 0;
        }

        if (isset($args[3])) {
            $notify = $args[3];
        } else {
            $notify = 0;
        }

        $order_info = $this->model_checkout_order->getOrder($order_id);

        $this->load->model('extension/module/serialkeys');

        $products = $this->model_checkout_order->getOrderProducts($order_id);

        foreach ($products as $product) {
            if($this->model_extension_module_serialkeys->hasProductSeriakeys($product['product_id'])) {

                if (!in_array($order_info['order_status_id'], array_merge($this->config->get('config_processing_status'), $this->config->get('config_complete_status'))) && in_array($order_status_id, array_merge($this->config->get('config_processing_status'), $this->config->get('config_complete_status')))) {
                    $this->model_extension_module_serialkeys->bindSerialkeys($order_id, $product['product_id'], $product['quantity']);
                }
            }
        }

        $products = $this->model_extension_module_serialkeys->getOrderProducts($order_id);

        $serialkeys = new serialkeys($this->registry);
        $send = 0;
        foreach ($products as $product) {
            if($this->model_extension_module_serialkeys->hasProductSeriakeys($product['product_id'])) {

                if(!in_array($order_info['order_status_id'], $this->config->get('config_complete_status')) && in_array($order_status_id, $this->config->get('config_complete_status'))) {
                    if(!$serialkeys->sendKeys($order_id, $product['product_id'], $product['price'], $product['tax'])) {
                        $send++;
                    }
                }
            }
        }

        if($send && !$notify) {
            $this->config->set('forced_send', 1);

            $action = new Action('mail/order/edit');
            $action->execute($this->registry, array($order_info, $order_info['order_status_id'], ''));
        }
    }

    public function addOrderHistoryAfter(&$route, &$args) {
        if (isset($args[0])) {
            $order_id = $args[0];
        } else {
            $order_id = 0;
        }

        $first = false;

        $history_query = $this->db->query("SELECT COUNT(*) as total FROM " . DB_PREFIX . "order_history WHERE order_id='" . (int)$order_id . "'");
        if($history_query->row['total'] == 1) {
            $first = true;
        }

        $order_info = $this->model_checkout_order->getOrder($order_id);

        $this->load->language('extension/module/serialkeys');
        $this->load->model('extension/module/serialkeys');

        $messages = array();

        $products = $this->model_extension_module_serialkeys->getOrderProducts($order_id);
        foreach ($products as $product) {

            if($this->model_extension_module_serialkeys->hasProductSeriakeys($product['product_id'])) {

                $new_qty = $this->model_extension_module_serialkeys->updateStock($product['product_id']);

                if($first && ($new_qty <= $this->config->get('module_serialkeys_stock_notify'))) {
                    $messages[] = sprintf($this->language->get('text_less'),$this->config->get('module_serialkeys_stock_notify'), $product['name']);
                }
            }
        }

        if($messages) {
            $mail = new Mail($this->config->get('config_mail_engine'));
            $mail->protocol = $this->config->get('config_mail_protocol');
            $mail->parameter = $this->config->get('config_mail_parameter');
            $mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
            $mail->smtp_username = $this->config->get('config_mail_smtp_username');
            $mail->smtp_password = html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
            $mail->smtp_port = $this->config->get('config_mail_smtp_port');
            $mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');

            $mail->setTo($this->config->get('config_email'));
            $mail->setFrom($this->config->get('config_email'));
            $mail->setReplyTo($order_info['email']);
            $mail->setSender($this->language->get('text_alert'));
            $mail->setSubject($this->language->get('text_alert'));
            $mail->setText(html_entity_decode(implode("\r\n", $messages), ENT_QUOTES, 'UTF-8'));
            $mail->send();
        }
    }

    public function deleteOrder(&$route, &$args) {
        if (isset($args[0])) {
            $order_id = $args[0];
        } else {
            $order_id = 0;
        }

        if($order_id) {
            $this->db->query("DELETE FROM " . DB_PREFIX . "product_sk WHERE order_id='" . (int)$order_id . "'");
        }
    }

    public function send() {
        $this->api();

        $json['status'] = false;

        if (isset($this->session->data['api_id']) && !empty($this->request->post['order_id'])) {
            $this->load->language('extension/module/serialkeys');
            $this->load->model('extension/module/serialkeys');
            $this->load->model('checkout/order');

            $order_info = $this->model_checkout_order->getOrder($this->request->post['order_id']);
            $products = $this->model_extension_module_serialkeys->getOrderProducts($this->request->post['order_id']);

            $serialkeys = new serialkeys($this->registry);
            $send = 0;

            foreach ($products as $product) {
                if($this->model_extension_module_serialkeys->hasProductSeriakeys($product['product_id'])) {

                    if(!$serialkeys->sendKeys($order_info['order_id'], $product['product_id'], $product['price'], $product['tax'])) {
                        $send++;
                    }
                }
            }

            if($send) {
                $this->config->set('forced_send', 1);

                $action = new Action('mail/order/edit');
                $action->execute($this->registry, array($order_info, $order_info['order_status_id'], ''));
            }

            $json['status'] = true;
            $json['success'] = $this->language->get('text_success_send');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    protected function api() {
        $this->db->query("DELETE FROM `" . DB_PREFIX . "api_session` WHERE TIMESTAMPADD(HOUR, 1, date_modified) < NOW()");

        // Make sure the IP is allowed
        $api_query = $this->db->query("SELECT DISTINCT * FROM `" . DB_PREFIX . "api` `a` LEFT JOIN `" . DB_PREFIX . "api_session` `as` ON (a.api_id = as.api_id) LEFT JOIN " . DB_PREFIX . "api_ip `ai` ON (a.api_id = ai.api_id) WHERE a.status = '1' AND `as`.`session_id` = '" . $this->db->escape($this->request->get['api_token']) . "' AND ai.ip = '" . $this->db->escape($this->request->server['REMOTE_ADDR']) . "'");

        if ($api_query->num_rows) {
            $this->session->start($this->request->get['api_token']);

            // keep the session alive
            $this->db->query("UPDATE `" . DB_PREFIX . "api_session` SET `date_modified` = NOW() WHERE `api_session_id` = '" . (int)$api_query->row['api_session_id'] . "'");
        }
    }
}
