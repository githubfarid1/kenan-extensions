<?php
// Text
$_['text_less'] = 'There is less than %s items left of: %s';
$_['text_alert'] = 'Out stock Alert';
$_['text_account'] = 'Account';
$_['text_no_keys'] = 'No Serial Keys.';
$_['text_success_send'] = 'Serial Keys was sended!';

// Column
$_['column_order'] = 'Order ID';
$_['column_date'] = 'Date Added';
$_['column_product'] = 'Product Name';
$_['column_key'] = 'Serial Number';
$_['column_link'] = 'Activation Link';