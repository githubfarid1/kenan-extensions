<?php
class ModelExtensionModuleSerialkeys extends Model {

    public function getProductTemplates() {
        $data = array();

        $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_template");

        foreach($query->rows as $row) {

            $template = array();

            $q2 = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_template_description WHERE id='" . (int)$row['id'] . "'");
            foreach($q2->rows as $r2) {
                $template[$r2['language_id']] = html_entity_decode($r2['description']);
            }

            $data[] = array(
                'name' => $row['name'],
                'id' => $row['id'],
                'template' => $template
            );
        }

        return $data;
    }

    public function saveProductTemplates($data) {
        $this->db->query("DELETE FROM " . DB_PREFIX . "product_template");
        $this->db->query("DELETE FROM " . DB_PREFIX . "product_template_description");

        if(isset($data['product_template'])) {
            foreach($data['product_template'] as $product_template) {
                if($product_template['id']) {
                    $this->db->query("INSERT INTO " . DB_PREFIX . "product_template SET id='" . (int)$product_template['id'] . "', `name`='" . $this->db->escape($product_template['name']) . "'");
                    $id = $product_template['id'];
                } else {
                    $this->db->query("INSERT INTO " . DB_PREFIX . "product_template SET `name`='" . $this->db->escape($product_template['name']) . "'");
                    $id = $this->db->getLastId();
                }

                foreach($product_template['description'] as $language_id => $description) {
                    $this->db->query("INSERT INTO " . DB_PREFIX . "product_template_description SET id='" . (int)$id . "', language_id='" . (int)$language_id . "', description='" . $this->db->escape($description) . "'");
                }
            }
        }
    }

    public function getSerialkeys($product_id, $order_id = 0) {
        $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_sk WHERE product_id='" . (int)$product_id . "' AND order_id='" . (int)$order_id . "'");
        return $query->rows;
    }

    public function deleteSerialkey($product_sk_id) {
        $this->db->query("DELETE FROM " . DB_PREFIX . "product_sk WHERE product_sk_id='" . (int)$product_sk_id . "'");
    }

    public function editProduct($product_id, $data) {
        $this->db->query("UPDATE " . DB_PREFIX . "product SET sk_status='" . (int)$data['sk_status'] . "', sk_link='" . (int)$data['sk_link'] . "', sk_template='" . (int)$data['sk_template'] . "' WHERE product_id='" . (int)$product_id . "'");

        $this->db->query("DELETE FROM " . DB_PREFIX . "product_sk WHERE product_id='" . (int)$product_id . "' AND order_id='0'");

       $this->editSerialkeys($product_id, $data['serialkeys']);

        foreach($data['product_description'] as $language_id => $description) {
            $this->db->query("UPDATE " . DB_PREFIX . "product_description SET `link`='" . $this->db->escape($description['link']) . "' WHERE product_id='" . (int)$product_id . "' AND language_id='" . (int)$language_id . "'");
        }
    }

    public function editSerialkeys($product_id, $serialkeys) {
        $quantity = 0;
        $keys = array();
        $serialkeys = explode("\n", $serialkeys);

        foreach($serialkeys as $serialkey) {
            $serialkey = trim($serialkey);
            if($serialkey) {
                $keys[] = $serialkey;
            }
        }

        $keys = array_unique($keys);

        foreach ($keys as $serialkey) {
            $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_sk WHERE product_id='" . (int)$product_id . "' AND serialkey='" . $this->db->escape($serialkey) . "'");
            if(!$query->num_rows) {
                $this->db->query("INSERT INTO " . DB_PREFIX . "product_sk SET serialkey='" . $this->db->escape($serialkey) . "', product_id='" . (int)$product_id . "', order_id='0'");
                $quantity++;
            }
        }

        if($quantity) {
            $this->db->query("UPDATE " . DB_PREFIX . "product SET quantity='" . (int)$quantity . "' WHERE product_id='" . (int)$product_id . "'");
        }
    }

    public function getSerialkeysRaw($order_id) {
        $query = $this->db->query("SELECT ps.serialkey, pd.name FROM " . DB_PREFIX . "product_sk ps LEFT JOIN " . DB_PREFIX . "product_description pd ON (pd.product_id = ps.product_id) WHERE ps.order_id='" . (int)$order_id . "' AND pd.language_id='" . (int)$this->config->get('config_language_id') . "' ORDER BY pd.name ASC");
        return $query->rows;
    }

    public function getSerialkeysHtml($order_id) {
        $data = '';

        $rows = $this->getSerialkeysRaw($order_id);

        $keys = array();
        foreach($rows as $row) {
            $keys[] = "<strong>" . $row['name'] . ":</strong> - " . $row['serialkey'];
        }

        if($keys) {
            $data = implode("<br/>", $keys);
        }

        return $data;
    }

    public function updateOrderProductStock($order_id) {
        $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_product WHERE order_id='" . (int)$order_id . "' GROUP BY product_id");
        foreach($query->rows as $product) {
            $q2 = $this->db->query("SELECT COUNT(*) as quantity FROM " . DB_PREFIX . "product_sk WHERE product_id='" . (int)$product['product_id'] . "' AND order_id='" . (int)$order_id . "'");
            $this->db->query("UPDATE " . DB_PREFIX . "product SET quantity='" . (int)$q2->row['quantity'] . "' WHERE product_id='" . (int)$product['product_id'] . "'");
        }
    }

    public function export($data) {
        $sql = "SELECT * FROM " . DB_PREFIX . "product_sk WHERE 1";

        if(!empty($data['export_all_products']) && isset($data['export_product'])) {
            $sql .= " AND product_id IN(" . implode(',', $data['export_product']) . ")";
        }

        if(!empty($data['export_sold']) && $data['export_sold'] == 'yes') {
            $sql .= " AND order_id > '0'";
        } elseif(!empty($data['export_sold']) && $data['export_sold'] == 'no') {
            $sql .= " AND order_id = '0'";
        }

        $query = $this->db->query($sql);
        return $query->rows;
    }

    public function import($data) {
        foreach($data as $line) {
            if($line['order_id']) {
                continue;
            }

            $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_sk WHERE product_id='" . (int)$line['product_id'] . "' AND serialkey='" . $this->db->escape($line['serialkey']) . "'");

            if(!$query->num_rows) {
                $this->db->query("INSERT INTO " . DB_PREFIX . "product_sk SET serialkey='" . $this->db->escape($line['serialkey']) . "', product_id='" . (int)$line['product_id'] . "', order_id='0'");
            }
        }
    }
}