<?php
// Heading
$_['heading_title']             = '<strong class="text-danger">Serial Keys Sale Module</strong>';
$_['heading_title_text']        = 'Serial Keys Sale Module';

// Tab
$_['tab_general']               = 'General';
$_['tab_template']              = 'Template';
$_['tab_import']                = 'Import';
$_['tab_export']                = 'Export';

// Text
$_['text_extension']            = 'Extensions';
$_['text_success']              = 'Success: You have modified serialkeys module!';
$_['text_edit']                 = 'Edit Serialkeys Sale Module';
$_['text_serialkeys']           = 'Serial Keys';
$_['text_error_ajax']           = 'Error! Something went wrong.';
$_['text_success_send']         = 'Success! Serial Keys was sended.';
$_['text_success_back']         = 'Success! Serial Keys was back to sale.';
$_['text_success_delete']       = 'Success! Serial Keys was deleted.';
$_['text_success_import']       = 'Success! Import was successful.';
$_['text_import_help']          = 'Only new keys';
$_['text_all']                  = 'All';

// Entry
$_['entry_stock_notify']        = 'Notify admin by email when lack of serial keys';
$_['entry_name']                = 'Name';
$_['entry_template']            = 'Template';
$_['entry_status']              = 'Notification Status';
$_['entry_title']               = 'Page Title';
$_['entry_title_placeholder']   = 'My Serial Keys and Download Links';
$_['entry_subject']             = 'SerialKeys Mail Subject';
$_['entry_subject_placeholder'] = 'Serial Keys for Product:';
$_['entry_products']            = 'All Products';
$_['entry_product']             = 'Product';
$_['entry_sold']                = 'Sold';
$_['entry_file']                = 'File, CSV';

// Button
$_['button_add_template']       = 'Add Template';
$_['button_send_keys']          = 'Send Keys';
$_['button_back_keys']          = 'Back Keys';
$_['button_delete_keys']        = 'Delete Keys';
$_['button_export']             = 'Export';

// Column
$_['column_name']               = 'Product Name';
$_['column_key']                = 'Serial Key';
$_['column_product_id']         = 'Product Id';
$_['column_order_id']           = 'Order Id';

// Comment
$_['comment_name']              = 'will be replaced in mail by product name';
$_['comment_price']             = 'will be replaced in mail by product order price';
$_['comment_serial']            = 'will be replaced in mail by serial keys';
$_['comment_link']              = 'will be replaced in mail by download link';

// Error
$_['error_permission']          = 'Warning: You do not have permission to modify serialkeys module!';
$_['error_file']                = 'Error! Invalid file.';