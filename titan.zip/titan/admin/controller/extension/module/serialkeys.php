<?php
class ControllerExtensionModuleSerialkeys extends Controller {
    public function install() {
        $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "product_template` (`id` INT(11) NOT NULL AUTO_INCREMENT, `name` VARCHAR(128) NOT NULL, PRIMARY KEY (`id`));");
        $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "product_template_description` (`id` INT(11) NOT NULL, `language_id` INT(11) NOT NULL, `description` TEXT NOT NULL, PRIMARY KEY(`id`,`language_id`));");
        $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "product_sk` (`product_sk_id` INT(11) NOT NULL AUTO_INCREMENT, `serialkey` VARCHAR(255) NOT NULL, `product_id` INT(11) NOT NULL, `order_id` INT(11) NOT NULL, PRIMARY KEY(`product_sk_id`));");

        $query = $this->db->query("DESCRIBE " . DB_PREFIX . "product");

        $match = 0;
        foreach($query->rows as $row) {
            if($row['Field'] == 'sk_status') {
                $match++;
                break;
            }
        }

        if(!$match) {
            $this->db->query("ALTER TABLE `" . DB_PREFIX . "product` ADD `sk_status` INT(1) NOT NULL");
            $this->db->query("ALTER TABLE `" . DB_PREFIX . "product` ADD `sk_link` INT(1) NOT NULL");
            $this->db->query("ALTER TABLE `" . DB_PREFIX . "product` ADD `sk_template` INT(11) NOT NULL");
        }

        $query = $this->db->query("DESCRIBE " . DB_PREFIX . "product_description");

        $match = 0;
        foreach($query->rows as $row) {
            if($row['Field'] == 'link') {
                $match++;
                break;
            }
        }

        if(!$match) {
            $this->db->query("ALTER TABLE `" . DB_PREFIX . "product_description` ADD `link` VARCHAR(255) NOT NULL");
        }

        $this->load->model('setting/event');

        $this->model_setting_event->deleteEventByCode('sk_product_add');
        $this->model_setting_event->deleteEventByCode('sk_product_edit');
        $this->model_setting_event->deleteEventByCode('sk_order_history');
        $this->model_setting_event->deleteEventByCode('sk_order_history_after');
        $this->model_setting_event->deleteEventByCode('sk_order_delete');

        $this->model_setting_event->addEvent('sk_product_add', 'admin/model/catalog/product/addProduct/after', 'extension/module/serialkeys/editProduct');
        $this->model_setting_event->addEvent('sk_product_edit', 'admin/model/catalog/product/editProduct/after', 'extension/module/serialkeys/editProduct');
        $this->model_setting_event->addEvent('sk_order_history', 'catalog/model/checkout/order/addOrderHistory/before', 'extension/module/serialkeys/addOrderHistory', 1 , -10);
        $this->model_setting_event->addEvent('sk_order_history_after', 'catalog/model/checkout/order/addOrderHistory/after', 'extension/module/serialkeys/addOrderHistoryAfter');
        $this->model_setting_event->addEvent('sk_order_delete', 'catalog/model/checkout/order/deleteOrder/before', 'extension/module/serialkeys/deleteOrder');
    }

    public function index() {
        $this->load->language('extension/module/serialkeys');

        $this->document->setTitle($this->language->get('heading_title_text'));

        $this->load->model('setting/setting');
        $this->load->model('extension/module/serialkeys');

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            $this->model_setting_setting->editSetting('module_serialkeys', $this->request->post);
            $this->model_extension_module_serialkeys->saveProductTemplates($this->request->post);

            $this->session->data['success'] = $this->language->get('text_success');

            $this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true));
        }

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true)
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title_text'),
            'href' => $this->url->link('extension/module/serialkeys', 'user_token=' . $this->session->data['user_token'], true)
        );

        $data['action'] = $this->url->link('extension/module/serialkeys', 'user_token=' . $this->session->data['user_token'], true);

        $data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);

        if (isset($this->request->post['module_serialkeys_stock_notify'])) {
            $data['module_serialkeys_stock_notify'] = $this->request->post['module_serialkeys_stock_notify'];
        } else {
            $data['module_serialkeys_stock_notify'] = $this->config->get('module_serialkeys_stock_notify');
        }

        if (isset($this->request->post['module_serialkeys_enabled'])) {
            $data['module_serialkeys_enabled'] = $this->request->post['module_serialkeys_enabled'];
        } else {
            $data['module_serialkeys_enabled'] = $this->config->get('module_serialkeys_enabled');
        }

        if (isset($this->request->post['module_serialkeys_title'])) {
            $data['module_serialkeys_title'] = $this->request->post['module_serialkeys_title'];
        } else {
            $data['module_serialkeys_title'] = $this->config->get('module_serialkeys_title');
        }

        if (isset($this->request->post['module_serialkeys_subject'])) {
            $data['module_serialkeys_subject'] = $this->request->post['module_serialkeys_subject'];
        } else {
            $data['module_serialkeys_subject'] = $this->config->get('module_serialkeys_subject');
        }

        $data['product_templates'] = $this->model_extension_module_serialkeys->getProductTemplates();

        $this->load->model('localisation/language');
        $data['languages'] = $this->model_localisation_language->getLanguages();

        $data['user_token'] = $this->session->data['user_token'];

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/module/serialkeys', $data));
    }

    protected function validate() {
        if (!$this->user->hasPermission('modify', 'extension/module/serialkeys')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        return !$this->error;
    }

    public function editProduct($route, $args, $output) {
        $product_id = $args[0];
        $data = $args[1];

        $this->load->model('extension/module/serialkeys');
        $this->model_extension_module_serialkeys->editProduct($product_id, $data);
    }

    public function info($order_info) {
        $this->load->language('extension/module/serialkeys');
        $this->load->model('extension/module/serialkeys');

        $data['user_token'] = $this->session->data['user_token'];

        $data['order_id'] = $order_info['order_id'];

        $data['serialkeys'] = $this->model_extension_module_serialkeys->getSerialkeysRaw($order_info['order_id']);

        // API login
        $this->load->model('user/api');

        $api_info = $this->model_user_api->getApi($this->config->get('config_api_id'));

        if ($api_info && $this->user->hasPermission('modify', 'sale/order')) {
            $session = new Session($this->config->get('session_engine'), $this->registry);

            $session->start();

            $this->model_user_api->deleteApiSessionBySessonId($session->getId());

            $this->model_user_api->addApiSession($api_info['api_id'], $session->getId(), $this->request->server['REMOTE_ADDR']);

            $session->data['api_id'] = $api_info['api_id'];

            $data['api_token'] = $session->getId();
        } else {
            $data['api_token'] = '';
        }

        // The URL we send API requests to
        $data['catalog'] = $this->request->server['HTTPS'] ? HTTPS_CATALOG : HTTP_CATALOG;

        return $this->load->view('extension/module/serialkeys_info', $data);
    }

    public function back() {
        $this->load->language('extension/module/serialkeys');
        $this->load->model('extension/module/serialkeys');

        $json['status'] = false;

        if(!empty($this->request->post['order_id'])) {

            $this->db->query("UPDATE " . DB_PREFIX . "product_sk SET order_id='0' WHERE order_id='" . (int)$this->request->post['order_id'] . "'");
            $this->model_extension_module_serialkeys->updateOrderProductStock($this->request->post['order_id']);

            $json['status'] = true;
            $json['success'] = $this->language->get('text_success_back');
            $json['redirect'] = true;
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function export() {
        header('Content-Type: application/csv');
        header('Content-Disposition: attachment; filename="serial_keys.csv";');

        $this->load->language('extension/module/serialkeys');
        $this->load->model('extension/module/serialkeys');

        $data = array();

        $data[] = array(
            $this->language->get('column_key'),
            $this->language->get('column_product_id'),
            $this->language->get('column_order_id'),
        );

        $results = $this->model_extension_module_serialkeys->export($this->request->get);

        foreach ($results as $result) {
            $data[] = array(
                (string)$result['serialkey'],
                $result['product_id'],
                $result['order_id']
            );
        }

        $f = fopen('php://output', 'w');

        foreach ($data as $line) {
            fputcsv($f, $line);
        }

        fpassthru($f);
    }

    public function import() {
        $json = array();

        $this->load->language('extension/module/serialkeys');

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && !$this->validateImport()) {

            $data = array();

            foreach ($this->getCsv() as $line_number => $line) {
                if(!$line_number) {
                    continue;
                }

                $data[] = array(
                    'serialkey' => trim($line[0]),
                    'product_id' => trim($line[1]),
                    'order_id' => trim($line[2])
                );
            }

            $this->load->model('extension/module/serialkeys');
            $this->model_extension_module_serialkeys->import($data);

            $json['success'] = $this->language->get('text_success_import');
        } else {
            $json['error'] = $this->language->get('error_file');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    protected function getCsv() {
        $file = $this->request->files['file']['tmp_name'];

        $handle = fopen ($file,"r");

        while(($line = fgetcsv($handle)) !==false){
            $csv[] = $line;
        }

        return $csv;
    }

    protected function validateImport() {
        $error = false;

        if (empty($this->request->files['file']['name']) && !is_file($this->request->files['file']['tmp_name'])) {
            $error = true;
        }

        if ($this->request->files['file']['type'] != 'text/csv' && $this->request->files['file']['type'] != 'application/vnd.ms-excel') {
            $error = true;
        }

        return $error;
    }
}