<?php

// здесь ищем ключи, даем пользователю и удаляем из базы

class ModelExtensionAccountSerialkeys extends Model {
	public function getSerial($order_serial_id) {
//		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_serialkeys od LEFT JOIN `" . DB_PREFIX . "order` o ON (od.order_id = o.order_id) WHERE o.customer_id = '" . (int)$this->customer->getId(). "' AND o.order_status_id > '0' AND o.order_status_id = '5' AND od.order_serial_id = '" . (int)$order_serial_id . "'");
		$query = $this->db->query("SELECT * FROM "
		. DB_PREFIX . "order_serialkey od
			LEFT JOIN `" . DB_PREFIX . "order` o ON (od.order_id = o.order_id) 
			LEFT JOIN `" . DB_PREFIX . "order_downloadlink` dl ON (dl.order_id = o.order_id) 
		WHERE 
			o.customer_id = '" . (int)$this->customer->getId(). "' AND o.order_status_id > '0' AND o.order_status_id = '5' AND od.order_serial_id = '" . (int)$order_serial_id . "'");
	 /*5 complete status*/
		return $query->row;
	}
	public function getSerialkeys($start = 0, $limit = 20) {
		if ($start < 0) {
			$start = 0;
		}

		$status = $this->config->get('config_complete_status');

		$query = $this->db->query("SELECT o.order_id, o.date_added, od.order_serialkey_id, od.productname, od.serialkey, 
		(SELECT downloadlink FROM `" . DB_PREFIX . "order_downloadlink` WHERE order_product_id = od.order_product_id AND order_id= o.order_id) AS downloadlink FROM "
		. DB_PREFIX . "order_serialkey od
			LEFT JOIN `" . DB_PREFIX . "order` o ON od.order_id = o.order_id 			
		WHERE 
			o.customer_id = '" . (int)$this->customer->getId() . "' AND o.order_status_id IN(" . implode(",", $status) . ") ORDER BY o.date_added DESC LIMIT " . (int)$start . "," . (int)$limit); // 5 complete status*/

		return $query->rows;
	}

	public function updateRemaining($order_download_id) {
		$this->db->query("UPDATE " . DB_PREFIX . "order_serialkey SET remaining = (remaining - 1) WHERE order_download_id = '" . (int)$order_download_id . "'");
	}

	public function getTotalSerialkeys() {
		$sql="SELECT COUNT(*) AS total FROM " . DB_PREFIX . "order_serialkey od LEFT JOIN `" . DB_PREFIX . "order` o ON (od.order_id = o.order_id) WHERE o.customer_id = '" . (int)$this->customer->getId() . "' AND o.order_status_id > '0' AND o.order_status_id = '5'";//быдлокод вместо пяти статус complete
		$query = $this->db->query($sql);

		return $query->row['total'];
	}
	public function getSerialkeys2($order_id) {


		$query = $this->db->query("SELECT o.order_id, o.date_added, od.order_serialkey_id, od.productname, od.serialkey FROM " . DB_PREFIX . "order_serialkey od LEFT JOIN `" . DB_PREFIX . "order` o ON od.order_id = o.order_id WHERE o.order_id = '" . (int)$order_id . "'  ORDER BY od.order_serialkey_id ");

		return $query->rows;
	}

}
?>