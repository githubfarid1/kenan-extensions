<?php
class ControllerExtensionDSEOModuleMetaDSEOModuleMeta extends Controller {
	private $codename = 'd_seo_module_meta';
	private $route = 'extension/d_seo_module_meta/d_seo_module_meta';
	private $config_file = 'd_seo_module_meta';
	private $error = array(); 
		
	/*
	*	Functions for SEO Module Meta.
	*/
	
	
	
}