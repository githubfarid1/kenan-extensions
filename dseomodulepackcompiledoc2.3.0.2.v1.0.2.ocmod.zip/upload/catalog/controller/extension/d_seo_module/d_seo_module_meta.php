<?php
class ControllerExtensionDSEOModuleDSEOModuleMeta extends Controller {
	private $codename = 'd_seo_module_meta';
	private $route = 'extension/d_seo_module/d_seo_module_meta';
	private $config_file = 'd_seo_module_meta';
	
	/*
	*	Functions for SEO Module.
	*/	
	public function home_before($data) {
		$store_id = (int)$this->config->get('config_store_id');
		$language_id = (int)$this->config->get('config_language_id');
				
		$status = ($this->config->get('module_' . $this->codename . '_status')) ? $this->config->get('module_' . $this->codename . '_status') : false;
			
		if ($status) {
			$route = 'common/home';
			
			$field_data = array(
				'field_code' => 'meta_data',
				'filter' => array(
					'route' => $route,
					'store_id' => $store_id,
					'language_id' => $language_id
				)
			);
			
			$meta_data = $this->load->controller('extension/module/d_seo_module/getFieldElements', $field_data);
			
			if ($meta_data) {
				$meta_info = $meta_data[$route][$store_id][$language_id];
			
				if (isset($meta_info['meta_title']) && $meta_info['meta_title']) {
					$this->document->setTitle($meta_info['meta_title']);
				}
			
				if (isset($meta_info['meta_description']) && $meta_info['meta_description']) {
					$this->document->setDescription($meta_info['meta_description']);
				}
			
				if (isset($meta_info['meta_keyword']) && $meta_info['meta_keyword']) {
					$this->document->setKeywords($meta_info['meta_keyword']);
				}
				
				$data['header'] = $this->load->controller('common/header');
			}
		}
		
		return $data;
	}
	
	public function home_after($html) {
		$store_id = (int)$this->config->get('config_store_id');
		$language_id = (int)$this->config->get('config_language_id');
		
		$status = ($this->config->get($this->codename . '_status')) ? $this->config->get($this->codename . '_status') : false;
						
		if ($status && file_exists(DIR_SYSTEM . 'library/d_simple_html_dom.php')) {
			$route = 'common/home';
			
			$field_data = array(
				'field_code' => 'meta_data',
				'filter' => array(
					'route' => $route,
					'store_id' => $store_id,
					'language_id' => $language_id
				)
			);
			
			$meta_data = $this->load->controller('extension/module/d_seo_module/getFieldElements', $field_data);

			if ($meta_data) {
				$meta_info = $meta_data[$route][$store_id][$language_id];
							
				if (isset($meta_info['meta_robots']) && $meta_info['meta_robots']) {
					$meta_robots = $meta_info['meta_robots'];
				} else {
					$meta_robots = 'index,follow';
				}
						
				$html_dom = new d_simple_html_dom();
				$html_dom->load((string)$html, $lowercase = true, $stripRN = false, $defaultBRText = DEFAULT_BR_TEXT);
							
				foreach ($html_dom->find('head') as $element) {
					$element->innertext .= '<meta name="robots" content="' . $meta_robots . '" />' . "\n";
				}
						
				return (string)$html_dom;
			}
		}
		
		return $html;
	}
		
	public function category_after($html) {		
		$store_id = (int)$this->config->get('config_store_id');
		$language_id = (int)$this->config->get('config_language_id');
		
		// Setting
		$_config = new Config();
		$_config->load($this->config_file);
		$config_setting = ($_config->get($this->codename . '_setting')) ? $_config->get($this->codename . '_setting') : array();
		
		$status = ($this->config->get('module_' . $this->codename . '_status')) ? $this->config->get('module_' . $this->codename . '_status') : false;
		$setting = ($this->config->get('module_' . $this->codename . '_setting')) ? $this->config->get('module_' . $this->codename . '_setting') : array();
		
		if (!empty($setting)) {
			$config_setting = array_replace_recursive($config_setting, $setting);
		}
		
		$setting = $config_setting;
		
		if ($status && file_exists(DIR_SYSTEM . 'library/d_simple_html_dom.php')) {
			if (isset($this->request->get['path'])) {
				$parts = explode('_', (string)$this->request->get['path']);
				$category_id = (int)array_pop($parts);
			} else {
				$category_id = 0;
			}
						
			$route = 'category_id=' . (int)$category_id;
			
			$field_data = array(
				'field_code' => 'meta_data',
				'filter' => array(
					'route' => $route,
					'store_id' => $store_id,
					'language_id' => $language_id
				)
			);
			
			$meta_data = $this->load->controller('extension/module/d_seo_module/getFieldElements', $field_data);
			
			if ($meta_data) {
				$meta_info = $meta_data[$route][$store_id][$language_id];
						
				$html_dom = new d_simple_html_dom();
				$html_dom->load((string)$html, $lowercase = true, $stripRN = false, $defaultBRText = DEFAULT_BR_TEXT);
				
				if ($setting['sheet']['category']['meta_title_page'] && isset($this->request->get['page']) && ($this->request->get['page'] > 1)) {
					$meta_title_page = '';
					
					if (isset($setting['meta_title_page_template'][$language_id])) {
						$meta_title_page = str_replace('[page_number]', $this->request->get['page'], $setting['meta_title_page_template'][$language_id]);
					} elseif ($setting['meta_title_page_template_default']) {
						$meta_title_page = str_replace('[page_number]', $this->request->get['page'], $setting['meta_title_page_template_default']);
					}

					if ($meta_title_page) {
						if ($html_dom->find('title')) {
							foreach ($html_dom->find('title') as $element) {
								$element->innertext = $meta_title_page . ' ' . $meta_info['meta_title'];
							}
						} else {
							foreach ($html_dom->find('head') as $element) {
								$element->innertext .= '<title>' . $meta_title_page . ' ' . $meta_info['meta_title'] . '</title>' . "\n";
							}
						}
					}
				}
														
				if ($setting['sheet']['category']['meta_description_page'] && isset($this->request->get['page']) && ($this->request->get['page'] > 1)) {
					$meta_description_page = '';
					
					if (isset($setting['meta_description_page_template'][$language_id])) {
						$meta_description_page = str_replace('[page_number]', $this->request->get['page'], $setting['meta_description_page_template'][$language_id]);
					} elseif ($setting['meta_title_page_template_default']) {
						$meta_description_page = str_replace('[page_number]', $this->request->get['page'], $setting['meta_description_page_template_default']);
					}
					
					if ($meta_description_page) {
						if ($html_dom->find('meta[name="description"]')) {
							foreach ($html_dom->find('meta[name="description"]') as $element) {
								$element->setAttribute('content', $meta_description_page . ' ' . $meta_info['meta_description']);
							}
						} else {
							foreach ($html_dom->find('head') as $element) {
								$element->innertext .= '<meta name="description" content="' . $meta_description_page . ' ' . $meta_info['meta_description'] . '" />' . "\n";
							}
						}
					}
				}
								
				if (isset($meta_info['meta_robots']) && $meta_info['meta_robots']) {
					foreach ($html_dom->find('head') as $element) {
						$element->innertext .= '<meta name="robots" content="' . $meta_info['meta_robots'] . '" />' . "\n";
					}
				}
			
				if (isset($meta_info['custom_title_1']) && $meta_info['custom_title_1']) {
					foreach ($html_dom->find($setting['sheet']['category']['custom_title_1_class']) as $element) {
						$element->innertext = $meta_info['custom_title_1'];
					}
				}
			
				if (isset($meta_info['custom_title_2']) && $meta_info['custom_title_2']) {
					foreach ($html_dom->find($setting['sheet']['category']['custom_title_2_class']) as $element) {
						$element->innertext = $meta_info['custom_title_2'];
					}
				}
			
				if ((isset($meta_info['custom_image_title']) && $meta_info['custom_image_title']) || (isset($meta_info['custom_image_alt']) && $meta_info['custom_image_alt'])) {
					foreach ($html_dom->find($setting['sheet']['category']['custom_image_class']) as $element) {
						if (isset($meta_info['custom_image_title']) && $meta_info['custom_image_title']) {
							$element->setAttribute('title', $meta_info['custom_image_title']);
						}
					
						if (isset($meta_info['custom_image_alt']) && $meta_info['custom_image_alt']) {
							$element->setAttribute('alt', $meta_info['custom_image_alt']);
						}
					}
				}
			
				return (string)$html_dom;
			}
		}
		
		return $html;
	}
	
	public function category_get_category($data) {
		$store_id = (int)$this->config->get('config_store_id');
		$language_id = (int)$this->config->get('config_language_id');
		
		$status = ($this->config->get('module_' . $this->codename . '_status')) ? $this->config->get('module_' . $this->codename . '_status') : false;
		
		if ($status && $data && $store_id) {		
			$route = 'category_id=' . (int)$data['category_id'];
			
			$field_data = array(
				'field_code' => 'meta_data',
				'filter' => array(
					'route' => $route,
					'store_id' => $store_id,
					'language_id' => $language_id
				)
			);
			
			$meta_data = $this->load->controller('extension/module/d_seo_module/getFieldElements', $field_data);
			
			if ($meta_data) {
				$meta_info = $meta_data[$route][$store_id][$language_id];
			
				if ($meta_info['name']) {
					$data['name'] = $meta_info['name'];
				}
			
				if ($meta_info['description']) {
					$data['description'] = $meta_info['description'];
				}
			
				if ($meta_info['meta_title']) {
					$data['meta_title'] = $meta_info['meta_title'];
				}
			
				if ($meta_info['meta_description']) {
					$data['meta_description'] = $meta_info['meta_description'];
				}
			
				if ($meta_info['meta_keyword']) {
					$data['meta_keyword'] = $meta_info['meta_keyword'];
				}
			}
		}
		
		return $data;
	}
	
	public function category_get_categories($data) {
		$store_id = (int)$this->config->get('config_store_id');
		$language_id = (int)$this->config->get('config_language_id');
		
		$status = ($this->config->get('module_' . $this->codename . '_status')) ? $this->config->get('module_' . $this->codename . '_status') : false;
		
		if ($status && $data && $store_id) {
			$field_data = array(
				'field_code' => 'meta_data',
				'filter' => array(
					'route' => 'category_id=%',
					'store_id' => $store_id,
					'language_id' => $language_id
				)
			);
			
			$meta_data = $this->load->controller('extension/module/d_seo_module/getFieldElements', $field_data);
			
			foreach ($data as $key => $category) {
				$route = 'category_id=' . (int)$category['category_id'];
							
				if (isset($meta_data[$route][$store_id][$language_id])) {
					$meta_info = $meta_data[$route][$store_id][$language_id];
			
					if ($meta_info['name']) {
						$data[$key]['name'] = $meta_info['name'];
					}
			
					if ($meta_info['description']) {
						$data[$key]['description'] = $meta_info['description'];
					}
			
					if ($meta_info['meta_title']) {
						$data[$key]['meta_title'] = $meta_info['meta_title'];
					}
			
					if ($meta_info['meta_description']) {
						$data[$key]['meta_description'] = $meta_info['meta_description'];
					}
			
					if ($meta_info['meta_keyword']) {
						$data[$key]['meta_keyword'] = $meta_info['meta_keyword'];
					}
				}
			}
		}
		
		return $data;
	}
		
	public function product_after($html) {
		$store_id = (int)$this->config->get('config_store_id');
		$language_id = (int)$this->config->get('config_language_id');
		
		// Setting
		$_config = new Config();
		$_config->load($this->config_file);
		$config_setting = ($_config->get($this->codename . '_setting')) ? $_config->get($this->codename . '_setting') : array();
		
		$status = ($this->config->get('module_' . $this->codename . '_status')) ? $this->config->get('module_' . $this->codename . '_status') : false;
		$setting = ($this->config->get('module_' . $this->codename . '_setting')) ? $this->config->get('module_' . $this->codename . '_setting') : array();
		
		if (!empty($setting)) {
			$config_setting = array_replace_recursive($config_setting, $setting);
		}
		
		$setting = $config_setting;
		
		if ($status && file_exists(DIR_SYSTEM . 'library/d_simple_html_dom.php')) {
			if (isset($this->request->get['product_id'])) {
				$product_id = (int)$this->request->get['product_id'];
			} else {
				$product_id = 0;
			}
		
			$route = 'product_id=' . (int)$product_id;
			
			$field_data = array(
				'field_code' => 'meta_data',
				'filter' => array(
					'route' => $route,
					'store_id' => $store_id,
					'language_id' => $language_id
				)
			);
			
			$meta_data = $this->load->controller('extension/module/d_seo_module/getFieldElements', $field_data);
			
			if ($meta_data) {
				$meta_info = $meta_data[$route][$store_id][$language_id];
		
				$html_dom = new d_simple_html_dom();
				$html_dom->load((string)$html, $lowercase = true, $stripRN = false, $defaultBRText = DEFAULT_BR_TEXT);
			
				if (isset($meta_info['meta_robots']) && $meta_info['meta_robots']) {
					foreach ($html_dom->find('head') as $element) {
						$element->innertext .= '<meta name="robots" content="' . $meta_info['meta_robots'] . '" />' . "\n";
					}
				}
			
				if (isset($meta_info['custom_title_1']) && $meta_info['custom_title_1']) {
					foreach ($html_dom->find($setting['sheet']['product']['custom_title_1_class']) as $element) {
						$element->innertext = $meta_info['custom_title_1'];
					}
				}
			
				if (isset($meta_info['custom_title_2']) && $meta_info['custom_title_2']) {
					foreach ($html_dom->find($setting['sheet']['product']['custom_title_2_class']) as $element) {
						$element->innertext = $meta_info['custom_title_2'];
					}
				}
			
				if ((isset($meta_info['custom_image_title']) && $meta_info['custom_image_title']) || (isset($meta_info['custom_image_alt']) && $meta_info['custom_image_alt'])) {
					foreach ($html_dom->find($setting['sheet']['product']['custom_image_class']) as $element) {
						if (isset($meta_info['custom_image_title']) && $meta_info['custom_image_title']) {
							$element->setAttribute('title', $meta_info['custom_image_title']);
						}
					
						if (isset($meta_info['custom_image_alt']) && $meta_info['custom_image_alt']) {
							$element->setAttribute('alt', $meta_info['custom_image_alt']);
						}
					}
				}
	
				return (string)$html_dom;
			}
		}
		
		return $html;
	}
	
	public function product_get_product($data) {
		$store_id = (int)$this->config->get('config_store_id');
		$language_id = (int)$this->config->get('config_language_id');
		
		$status = ($this->config->get('module_' . $this->codename . '_status')) ? $this->config->get('module_' . $this->codename . '_status') : false;
				
		if ($status && $data && $store_id) {			
			$route = 'product_id=' . (int)$data['product_id'];
			
			$field_data = array(
				'field_code' => 'meta_data',
				'filter' => array(
					'route' => $route,
					'store_id' => $store_id,
					'language_id' => $language_id
				)
			);
			
			$meta_data = $this->load->controller('extension/module/d_seo_module/getFieldElements', $field_data);
			
			if ($meta_data) {
				$meta_info = $meta_data[$route][$store_id][$language_id];
			
				if ($meta_info['name']) {
					$data['name'] = $meta_info['name'];
				}
			
				if ($meta_info['description']) {
					$data['description'] = $meta_info['description'];
				}
			
				if ($meta_info['meta_title']) {
					$data['meta_title'] = $meta_info['meta_title'];
				}
			
				if ($meta_info['meta_description']) {
					$data['meta_description'] = $meta_info['meta_description'];
				}
			
				if ($meta_info['meta_keyword']) {
					$data['meta_keyword'] = $meta_info['meta_keyword'];
				}
				
				if ($meta_info['tag']) {
					$data['tag'] = $meta_info['tag'];
				}
			}
		}
		
		return $data;
	}
			
	public function manufacturer_info_before($data) {
		$store_id = (int)$this->config->get('config_store_id');
		$language_id = (int)$this->config->get('config_language_id');
		
		$status = ($this->config->get('module_' . $this->codename . '_status')) ? $this->config->get('module_' . $this->codename . '_status') : false;
				
		if ($status) {
			if (isset($this->request->get['manufacturer_id'])) {
				$manufacturer_id = (int)$this->request->get['manufacturer_id'];
			} else {
				$manufacturer_id = 0;
			}
			
			$route = 'manufacturer_id=' . (int)$manufacturer_id;
			
			$field_data = array(
				'field_code' => 'meta_data',
				'filter' => array(
					'route' => $route,
					'store_id' => $store_id,
					'language_id' => $language_id
				)
			);
			
			$meta_data = $this->load->controller('extension/module/d_seo_module/getFieldElements', $field_data);
			
			if ($meta_data) {
				$meta_info = $meta_data[$route][$store_id][$language_id];
			
				if (isset($meta_info['name']) && $meta_info['name']) {
					$data['heading_title'] = $meta_info['name'];
					$this->document->setTitle($meta_info['name']);
				}
			
				if (isset($meta_info['meta_title']) && $meta_info['meta_title']) {
					$this->document->setTitle($meta_info['meta_title']);
				}
			
				if (isset($meta_info['meta_description']) && $meta_info['meta_description']) {
					$this->document->setDescription($meta_info['meta_description']);
				}
			
				if (isset($meta_info['meta_keyword']) && $meta_info['meta_keyword']) {
					$this->document->setKeywords($meta_info['meta_keyword']);
				}
						
				$data['header'] = $this->load->controller('common/header');
			}
		}
		
		return $data;
	}
	
	public function manufacturer_info_after($html) {		
		$store_id = (int)$this->config->get('config_store_id');
		$language_id = (int)$this->config->get('config_language_id');
		
		// Setting
		$_config = new Config();
		$_config->load($this->config_file);
		$config_setting = ($_config->get($this->codename . '_setting')) ? $_config->get($this->codename . '_setting') : array();
		
		$status = ($this->config->get('module_' . $this->codename . '_status')) ? $this->config->get('module_' . $this->codename . '_status') : false;
		$setting = ($this->config->get('module_' . $this->codename . '_setting')) ? $this->config->get('module_' . $this->codename . '_setting') : array();
		
		if (!empty($setting)) {
			$config_setting = array_replace_recursive($config_setting, $setting);
		}
		
		$setting = $config_setting;
		
		if ($status && file_exists(DIR_SYSTEM . 'library/d_simple_html_dom.php')) {
			if (isset($this->request->get['manufacturer_id'])) {
				$manufacturer_id = (int)$this->request->get['manufacturer_id'];
			} else {
				$manufacturer_id = 0;
			}
			
			$route = 'manufacturer_id=' . (int)$manufacturer_id;
			
			$field_data = array(
				'field_code' => 'meta_data',
				'filter' => array(
					'route' => $route,
					'store_id' => $store_id,
					'language_id' => $language_id
				)
			);
			
			$meta_data = $this->load->controller('extension/module/d_seo_module/getFieldElements', $field_data);
			
			if ($meta_data) {
				$meta_info = $meta_data[$route][$store_id][$language_id];
			
				$html_dom = new d_simple_html_dom();
				$html_dom->load((string)$html, $lowercase = true, $stripRN = false, $defaultBRText = DEFAULT_BR_TEXT);
						
				if ($setting['sheet']['manufacturer']['meta_title_page'] && isset($this->request->get['page']) && ($this->request->get['page'] > 1)) {
					$meta_title_page = '';
					
					if (isset($setting['meta_title_page_template'][$language_id])) {
						$meta_title_page = str_replace('[page_number]', $this->request->get['page'], $setting['meta_title_page_template'][$language_id]);
					} elseif ($setting['meta_title_page_template_default']) {
						$meta_title_page = str_replace('[page_number]', $this->request->get['page'], $setting['meta_title_page_template_default']);
					}

					if ($meta_title_page) {
						if ($html_dom->find('title')) {
							foreach ($html_dom->find('title') as $element) {
								$element->innertext = $meta_title_page . ' ' . $meta_info['meta_title'];
							}
						} else {
							foreach ($html_dom->find('head') as $element) {
								$element->innertext .= '<title>' . $meta_title_page . ' ' . $meta_info['meta_title'] . '</title>' . "\n";
							}
						}
					}
				}
														
				if ($setting['sheet']['manufacturer']['meta_description_page'] && isset($this->request->get['page']) && ($this->request->get['page'] > 1)) {
					$meta_description_page = '';
					
					if (isset($setting['meta_description_page_template'][$language_id])) {
						$meta_description_page = str_replace('[page_number]', $this->request->get['page'], $setting['meta_description_page_template'][$language_id]);
					} elseif ($setting['meta_title_page_template_default']) {
						$meta_description_page = str_replace('[page_number]', $this->request->get['page'], $setting['meta_description_page_template_default']);
					}
					
					if ($meta_description_page) {
						if ($html_dom->find('meta[name="description"]')) {
							foreach ($html_dom->find('meta[name="description"]') as $element) {
								$element->setAttribute('content', $meta_description_page . ' ' . $meta_info['meta_description']);
							}
						} else {
							foreach ($html_dom->find('head') as $element) {
								$element->innertext .= '<meta name="description" content="' . $meta_description_page . ' ' . $meta_info['meta_description'] . '" />' . "\n";
							}
						}
					}
				}
				
				if (isset($meta_info['meta_robots']) && $meta_info['meta_robots']) {
					foreach ($html_dom->find('head') as $element) {
						$element->innertext .= '<meta name="robots" content="' . $meta_info['meta_robots'] . '" />' . "\n";
					}
				}
			
				if (isset($meta_info['custom_title_1']) && $meta_info['custom_title_1']) {
					foreach ($html_dom->find($setting['sheet']['manufacturer']['custom_title_1_class']) as $element) {
						$element->innertext = $meta_info['custom_title_1'];
					}
				}
			
				if (isset($meta_info['custom_title_2']) && $meta_info['custom_title_2']) {
					foreach ($html_dom->find($setting['sheet']['manufacturer']['custom_title_2_class']) as $element) {
						$element->innertext = $meta_info['custom_title_2'];
					}
				}
			
				if ((isset($meta_info['custom_image_title']) && $meta_info['custom_image_title']) || (isset($meta_info['custom_image_alt']) && $meta_info['custom_image_alt'])) {
					foreach ($html_dom->find($setting['sheet']['manufacturer']['custom_image_class']) as $element) {
						if (isset($meta_info['custom_image_title']) && $meta_info['custom_image_title']) {
							$element->setAttribute('title', $meta_info['custom_image_title']);
						}
						
						if (isset($meta_info['custom_image_alt']) && $meta_info['custom_image_alt']) {
							$element->setAttribute('alt', $meta_info['custom_image_alt']);
						}
					}
				}
			
				if (isset($meta_info['description']) && $meta_info['description']) {
					foreach ($html_dom->find($setting['sheet']['manufacturer']['before_description_class']) as $element) {
						$element->outertext .= html_entity_decode($meta_info['description'], ENT_QUOTES, 'UTF-8');
					}
				}
			
				return (string)$html_dom;
			}
		}
		
		return $html;
	}
	
	public function manufacturer_get_manufacturer($data) {		
		$store_id = (int)$this->config->get('config_store_id');
		$language_id = (int)$this->config->get('config_language_id');
		
		$status = ($this->config->get('module_' . $this->codename . '_status')) ? $this->config->get('module_' . $this->codename . '_status') : false;
				
		if ($status && $data) {			
			$route = 'manufacturer_id=' . (int)$data['manufacturer_id'];
			
			$field_data = array(
				'field_code' => 'meta_data',
				'filter' => array(
					'route' => $route,
					'store_id' => $store_id,
					'language_id' => $language_id
				)
			);
			
			$meta_data = $this->load->controller('extension/module/d_seo_module/getFieldElements', $field_data);
			
			if ($meta_data) {
				$meta_info = $meta_data[$route][$store_id][$language_id];
			
				if (isset($meta_info['name']) && $meta_info['name']) {
					$data['name'] = $meta_info['name'];
				}
			
				if (isset($meta_info['description']) && $meta_info['description']) {
					$data['description'] = $meta_info['description'];
				}
			
				if (isset($meta_info['meta_title']) && $meta_info['meta_title']) {
					$data['meta_title'] = $meta_info['meta_title'];
				}
			
				if (isset($meta_info['meta_description']) && $meta_info['meta_description']) {
					$data['meta_description'] = $meta_info['meta_description'];
				}
			
				if (isset($meta_info['meta_keyword']) && $meta_info['meta_keyword']) {
					$data['meta_keyword'] = $meta_info['meta_keyword'];
				}
			}
		}
		
		return $data;
	}
	
	public function manufacturer_get_manufacturers($data) {
		$store_id = (int)$this->config->get('config_store_id');
		$language_id = (int)$this->config->get('config_language_id');
		
		$status = ($this->config->get('module_' . $this->codename . '_status')) ? $this->config->get('module_' . $this->codename . '_status') : false;
				
		if ($status && $data) {	
			$field_data = array(
				'field_code' => 'meta_data',
				'filter' => array(
					'route' => 'manufacturer_id=%',
					'store_id' => $store_id,
					'language_id' => $language_id
				)
			);
			
			$meta_data = $this->load->controller('extension/module/d_seo_module/getFieldElements', $field_data);
			
			foreach ($data as $key => $information) {
				$route = 'manufacturer_id=' . (int)$information['manufacturer_id'];

				if (isset($meta_data[$route][$store_id][$language_id])) {
					$meta_info = $meta_data[$route][$store_id][$language_id];
			
					if (isset($meta_info['name']) && $meta_info['name']) {
						$data[$key]['name'] = $meta_info['name'];
					}
			
					if (isset($meta_info['description']) && $meta_info['description']) {
						$data[$key]['description'] = $meta_info['description'];
					}
			
					if (isset($meta_info['meta_title']) && $meta_info['meta_title']) {
						$data[$key]['meta_title'] = $meta_info['meta_title'];
					}
			
					if (isset($meta_info['meta_description']) && $meta_info['meta_description']) {
						$data[$key]['meta_description'] = $meta_info['meta_description'];
					}
			
					if (isset($meta_info['meta_keyword']) && $meta_info['meta_keyword']) {
						$data[$key]['meta_keyword'] = $meta_info['meta_keyword'];
					}
				}
			}
		}
		
		return $data;
	}
		
	public function information_after($html) {
		$store_id = (int)$this->config->get('config_store_id');
		$language_id = (int)$this->config->get('config_language_id');
		
		// Setting
		$_config = new Config();
		$_config->load($this->config_file);
		$config_setting = ($_config->get($this->codename . '_setting')) ? $_config->get($this->codename . '_setting') : array();
		
		$status = ($this->config->get('module_' . $this->codename . '_status')) ? $this->config->get('module_' . $this->codename . '_status') : false;
		$setting = ($this->config->get('module_' . $this->codename . '_setting')) ? $this->config->get('module_' . $this->codename . '_setting') : array();
		
		if (!empty($setting)) {
			$config_setting = array_replace_recursive($config_setting, $setting);
		}
		
		$setting = $config_setting;
		
		if ($status && file_exists(DIR_SYSTEM . 'library/d_simple_html_dom.php')) {
			if (isset($this->request->get['information_id'])) {
				$information_id = (int)$this->request->get['information_id'];
			} else {
				$information_id = 0;
			}
		
			$route = 'information_id=' . (int)$information_id;
			
			$field_data = array(
				'field_code' => 'meta_data',
				'filter' => array(
					'route' => $route,
					'store_id' => $store_id,
					'language_id' => $language_id
				)
			);
			
			$meta_data = $this->load->controller('extension/module/d_seo_module/getFieldElements', $field_data);
			
			if ($meta_data) {
				$meta_info = $meta_data[$route][$store_id][$language_id];
			
				$html_dom = new d_simple_html_dom();
				$html_dom->load((string)$html, $lowercase = true, $stripRN = false, $defaultBRText = DEFAULT_BR_TEXT);
			
				if (isset($meta_info['meta_robots']) && $meta_info['meta_robots']) {
					foreach ($html_dom->find('head') as $element) {
						$element->innertext .= '<meta name="robots" content="' . $meta_info['meta_robots'] . '" />' . "\n";
					}
				}
			
				if (isset($meta_info['custom_title_1']) && $meta_info['custom_title_1']) {
					foreach ($html_dom->find($setting['sheet']['information']['custom_title_1_class']) as $element) {
						$element->innertext = $meta_info['custom_title_1'];
					}
				}
			
				if (isset($meta_info['custom_title_2']) && $meta_info['custom_title_2']) {
					foreach ($html_dom->find($setting['sheet']['information']['custom_title_2_class']) as $element) {
						$element->innertext = $meta_info['custom_title_2'];
					}
				}
			
				return (string)$html_dom;
			}
		}
		
		return $html;
	}
	
	public function information_get_information($data) {
		$store_id = (int)$this->config->get('config_store_id');
		$language_id = (int)$this->config->get('config_language_id');
		
		$status = ($this->config->get('module_' . $this->codename . '_status')) ? $this->config->get('module_' . $this->codename . '_status') : false;
				
		if ($status && $data && $store_id) {			
			$route = 'information_id=' . (int)$data['information_id'];
			
			$field_data = array(
				'field_code' => 'meta_data',
				'filter' => array(
					'route' => $route,
					'store_id' => $store_id,
					'language_id' => $language_id
				)
			);
			
			$meta_data = $this->load->controller('extension/module/d_seo_module/getFieldElements', $field_data);
			
			if ($meta_data) {
				$meta_info = $meta_data[$route][$store_id][$language_id];
			
				if ($meta_info['title']) {
					$data['title'] = $meta_info['title'];
				}
			
				if ($meta_info['description']) {
					$data['description'] = $meta_info['description'];
				}
			
				if ($meta_info['meta_title']) {
					$data['meta_title'] = $meta_info['meta_title'];
				}
			
				if ($meta_info['meta_description']) {
					$data['meta_description'] = $meta_info['meta_description'];
				}
			
				if ($meta_info['meta_keyword']) {
					$data['meta_keyword'] = $meta_info['meta_keyword'];
				}
			}
		}
		
		return $data;
	}
	
	public function information_get_informations($data) {
		$store_id = (int)$this->config->get('config_store_id');
		$language_id = (int)$this->config->get('config_language_id');
		
		$status = ($this->config->get('module_' . $this->codename . '_status')) ? $this->config->get('module_' . $this->codename . '_status') : false;
				
		if ($status && $data && $store_id) {			
			$field_data = array(
				'field_code' => 'meta_data',
				'filter' => array(
					'route' => 'information_id=%',
					'store_id' => $store_id,
					'language_id' => $language_id
				)
			);
			
			$meta_data = $this->load->controller('extension/module/d_seo_module/getFieldElements', $field_data);
				
			foreach ($data as $key => $information) {
				$route = 'information_id=' . (int)$information['information_id'];
	
				if (isset($meta_data[$route][$store_id][$language_id])) {
					$meta_info = $meta_data[$route][$store_id][$language_id];
			
					if ($meta_info['title']) {
						$data[$key]['title'] = $meta_info['title'];
					}
			
					if ($meta_info['description']) {
						$data[$key]['description'] = $meta_info['description'];
					}
			
					if ($meta_info['meta_title']) {
						$data[$key]['meta_title'] = $meta_info['meta_title'];
					}
			
					if ($meta_info['meta_description']) {
						$data[$key]['meta_description'] = $meta_info['meta_description'];
					}
			
					if ($meta_info['meta_keyword']) {
						$data[$key]['meta_keyword'] = $meta_info['meta_keyword'];
					}
				}
			}
		}
		
		return $data;
	}
	
	public function search_after($html) {
		$store_id = (int)$this->config->get('config_store_id');
		$language_id = (int)$this->config->get('config_language_id');
		
		// Setting
		$_config = new Config();
		$_config->load($this->config_file);
		$config_setting = ($_config->get($this->codename . '_setting')) ? $_config->get($this->codename . '_setting') : array();
		
		$status = ($this->config->get('module_' . $this->codename . '_status')) ? $this->config->get('module_' . $this->codename . '_status') : false;
		$setting = ($this->config->get('module_' . $this->codename . '_setting')) ? $this->config->get('module_' . $this->codename . '_setting') : array();
		
		if (!empty($setting)) {
			$config_setting = array_replace_recursive($config_setting, $setting);
		}
		
		$setting = $config_setting;
		
		if ($status && file_exists(DIR_SYSTEM . 'library/d_simple_html_dom.php')) {			
			if ($setting['sheet']['search']['meta_title_page'] && isset($this->request->get['page']) && ($this->request->get['page'] > 1)) {
				$html_dom = new d_simple_html_dom();
				$html_dom->load((string)$html, $lowercase = true, $stripRN = false, $defaultBRText = DEFAULT_BR_TEXT);
			
				$meta_title_page = '';
				
				if (isset($setting['meta_title_page_template'][$language_id])) {
					$meta_title_page = str_replace('[page_number]', $this->request->get['page'], $setting['meta_title_page_template'][$language_id]);
				} elseif ($setting['meta_title_page_template_default']) {
					$meta_title_page = str_replace('[page_number]', $this->request->get['page'], $setting['meta_title_page_template_default']);
				}

				if ($meta_title_page) {
					if ($html_dom->find('title')) {
						foreach ($html_dom->find('title') as $element) {
							$element->innertext = $meta_title_page . ' ' . $element->innertext;
						}
					}
				}
				
				return (string)$html_dom;
			}
		}
		
		return $html;
	}
	
	public function special_after($html) {
		$store_id = (int)$this->config->get('config_store_id');
		$language_id = (int)$this->config->get('config_language_id');
		
		// Setting
		$_config = new Config();
		$_config->load($this->config_file);
		$config_setting = ($_config->get($this->codename . '_setting')) ? $_config->get($this->codename . '_setting') : array();
		
		$status = ($this->config->get('module_' . $this->codename . '_status')) ? $this->config->get('module_' . $this->codename . '_status') : false;
		$setting = ($this->config->get('module_' . $this->codename . '_setting')) ? $this->config->get('module_' . $this->codename . '_setting') : array();
		
		if (!empty($setting)) {
			$config_setting = array_replace_recursive($config_setting, $setting);
		}
		
		$setting = $config_setting;
		
		if ($status && file_exists(DIR_SYSTEM . 'library/d_simple_html_dom.php')) {			
			if ($setting['sheet']['special']['meta_title_page'] && isset($this->request->get['page']) && ($this->request->get['page'] > 1)) {
				$html_dom = new d_simple_html_dom();
				$html_dom->load((string)$html, $lowercase = true, $stripRN = false, $defaultBRText = DEFAULT_BR_TEXT);
			
				$meta_title_page = '';
				
				if (isset($setting['meta_title_page_template'][$language_id])) {
					$meta_title_page = str_replace('[page_number]', $this->request->get['page'], $setting['meta_title_page_template'][$language_id]);
				} elseif ($setting['meta_title_page_template_default']) {
					$meta_title_page = str_replace('[page_number]', $this->request->get['page'], $setting['meta_title_page_template_default']);
				}

				if ($meta_title_page) {
					if ($html_dom->find('title')) {
						foreach ($html_dom->find('title') as $element) {
							$element->innertext = $meta_title_page . ' ' . $element->innertext;
						}
					}
				}
				
				return (string)$html_dom;
			}
		}
		
		return $html;
	}
	
	public function field_config() {
		$_language = new Language();
		$_language->load($this->route);
		
		$_config = new Config();
		$_config->load($this->config_file);
		$field_setting = ($_config->get($this->codename . '_field_setting')) ? $_config->get($this->codename . '_field_setting') : array();

		foreach ($field_setting['sheet'] as $sheet) {			
			foreach ($sheet['field'] as $field) {
				if (substr($field['name'], 0, strlen('text_')) == 'text_') {
					$field_setting['sheet'][$sheet['code']]['field'][$field['code']]['name'] = $_language->get($field['name']);
				}
				
				if (substr($field['description'], 0, strlen('help_')) == 'help_') {
					$field_setting['sheet'][$sheet['code']]['field'][$field['code']]['description'] = $_language->get($field['description']);
				}
			}
		}
					
		return $field_setting;
	}
	
	public function field_elements($filter_data) {
		$this->load->model($this->route);
		
		return $this->{'model_extension_d_seo_module_' . $this->codename}->getFieldElements($filter_data);
	}
}