<?php
class ControllerExtensionModuleDSEOModuleAdviser extends Controller {
	private $codename = 'd_seo_module_adviser';
	private $route = 'extension/module/d_seo_module_adviser';
	private $config_file = 'd_seo_module_adviser';
	
	/*
	*	Return Adviser Info.
	*/	
	public function getAdviserInfo($route) {			
		$this->load->model($this->route);
				
		$adviser_info['adviser_elements'] = array();
		$adviser_info['rating'] = array();
		
		if ($route) {				
			if ($this->config->get($this->codename . '_info_' . $route)) {
				$adviser_info = $this->config->get($this->codename . '_info_' . $route);
			} else {												
				$installed_seo_adviser_extensions = $this->{'model_extension_module_' . $this->codename}->getInstalledSEOAdviserExtensions();
				
				foreach ($installed_seo_adviser_extensions as $installed_seo_adviser_extension) {
					$adviser_elements = $this->load->controller('extension/' . $this->codename . '/' . $installed_seo_adviser_extension . '/adviser_elements', $route);
				
					if ($adviser_elements) {
						$adviser_info['adviser_elements'] = array_merge($adviser_info['adviser_elements'], $adviser_elements);
					}
				}

				$adviser_info['adviser_elements'] = $this->{'model_extension_module_' . $this->codename}->sortArrayByColumn($adviser_info['adviser_elements'], 'rating');
				
				$total_rating = 0;
				$total_weight = 0;
			
				foreach ($adviser_info['adviser_elements'] as $adviser_element) {
					$total_rating += $adviser_element['rating'] * $adviser_element['weight'];
					$total_weight += $adviser_element['weight'];
				}
						
				if ($total_weight) {
					$adviser_info['rating'] = $total_rating / $total_weight;
				} else {
					$adviser_info['rating'] = 0;
				}

				$this->config->set($this->codename . '_info_' . $route, $adviser_info);
			}
		}
				
		return $adviser_info;
	}
}