<?php
class ControllerExtensionDToolbarDSEOModuleAdviser extends Controller {
	private $codename = 'd_seo_module_adviser';
	private $route = 'extension/d_toolbar/d_seo_module_adviser';
	private $config_file = 'd_seo_module_adviser';
	
	/*
	*	Functions for Toolbar.
	*/	
	public function toolbar_widgets($route) {	
		$_language = new Language();
		$_language->load($this->route);
				
		$this->load->model('extension/module/' . $this->codename);
		
		$status = ($this->config->get('module_' . $this->codename . '_status')) ? $this->config->get('module_' . $this->codename . '_status') : false;
								
		$toolbar_widgets = array();
		
		if ($status && $route) {
			$data['text_seo_rating'] = $_language->get('text_seo_rating');
				
			$data['adviser_elements'] = array();
			$data['rating'] = '';
				
			$adviser_info = $this->load->controller('extension/module/d_seo_module_adviser/getAdviserInfo', $route);
			
			if (isset($adviser_info['adviser_elements']) && isset($adviser_info['rating'])) {
				$data['adviser_elements'] = $adviser_info['adviser_elements'];
				$data['rating'] = $adviser_info['rating'];
			}
					
			// Setting
			$this->config->load($this->config_file);
			$setting = ($this->config->get($this->codename . '_toolbar_setting')) ? $this->config->get($this->codename . '_toolbar_setting') : array();
				
			foreach ($setting['widget'] as $widget) {
				if (substr($widget['name'], 0, strlen('text_')) == 'text_') {
					$widget['name'] = $_language->get($widget['name']);
				}
				
				if (VERSION >= '3.0.0.0') {
					$theme = $this->config->get('theme_' . $this->config->get('config_theme') . '_directory');
				} elseif (VERSION >= '2.2.0.0') {
					$theme = $this->config->get($this->config->get('config_theme') . '_directory');
				} else {
					$theme = $this->config->get('config_template');
				}
				
				if (file_exists(DIR_TEMPLATE . $theme . '/stylesheet/d_toolbar/' . $this->codename . '.css')) {
					$this->document->addStyle('catalog/view/theme/' . $theme . '/stylesheet/d_toolbar/' . $this->codename . '.css');
				} else {
					$this->document->addStyle('catalog/view/theme/default/stylesheet/d_toolbar/' . $this->codename . '.css');
				}
				
				
				if (VERSION >= '2.2.0.0') {	
					$widget['html'] = $this->load->view($this->route, $data);
				} else {
					if (file_exists(DIR_TEMPLATE . $theme . '/template/' . $this->route . '.twig')) {
						$widget['html'] = $this->load->view($theme . '/template/' . $this->route, $data);
					} else {
						$widget['html'] = $this->load->view('default/template/' . $this->route, $data);
					}
                }
								
				$toolbar_widgets[$widget['code']] = $widget;
			}
		}	
					
		return $toolbar_widgets;
	}
}