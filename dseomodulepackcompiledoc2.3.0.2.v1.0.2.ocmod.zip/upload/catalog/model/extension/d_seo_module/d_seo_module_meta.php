<?php
class ModelExtensionDSEOModuleDSEOModuleMeta extends Model {
	private $codename = 'd_seo_module_meta';
	
	/*
	*	Return Field Elements.
	*/
	public function getFieldElements($data) {				
		if ($data['field_code'] == 'meta_data') {
			$this->load->model('extension/module/' . $this->codename);
		
			$stores = $this->{'model_extension_module_' . $this->codename}->getStores();
			
			$field_info = $this->load->controller('extension/module/d_seo_module/getFieldInfo');
			$custom_page_exception_routes = $this->load->controller('extension/module/d_seo_module_meta/getCustomPageExceptionRoutes');
			
			$field_elements = array();
			
			if ((isset($data['filter']['route']) && (strpos($data['filter']['route'], 'category_id') === 0)) || !isset($data['filter']['route'])) {
				$sql = "SELECT * FROM " . DB_PREFIX . "category_description";
			
				$implode = array();
				
				foreach ($data['filter'] as $filter_code => $filter) {
					if (!empty($filter)) {
						if ($filter_code == 'route') {
							$route_arr = explode('category_id=', $filter);
			
							if (isset($route_arr[1]) && ($route_arr[1] != '%')) {
								$category_id = $route_arr[1];
								$implode[] = "category_id = '" . (int)$category_id . "'";
							}
						}
													
						if ($filter_code == 'language_id' ) {
							$implode[] = "language_id = '" . (int)$filter . "'";
						}
											
						if ($filter_code == 'name') {
							$implode[] = "name = '" . $this->db->escape($filter) . "'";
						}
										
						if ($filter_code == 'description') {
							$implode[] = "description = '" . $this->db->escape($filter) . "'";
						}
					
						if ($filter_code == 'meta_title') {
							$implode[] = "meta_title = '" . $this->db->escape($filter) . "'";
						}
					
						if ($filter_code == 'meta_description') {
							$implode[] = "meta_description = '" . $this->db->escape($filter) . "'";
						}
					
						if ($filter_code == 'meta_keyword') {
							$implode[] = "meta_keyword = '" . $this->db->escape($filter) . "'";
						}
					}
				}
					
				if ($implode) {
					$sql .= " WHERE " . implode(' AND ', $implode);
				}
						
				$query = $this->db->query($sql);
					
				foreach ($query->rows as $result) {
					$route = 'category_id=' . $result['category_id'];
				
					if ((isset($field_info['sheet']['category']['field']['name']['multi_store']) && $field_info['sheet']['category']['field']['name']['multi_store'] && isset($field_info['sheet']['category']['field']['name']['multi_store_status']) && $field_info['sheet']['category']['field']['name']['multi_store_status'])) {
						if ((isset($data['filter']['store_id']) && ($data['filter']['store_id'] == 0)) || !isset($data['filter']['store_id'])) {
							$field_elements[$route][0][$result['language_id']]['name'] = $result['name'];
						}
					} else {
						foreach ($stores as $store) {
							if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$route][$store['store_id']][$result['language_id']]['name'] = $result['name'];
							}
						}
					}
				
					if ((isset($field_info['sheet']['category']['field']['description']['multi_store']) && $field_info['sheet']['category']['field']['description']['multi_store'] && isset($field_info['sheet']['category']['field']['description']['multi_store_status']) && $field_info['sheet']['category']['field']['description']['multi_store_status'])) {
						if ((isset($data['filter']['store_id']) && ($data['filter']['store_id'] == 0)) || !isset($data['filter']['store_id'])) {
							$field_elements[$route][0][$result['language_id']]['description'] = $result['description'];
						}
					} else {
						foreach ($stores as $store) {
							if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$route][$store['store_id']][$result['language_id']]['description'] = $result['description'];
							}
						}
					}

					if ((isset($field_info['sheet']['category']['field']['meta_title']['multi_store']) && $field_info['sheet']['category']['field']['meta_title']['multi_store'] && isset($field_info['sheet']['category']['field']['meta_title']['multi_store_status']) && $field_info['sheet']['category']['field']['meta_title']['multi_store_status'])) {
						if ((isset($data['filter']['store_id']) && ($data['filter']['store_id'] == 0)) || !isset($data['filter']['store_id'])) {
							$field_elements[$route][0][$result['language_id']]['meta_title'] = $result['meta_title'];
						}
					} else {
						foreach ($stores as $store) {
							if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$route][$store['store_id']][$result['language_id']]['meta_title'] = $result['meta_title'];
							}
						}
					}

					if ((isset($field_info['sheet']['category']['field']['meta_description']['multi_store']) && $field_info['sheet']['category']['field']['meta_description']['multi_store'] && isset($field_info['sheet']['category']['field']['meta_description']['multi_store_status']) && $field_info['sheet']['category']['field']['meta_description']['multi_store_status'])) {
						if ((isset($data['filter']['store_id']) && ($data['filter']['store_id'] == 0)) || !isset($data['filter']['store_id'])) {
							$field_elements[$route][0][$result['language_id']]['meta_description'] = $result['meta_description'];
						}
					} else {
						foreach ($stores as $store) {
							if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$route][$store['store_id']][$result['language_id']]['meta_description'] = $result['meta_description'];
							}
						}
					}

					if ((isset($field_info['sheet']['category']['field']['meta_keyword']['multi_store']) && $field_info['sheet']['category']['field']['meta_keyword']['multi_store'] && isset($field_info['sheet']['category']['field']['meta_keyword']['multi_store_status']) && $field_info['sheet']['category']['field']['meta_keyword']['multi_store_status'])) {
						if ((isset($data['filter']['store_id']) && ($data['filter']['store_id'] == 0)) || !isset($data['filter']['store_id'])) {
							$field_elements[$route][0][$result['language_id']]['meta_keyword'] = $result['meta_keyword'];
						}
					} else {
						foreach ($stores as $store) {
							if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$route][$store['store_id']][$result['language_id']]['meta_keyword'] = $result['meta_keyword'];
							}
						}
					}					
				}
			}
			
			if ((isset($data['filter']['route']) && (strpos($data['filter']['route'], 'product_id') === 0)) || !isset($data['filter']['route'])) {
				$sql = "SELECT * FROM " . DB_PREFIX . "product_description";
			
				$implode = array();
								
				foreach ($data['filter'] as $filter_code => $filter) {
					if (!empty($filter)) {
						if ($filter_code == 'route') {
							$route_arr = explode('product_id=', $filter);
			
							if (isset($route_arr[1]) && ($route_arr[1] != '%')) {
								$product_id = $route_arr[1];
								$implode[] = "product_id = '" . (int)$product_id . "'";
							}
						}
													
						if ($filter_code == 'language_id' ) {
							$implode[] = "language_id = '" . (int)$filter . "'";
						}
											
						if ($filter_code == 'name') {
							$implode[] = "name = '" . $this->db->escape($filter) . "'";
						}
										
						if ($filter_code == 'description') {
							$implode[] = "description = '" . $this->db->escape($filter) . "'";
						}
					
						if ($filter_code == 'meta_title') {
							$implode[] = "meta_title = '" . $this->db->escape($filter) . "'";
						}
					
						if ($filter_code == 'meta_description') {
							$implode[] = "meta_description = '" . $this->db->escape($filter) . "'";
						}
					
						if ($filter_code == 'meta_keyword') {
							$implode[] = "meta_keyword = '" . $this->db->escape($filter) . "'";
						}
					
						if ($filter_code == 'tag') {
							$implode[] = "tag = '" . $this->db->escape($filter) . "'";
						}
					}
				}
					
				if ($implode) {
					$sql .= " WHERE " . implode(' AND ', $implode);
				}
						
				$query = $this->db->query($sql);
										
				foreach ($query->rows as $result) {
					$route = 'product_id=' . $result['product_id'];
							
					if ((isset($field_info['sheet']['product']['field']['name']['multi_store']) && $field_info['sheet']['product']['field']['name']['multi_store'] && isset($field_info['sheet']['product']['field']['name']['multi_store_status']) && $field_info['sheet']['product']['field']['name']['multi_store_status'])) {
						if ((isset($data['filter']['store_id']) && ($data['filter']['store_id'] == 0)) || !isset($data['filter']['store_id'])) {
							$field_elements[$route][0][$result['language_id']]['name'] = $result['name'];
						}
					} else {
						foreach ($stores as $store) {
							if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$route][$store['store_id']][$result['language_id']]['name'] = $result['name'];
							}
						}
					}
				
					if ((isset($field_info['sheet']['product']['field']['description']['multi_store']) && $field_info['sheet']['product']['field']['description']['multi_store'] && isset($field_info['sheet']['product']['field']['description']['multi_store_status']) && $field_info['sheet']['product']['field']['description']['multi_store_status'])) {
						if ((isset($data['filter']['store_id']) && ($data['filter']['store_id'] == 0)) || !isset($data['filter']['store_id'])) {
							$field_elements[$route][0][$result['language_id']]['description'] = $result['description'];
						}
					} else {
						foreach ($stores as $store) {
							if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$route][$store['store_id']][$result['language_id']]['description'] = $result['description'];
							}
						}
					}

					if ((isset($field_info['sheet']['product']['field']['meta_title']['multi_store']) && $field_info['sheet']['product']['field']['meta_title']['multi_store'] && isset($field_info['sheet']['product']['field']['meta_title']['multi_store_status']) && $field_info['sheet']['product']['field']['meta_title']['multi_store_status'])) {
						if ((isset($data['filter']['store_id']) && ($data['filter']['store_id'] == 0)) || !isset($data['filter']['store_id'])) {
							$field_elements[$route][0][$result['language_id']]['meta_title'] = $result['meta_title'];
						}
					} else {
						foreach ($stores as $store) {
							if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$route][$store['store_id']][$result['language_id']]['meta_title'] = $result['meta_title'];
							}
						}
					}

					if ((isset($field_info['sheet']['product']['field']['meta_description']['multi_store']) && $field_info['sheet']['product']['field']['meta_description']['multi_store'] && isset($field_info['sheet']['product']['field']['meta_description']['multi_store_status']) && $field_info['sheet']['product']['field']['meta_description']['multi_store_status'])) {
						if ((isset($data['filter']['store_id']) && ($data['filter']['store_id'] == 0)) || !isset($data['filter']['store_id'])) {
							$field_elements[$route][0][$result['language_id']]['meta_description'] = $result['meta_description'];
						}
					} else {
						foreach ($stores as $store) {
							if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$route][$store['store_id']][$result['language_id']]['meta_description'] = $result['meta_description'];
							}
						}
					}

					if ((isset($field_info['sheet']['product']['field']['meta_keyword']['multi_store']) && $field_info['sheet']['product']['field']['meta_keyword']['multi_store'] && isset($field_info['sheet']['product']['field']['meta_keyword']['multi_store_status']) && $field_info['sheet']['product']['field']['meta_keyword']['multi_store_status'])) {
						if ((isset($data['filter']['store_id']) && ($data['filter']['store_id'] == 0)) || !isset($data['filter']['store_id'])) {
							$field_elements[$route][0][$result['language_id']]['meta_keyword'] = $result['meta_keyword'];
						}
					} else {
						foreach ($stores as $store) {
							if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$route][$store['store_id']][$result['language_id']]['meta_keyword'] = $result['meta_keyword'];
							}
						}
					}
					
					if ((isset($field_info['sheet']['product']['field']['tag']['multi_store']) && $field_info['sheet']['product']['field']['tag']['multi_store'] && isset($field_info['sheet']['product']['field']['tag']['multi_store_status']) && $field_info['sheet']['product']['field']['tag']['multi_store_status'])) {
						if ((isset($data['filter']['store_id']) && ($data['filter']['store_id'] == 0)) || !isset($data['filter']['store_id'])) {
							$field_elements[$route][0][$result['language_id']]['tag'] = $result['tag'];
						}
					} else {
						foreach ($stores as $store) {
							if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$route][$store['store_id']][$result['language_id']]['tag'] = $result['tag'];
							}
						}
					}
				}
			}
			
			if ((isset($data['filter']['route']) && (strpos($data['filter']['route'], 'information_id') === 0)) || !isset($data['filter']['route'])) {
				$sql = "SELECT * FROM " . DB_PREFIX . "information_description";
			
				$implode = array();
				
				foreach ($data['filter'] as $filter_code => $filter) {
					if (!empty($filter)) {
						if ($filter_code == 'route') {
							$route_arr = explode('information_id=', $filter);
			
							if (isset($route_arr[1]) && ($route_arr[1] != '%')) {
								$information_id = $route_arr[1];
								$implode[] = "information_id = '" . (int)$information_id . "'";
							}
						}
													
						if ($filter_code == 'language_id' ) {
							$implode[] = "language_id = '" . (int)$filter . "'";
						}
											
						if ($filter_code == 'title') {
							$implode[] = "title = '" . $this->db->escape($filter) . "'";
						}
										
						if ($filter_code == 'description') {
							$implode[] = "description = '" . $this->db->escape($filter) . "'";
						}
					
						if ($filter_code == 'meta_title') {
							$implode[] = "meta_title = '" . $this->db->escape($filter) . "'";
						}
					
						if ($filter_code == 'meta_description') {
							$implode[] = "meta_description = '" . $this->db->escape($filter) . "'";
						}
					
						if ($filter_code == 'meta_keyword') {
							$implode[] = "meta_keyword = '" . $this->db->escape($filter) . "'";
						}
					}
				}
			
				if ($implode) {
					$sql .= " WHERE " . implode(' AND ', $implode);
				}
						
				$query = $this->db->query($sql);
										
				foreach ($query->rows as $result) {
					$route = 'information_id=' . $result['information_id'];
							
					if ((isset($field_info['sheet']['information']['field']['title']['multi_store']) && $field_info['sheet']['information']['field']['title']['multi_store'] && isset($field_info['sheet']['information']['field']['title']['multi_store_status']) && $field_info['sheet']['information']['field']['title']['multi_store_status'])) {
						if ((isset($data['filter']['store_id']) && ($data['filter']['store_id'] == 0)) || !isset($data['filter']['store_id'])) {
							$field_elements[$route][0][$result['language_id']]['title'] = $result['title'];
						}
					} else {
						foreach ($stores as $store) {
							if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$route][$store['store_id']][$result['language_id']]['title'] = $result['title'];
							}
						}
					}
				
					if ((isset($field_info['sheet']['information']['field']['description']['multi_store']) && $field_info['sheet']['information']['field']['description']['multi_store'] && isset($field_info['sheet']['information']['field']['description']['multi_store_status']) && $field_info['sheet']['information']['field']['description']['multi_store_status'])) {
						if ((isset($data['filter']['store_id']) && ($data['filter']['store_id'] == 0)) || !isset($data['filter']['store_id'])) {
							$field_elements[$route][0][$result['language_id']]['description'] = $result['description'];
						}
					} else {
						foreach ($stores as $store) {
							if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$route][$store['store_id']][$result['language_id']]['description'] = $result['description'];
							}
						}
					}

					if ((isset($field_info['sheet']['information']['field']['meta_title']['multi_store']) && $field_info['sheet']['information']['field']['meta_title']['multi_store'] && isset($field_info['sheet']['information']['field']['meta_title']['multi_store_status']) && $field_info['sheet']['information']['field']['meta_title']['multi_store_status'])) {
						if ((isset($data['filter']['store_id']) && ($data['filter']['store_id'] == 0)) || !isset($data['filter']['store_id'])) {
							$field_elements[$route][0][$result['language_id']]['meta_title'] = $result['meta_title'];
						}
					} else {
						foreach ($stores as $store) {
							if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$route][$store['store_id']][$result['language_id']]['meta_title'] = $result['meta_title'];
							}
						}
					}

					if ((isset($field_info['sheet']['information']['field']['meta_description']['multi_store']) && $field_info['sheet']['information']['field']['meta_description']['multi_store'] && isset($field_info['sheet']['information']['field']['meta_description']['multi_store_status']) && $field_info['sheet']['information']['field']['meta_description']['multi_store_status'])) {
						if ((isset($data['filter']['store_id']) && ($data['filter']['store_id'] == 0)) || !isset($data['filter']['store_id'])) {
							$field_elements[$route][0][$result['language_id']]['meta_description'] = $result['meta_description'];
						}
					} else {
						foreach ($stores as $store) {
							if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$route][$store['store_id']][$result['language_id']]['meta_description'] = $result['meta_description'];
							}
						}
					}

					if ((isset($field_info['sheet']['information']['field']['meta_keyword']['multi_store']) && $field_info['sheet']['information']['field']['meta_keyword']['multi_store'] && isset($field_info['sheet']['information']['field']['meta_keyword']['multi_store_status']) && $field_info['sheet']['information']['field']['meta_keyword']['multi_store_status'])) {
						if ((isset($data['filter']['store_id']) && ($data['filter']['store_id'] == 0)) || !isset($data['filter']['store_id'])) {
							$field_elements[$route][0][$result['language_id']]['meta_keyword'] = $result['meta_keyword'];
						}
					} else {
						foreach ($stores as $store) {
							if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$route][$store['store_id']][$result['language_id']]['meta_keyword'] = $result['meta_keyword'];
							}
						}
					}
				}
			}
			
			if ((isset($data['filter']['route']) && ((strpos($data['filter']['route'], 'category_id') === 0) || (strpos($data['filter']['route'], 'product_id') === 0) || (strpos($data['filter']['route'], 'manufacturer_id') === 0) || (strpos($data['filter']['route'], 'information_id') === 0) || (preg_match('/[A-Za-z0-9]+\/[A-Za-z0-9]+/i', $data['filter']['route']) && !($custom_page_exception_routes && in_array($data['filter']['route'], $custom_page_exception_routes))))) || !isset($data['filter']['route'])) {
				$sql = "SELECT * FROM " . DB_PREFIX . "d_meta_data";
				
				$implode = array();
								
				foreach ($data['filter'] as $filter_code => $filter) {
					if (!empty($filter)) {
						if ($filter_code == 'route') {
							if (strpos($filter, '%') !== false) {
								$implode[] = "route LIKE '" . $this->db->escape($filter) . "'";
							} else {
								$implode[] = "route = '" . $this->db->escape($filter) . "'";
							}
						}
																			
						if ($filter_code == 'language_id' ) {
							$implode[] = "language_id = '" . (int)$filter . "'";
						}
											
						if ($filter_code == 'name') {
							$implode[] = "name = '" . $this->db->escape($filter) . "'";
						}
						
						if ($filter_code == 'title') {
							$implode[] = "title = '" . $this->db->escape($filter) . "'";
						}
										
						if ($filter_code == 'description') {
							$implode[] = "description = '" . $this->db->escape($filter) . "'";
						}
					
						if ($filter_code == 'meta_title') {
							$implode[] = "meta_title = '" . $this->db->escape($filter) . "'";
						}
					
						if ($filter_code == 'meta_description') {
							$implode[] = "meta_description = '" . $this->db->escape($filter) . "'";
						}
					
						if ($filter_code == 'meta_keyword') {
							$implode[] = "meta_keyword = '" . $this->db->escape($filter) . "'";
						}
					
						if ($filter_code == 'tag') {
							$implode[] = "tag = '" . $this->db->escape($filter) . "'";
						}
					
						if ($filter_code == 'custom_title_1') {
							$implode[] = "custom_title_1 = '" . $this->db->escape($filter) . "'";
						}
					
						if ($filter_code == 'custom_title_2') {
							$implode[] = "custom_title_2 = '" . $this->db->escape($filter) . "'";
						}
					
						if ($filter_code == 'custom_image_title') {
							$implode[] = "custom_image_title = '" . $this->db->escape($filter) . "'";
						}
					
						if ($filter_code == 'custom_image_alt') {
							$implode[] = "custom_image_alt = '" . $this->db->escape($filter) . "'";
						}
					
						if ($filter_code == 'meta_robots') {
							$implode[] = "meta_robots = '" . $this->db->escape($filter) . "'";
						}
					}
				}
					
				if ($implode) {
					$sql .= " WHERE " . implode(' AND ', $implode);
				}
					
				$query = $this->db->query($sql);
				
				foreach ($query->rows as $result) {
					if (strpos($result['route'], 'category_id') === 0) {
						if ($result['store_id'] && isset($field_info['sheet']['category']['field']['name']['multi_store']) && $field_info['sheet']['category']['field']['name']['multi_store'] && isset($field_info['sheet']['category']['field']['name']['multi_store_status']) && $field_info['sheet']['category']['field']['name']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['name'] = $result['name'];
							}
						}
					
						if ($result['store_id'] && isset($field_info['sheet']['category']['field']['description']['multi_store']) && $field_info['sheet']['category']['field']['description']['multi_store'] && isset($field_info['sheet']['category']['field']['description']['multi_store_status']) && $field_info['sheet']['category']['field']['description']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['description'] = $result['description'];
							}
						}
					
						if ($result['store_id'] && isset($field_info['sheet']['category']['field']['meta_title']['multi_store']) && $field_info['sheet']['category']['field']['meta_title']['multi_store'] && isset($field_info['sheet']['category']['field']['meta_title']['multi_store_status']) && $field_info['sheet']['category']['field']['meta_title']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['meta_title'] = $result['meta_title'];
							}
						}
					
						if ($result['store_id'] && isset($field_info['sheet']['category']['field']['meta_description']['multi_store']) && $field_info['sheet']['category']['field']['meta_description']['multi_store'] && isset($field_info['sheet']['category']['field']['meta_description']['multi_store_status']) && $field_info['sheet']['category']['field']['meta_description']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['meta_description'] = $result['meta_description'];
							}
						}
					
						if ($result['store_id'] && isset($field_info['sheet']['category']['field']['meta_keyword']['multi_store']) && $field_info['sheet']['category']['field']['meta_keyword']['multi_store'] && isset($field_info['sheet']['category']['field']['meta_keyword']['multi_store_status']) && $field_info['sheet']['category']['field']['meta_keyword']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['meta_keyword'] = $result['meta_keyword'];
							}
						}
						
						if ($result['store_id'] && isset($field_info['sheet']['category']['field']['custom_title_1']['multi_store']) && $field_info['sheet']['category']['field']['custom_title_1']['multi_store'] && isset($field_info['sheet']['category']['field']['custom_title_1']['multi_store_status']) && $field_info['sheet']['category']['field']['custom_title_1']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['custom_title_1'] = $result['custom_title_1'];
							}
						} elseif ($result['store_id'] == 0) {
							foreach ($stores as $store) {
								if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
									$field_elements[$result['route']][$store['store_id']][$result['language_id']]['custom_title_1'] = $result['custom_title_1'];
								}
							}
						}
						
						if ($result['store_id'] && isset($field_info['sheet']['category']['field']['custom_title_2']['multi_store']) && $field_info['sheet']['category']['field']['custom_title_2']['multi_store'] && isset($field_info['sheet']['category']['field']['custom_title_2']['multi_store_status']) && $field_info['sheet']['category']['field']['custom_title_2']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['custom_title_2'] = $result['custom_title_2'];
							}
						} elseif ($result['store_id'] == 0) {
							foreach ($stores as $store) {
								if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
									$field_elements[$result['route']][$store['store_id']][$result['language_id']]['custom_title_2'] = $result['custom_title_2'];
								}
							}
						}
						
						if ($result['store_id'] && isset($field_info['sheet']['category']['field']['custom_image_title']['multi_store']) && $field_info['sheet']['category']['field']['custom_image_title']['multi_store'] && isset($field_info['sheet']['category']['field']['custom_image_title']['multi_store_status']) && $field_info['sheet']['category']['field']['custom_image_title']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['custom_image_title'] = $result['custom_image_title'];
							}
						} elseif ($result['store_id'] == 0) {
							foreach ($stores as $store) {
								if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
									$field_elements[$result['route']][$store['store_id']][$result['language_id']]['custom_image_title'] = $result['custom_image_title'];
								}
							}
						}
						
						if ($result['store_id'] && isset($field_info['sheet']['category']['field']['custom_image_alt']['multi_store']) && $field_info['sheet']['category']['field']['custom_image_alt']['multi_store'] && isset($field_info['sheet']['category']['field']['custom_image_alt']['multi_store_status']) && $field_info['sheet']['category']['field']['custom_image_alt']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['custom_image_alt'] = $result['custom_image_alt'];
							}
						} elseif ($result['store_id'] == 0) {
							foreach ($stores as $store) {
								if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
									$field_elements[$result['route']][$store['store_id']][$result['language_id']]['custom_image_alt'] = $result['custom_image_alt'];
								}
							}
						}
						
						if ($result['store_id'] && isset($field_info['sheet']['category']['field']['meta_robots']['multi_store']) && $field_info['sheet']['category']['field']['meta_robots']['multi_store'] && isset($field_info['sheet']['category']['field']['meta_robots']['multi_store_status']) && $field_info['sheet']['category']['field']['meta_robots']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['meta_robots'] = $result['meta_robots'];
							}
						} elseif ($result['store_id'] == 0) {
							foreach ($stores as $store) {
								if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
									$field_elements[$result['route']][$store['store_id']][$result['language_id']]['meta_robots'] = $result['meta_robots'];
								}
							}
						}
					}
				
					if (strpos($result['route'], 'product_id') === 0) {
						if ($result['store_id'] && isset($field_info['sheet']['product']['field']['name']['multi_store']) && $field_info['sheet']['product']['field']['name']['multi_store'] && isset($field_info['sheet']['product']['field']['name']['multi_store_status']) && $field_info['sheet']['product']['field']['name']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['name'] = $result['name'];
							}
						}
					
						if ($result['store_id'] && isset($field_info['sheet']['product']['field']['description']['multi_store']) && $field_info['sheet']['product']['field']['description']['multi_store'] && isset($field_info['sheet']['product']['field']['description']['multi_store_status']) && $field_info['sheet']['product']['field']['description']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['description'] = $result['description'];
							}
						}
					
						if ($result['store_id'] && isset($field_info['sheet']['product']['field']['meta_title']['multi_store']) && $field_info['sheet']['product']['field']['meta_title']['multi_store'] && isset($field_info['sheet']['product']['field']['meta_title']['multi_store_status']) && $field_info['sheet']['product']['field']['meta_title']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['meta_title'] = $result['meta_title'];
							}
						}
					
						if ($result['store_id'] && isset($field_info['sheet']['product']['field']['meta_description']['multi_store']) && $field_info['sheet']['product']['field']['meta_description']['multi_store'] && isset($field_info['sheet']['product']['field']['meta_description']['multi_store_status']) && $field_info['sheet']['product']['field']['meta_description']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['meta_description'] = $result['meta_description'];
							}
						}
					
						if ($result['store_id'] && isset($field_info['sheet']['product']['field']['meta_keyword']['multi_store']) && $field_info['sheet']['product']['field']['meta_keyword']['multi_store'] && isset($field_info['sheet']['product']['field']['meta_keyword']['multi_store_status']) && $field_info['sheet']['product']['field']['meta_keyword']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['meta_keyword'] = $result['meta_keyword'];
							}
						}
						
						if ($result['store_id'] && isset($field_info['sheet']['product']['field']['tag']['multi_store']) && $field_info['sheet']['product']['field']['tag']['multi_store'] && isset($field_info['sheet']['product']['field']['tag']['multi_store_status']) && $field_info['sheet']['product']['field']['tag']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['tag'] = $result['tag'];
							}
						}
						
						if ($result['store_id'] && isset($field_info['sheet']['product']['field']['custom_title_1']['multi_store']) && $field_info['sheet']['product']['field']['custom_title_1']['multi_store'] && isset($field_info['sheet']['product']['field']['custom_title_1']['multi_store_status']) && $field_info['sheet']['product']['field']['custom_title_1']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['custom_title_1'] = $result['custom_title_1'];
							}
						} elseif ($result['store_id'] == 0) {
							foreach ($stores as $store) {
								if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
									$field_elements[$result['route']][$store['store_id']][$result['language_id']]['custom_title_1'] = $result['custom_title_1'];
								}
							}
						}
						
						if ($result['store_id'] && isset($field_info['sheet']['product']['field']['custom_title_2']['multi_store']) && $field_info['sheet']['product']['field']['custom_title_2']['multi_store'] && isset($field_info['sheet']['product']['field']['custom_title_2']['multi_store_status']) && $field_info['sheet']['product']['field']['custom_title_2']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['custom_title_2'] = $result['custom_title_2'];
							}
						} elseif ($result['store_id'] == 0) {
							foreach ($stores as $store) {
								if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
									$field_elements[$result['route']][$store['store_id']][$result['language_id']]['custom_title_2'] = $result['custom_title_2'];
								}
							}
						}
						
						if ($result['store_id'] && isset($field_info['sheet']['product']['field']['custom_image_title']['multi_store']) && $field_info['sheet']['product']['field']['custom_image_title']['multi_store'] && isset($field_info['sheet']['product']['field']['custom_image_title']['multi_store_status']) && $field_info['sheet']['product']['field']['custom_image_title']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['custom_image_title'] = $result['custom_image_title'];
							}
						} elseif ($result['store_id'] == 0) {
							foreach ($stores as $store) {
								if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
									$field_elements[$result['route']][$store['store_id']][$result['language_id']]['custom_image_title'] = $result['custom_image_title'];
								}
							}
						}
						
						if ($result['store_id'] && isset($field_info['sheet']['product']['field']['custom_image_alt']['multi_store']) && $field_info['sheet']['product']['field']['custom_image_alt']['multi_store'] && isset($field_info['sheet']['product']['field']['custom_image_alt']['multi_store_status']) && $field_info['sheet']['product']['field']['custom_image_alt']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['custom_image_alt'] = $result['custom_image_alt'];
							}
						} elseif ($result['store_id'] == 0) {
							foreach ($stores as $store) {
								if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
									$field_elements[$result['route']][$store['store_id']][$result['language_id']]['custom_image_alt'] = $result['custom_image_alt'];
								}
							}
						}
						
						if ($result['store_id'] && isset($field_info['sheet']['product']['field']['meta_robots']['multi_store']) && $field_info['sheet']['product']['field']['meta_robots']['multi_store'] && isset($field_info['sheet']['product']['field']['meta_robots']['multi_store_status']) && $field_info['sheet']['product']['field']['meta_robots']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['meta_robots'] = $result['meta_robots'];
							}
						} elseif ($result['store_id'] == 0) {
							foreach ($stores as $store) {
								if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
									$field_elements[$result['route']][$store['store_id']][$result['language_id']]['meta_robots'] = $result['meta_robots'];
								}
							}
						}
					}
				
					if (strpos($result['route'], 'manufacturer_id') === 0) {
						if ($result['store_id'] && isset($field_info['sheet']['manufacturer']['field']['name']['multi_store']) && $field_info['sheet']['manufacturer']['field']['name']['multi_store'] && isset($field_info['sheet']['manufacturer']['field']['name']['multi_store_status']) && $field_info['sheet']['manufacturer']['field']['name']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['name'] = $result['name'];
							}
						} elseif ($result['store_id'] == 0) {
							foreach ($stores as $store) {
								if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
									$field_elements[$result['route']][$store['store_id']][$result['language_id']]['name'] = $result['name'];
								}
							}
						}
						
						if ($result['store_id'] && isset($field_info['sheet']['manufacturer']['field']['description']['multi_store']) && $field_info['sheet']['manufacturer']['field']['description']['multi_store'] && isset($field_info['sheet']['manufacturer']['field']['description']['multi_store_status']) && $field_info['sheet']['manufacturer']['field']['description']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['description'] = $result['description'];
							}
						} elseif ($result['store_id'] == 0) {
							foreach ($stores as $store) {
								if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
									$field_elements[$result['route']][$store['store_id']][$result['language_id']]['description'] = $result['description'];
								}
							}
						}
						
						if ($result['store_id'] && isset($field_info['sheet']['manufacturer']['field']['meta_title']['multi_store']) && $field_info['sheet']['manufacturer']['field']['meta_title']['multi_store'] && isset($field_info['sheet']['manufacturer']['field']['meta_title']['multi_store_status']) && $field_info['sheet']['manufacturer']['field']['meta_title']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['meta_title'] = $result['meta_title'];
							}
						} elseif ($result['store_id'] == 0) {
							foreach ($stores as $store) {
								if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
									$field_elements[$result['route']][$store['store_id']][$result['language_id']]['meta_title'] = $result['meta_title'];
								}
							}
						}
						
						if ($result['store_id'] && isset($field_info['sheet']['manufacturer']['field']['meta_description']['multi_store']) && $field_info['sheet']['manufacturer']['field']['meta_description']['multi_store'] && isset($field_info['sheet']['manufacturer']['field']['meta_description']['multi_store_status']) && $field_info['sheet']['manufacturer']['field']['meta_description']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['meta_description'] = $result['meta_description'];
							}
						} elseif ($result['store_id'] == 0) {
							foreach ($stores as $store) {
								if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
									$field_elements[$result['route']][$store['store_id']][$result['language_id']]['meta_description'] = $result['meta_description'];
								}
							}
						}
						
						if ($result['store_id'] && isset($field_info['sheet']['manufacturer']['field']['meta_keyword']['multi_store']) && $field_info['sheet']['manufacturer']['field']['meta_keyword']['multi_store'] && isset($field_info['sheet']['manufacturer']['field']['meta_keyword']['multi_store_status']) && $field_info['sheet']['manufacturer']['field']['meta_keyword']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['meta_keyword'] = $result['meta_keyword'];
							}
						} elseif ($result['store_id'] == 0) {
							foreach ($stores as $store) {
								if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
									$field_elements[$result['route']][$store['store_id']][$result['language_id']]['meta_keyword'] = $result['meta_keyword'];
								}
							}
						}
						
						if ($result['store_id'] && isset($field_info['sheet']['manufacturer']['field']['custom_title_1']['multi_store']) && $field_info['sheet']['manufacturer']['field']['custom_title_1']['multi_store'] && isset($field_info['sheet']['manufacturer']['field']['custom_title_1']['multi_store_status']) && $field_info['sheet']['manufacturer']['field']['custom_title_1']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['custom_title_1'] = $result['custom_title_1'];
							}
						} elseif ($result['store_id'] == 0) {
							foreach ($stores as $store) {
								if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
									$field_elements[$result['route']][$store['store_id']][$result['language_id']]['custom_title_1'] = $result['custom_title_1'];
								}
							}
						}
						
						if ($result['store_id'] && isset($field_info['sheet']['manufacturer']['field']['custom_title_2']['multi_store']) && $field_info['sheet']['manufacturer']['field']['custom_title_2']['multi_store'] && isset($field_info['sheet']['manufacturer']['field']['custom_title_2']['multi_store_status']) && $field_info['sheet']['manufacturer']['field']['custom_title_2']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['custom_title_2'] = $result['custom_title_2'];
							}
						} elseif ($result['store_id'] == 0) {
							foreach ($stores as $store) {
								if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
									$field_elements[$result['route']][$store['store_id']][$result['language_id']]['custom_title_2'] = $result['custom_title_2'];
								}
							}
						}
						
						if ($result['store_id'] && isset($field_info['sheet']['manufacturer']['field']['custom_image_title']['multi_store']) && $field_info['sheet']['manufacturer']['field']['custom_image_title']['multi_store'] && isset($field_info['sheet']['manufacturer']['field']['custom_image_title']['multi_store_status']) && $field_info['sheet']['manufacturer']['field']['custom_image_title']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['custom_image_title'] = $result['custom_image_title'];
							}
						} elseif ($result['store_id'] == 0) {
							foreach ($stores as $store) {
								if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
									$field_elements[$result['route']][$store['store_id']][$result['language_id']]['custom_image_title'] = $result['custom_image_title'];
								}
							}
						}
						
						if ($result['store_id'] && isset($field_info['sheet']['manufacturer']['field']['custom_image_alt']['multi_store']) && $field_info['sheet']['manufacturer']['field']['custom_image_alt']['multi_store'] && isset($field_info['sheet']['manufacturer']['field']['custom_image_alt']['multi_store_status']) && $field_info['sheet']['manufacturer']['field']['custom_image_alt']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['custom_image_alt'] = $result['custom_image_alt'];
							}
						} elseif ($result['store_id'] == 0) {
							foreach ($stores as $store) {
								if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
									$field_elements[$result['route']][$store['store_id']][$result['language_id']]['custom_image_alt'] = $result['custom_image_alt'];
								}
							}
						}
						
						if ($result['store_id'] && isset($field_info['sheet']['manufacturer']['field']['meta_robots']['multi_store']) && $field_info['sheet']['manufacturer']['field']['meta_robots']['multi_store'] && isset($field_info['sheet']['manufacturer']['field']['meta_robots']['multi_store_status']) && $field_info['sheet']['manufacturer']['field']['meta_robots']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['meta_robots'] = $result['meta_robots'];
							}
						} elseif ($result['store_id'] == 0) {
							foreach ($stores as $store) {
								if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
									$field_elements[$result['route']][$store['store_id']][$result['language_id']]['meta_robots'] = $result['meta_robots'];
								}
							}
						}
					}
								
					if (strpos($result['route'], 'information_id') === 0) {
						if ($result['store_id'] && isset($field_info['sheet']['information']['field']['title']['multi_store']) && $field_info['sheet']['information']['field']['title']['multi_store'] && isset($field_info['sheet']['information']['field']['title']['multi_store_status']) && $field_info['sheet']['information']['field']['title']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['title'] = $result['title'];
							}
						}
					
						if ($result['store_id'] && isset($field_info['sheet']['information']['field']['description']['multi_store']) && $field_info['sheet']['information']['field']['description']['multi_store'] && isset($field_info['sheet']['information']['field']['description']['multi_store_status']) && $field_info['sheet']['information']['field']['description']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['description'] = $result['description'];
							}
						}
					
						if ($result['store_id'] && isset($field_info['sheet']['information']['field']['meta_title']['multi_store']) && $field_info['sheet']['information']['field']['meta_title']['multi_store'] && isset($field_info['sheet']['information']['field']['meta_title']['multi_store_status']) && $field_info['sheet']['information']['field']['meta_title']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['meta_title'] = $result['meta_title'];
							}
						}
					
						if ($result['store_id'] && isset($field_info['sheet']['information']['field']['meta_description']['multi_store']) && $field_info['sheet']['information']['field']['meta_description']['multi_store'] && isset($field_info['sheet']['information']['field']['meta_description']['multi_store_status']) && $field_info['sheet']['information']['field']['meta_description']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['meta_description'] = $result['meta_description'];
							}
						}
					
						if ($result['store_id'] && isset($field_info['sheet']['information']['field']['meta_keyword']['multi_store']) && $field_info['sheet']['information']['field']['meta_keyword']['multi_store'] && isset($field_info['sheet']['information']['field']['meta_keyword']['multi_store_status']) && $field_info['sheet']['information']['field']['meta_keyword']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['meta_keyword'] = $result['meta_keyword'];
							}
						}
												
						if ($result['store_id'] && isset($field_info['sheet']['information']['field']['custom_title_1']['multi_store']) && $field_info['sheet']['information']['field']['custom_title_1']['multi_store'] && isset($field_info['sheet']['information']['field']['custom_title_1']['multi_store_status']) && $field_info['sheet']['information']['field']['custom_title_1']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['custom_title_1'] = $result['custom_title_1'];
							}
						} elseif ($result['store_id'] == 0) {
							foreach ($stores as $store) {
								if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
									$field_elements[$result['route']][$store['store_id']][$result['language_id']]['custom_title_1'] = $result['custom_title_1'];
								}
							}
						}
						
						if ($result['store_id'] && isset($field_info['sheet']['information']['field']['custom_title_2']['multi_store']) && $field_info['sheet']['information']['field']['custom_title_2']['multi_store'] && isset($field_info['sheet']['information']['field']['custom_title_2']['multi_store_status']) && $field_info['sheet']['information']['field']['custom_title_2']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['custom_title_2'] = $result['custom_title_2'];
							}
						} elseif ($result['store_id'] == 0) {
							foreach ($stores as $store) {
								if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
									$field_elements[$result['route']][$store['store_id']][$result['language_id']]['custom_title_2'] = $result['custom_title_2'];
								}
							}
						}
												
						if ($result['store_id'] && isset($field_info['sheet']['information']['field']['meta_robots']['multi_store']) && $field_info['sheet']['information']['field']['meta_robots']['multi_store'] && isset($field_info['sheet']['information']['field']['meta_robots']['multi_store_status']) && $field_info['sheet']['information']['field']['meta_robots']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['meta_robots'] = $result['meta_robots'];
							}
						} elseif ($result['store_id'] == 0) {
							foreach ($stores as $store) {
								if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
									$field_elements[$result['route']][$store['store_id']][$result['language_id']]['meta_robots'] = $result['meta_robots'];
								}
							}
						}
					}
			
					if (preg_match('/[A-Za-z0-9]+\/[A-Za-z0-9]+/i', $result['route']) && !($custom_page_exception_routes && in_array($result['route'], $custom_page_exception_routes))) {
						if ($result['store_id'] && isset($field_info['sheet']['custom_page']['field']['meta_title']['multi_store']) && $field_info['sheet']['custom_page']['field']['meta_title']['multi_store'] && isset($field_info['sheet']['custom_page']['field']['meta_title']['multi_store_status']) && $field_info['sheet']['custom_page']['field']['meta_title']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['meta_title'] = $result['meta_title'];
							}
						} elseif ($result['store_id'] == 0) {
							foreach ($stores as $store) {
								if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
									$field_elements[$result['route']][$store['store_id']][$result['language_id']]['meta_title'] = $result['meta_title'];
								}
							}
						}
					
						if ($result['store_id'] && isset($field_info['sheet']['custom_page']['field']['meta_description']['multi_store']) && $field_info['sheet']['custom_page']['field']['meta_description']['multi_store'] && isset($field_info['sheet']['custom_page']['field']['meta_description']['multi_store_status']) && $field_info['sheet']['custom_page']['field']['meta_description']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['meta_description'] = $result['meta_description'];
							}
						} elseif ($result['store_id'] == 0) {
							foreach ($stores as $store) {
								if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
									$field_elements[$result['route']][$store['store_id']][$result['language_id']]['meta_description'] = $result['meta_description'];
								}
							}
						}
					
						if ($result['store_id'] && isset($field_info['sheet']['custom_page']['field']['meta_keyword']['multi_store']) && $field_info['sheet']['custom_page']['field']['meta_keyword']['multi_store'] && isset($field_info['sheet']['custom_page']['field']['meta_keyword']['multi_store_status']) && $field_info['sheet']['custom_page']['field']['meta_keyword']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['meta_keyword'] = $result['meta_keyword'];
							}
						} elseif ($result['store_id'] == 0) {
							foreach ($stores as $store) {
								if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
									$field_elements[$result['route']][$store['store_id']][$result['language_id']]['meta_keyword'] = $result['meta_keyword'];
								}
							}
						}
						
						if ($result['store_id'] && isset($field_info['sheet']['custom_page']['field']['meta_robots']['multi_store']) && $field_info['sheet']['custom_page']['field']['meta_robots']['multi_store'] && isset($field_info['sheet']['custom_page']['field']['meta_robots']['multi_store_status']) && $field_info['sheet']['custom_page']['field']['meta_robots']['multi_store_status']) {
							if ((isset($data['filter']['store_id']) && ($result['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
								$field_elements[$result['route']][$result['store_id']][$result['language_id']]['meta_robots'] = $result['meta_robots'];
							}
						} elseif ($result['store_id'] == 0) {
							foreach ($stores as $store) {
								if ((isset($data['filter']['store_id']) && ($store['store_id'] == $data['filter']['store_id'])) || !isset($data['filter']['store_id'])) {
									$field_elements[$result['route']][$store['store_id']][$result['language_id']]['meta_robots'] = $result['meta_robots'];
								}
							}
						}
					}
				}
			}
				
			return $field_elements;
		}
				
		return false;
	}
}