<?php
class ModelExtensionModuleDSEOModuleAdviser extends Model {
	private $codename = 'd_seo_module_adviser';
		
	/*
	*	Return list of installed SEO Adviser extensions.
	*/
	public function getInstalledSEOAdviserExtensions() {
		$this->load->model('setting/setting');
				
		$installed_extensions = array();
		
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "extension ORDER BY code");
		
		foreach ($query->rows as $result) {
			$installed_extensions[] = $result['code'];
		}
		
		$installed_seo_adviser_extensions = $this->model_setting_setting->getSetting('d_seo_extension');
		$installed_seo_adviser_extensions = isset($installed_seo_adviser_extensions['d_seo_extension_install']) ? $installed_seo_adviser_extensions['d_seo_extension_install'] : array();
		
		$seo_adviser_extensions = array();
		
		$files = glob(DIR_APPLICATION . 'controller/extension/' . $this->codename . '/*.php');
		
		if ($files) {
			foreach ($files as $file) {
				$seo_adviser_extension = basename($file, '.php');
				
				if (in_array($seo_adviser_extension, $installed_extensions) && in_array($seo_adviser_extension, $installed_seo_adviser_extensions)) {
					$seo_adviser_extensions[] = $seo_adviser_extension;
				}
			}
		}
		
		return $seo_adviser_extensions;
	}
			
	/*
	*	Sort Array By Column.
	*/
	public function sortArrayByColumn($arr, $col, $dir = SORT_ASC) {
		$sort_col = array();
		$sort_key = array();
		
		foreach ($arr as $key => $row) {
			$sort_key[$key] = $key;
			
			if (isset($row[$col])) {
				$sort_col[$key] = $row[$col];
			} else {
				$sort_col[$key] = '';
			}
		}
		
		array_multisort($sort_col, $dir, $sort_key, SORT_ASC, $arr);
		
		return $arr;
	}
}

?>