<?php
// Text
$_['text_seo_rating']							= 'SEO Rating';

?>