<?php
// Heading
$_['heading_title_main']  						= 'SEO Module Meta';

// Text
$_['text_category_name']						= 'Category Name';
$_['text_product_name']							= 'Product Name';
$_['text_manufacturer_name']					= 'Manufacturer Name';
$_['text_information_title']					= 'Information Title';
$_['text_title']								= 'Title';
$_['text_description']							= 'Description';
$_['text_meta_title']							= 'Meta Tag Title';
$_['text_meta_description']						= 'Meta Tag Description';
$_['text_meta_keyword']							= 'Meta Tag Keywords';
$_['text_meta_robots']							= 'Meta Robots';
$_['text_tag']									= 'Product Tags';
$_['text_custom_title_1']						= 'Custom Title 1';
$_['text_custom_title_2']						= 'Custom Title 2';
$_['text_custom_image_title']					= 'Custom Image Title';
$_['text_custom_image_alt']						= 'Custom Image Alt';

// Help
$_['help_home_meta_robots']						= 'Meta Robots is multilingual field, which allows the robot to determine, whether it is possible to index the page and to search for links provided on the page.';
$_['help_category_custom_title']				= 'Custom Title is multilingual field, which allows you to specify the title of the category on the category page different from the page title.';
$_['help_category_custom_image_title']			= 'Custom Image Title is multilingual field, which allows you specify the attribute title of main image of the category on the category page different from the page title.';
$_['help_category_custom_image_alt']			= 'Custom Image Alt is multilingual field, which allows you specify the attribute alt of main image of the category on the category page different from the page title.';
$_['help_category_meta_robots']					= 'Meta Robots is multilingual field, which allows the robot to determine, whether it is possible to index this category page and search for links provided on the page.';
$_['help_product_tag']							= 'Comma separated.';
$_['help_product_custom_title']					= 'Custom Title is multilingual field, which allows you to specify the title of the product on the product page different from the page title.';
$_['help_product_custom_image_title']			= 'Custom Image Title is multilingual field, which allows you specify the attribute title of main image of the product on the product page different from the page title.';
$_['help_product_custom_image_alt']				= 'Custom Image Alt is multilingual field, which allows you specify the attribute alt of main image of the product on the product page different from the page title.';
$_['help_product_meta_robots']					= 'Meta Robots is multilingual field, which allows the robot to determine, whether it is possible to index this product page and to search for links provided on the page.';
$_['help_manufacturer_custom_title']			= 'Custom Title is multilingual field, which allows you to specify the title of the manufacturer on the manufacturer page different from the page title.';
$_['help_manufacturer_custom_image_title']		= 'Custom Image Title is multilingual field, which allows you specify the attribute title of main image of the manufacturer on the manufacturer page different from the page title.';
$_['help_manufacturer_custom_image_alt']		= 'Custom Image Alt is multilingual field, which allows you specify the attribute alt of main image of the manufacturer on the manufacturer page different from the page title.';
$_['help_manufacturer_meta_robots']				= 'Meta Robots is multilingual field, which allows the robot to determine, whether it is possible to index this manufacturer page and to search for links provided on the page.';
$_['help_information_custom_title']				= 'Custom Title is multilingual field, which allows you to specify the title of the information on the information page different from the page title.';
$_['help_information_meta_robots']				= 'Meta Robots is multilingual field, which allows the robot to determine, whether it is possible to index this information page and to search for links provided on the page.';

?>