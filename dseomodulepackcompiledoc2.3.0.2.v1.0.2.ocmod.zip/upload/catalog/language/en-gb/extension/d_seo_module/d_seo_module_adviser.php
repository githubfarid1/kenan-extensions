<?php
// Heading
$_['heading_title_main']  						= 'SEO Module Adviser';

// Text
$_['text_seo_rating']							= 'SEO Rating';

// Help
$_['help_seo_rating']							= 'SEO Rating indicates the rating of the page for the current language for SEO. It takes a value from 0 to 100.';

?>