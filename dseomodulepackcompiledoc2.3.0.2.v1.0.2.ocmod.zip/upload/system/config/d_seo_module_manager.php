<?php 
$_['d_seo_module_manager_setting'] = array(
	'list_limit' => '20',
	'sheet' => array(
		'category' => array(
			'code' => 'category',
			'icon' => 'fa-navicon',
			'name' => 'text_category',
			'sort_order' => '1',
			'field_index' => 'category_id',
			'field' => array(
				'category_id' => array(
					'code' => 'category_id',
					'name' => 'text_category_id',
					'type' => 'link',
					'sort_order' => '1',
					'multi_store' => false,
					'multi_language' => false,
					'list_status' => true,
					'export_status' => true,
					'required' => true
				),
				'name' => array(
					'code' => 'name',
					'name' => 'text_category_name',
					'type' => 'text',
					'sort_order' => '2',
					'multi_store' => false,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'description' => array(
					'code' => 'description',
					'name' => 'text_description',
					'type' => 'textarea',
					'sort_order' => '3',
					'multi_store' => false,
					'multi_language' => true,
					'list_status' => false,
					'export_status' => true,
					'required' => false
				),
				'meta_title' => array(
					'code' => 'meta_title',
					'name' => 'text_meta_title',
					'type' => 'text',
					'sort_order' => '4',
					'multi_store' => false,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'meta_description' => array(
					'code' => 'meta_description',
					'name' => 'text_meta_description',
					'type' => 'textarea',
					'sort_order' => '5',
					'multi_store' => false,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'meta_keyword' => array(
					'code' => 'meta_keyword',
					'name' => 'text_meta_keyword',
					'type' => 'textarea',
					'sort_order' => '6',
					'multi_store' => false,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				)
			)
		),
		'product' => array(
			'code' => 'product',
			'icon' => 'fa-shopping-cart',
			'name' => 'text_product',
			'sort_order' => '2',
			'field_index' => 'product_id',
			'field' => array(
				'product_id' => array(
					'code' => 'product_id',
					'name' => 'text_product_id',
					'type' => 'link',
					'sort_order' => '1',
					'multi_store' => false,
					'multi_language' => false,
					'list_status' => true,
					'export_status' => true,
					'required' => true
				),
				'name' => array(
					'code' => 'name',
					'name' => 'text_product_name',
					'type' => 'text',
					'sort_order' => '2',
					'multi_store' => false,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'description' => array(
					'code' => 'description',
					'name' => 'text_description',
					'type' => 'textarea',
					'sort_order' => '3',
					'multi_store' => false,
					'multi_language' => true,
					'list_status' => false,
					'export_status' => true,
					'required' => false
				),
				'meta_title' => array(
					'code' => 'meta_title',
					'name' => 'text_meta_title',
					'type' => 'text',
					'sort_order' => '4',
					'multi_store' => false,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'meta_description' => array(
					'code' => 'meta_description',
					'name' => 'text_meta_description',
					'type' => 'textarea',
					'sort_order' => '5',
					'multi_store' => false,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'meta_keyword' => array(
					'code' => 'meta_keyword',
					'name' => 'text_meta_keyword',
					'type' => 'textarea',
					'sort_order' => '6',
					'multi_store' => false,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'tag' => array(
					'code' => 'tag',
					'name' => 'text_tag',
					'type' => 'text',
					'sort_order' => '7',
					'multi_store' => false,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				)
			)
		),
		'manufacturer' => array(
			'code' => 'manufacturer',
			'icon' => 'fa-tag',
			'name' => 'text_manufacturer',
			'sort_order' => '3',
			'field_index' => 'manufacturer_id',
			'field' => array(
				'manufacturer_id' => array(
					'code' => 'manufacturer_id',
					'name' => 'text_manufacturer_id',
					'type' => 'link',
					'sort_order' => '1',
					'multi_store' => false,
					'multi_language' => false,
					'list_status' => true,
					'export_status' => true,
					'required' => true
				),
				'name' => array(
					'code' => 'name',
					'name' => 'text_manufacturer_name',
					'type' => 'text',
					'sort_order' => '2',
					'multi_store' => false,
					'multi_language' => false,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				)
			)
		),
		'information' => array(
			'code' => 'information',
			'icon' => 'fa-info-circle',
			'name' => 'text_information',
			'sort_order' => '4',
			'field_index' => 'information_id',
			'field' => array(
				'information_id' => array(
					'code' => 'information_id',
					'name' => 'text_information_id',
					'type' => 'link',
					'sort_order' => '1',
					'multi_store' => false,
					'multi_language' => false,
					'list_status' => true,
					'export_status' => true,
					'required' => true
				),
				'title' => array(
					'code' => 'title',
					'name' => 'text_information_title',
					'type' => 'text',
					'sort_order' => '2',
					'multi_store' => false,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'description' => array(
					'code' => 'description',
					'name' => 'text_description',
					'type' => 'textarea',
					'sort_order' => '3',
					'multi_store' => false,
					'multi_language' => true,
					'list_status' => false,
					'export_status' => true,
					'required' => false
				),
				'meta_title' => array(
					'code' => 'meta_title',
					'name' => 'text_meta_title',
					'type' => 'text',
					'sort_order' => '4',
					'multi_store' => false,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'meta_description' => array(
					'code' => 'meta_description',
					'name' => 'text_meta_description',
					'type' => 'textarea',
					'sort_order' => '5',
					'multi_store' => false,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'meta_keyword' => array(
					'code' => 'meta_keyword',
					'name' => 'text_meta_keyword',
					'type' => 'textarea',
					'sort_order' => '6',
					'multi_store' => false,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				)
			)
		)
	)
);
$_['d_seo_module_manager_feature_setting'] = array(
	'export_import_of_all_seo_parameters' => array(
		'name' => 'text_export_import_of_all_seo_parameters',
		'image' => 'd_seo_module_manager/feature/export_import_of_all_seo_parameters.svg',
		'href' => 'https://opencartseomodule.com/export-import-of-all-seo-parameters',
	),
	'manage_all_seo_data_for_all_pages' => array(
		'name' => 'text_manage_all_seo_data_for_all_pages',
		'image' => 'd_seo_module_manager/feature/manage_all_seo_data_for_all_pages.svg',
		'href' => 'https://opencartseomodule.com/manage-all-seo-data-from-one-place',
	),
	'flexible_settings_for_overview' => array(
		'name' => 'text_flexible_settings_for_overview',
		'image' => 'd_seo_module_manager/feature/flexible_settings_for_overview.svg',
		'href' => 'https://opencartseomodule.com/flexible-settings-for-overview',
	),
	'flexible_settings-for-export-import-to-excel' => array(
		'name' => 'text_flexible_settings-for-export-import-to-excel',
		'image' => 'd_seo_module_manager/feature/flexible_settings-for-export-import-to-excel.svg',
		'href' => 'https://opencartseomodule.com/settings-for-export-import-to-excel',
	),
	'seo_module_manager_api' => array(
		'name' => 'text_seo_module_manager_api',
		'image' => 'd_seo_module_manager/feature/seo_module_manager_api.svg',
		'href' => 'https://opencartseomodule.com/seo-module-manager-api',
	)
);
?>