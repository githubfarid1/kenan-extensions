<?php 
$_['d_seo_module_adviser_field_setting'] = array(
	'sheet' => array(
		'category' => array(
			'code' => 'category',
			'field' => array(
				'seo_rating' => array(
					'code' => 'seo_rating',
					'name' => 'text_seo_rating',
					'description' => 'help_seo_rating',
					'type' => 'info',
					'sort_order' => '50',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				)
			)
		),
		'product' => array(
			'code' => 'product',
			'field' => array(
				'seo_rating' => array(
					'code' => 'seo_rating',
					'name' => 'text_seo_rating',
					'description' => 'help_seo_rating',
					'type' => 'info',
					'sort_order' => '50',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				)
			)
		),
		'manufacturer' => array(
			'code' => 'manufacturer',
			'field' => array(
				'seo_rating' => array(
					'code' => 'seo_rating',
					'name' => 'text_seo_rating',
					'description' => 'help_seo_rating',
					'type' => 'info',
					'sort_order' => '50',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				)
			)
		),
		'information' => array(
			'code' => 'information',
			'field' => array(
				'seo_rating' => array(
					'code' => 'seo_rating',
					'name' => 'text_seo_rating',
					'description' => 'help_seo_rating',
					'type' => 'info',
					'sort_order' => '50',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				)
			)
		),
		'custom_page' => array(
			'code' => 'custom_page',
			'field' => array(
				'seo_rating' => array(
					'code' => 'seo_rating',
					'name' => 'text_seo_rating',
					'description' => 'help_seo_rating',
					'type' => 'info',
					'sort_order' => '50',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				)
			)
		)
	)
);
$_['d_seo_module_adviser_toolbar_setting'] = array(
	'widget' => array(
		'seo_rating' => array(
			'code' 	=> 'seo_rating',
			'name' 	=> 'text_seo_rating',
			'status' => true,
			'sort_order' => '10',
			'html' => ''
		)
	)
);
$_['d_seo_module_adviser_feature_setting'] = array(
	'seo_insights_per_page' => array(
		'name' => 'text_seo_insights_per_page',
		'image' => 'd_seo_module_adviser/feature/seo_insights_per_page.svg',
		'href' => 'https://opencartseomodule.com/seo-insights-per-page',
	),
	'multi_language_url_support_for_seo_rating' => array(
		'name' => 'text_multi_language_url_support_for_seo_rating',
		'image' => 'd_seo_module_adviser/feature/multi_language_url_support_for_seo_rating.svg',
		'href' => 'https://opencartseomodule.com/multi-language-url-support-for-seo-rating',
	),
	'seo_rating_per_page' => array(
		'name' => 'text_seo_rating_per_page',
		'image' => 'd_seo_module_adviser/feature/seo_rating_per_page.svg',
		'href' => 'https://opencartseomodule.com/seo-rating-for-every-page',
	),
	'seo_rating_toolbar_widget' => array(
		'name' => 'text_seo_rating_toolbar_widget',
		'image' => 'd_seo_module_adviser/feature/seo_rating_toolbar_widget.svg',
		'href' => 'https://opencartseomodule.com/seo-rating-toolbar-widget',
	),
	'seo_module_adviser_api' => array(
		'name' => 'text_seo_module_adviser_api',
		'image' => 'd_seo_module_adviser/feature/seo_module_adviser_api.svg',
		'href' => 'https://opencartseomodule.com/seo-module-adviser-api',
	)
);
?>