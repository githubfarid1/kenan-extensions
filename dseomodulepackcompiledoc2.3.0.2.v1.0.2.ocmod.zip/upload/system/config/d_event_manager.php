<?php 
$_['d_event_manager_setting'] = array(
    'config' => 'd_event_manager', 
    'tests' => array(),
    'skipped_models' => array('total')
);
    