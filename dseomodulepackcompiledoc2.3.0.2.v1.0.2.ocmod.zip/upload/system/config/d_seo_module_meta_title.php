<?php 
$_['d_seo_module_meta_title_setting'] = array(
	'list_limit' => '10',
	'duplicate_status' => true,
	'empty_status' => true,
	'stores_id' => array()
);
?>