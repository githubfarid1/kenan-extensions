<?php 
$_['d_seo_module_meta_setting'] = array(
	'meta_title_page_template_default' => 'Page [page_number].',
	'meta_description_page_template_default' => 'Page [page_number].',
	'sheet' => array(
		'category' => array(
			'code' => 'category',
			'icon' => 'fa-navicon',
			'name' => 'text_category',
			'custom_title_1_class' => '#content h1',
			'custom_title_2_class' => '#content h2',
			'custom_image_class' => '#content .col-sm-2 img',
			'meta_title_page' => true,
			'meta_description_page' => true
		),
		'product' => array(
			'code' => 'product',
			'icon' => 'fa-shopping-cart',
			'name' => 'text_product',
			'custom_title_1_class' => '#content h1',
			'custom_title_2_class' => '#content h2',
			'custom_image_class' => '#content a.thumbnail, #content .thumbnail img'
		),
		'manufacturer' => array(
			'code' => 'manufacturer',
			'icon' => 'fa-tag',
			'name' => 'text_manufacturer',
			'before_description_class' => '#content h2',
			'custom_title_1_class' => '#content h1',
			'custom_title_2_class' => '#content h2',
			'custom_image_class' => '#content img',
			'meta_title_page' => true,
			'meta_description_page' => true
		),
		'information' => array(
			'code' => 'information',
			'icon' => 'fa-info-circle',
			'name' => 'text_information',
			'custom_title_1_class' => '#content h1',
			'custom_title_2_class' => '#content h2'
		),
		'search' => array(
			'code' => 'search',
			'icon' => 'fa-search',
			'name' => 'text_search',
			'meta_title_page' => true
		),
		'special' => array(
			'code' => 'special',
			'icon' => 'fa-gift',
			'name' => 'text_special',
			'meta_title_page' => true
		)
	)
);
$_['d_seo_module_meta_field_setting'] = array(
	'sheet' => array(
		'category' => array(
			'code' => 'category',
			'field' => array(
				'name' => array(
					'code' => 'name',
					'name' => 'text_category_name',
					'description' => '',
					'type' => 'text',
					'sort_order' => '1',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => true
				),
				'description' => array(
					'code' => 'description',
					'name' => 'text_description',
					'description' => '',
					'type' => 'textarea',
					'sort_order' => '2',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				),
				'meta_title' => array(
					'code' => 'meta_title',
					'name' => 'text_meta_title',
					'description' => '',
					'type' => 'text',
					'sort_order' => '3',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => true
				),
				'meta_description' => array(
					'code' => 'meta_description',
					'name' => 'text_meta_description',
					'description' => '',
					'type' => 'textarea',
					'sort_order' => '4',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				),
				'meta_keyword' => array(
					'code' => 'meta_keyword',
					'name' => 'text_meta_keyword',
					'description' => '',
					'type' => 'textarea',
					'sort_order' => '5',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				),
				'custom_title_1' => array(
					'code' => 'custom_title_1',
					'name' => 'text_custom_title_1',
					'description' => 'help_category_custom_title',
					'type' => 'text',
					'sort_order' => '10',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				),
				'custom_title_2' => array(
					'code' => 'custom_title_2',
					'name' => 'text_custom_title_2',
					'description' => 'help_category_custom_title',
					'type' => 'text',
					'sort_order' => '11',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				),
				'custom_image_title' => array(
					'code' => 'custom_image_title',
					'name' => 'text_custom_image_title',
					'description' => 'help_category_custom_image_title',
					'type' => 'text',
					'sort_order' => '12',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				),
				'custom_image_alt' => array(
					'code' => 'custom_image_alt',
					'name' => 'text_custom_image_alt',
					'description' => 'help_category_custom_image_alt',
					'type' => 'text',
					'sort_order' => '13',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				),
				'meta_robots' => array(
					'code' => 'meta_robots',
					'name' => 'text_meta_robots',
					'description' => 'help_category_meta_robots',
					'type' => 'select',
					'option' => array(
						'0' => array(
							'code' => 'index,follow', 
							'name' => 'index,follow'
						),
						'1' => array(
							'code' => 'noindex,follow', 
							'name' => 'noindex,follow'
						),
						'2' => array(
							'code' => 'index,nofollow', 
							'name' => 'index,nofollow'
						),
						'3' => array(
							'code' => 'noindex,nofollow', 
							'name' => 'noindex,nofollow'
						)
					),
					'sort_order' => '14',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				)
			)
		),
		'product' => array(
			'code' => 'product',
			'field' => array(
				'name' => array(
					'code' => 'name',
					'name' => 'text_product_name',
					'description' => '',
					'type' => 'text',
					'sort_order' => '2',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => true
				),
				'description' => array(
					'code' => 'description',
					'name' => 'text_description',
					'description' => '',
					'type' => 'textarea',
					'sort_order' => '3',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				),
				'meta_title' => array(
					'code' => 'meta_title',
					'name' => 'text_meta_title',
					'description' => '',
					'type' => 'text',
					'sort_order' => '4',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => true
				),
				'meta_description' => array(
					'code' => 'meta_description',
					'name' => 'text_meta_description',
					'description' => '',
					'type' => 'textarea',
					'sort_order' => '5',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				),
				'meta_keyword' => array(
					'code' => 'meta_keyword',
					'name' => 'text_meta_keyword',
					'description' => '',
					'type' => 'textarea',
					'sort_order' => '6',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				),
				'tag' => array(
					'code' => 'tag',
					'name' => 'text_tag',
					'description' => 'help_product_tag',
					'type' => 'text',
					'sort_order' => '7',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				),
				'custom_title_1' => array(
					'code' => 'custom_title_1',
					'name' => 'text_custom_title_1',
					'description' => 'help_product_custom_title',
					'type' => 'text',
					'sort_order' => '10',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				),
				'custom_title_2' => array(
					'code' => 'custom_title_2',
					'name' => 'text_custom_title_2',
					'description' => 'help_product_custom_title',
					'type' => 'text',
					'sort_order' => '11',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				),
				'custom_image_title' => array(
					'code' => 'custom_image_title',
					'name' => 'text_custom_image_title',
					'description' => 'help_product_custom_image_title',
					'type' => 'text',
					'sort_order' => '12',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				),
				'custom_image_alt' => array(
					'code' => 'custom_image_alt',
					'name' => 'text_custom_image_alt',
					'description' => 'help_product_custom_image_alt',
					'type' => 'text',
					'sort_order' => '13',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				),
				'meta_robots' => array(
					'code' => 'meta_robots',
					'name' => 'text_meta_robots',
					'description' => 'help_product_meta_robots',
					'type' => 'select',
					'option' => array(
						'0' => array(
							'code' => 'index,follow', 
							'name' => 'index,follow'
						),
						'1' => array(
							'code' => 'noindex,follow', 
							'name' => 'noindex,follow'
						),
						'2' => array(
							'code' => 'index,nofollow', 
							'name' => 'index,nofollow'
						),
						'3' => array(
							'code' => 'noindex,nofollow', 
							'name' => 'noindex,nofollow'
						)
					),
					'sort_order' => '14',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				)
			)
		),
		'manufacturer' => array(
			'code' => 'manufacturer',
			'field' => array(
				'name' => array(
					'code' => 'name',
					'name' => 'text_manufacturer_name',
					'description' => '',
					'type' => 'text',
					'sort_order' => '10',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => true
				),
				'description' => array(
					'code' => 'description',
					'name' => 'text_description',
					'description' => '',
					'type' => 'textarea',
					'sort_order' => '11',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				),
				'meta_title' => array(
					'code' => 'meta_title',
					'name' => 'text_meta_title',
					'description' => '',
					'type' => 'text',
					'sort_order' => '12',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => true
				),
				'meta_description' => array(
					'code' => 'meta_description',
					'name' => 'text_meta_description',
					'description' => '',
					'type' => 'textarea',
					'sort_order' => '13',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				),
				'meta_keyword' => array(
					'code' => 'meta_keyword',
					'name' => 'text_meta_keyword',
					'description' => '',
					'type' => 'textarea',
					'sort_order' => '14',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				),
				'custom_title_1' => array(
					'code' => 'custom_title_1',
					'name' => 'text_custom_title_1',
					'description' => 'help_manufacturer_custom_title',
					'type' => 'text',
					'sort_order' => '15',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				),
				'custom_title_2' => array(
					'code' => 'custom_title_2',
					'name' => 'text_custom_title_2',
					'description' => 'help_manufacturer_custom_title',
					'type' => 'text',
					'sort_order' => '16',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				),
				'custom_image_title' => array(
					'code' => 'custom_image_title',
					'name' => 'text_custom_image_title',
					'description' => 'help_manufacturer_custom_image_title',
					'type' => 'text',
					'sort_order' => '17',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				),
				'custom_image_alt' => array(
					'code' => 'custom_image_alt',
					'name' => 'text_custom_image_alt',
					'description' => 'help_manufacturer_custom_image_alt',
					'type' => 'text',
					'sort_order' => '18',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				),
				'meta_robots' => array(
					'code' => 'meta_robots',
					'name' => 'text_meta_robots',
					'description' => 'help_manufacturer_meta_robots',
					'type' => 'select',
					'option' => array(
						'0' => array(
							'code' => 'index,follow', 
							'name' => 'index,follow'
						),
						'1' => array(
							'code' => 'noindex,follow', 
							'name' => 'noindex,follow'
						),
						'2' => array(
							'code' => 'index,nofollow', 
							'name' => 'index,nofollow'
						),
						'3' => array(
							'code' => 'noindex,nofollow', 
							'name' => 'noindex,nofollow'
						)
					),
					'sort_order' => '19',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				)
			)
		),
		'information' => array(
			'code' => 'information',
			'field' => array(
				'title' => array(
					'code' => 'title',
					'name' => 'text_information_title',
					'description' => '',
					'type' => 'text',
					'sort_order' => '2',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => true
				),
				'description' => array(
					'code' => 'description',
					'name' => 'text_description',
					'description' => '',
					'type' => 'textarea',
					'sort_order' => '3',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => true
				),
				'meta_title' => array(
					'code' => 'meta_title',
					'name' => 'text_meta_title',
					'description' => '',
					'type' => 'text',
					'sort_order' => '4',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => true
				),
				'meta_description' => array(
					'code' => 'meta_description',
					'name' => 'text_meta_description',
					'description' => '',
					'type' => 'textarea',
					'sort_order' => '5',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				),
				'meta_keyword' => array(
					'code' => 'meta_keyword',
					'name' => 'text_meta_keyword',
					'description' => '',
					'type' => 'textarea',
					'sort_order' => '6',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				),
				'custom_title_1' => array(
					'code' => 'custom_title_1',
					'name' => 'text_custom_title_1',
					'description' => 'help_information_custom_title',
					'type' => 'text',
					'sort_order' => '10',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				),
				'custom_title_2' => array(
					'code' => 'custom_title_2',
					'name' => 'text_custom_title_2',
					'description' => 'help_information_custom_title',
					'type' => 'text',
					'sort_order' => '11',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				),
				'meta_robots' => array(
					'code' => 'meta_robots',
					'name' => 'text_meta_robots',
					'description' => 'help_information_meta_robots',
					'type' => 'select',
					'option' => array(
						'0' => array(
							'code' => 'index,follow', 
							'name' => 'index,follow'
						),
						'1' => array(
							'code' => 'noindex,follow', 
							'name' => 'noindex,follow'
						),
						'2' => array(
							'code' => 'index,nofollow', 
							'name' => 'index,nofollow'
						),
						'3' => array(
							'code' => 'noindex,nofollow', 
							'name' => 'noindex,nofollow'
						)
					),
					'sort_order' => '12',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				)
			)
		),
		'custom_page' => array(
			'code' => 'custom_page',
			'field' => array(
				'meta_title' => array(
					'code' => 'meta_title',
					'name' => 'text_meta_title',
					'description' => '',
					'type' => 'text',
					'sort_order' => '1',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => true
				),
				'meta_description' => array(
					'code' => 'meta_description',
					'name' => 'text_meta_description',
					'description' => '',
					'type' => 'textarea',
					'sort_order' => '2',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				),
				'meta_keyword' => array(
					'code' => 'meta_keyword',
					'name' => 'text_meta_keyword',
					'description' => '',
					'type' => 'textarea',
					'sort_order' => '3',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				),
				'meta_robots' => array(
					'code' => 'meta_robots',
					'name' => 'text_meta_robots',
					'description' => 'help_category_meta_robots',
					'type' => 'select',
					'option' => array(
						'0' => array(
							'code' => 'index,follow', 
							'name' => 'index,follow'
						),
						'1' => array(
							'code' => 'noindex,follow', 
							'name' => 'noindex,follow'
						),
						'2' => array(
							'code' => 'index,nofollow', 
							'name' => 'index,nofollow'
						),
						'3' => array(
							'code' => 'noindex,nofollow', 
							'name' => 'noindex,nofollow'
						)
					),
					'sort_order' => '4',
					'multi_store' => true,
					'multi_language' => true,
					'multi_store_status' => false,
					'required' => false
				)
			)
		)
	)
);			
$_['d_seo_module_meta_generator_setting'] = array(
	'sheet' => array(
		'category' => array(
			'code' => 'category',
			'icon' => 'fa-navicon',
			'name' => 'text_category',
			'sort_order' => '1',
			'field' => array(
				'meta_title' => array(
					'code' => 'meta_title',
					'name' => 'text_meta_title',
					'description' => 'help_generate_category_meta_title',
					'sort_order' => '1',
					'template_default' => '[name]',
					'template_button' => array(
						'[name]' => '[name]', 
						'[parent_name]' => '[parent_name]', 
						'[description]'=> '[description]', 
						'[target_keyword]' => '[target_keyword]', 
						'[sample_products]' => '[sample_products]', 
						'[total_products]' => '[total_products]', 
						'[store_name]' => '[store_name]', 
						'[store_title]' => '[store_title]'
					),
					'multi_language' => true,
					'translit_symbol_status' => false,
					'translit_language_symbol_status' => false,
					'transform_language_symbol_id' => '0',
					'trim_symbol_status' => false,
					'overwrite' => false,
					'button_generate' => true,
					'button_clear' => true
				),
				'meta_description' => array(
					'code' => 'meta_description',
					'name' => 'text_meta_description',
					'description' => 'help_generate_category_meta_description',
					'sort_order' => '2',
					'template_default' => '[name] - [description#sentences=1]',
					'template_button' => array(
						'[name]' => '[name]', 
						'[parent_name]' => '[parent_name]', 
						'[description]'=> '[description]', 
						'[target_keyword]' => '[target_keyword]', 
						'[sample_products]' => '[sample_products]', 
						'[total_products]' => '[total_products]', 
						'[store_name]' => '[store_name]', 
						'[store_title]' => '[store_title]'
					),
					'multi_language' => true,
					'translit_symbol_status' => false,
					'translit_language_symbol_status' => false,
					'transform_language_symbol_id' => '0',
					'trim_symbol_status' => false,
					'overwrite' => false,
					'button_generate' => true,
					'button_clear' => true
				),
				'meta_keyword' => array(
					'code' => 'meta_keyword',
					'name' => 'text_meta_keyword',
					'description' => 'help_generate_category_meta_keyword',
					'sort_order' => '3',
					'template_default' => '[name], [parent_name]',
					'template_button' => array(
						'[name]' => '[name]', 
						'[parent_name]' => '[parent_name]', 
						'[description]'=> '[description]', 
						'[target_keyword]' => '[target_keyword]', 
						'[sample_products]' => '[sample_products]', 
						'[total_products]' => '[total_products]', 
						'[store_name]' => '[store_name]', 
						'[store_title]' => '[store_title]'
					),
					'multi_language' => true,
					'translit_symbol_status' => false,
					'translit_language_symbol_status' => false,
					'transform_language_symbol_id' => '0',
					'trim_symbol_status' => false,
					'overwrite' => false,
					'button_generate' => true,
					'button_clear' => true
				),
				'custom_title_1' => array(
					'code' => 'custom_title_1',
					'name' => 'text_custom_title_1',
					'description' => 'help_generate_category_custom_title_1',
					'sort_order' => '10',
					'template_default' => '[name]',
					'template_button' => array(
						'[name]' => '[name]', 
						'[parent_name]' => '[parent_name]', 
						'[description]'=> '[description]', 
						'[target_keyword]' => '[target_keyword]', 
						'[sample_products]' => '[sample_products]', 
						'[total_products]' => '[total_products]', 
						'[store_name]' => '[store_name]', 
						'[store_title]' => '[store_title]'
					),
					'multi_language' => true,
					'translit_symbol_status' => false,
					'translit_language_symbol_status' => false,
					'transform_language_symbol_id' => '0',
					'trim_symbol_status' => false,
					'overwrite' => false,
					'button_generate' => true,
					'button_clear' => true
				),
				'custom_title_2' => array(
					'code' => 'custom_title_2',
					'name' => 'text_custom_title_2',
					'description' => 'help_generate_category_custom_title_2',
					'sort_order' => '11',
					'template_default' => '[name]',
					'template_button' => array(
						'[name]' => '[name]', 
						'[parent_name]' => '[parent_name]', 
						'[description]'=> '[description]', 
						'[target_keyword]' => '[target_keyword]', 
						'[sample_products]' => '[sample_products]', 
						'[total_products]' => '[total_products]', 
						'[store_name]' => '[store_name]', 
						'[store_title]' => '[store_title]'
					),
					'multi_language' => true,
					'translit_symbol_status' => false,
					'translit_language_symbol_status' => false,
					'transform_language_symbol_id' => '0',
					'trim_symbol_status' => false,
					'overwrite' => false,
					'button_generate' => true,
					'button_clear' => true
				),
				'custom_image_name' => array(
					'code' => 'custom_image_name',
					'name' => 'text_custom_image_name',
					'description' => 'help_generate_category_custom_image_name',
					'sort_order' => '12',
					'template_default' => '[name]',
					'template_button' => array(
						'[name]' => '[name]', 
						'[parent_name]' => '[parent_name]', 
						'[description]'=> '[description]', 
						'[target_keyword]' => '[target_keyword]', 
						'[sample_products]' => '[sample_products]', 
						'[total_products]' => '[total_products]', 
						'[store_name]' => '[store_name]', 
						'[store_title]' => '[store_title]'
					),
					'multi_language' => false,
					'translit_language_symbol_status' => false,
					'transform_language_symbol_id' => '1',
					'trim_symbol_status' => true,
					'button_generate' => true,
					'button_clear' => true
				),
				'custom_image_title' => array(
					'code' => 'custom_image_title',
					'name' => 'text_custom_image_title',
					'description' => 'help_generate_category_custom_image_title',
					'sort_order' => '13',
					'template_default' => '[name]',
					'template_button' => array(
						'[name]' => '[name]', 
						'[parent_name]' => '[parent_name]', 
						'[description]'=> '[description]', 
						'[target_keyword]' => '[target_keyword]', 
						'[sample_products]' => '[sample_products]', 
						'[total_products]' => '[total_products]', 
						'[store_name]' => '[store_name]', 
						'[store_title]' => '[store_title]'
					),
					'multi_language' => true,
					'translit_symbol_status' => true,
					'translit_language_symbol_status' => false,
					'transform_language_symbol_id' => '0',
					'trim_symbol_status' => true,
					'overwrite' => false,
					'button_generate' => true,
					'button_clear' => true
				),
				'custom_image_alt' => array(
					'code' => 'custom_image_alt',
					'name' => 'text_custom_image_alt',
					'description' => 'help_generate_category_custom_image_alt',
					'sort_order' => '14',
					'template_default' => '[name]',
					'template_button' => array(
						'[name]' => '[name]', 
						'[parent_name]' => '[parent_name]', 
						'[description]'=> '[description]', 
						'[target_keyword]' => '[target_keyword]', 
						'[sample_products]' => '[sample_products]', 
						'[total_products]' => '[total_products]', 
						'[store_name]' => '[store_name]', 
						'[store_title]' => '[store_title]'
					),
					'multi_language' => true,
					'translit_symbol_status' => true,
					'translit_language_symbol_status' => false,
					'transform_language_symbol_id' => '0',
					'trim_symbol_status' => true,
					'overwrite' => false,
					'button_generate' => true,
					'button_clear' => true
				)
			),
			'button_popup' => array(
				'[description]' => array(
					'code' => '[description]',
					'name' => 'text_insert_description',
					'field' => array(
						'sentences' => array(
							'code' => 'sentences',
							'name' => 'text_sentence_total',
							'type' => 'text',
							'value' => '1'
						)
					)
				),
				'[target_keyword]' => array(
					'code' => '[target_keyword]',
					'name' => 'text_insert_target_keyword',
					'field' => array(
						'number' => array(
							'code' => 'number',
							'name' => 'text_keyword_number',
							'type' => 'text',
							'value' => '1'
						)
					)
				),
				'[sample_products]' => array(
					'code' => '[sample_products]',
					'name' => 'text_insert_sample_products',
					'field' => array(
						'total' => array(
							'code' => 'total',
							'name' => 'text_product_total',
							'type' => 'text',
							'value' => '3'
						),
						'separator' => array(
							'code' => 'separator',
							'name' => 'text_product_separator',
							'type' => 'text',
							'value' => ','
						)
					)
				)
			)
		),
		'product' => array(
			'code' => 'product',
			'icon' => 'fa-shopping-cart',
			'name' => 'text_product',
			'sort_order' => '2',
			'field' => array(
				'meta_title' => array(
					'code' => 'meta_title',
					'name' => 'text_meta_title',
					'description' => 'help_generate_product_meta_title',
					'sort_order' => '1',
					'template_default' => '[name]',
					'template_button' => array(
						'[name]' => '[name]', 
						'[description]' => '[description]', 
						'[target_keyword]' => '[target_keyword]', 
						'[category]' => '[category]', 
						'[model]' => '[model]', 
						'[sku]' => '[sku]', 
						'[upc]' => '[upc]', 
						'[manufacturer]' => '[manufacturer]', 
						'[store_name]' => '[store_name]', 
						'[store_title]'=> '[store_title]'
					),
					'multi_language' => true,
					'translit_symbol_status' => false,
					'translit_language_symbol_status' => false,
					'transform_language_symbol_id' => '0',
					'trim_symbol_status' => false,
					'overwrite' => false,
					'button_generate' => true,
					'button_clear' => true
				),
				'meta_description' => array(
					'code' => 'meta_description',
					'name' => 'text_meta_description',
					'description' => 'help_generate_product_meta_description',
					'sort_order' => '2',
					'template_default' => '[name] - [model] ([manufacturer]). [description#sentences=1]',
					'template_button' => array(
						'[name]' => '[name]', 
						'[description]' => '[description]', 
						'[target_keyword]' => '[target_keyword]', 
						'[category]' => '[category]', 
						'[model]' => '[model]', 
						'[sku]' => '[sku]', 
						'[upc]' => '[upc]', 
						'[manufacturer]' => '[manufacturer]', 
						'[store_name]' => '[store_name]', 
						'[store_title]'=> '[store_title]'
					),
					'multi_language' => true,
					'translit_symbol_status' => false,
					'translit_language_symbol_status' => false,
					'transform_language_symbol_id' => '0',
					'trim_symbol_status' => false,
					'overwrite' => false,
					'button_generate' => true,
					'button_clear' => true
				),
				'meta_keyword' => array(
					'code' => 'meta_keyword',
					'name' => 'text_meta_keyword',
					'description' => 'help_generate_product_meta_keyword',
					'sort_order' => '3',
					'template_default' => '[name], [category], [manufacturer]',
					'template_button' => array(
						'[name]' => '[name]', 
						'[description]' => '[description]', 
						'[target_keyword]' => '[target_keyword]', 
						'[category]' => '[category]', 
						'[model]' => '[model]', 
						'[sku]' => '[sku]', 
						'[upc]' => '[upc]', 
						'[manufacturer]' => '[manufacturer]', 
						'[store_name]' => '[store_name]', 
						'[store_title]'=> '[store_title]'
					),
					'multi_language' => true,
					'translit_symbol_status' => false,
					'translit_language_symbol_status' => false,
					'transform_language_symbol_id' => '0',
					'trim_symbol_status' => false,
					'overwrite' => false,
					'button_generate' => true,
					'button_clear' => true
				),
				'tag' => array(
					'code' => 'tag',
					'name' => 'text_tag',
					'description' => 'help_generate_product_tag',
					'sort_order' => '4',
					'template_default' => '[name], [category], [manufacturer]',
					'template_button' => array(
						'[name]' => '[name]', 
						'[description]' => '[description]', 
						'[target_keyword]' => '[target_keyword]', 
						'[category]' => '[category]', 
						'[model]' => '[model]', 
						'[sku]' => '[sku]', 
						'[upc]' => '[upc]', 
						'[manufacturer]' => '[manufacturer]', 
						'[store_name]' => '[store_name]', 
						'[store_title]'=> '[store_title]'
					),
					'multi_language' => true,
					'translit_symbol_status' => false,
					'translit_language_symbol_status' => false,
					'transform_language_symbol_id' => '0',
					'trim_symbol_status' => false,
					'overwrite' => false,
					'button_generate' => true,
					'button_clear' => true
				),
				'custom_title_1' => array(
					'code' => 'custom_title_1',
					'name' => 'text_custom_title_1',
					'description' => 'help_generate_product_custom_title_1',
					'sort_order' => '10',
					'template_default' => '[name]',
					'template_button' => array(
						'[name]' => '[name]', 
						'[description]' => '[description]', 
						'[target_keyword]' => '[target_keyword]', 
						'[category]' => '[category]', 
						'[model]' => '[model]', 
						'[sku]' => '[sku]', 
						'[upc]' => '[upc]', 
						'[manufacturer]' => '[manufacturer]', 
						'[store_name]' => '[store_name]', 
						'[store_title]'=> '[store_title]'
					),
					'multi_language' => true,
					'translit_symbol_status' => false,
					'translit_language_symbol_status' => false,
					'transform_language_symbol_id' => '0',
					'trim_symbol_status' => false,
					'overwrite' => false,
					'button_generate' => true,
					'button_clear' => true
				),
				'custom_title_2' => array(
					'code' => 'custom_title_2',
					'name' => 'text_custom_title_2',
					'description' => 'help_generate_product_custom_title_2',
					'sort_order' => '11',
					'template_default' => '[name]',
					'template_button' => array(
						'[name]' => '[name]', 
						'[description]' => '[description]', 
						'[target_keyword]' => '[target_keyword]', 
						'[category]' => '[category]', 
						'[model]' => '[model]', 
						'[sku]' => '[sku]', 
						'[upc]' => '[upc]', 
						'[manufacturer]' => '[manufacturer]', 
						'[store_name]' => '[store_name]', 
						'[store_title]'=> '[store_title]'
					),
					'multi_language' => true,
					'translit_symbol_status' => false,
					'translit_language_symbol_status' => false,
					'transform_language_symbol_id' => '0',
					'trim_symbol_status' => false,
					'overwrite' => false,
					'button_generate' => true,
					'button_clear' => true
				),
				'custom_image_name' => array(
					'code' => 'custom_image_name',
					'name' => 'text_custom_image_name',
					'description' => 'help_generate_product_custom_image_name',
					'sort_order' => '12',
					'template_default' => '[name]',
					'template_button' => array(
						'[name]' => '[name]', 
						'[description]' => '[description]', 
						'[target_keyword]' => '[target_keyword]', 
						'[category]' => '[category]', 
						'[model]' => '[model]', 
						'[sku]' => '[sku]', 
						'[upc]' => '[upc]', 
						'[manufacturer]' => '[manufacturer]', 
						'[store_name]' => '[store_name]', 
						'[store_title]'=> '[store_title]'
					),
					'multi_language' => false,
					'translit_language_symbol_status' => false,
					'transform_language_symbol_id' => '1',
					'trim_symbol_status' => true,
					'button_generate' => true,
					'button_clear' => true
				),
				'custom_image_title' => array(
					'code' => 'custom_image_title',
					'name' => 'text_custom_image_title',
					'description' => 'help_generate_product_custom_image_title',
					'sort_order' => '13',
					'template_default' => '[name] [category]',
					'template_button' => array(
						'[name]' => '[name]', 
						'[description]' => '[description]', 
						'[target_keyword]' => '[target_keyword]', 
						'[category]' => '[category]', 
						'[model]' => '[model]', 
						'[sku]' => '[sku]', 
						'[upc]' => '[upc]', 
						'[manufacturer]' => '[manufacturer]', 
						'[store_name]' => '[store_name]', 
						'[store_title]'=> '[store_title]'
					),
					'multi_language' => true,
					'translit_symbol_status' => true,
					'translit_language_symbol_status' => false,
					'transform_language_symbol_id' => '0',
					'trim_symbol_status' => true,
					'overwrite' => false,
					'button_generate' => true,
					'button_clear' => true
				),
				'custom_image_alt' => array(
					'code' => 'custom_image_alt',
					'name' => 'text_custom_image_alt',
					'description' => 'help_generate_product_custom_image_alt',
					'sort_order' => '14',
					'template_default' => '[name] [category]',
					'template_button' => array(
						'[name]' => '[name]', 
						'[description]' => '[description]', 
						'[target_keyword]' => '[target_keyword]', 
						'[category]' => '[category]', 
						'[model]' => '[model]', 
						'[sku]' => '[sku]', 
						'[upc]' => '[upc]', 
						'[manufacturer]' => '[manufacturer]', 
						'[store_name]' => '[store_name]', 
						'[store_title]'=> '[store_title]'
					),
					'multi_language' => true,
					'translit_symbol_status' => true,
					'translit_language_symbol_status' => false,
					'transform_language_symbol_id' => '0',
					'trim_symbol_status' => true,
					'overwrite' => false,
					'button_generate' => true,
					'button_clear' => true
				)
			),
			'button_popup' => array(
				'[description]' => array(
					'code' => '[description]',
					'name' => 'text_insert_description',
					'field' => array(
						'sentences' => array(
							'code' => 'sentences',
							'name' => 'text_sentence_total',
							'type' => 'text',
							'value' => '1'
						)
					)
				),
				'[target_keyword]' => array(
					'code' => '[target_keyword]',
					'name' => 'text_insert_target_keyword',
					'field' => array(
						'number' => array(
							'code' => 'number',
							'name' => 'text_keyword_number',
							'type' => 'text',
							'value' => '1'
						)
					)
				)
			)
		),
		'manufacturer' => array(
			'code' => 'manufacturer',
			'icon' => 'fa-tag',
			'name' => 'text_manufacturer',
			'sort_order' => '3',
			'field' => array(
				'meta_title' => array(
					'code' => 'meta_title',
					'name' => 'text_meta_title',
					'description' => 'help_generate_manufacturer_meta_title',
					'sort_order' => '1',
					'template_default' => '[name]',
					'template_button' => array(
						'[name]'=> '[name]', 
						'[description]' => '[description]', 
						'[target_keyword]' => '[target_keyword]', 
						'[sample_products]' => '[sample_products]', 
						'[total_products]' => '[total_products]', 
						'[store_name]' => '[store_name]', 
						'[store_title]' => '[store_title]'
					),
					'multi_language' => true,
					'translit_symbol_status' => false,
					'translit_language_symbol_status' => false,
					'transform_language_symbol_id' => '0',
					'trim_symbol_status' => false,
					'overwrite' => false,
					'button_generate' => true,
					'button_clear' => true
				),
				'meta_description' => array(
					'code' => 'meta_description',
					'name' => 'text_meta_description',
					'description' => 'help_generate_manufacturer_meta_description',
					'sort_order' => '2',
					'template_default' => '[name] - [description#sentences=1]',
					'template_button' => array(
						'[name]'=> '[name]', 
						'[description]' => '[description]', 
						'[target_keyword]' => '[target_keyword]', 
						'[sample_products]' => '[sample_products]', 
						'[total_products]' => '[total_products]', 
						'[store_name]' => '[store_name]', 
						'[store_title]' => '[store_title]'
					),
					'multi_language' => true,
					'translit_symbol_status' => false,
					'translit_language_symbol_status' => false,
					'transform_language_symbol_id' => '0',
					'trim_symbol_status' => false,
					'overwrite' => false,
					'button_generate' => true,
					'button_clear' => true
				),
				'meta_keyword' => array(
					'code' => 'meta_keyword',
					'name' => 'text_meta_keyword',
					'description' => 'help_generate_manufacturer_meta_keyword',
					'sort_order' => '3',
					'template_default' => '[name]',
					'template_button' => array(
						'[name]'=> '[name]', 
						'[description]' => '[description]', 
						'[target_keyword]' => '[target_keyword]', 
						'[sample_products]' => '[sample_products]', 
						'[total_products]' => '[total_products]', 
						'[store_name]' => '[store_name]', 
						'[store_title]' => '[store_title]'
					),
					'multi_language' => true,
					'translit_symbol_status' => false,
					'translit_language_symbol_status' => false,
					'transform_language_symbol_id' => '0',
					'trim_symbol_status' => false,
					'overwrite' => false,
					'button_generate' => true,
					'button_clear' => true
				),
				'custom_title_1' => array(
					'code' => 'custom_title_1',
					'name' => 'text_custom_title_1',
					'description' => 'help_generate_manufacturer_custom_title_1',
					'sort_order' => '10',
					'template_default' => '[name]',
					'template_button' => array(
						'[name]'=> '[name]', 
						'[description]' => '[description]', 
						'[target_keyword]' => '[target_keyword]', 
						'[sample_products]' => '[sample_products]', 
						'[total_products]' => '[total_products]', 
						'[store_name]' => '[store_name]', 
						'[store_title]' => '[store_title]'
					),
					'multi_language' => true,
					'translit_symbol_status' => false,
					'translit_language_symbol_status' => false,
					'transform_language_symbol_id' => '0',
					'trim_symbol_status' => false,
					'overwrite' => false,
					'button_generate' => true,
					'button_clear' => true
				),
				'custom_title_2' => array(
					'code' => 'custom_title_2',
					'name' => 'text_custom_title_2',
					'description' => 'help_generate_manufacturer_custom_title_2',
					'sort_order' => '11',
					'template_default' => '[name]',
					'template_button' => array(
						'[name]'=> '[name]', 
						'[description]' => '[description]', 
						'[target_keyword]' => '[target_keyword]', 
						'[sample_products]' => '[sample_products]', 
						'[total_products]' => '[total_products]', 
						'[store_name]' => '[store_name]', 
						'[store_title]' => '[store_title]'
					),
					'multi_language' => true,
					'translit_symbol_status' => false,
					'translit_language_symbol_status' => false,
					'transform_language_symbol_id' => '0',
					'trim_symbol_status' => false,
					'overwrite' => false,
					'button_generate' => true,
					'button_clear' => true
				),
				'custom_image_name' => array(
					'code' => 'custom_image_name',
					'name' => 'text_custom_image_name',
					'description' => 'help_generate_manufacturer_custom_image_name',
					'sort_order' => '12',
					'template_default' => '[name]',
					'template_button' => array(
						'[name]'=> '[name]', 
						'[description]' => '[description]', 
						'[target_keyword]' => '[target_keyword]', 
						'[sample_products]' => '[sample_products]', 
						'[total_products]' => '[total_products]', 
						'[store_name]' => '[store_name]', 
						'[store_title]' => '[store_title]'
					),
					'multi_language' => false,
					'translit_language_symbol_status' => false,
					'transform_language_symbol_id' => '1',
					'trim_symbol_status' => true,
					'button_generate' => true,
					'button_clear' => true
				),
				'custom_image_title' => array(
					'code' => 'custom_image_title',
					'name' => 'text_custom_image_title',
					'description' => 'help_generate_manufacturer_custom_image_title',
					'sort_order' => '13',
					'template_default' => '[name]',
					'template_button' => array(
						'[name]'=> '[name]', 
						'[description]' => '[description]', 
						'[target_keyword]' => '[target_keyword]', 
						'[sample_products]' => '[sample_products]', 
						'[total_products]' => '[total_products]', 
						'[store_name]' => '[store_name]', 
						'[store_title]' => '[store_title]'
					),
					'multi_language' => true,
					'translit_symbol_status' => true,
					'translit_language_symbol_status' => false,
					'transform_language_symbol_id' => '0',
					'trim_symbol_status' => true,
					'overwrite' => false,
					'button_generate' => true,
					'button_clear' => true
				),
				'custom_image_alt' => array(
					'code' => 'custom_image_alt',
					'name' => 'text_custom_image_alt',
					'description' => 'help_generate_manufacturer_custom_image_alt',
					'sort_order' => '14',
					'template_default' => '[name]',
					'template_button' => array(
						'[name]'=> '[name]', 
						'[description]' => '[description]', 
						'[target_keyword]' => '[target_keyword]', 
						'[sample_products]' => '[sample_products]', 
						'[total_products]' => '[total_products]', 
						'[store_name]' => '[store_name]', 
						'[store_title]' => '[store_title]'
					),
					'multi_language' => true,
					'translit_symbol_status' => true,
					'translit_language_symbol_status' => false,
					'transform_language_symbol_id' => '0',
					'trim_symbol_status' => true,
					'overwrite' => false,
					'button_generate' => true,
					'button_clear' => true
				)
			),
			'button_popup' => array(
				'[description]' => array(
					'code' => '[description]',
					'name' => 'text_insert_description',
					'field' => array(
						'sentences' => array(
							'code' => 'sentences',
							'name' => 'text_sentence_total',
							'type' => 'text',
							'value' => '1'
						)
					)
				),
				'[target_keyword]' => array(
					'code' => '[target_keyword]',
					'name' => 'text_insert_target_keyword',
					'field' => array(
						'number' => array(
							'code' => 'number',
							'name' => 'text_keyword_number',
							'type' => 'text',
							'value' => '1'
						)
					)
				),
				'[sample_products]' => array(
					'code' => '[sample_products]',
					'name' => 'text_insert_sample_products',
					'field' => array(
						'total' => array(
							'code' => 'total',
							'name' => 'text_product_total',
							'type' => 'text',
							'value' => '3'
						),
						'separator' => array(
							'code' => 'separator',
							'name' => 'text_product_separator',
							'type' => 'text',
							'value' => ','
						)
					)
				)
			)
		),
		'information' => array(
			'code' => 'information',
			'icon' => 'fa-info-circle',
			'name' => 'text_information',
			'sort_order' => '4',
			'field' => array(
				'meta_title' => array(
					'code' => 'meta_title',
					'name' => 'text_meta_title',
					'description' => 'help_generate_information_meta_title',
					'sort_order' => '1',
					'template_default' => '[title]',
					'template_button' => array(
						'[title]' => '[title]', 
						'[description]' => '[description]', 
						'[target_keyword]' => '[target_keyword]', 
						'[store_name]' => '[store_name]', 
						'[store_title]' => '[store_title]'
					),
					'multi_language' => true,
					'translit_symbol_status' => false,
					'translit_language_symbol_status' => false,
					'transform_language_symbol_id' => '0',
					'trim_symbol_status' => false,
					'overwrite' => false,
					'button_generate' => true,
					'button_clear' => true
				),
				'meta_description' => array(
					'code' => 'meta_description',
					'name' => 'text_meta_description',
					'description' => 'help_generate_information_meta_description',
					'sort_order' => '2',
					'template_default' => '[title] - [description#sentences=1]',
					'template_button' => array(
						'[title]' => '[title]', 
						'[description]' => '[description]', 
						'[target_keyword]' => '[target_keyword]', 
						'[store_name]' => '[store_name]', 
						'[store_title]' => '[store_title]'
					),
					'multi_language' => true,
					'translit_symbol_status' => false,
					'translit_language_symbol_status' => false,
					'transform_language_symbol_id' => '0',
					'trim_symbol_status' => false,
					'overwrite' => false,
					'button_generate' => true,
					'button_clear' => true
				),
				'meta_keyword' => array(
					'code' => 'meta_keyword',
					'name' => 'text_meta_keyword',
					'description' => 'help_generate_information_meta_keyword',
					'sort_order' => '3',
					'template_default' => '[title]',
					'template_button' => array(
						'[title]' => '[title]', 
						'[description]' => '[description]', 
						'[target_keyword]' => '[target_keyword]', 
						'[store_name]' => '[store_name]', 
						'[store_title]' => '[store_title]'
					),
					'multi_language' => true,
					'translit_symbol_status' => false,
					'translit_language_symbol_status' => false,
					'transform_language_symbol_id' => '0',
					'trim_symbol_status' => false,
					'overwrite' => false,
					'button_generate' => true,
					'button_clear' => true
				),
				'custom_title_1' => array(
					'code' => 'custom_title_1',
					'name' => 'text_custom_title_1',
					'description' => 'help_generate_information_custom_title_1',
					'sort_order' => '10',
					'template_default' => '[title]',
					'template_button' => array(
						'[title]' => '[title]', 
						'[description]' => '[description]', 
						'[target_keyword]' => '[target_keyword]', 
						'[store_name]' => '[store_name]', 
						'[store_title]' => '[store_title]'
					),
					'multi_language' => true,
					'translit_symbol_status' => false,
					'translit_language_symbol_status' => false,
					'transform_language_symbol_id' => '0',
					'trim_symbol_status' => false,
					'overwrite' => false,
					'button_generate' => true,
					'button_clear' => true
				),
				'custom_title_2' => array(
					'code' => 'custom_title_2',
					'name' => 'text_custom_title_2',
					'description' => 'help_generate_information_custom_title_2',
					'sort_order' => '11',
					'template_default' => '[title]',
					'template_button' => array(
						'[title]' => '[title]', 
						'[description]' => '[description]', 
						'[target_keyword]' => '[target_keyword]', 
						'[store_name]' => '[store_name]', 
						'[store_title]' => '[store_title]'
					),
					'multi_language' => true,
					'translit_symbol_status' => false,
					'translit_language_symbol_status' => false,
					'transform_language_symbol_id' => '0',
					'trim_symbol_status' => false,
					'overwrite' => false,
					'button_generate' => true,
					'button_clear' => true
				)
			),
			'button_popup' => array(
				'[description]' => array(
					'code' => '[description]',
					'name' => 'text_insert_description',
					'field' => array(
						'sentences' => array(
							'code' => 'sentences',
							'name' => 'text_sentence_total',
							'type' => 'text',
							'value' => '1'
						)
					)
				),
				'[target_keyword]' => array(
					'code' => '[target_keyword]',
					'name' => 'text_insert_target_keyword',
					'field' => array(
						'number' => array(
							'code' => 'number',
							'name' => 'text_keyword_number',
							'type' => 'text',
							'value' => '1'
						)
					)
				),
				'[sample_products]' => array(
					'code' => '[sample_products]',
					'name' => 'text_insert_sample_products',
					'field' => array(
						'total' => array(
							'code' => 'total',
							'name' => 'text_product_total',
							'type' => 'text',
							'value' => '3'
						),
						'separator' => array(
							'code' => 'separator',
							'name' => 'text_product_separator',
							'type' => 'text',
							'value' => ','
						)
					)
				)
			)
		)
	),
	'transform_language_symbol' => array(
		'0' => array(
			'id'	=> '0',
			'name'	=> 'text_transform_none'
		),
		'1' => array(
			'id'	=> '1',
			'name'	=> 'text_transform_upper_to_lower'
		),
		'2' => array(
			'id'	=> '2',
			'name'	=> 'text_transform_lower_to_upper'
		)
	)
);
$_['d_seo_module_meta_manager_setting'] = array(
	'sheet' => array(
		'category' => array(
			'code' => 'category',
			'field' => array(
				'name' => array(
					'code' => 'name',
					'name' => 'text_category_name',
					'type' => 'text',
					'sort_order' => '2',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'description' => array(
					'code' => 'description',
					'name' => 'text_description',
					'type' => 'textarea',
					'sort_order' => '3',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => false,
					'export_status' => true,
					'required' => false
				),
				'meta_title' => array(
					'code' => 'meta_title',
					'name' => 'text_meta_title',
					'type' => 'text',
					'sort_order' => '4',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'meta_description' => array(
					'code' => 'meta_description',
					'name' => 'text_meta_description',
					'type' => 'textarea',
					'sort_order' => '5',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'meta_keyword' => array(
					'code' => 'meta_keyword',
					'name' => 'text_meta_keyword',
					'type' => 'textarea',
					'sort_order' => '6',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'custom_title_1' => array(
					'code' => 'custom_title_1',
					'name' => 'text_custom_title_1',
					'type' => 'text',
					'sort_order' => '10',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'custom_title_2' => array(
					'code' => 'custom_title_2',
					'name' => 'text_custom_title_2',
					'type' => 'text',
					'sort_order' => '11',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'custom_image_title' => array(
					'code' => 'custom_image_title',
					'name' => 'text_custom_image_title',
					'type' => 'text',
					'sort_order' => '12',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => false,
					'export_status' => true,
					'required' => false
				),
				'custom_image_alt' => array(
					'code' => 'custom_image_alt',
					'name' => 'text_custom_image_alt',
					'type' => 'text',
					'sort_order' => '13',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => false,
					'export_status' => true,
					'required' => false
				),
				'meta_robots' => array(
					'code' => 'meta_robots',
					'name' => 'text_meta_robots',
					'type' => 'select',
					'option' => array(
						'0' => array(
							'code' => 'index,follow', 
							'name' => 'index,follow'
						),
						'1' => array(
							'code' => 'noindex,follow', 
							'name' => 'noindex,follow'
						),
						'2' => array(
							'code' => 'index,nofollow', 
							'name' => 'index,nofollow'
						),
						'3' => array(
							'code' => 'noindex,nofollow', 
							'name' => 'noindex,nofollow'
						)
					),
					'sort_order' => '14',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => false,
					'export_status' => true,
					'required' => false
				)
			)
		),
		'product' => array(
			'code' => 'product',
			'field' => array(
				'name' => array(
					'code' => 'name',
					'name' => 'text_product_name',
					'type' => 'text',
					'sort_order' => '2',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'description' => array(
					'code' => 'description',
					'name' => 'text_description',
					'type' => 'textarea',
					'sort_order' => '3',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => false,
					'export_status' => true,
					'required' => false
				),
				'meta_title' => array(
					'code' => 'meta_title',
					'name' => 'text_meta_title',
					'type' => 'text',
					'sort_order' => '4',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'meta_description' => array(
					'code' => 'meta_description',
					'name' => 'text_meta_description',
					'type' => 'textarea',
					'sort_order' => '5',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'meta_keyword' => array(
					'code' => 'meta_keyword',
					'name' => 'text_meta_keyword',
					'type' => 'textarea',
					'sort_order' => '6',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'tag' => array(
					'code' => 'tag',
					'name' => 'text_tag',
					'type' => 'text',
					'sort_order' => '7',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'custom_title_1' => array(
					'code' => 'custom_title_1',
					'name' => 'text_custom_title_1',
					'type' => 'text',
					'sort_order' => '10',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'custom_title_2' => array(
					'code' => 'custom_title_2',
					'name' => 'text_custom_title_2',
					'type' => 'text',
					'sort_order' => '11',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'custom_image_title' => array(
					'code' => 'custom_image_title',
					'name' => 'text_custom_image_title',
					'type' => 'text',
					'sort_order' => '12',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => false,
					'export_status' => true,
					'required' => false
				),
				'custom_image_alt' => array(
					'code' => 'custom_image_alt',
					'name' => 'text_custom_image_alt',
					'type' => 'text',
					'sort_order' => '13',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => false,
					'export_status' => true,
					'required' => false
				),
				'meta_robots' => array(
					'code' => 'meta_robots',
					'name' => 'text_meta_robots',
					'type' => 'select',
					'option' => array(
						'0' => array(
							'code' => 'index,follow', 
							'name' => 'index,follow'
						),
						'1' => array(
							'code' => 'noindex,follow', 
							'name' => 'noindex,follow'
						),
						'2' => array(
							'code' => 'index,nofollow', 
							'name' => 'index,nofollow'
						),
						'3' => array(
							'code' => 'noindex,nofollow', 
							'name' => 'noindex,nofollow'
						)
					),
					'sort_order' => '14',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => false,
					'export_status' => true,
					'required' => false
				)
			)
		),
		'manufacturer' => array(
			'code' => 'manufacturer',
			'field' => array(
				'name' => array(
					'code' => 'name',
					'name' => 'text_manufacturer_name',
					'type' => 'text',
					'sort_order' => '10',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'description' => array(
					'code' => 'description',
					'name' => 'text_description',
					'type' => 'textarea',
					'sort_order' => '11',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => false,
					'export_status' => true,
					'required' => false
				),
				'meta_title' => array(
					'code' => 'meta_title',
					'name' => 'text_meta_title',
					'type' => 'text',
					'sort_order' => '12',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'meta_description' => array(
					'code' => 'meta_description',
					'name' => 'text_meta_description',
					'type' => 'textarea',
					'sort_order' => '13',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'meta_keyword' => array(
					'code' => 'meta_keyword',
					'name' => 'text_meta_keyword',
					'type' => 'textarea',
					'sort_order' => '14',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'custom_title_1' => array(
					'code' => 'custom_title_1',
					'name' => 'text_custom_title_1',
					'type' => 'text',
					'sort_order' => '15',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'custom_title_2' => array(
					'code' => 'custom_title_2',
					'name' => 'text_custom_title_2',
					'type' => 'text',
					'sort_order' => '16',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'custom_image_title' => array(
					'code' => 'custom_image_title',
					'name' => 'text_custom_image_title',
					'type' => 'text',
					'sort_order' => '17',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'custom_image_alt' => array(
					'code' => 'custom_image_alt',
					'name' => 'text_custom_image_alt',
					'type' => 'text',
					'sort_order' => '18',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'meta_robots' => array(
					'code' => 'meta_robots',
					'name' => 'text_meta_robots',
					'type' => 'select',
					'option' => array(
						'0' => array(
							'code' => 'index,follow', 
							'name' => 'index,follow'
						),
						'1' => array(
							'code' => 'noindex,follow', 
							'name' => 'noindex,follow'
						),
						'2' => array(
							'code' => 'index,nofollow', 
							'name' => 'index,nofollow'
						),
						'3' => array(
							'code' => 'noindex,nofollow', 
							'name' => 'noindex,nofollow'
						)
					),
					'sort_order' => '19',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => false,
					'export_status' => true,
					'required' => false
				)
			)
		),
		'information' => array(
			'code' => 'information',
			'field' => array(
				'title' => array(
					'code' => 'title',
					'name' => 'text_information_title',
					'type' => 'text',
					'sort_order' => '2',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'description' => array(
					'code' => 'description',
					'name' => 'text_description',
					'type' => 'textarea',
					'sort_order' => '3',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => false,
					'export_status' => true,
					'required' => false
				),
				'meta_title' => array(
					'code' => 'meta_title',
					'name' => 'text_meta_title',
					'type' => 'text',
					'sort_order' => '4',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'meta_description' => array(
					'code' => 'meta_description',
					'name' => 'text_meta_description',
					'type' => 'textarea',
					'sort_order' => '5',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'meta_keyword' => array(
					'code' => 'meta_keyword',
					'name' => 'text_meta_keyword',
					'type' => 'textarea',
					'sort_order' => '6',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'custom_title_1' => array(
					'code' => 'custom_title_1',
					'name' => 'text_custom_title_1',
					'type' => 'text',
					'sort_order' => '10',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'custom_title_2' => array(
					'code' => 'custom_title_2',
					'name' => 'text_custom_title_2',
					'type' => 'text',
					'sort_order' => '11',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => true,
					'export_status' => true,
					'required' => false
				),
				'meta_robots' => array(
					'code' => 'meta_robots',
					'name' => 'text_meta_robots',
					'type' => 'select',
					'option' => array(
						'0' => array(
							'code' => 'index,follow', 
							'name' => 'index,follow'
						),
						'1' => array(
							'code' => 'noindex,follow', 
							'name' => 'noindex,follow'
						),
						'2' => array(
							'code' => 'index,nofollow', 
							'name' => 'index,nofollow'
						),
						'3' => array(
							'code' => 'noindex,nofollow', 
							'name' => 'noindex,nofollow'
						)
					),
					'sort_order' => '12',
					'multi_store' => true,
					'multi_language' => true,
					'list_status' => false,
					'export_status' => true,
					'required' => false
				)
			)
		)
	)
);
$_['d_seo_module_meta_feature_setting'] = array(
	'dashboard_widget_for_duplicate_and_empty_meta_titles' => array(
		'name' => 'text_dashboard_widget_for_duplicate_and_empty_meta_titles',
		'image' => 'd_seo_module_meta/feature/dashboard_widget_for_duplicate_and_empty_meta_titles.svg',
		'href' => 'https://opencartseomodule.com/dashboard-widget-for-duplicate-meta-titles',
	),
	'translit_symbols_and_letters_to_latin' => array(
		'name' => 'text_translit_symbols_and_letters_to_latin',
		'image' => 'd_seo_module_meta/feature/translit_symbols_and_letters_to_latin.svg',
		'href' => 'https://opencartseomodule.com/translit-meta-symbols-and-letters-to-latin',
	),
	'meta_robots_field_per_page' => array(
		'name' => 'text_meta_robots_field_per_page',
		'image' => 'd_seo_module_meta/feature/meta_robots_field_per_page.svg',
		'href' => 'https://opencartseomodule.com/meta-robots',
	),
	'edit_meta_information_for_all_pages' => array(
		'name' => 'text_edit_meta_information_for_all_pages',
		'image' => 'd_seo_module_meta/feature/edit_meta_information_for_all_pages.svg',
		'href' => 'https://opencartseomodule.com/edit-meta-information-for-all-pages',
	),
	'seo_module_meta_api' => array(
		'name' => 'text_seo_module_meta_api',
		'image' => 'd_seo_module_meta/feature/seo_module_meta_api.svg',
		'href' => 'https://opencartseomodule.com/seo-module-meta-api',
	),
	'autogenerate_meta_information' => array(
		'name' => 'text_autogenerate_meta_information',
		'image' => 'd_seo_module_meta/feature/autogenerate_meta_information.svg',
		'href' => 'https://opencartseomodule.com/autogenerate-meta-information',
	),
	'autogenerate-product-tags' => array(
		'name' => 'text_autogenerate-product-tags',
		'image' => 'd_seo_module_meta/feature/autogenerate-product-tags.svg',
		'href' => 'https://opencartseomodule.com/autogenerate-product-tags',
	),
	'autogenerate_heading_titles' => array(
		'name' => 'text_autogenerate_heading_titles',
		'image' => 'd_seo_module_meta/feature/autogenerate_heading_titles.svg',
		'href' => 'https://opencartseomodule.com/autogenerate-heading-titles',
	),
	'autogenerate_image_information' => array(
		'name' => 'text_autogenerate_image_information',
		'image' => 'd_seo_module_meta/feature/autogenerate_image_information.svg',
		'href' => 'https://opencartseomodule.com/autogenerate-image-alt-and-titles',
	),
	'clear_all_metas' => array(
		'name' => 'text_clear_all_metas',
		'image' => 'd_seo_module_meta/feature/clear_all_metas.svg',
		'href' => 'https://opencartseomodule.com/clear-all-metas',
	),
	'overwrite_old_metas' => array(
		'name' => 'text_overwrite_old_metas',
		'image' => 'd_seo_module_meta/feature/overwrite_old_metas.svg',
		'href' => 'https://opencartseomodule.com/overwrite-old-metas',
	)
);
?>