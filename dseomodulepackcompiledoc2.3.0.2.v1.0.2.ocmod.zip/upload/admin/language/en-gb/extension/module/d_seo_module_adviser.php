<?php
// Heading
$_['heading_title']       						= '<span style="color:#449DD0; font-weight:bold">SEO Module Adviser</span><span style="font-size:0.9em; color:#999"> by <a href="http://www.opencart.com/index.php?route=extension/extension&filter_username=Dreamvention" style="font-size:1em; color:#999" target="_blank">Dreamvention</a></span>'; 
$_['heading_title_main']  						= 'SEO Module Adviser';

// Text
$_['text_edit']            						= 'Edit SEO Module Adviser';
$_['text_install']              				= 'Install SEO Module Adviser';
$_['text_modules']         						= 'Modules';
$_['text_settings']       						= 'Settings';
$_['text_instructions']   						= 'Instructions';
$_['text_setup']								= 'Install SEO Module Adviser now';
$_['text_full_setup']							= 'Full';
$_['text_custom_setup']							= 'Custom';
$_['text_all_stores']     						= 'All Stores';
$_['text_all_languages']  						= 'All Languages';
$_['text_yes'] 									= 'Yes';
$_['text_no'] 									= 'No';
$_['text_enabled']          					= 'Enabled';
$_['text_disabled']          					= 'Disabled';
$_['text_seo_module']   						= 'SEO Module';
$_['text_adviser']   							= 'Adviser';
$_['text_uninstall_confirm']          			= 'After uninstalling of SEO Module Adviser will delete all additional fields in the product, category, manufacturer and information that have been added after installation. Are you sure you want to uninstall SEO Module Adviser?';
$_['text_powered_by']               			= 'Tested with <a href="https://shopunity.net/">Shopunity.net</a><br/>Find more extensions at <a href="https://dreamvention.ee/">Dreamvention.com</a>';
$_['text_instructions_full'] 					= '
<div class="row">
	<div class="col-sm-2">
		<ul class="nav nav-pills nav-stacked">
			<li class="active"><a href="#vtab_instruction_install"  data-toggle="tab">Installation and Updating</a></li>
			<li><a href="#vtab_instruction_setting" data-toggle="tab">Settings</a></li>
		</ul>
	</div>
	<div class="col-sm-10">
		<div class="tab-content">
			<div id="vtab_instruction_install" class="tab-pane active">
				<div class="tab-body">
					<h3>Installation</h3>
					<ol>
						<li>Unzip distribution file.</li>
						<li>Upload everything from the folder <code>UPLOAD</code> into the root folder of you shop.</li>
						<li>Goto admin of your shop and navigate to extensions -> modules -> SEO Module Adviser.</li>
						<li>Click install button.</li>
					</ol>
					<div class="bs-callout bs-callout-info">
						<h4>Note!</h4>
						<p>Our installation process requires you to have access to the internet because we will install all the required dependencies before we install the module. Install SEO Module Adviser is possible only after installing SEO Module.</p>
					</div>
					<div class="bs-callout bs-callout-warning">
						<h4>Warning!</h4>
						<p>If you get an error on this step, be sure to make you <code>DOWNLOAD</code> folder (usually in system folder of you shop) writable.</p>
					</div>
					<h3>Updating</h3>
					<ol>
						<li>Unzip distribution file.</li>
						<li>Upload everything from the folder <code>UPLOAD</code> into the root folder of you shop.</li>
						<li>Click overwrite for all files.</li>
					</ol>
					<div class="bs-callout bs-callout-info">
						<h4>Note!</h4>
						<p>Although we follow strict standards that do not allow feature updates to cause a full reinstall of the module, still it may happen that major releases require you to uninstall/install the module again before new feature take place.</p>
					</div>
					<div class="bs-callout bs-callout-warning">
						<h4>Warning!</h4>
						<p>If you have made custom corrections to the code, your code will be rewritten and lost once you update the module.</p>
					</div>
				</div>
			</div>
			<div id="vtab_instruction_setting" class="tab-pane">
				<div class="tab-body">
					<h3>Settings</h3>
					<p>Here you can:</p>
					<ol>
						<li>Enable/Disable SEO Module Adviser on the pages of your shop by click Status.</li>
						<li>Uninstall SEO Module Adviser.</li>
					</ol>
					<div class="bs-callout bs-callout-info">
						<h4>Note!</h4>
						<p>After installing of SEO Module Adviser in the admin panel of Opencart in the category, product, manufacturer, information and store settings on the tab "General" will appear information field "SEO Rating". If its value is less than 100, then below will be instructions, as it can be increased.</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>';
$_['text_not_found'] = '
<div class="jumbotron">
	<h1>Please install Shopunity</h1>
	<p>Before you can use this module you will need to install Shopunity. Simply download the archive for your version of opencart and install it view Extension Installer or unzip the archive and upload all the files into your root folder from the UPLOAD folder.</p>
	<p><a class="btn btn-primary btn-lg" href="https://shopunity.net/download" target="_blank">Download</a></p>
</div>';

// Features
$_['text_seo_insights_per_page']						= 'SEO insights per page';
$_['text_multi_language_url_support_for_seo_rating']	= 'Multi Language url support for SEO rating';
$_['text_seo_rating_per_page']							= 'SEO Rating per page';
$_['text_seo_rating_toolbar_widget']					= 'SEO Rating Toolbar widget';
$_['text_seo_module_adviser_api']						= 'SEO Module Adviser API';

	
// Entry
$_['entry_status']        						= 'Status';
$_['entry_uninstall']							= 'Uninstall Module';

// Help
$_['help_setup']								= 'SEO module Adviser is a 24/7 SEO professional that helps you manage your Webshop SEO in the best possible way. It is intelligent and it gets smarter with every new SEO module you add to your shop. With it\'s help you will reach the best SEO performance and will keep it up to date with very little effort. Click setup!';
$_['help_full_setup']							= 'Full Setup will install all available SEO modules and automatically generate meta data and SEO URLs for all pages of your store. Recommended for installing on the new store.';
$_['help_custom_setup']							= 'Custom Setup will install only required SEO modules. All further settings you have to do manually. Recommended for installing on the work store.';

// Button		
$_['button_save'] 								= 'Save';
$_['button_save_and_stay'] 						= 'Save and Stay';
$_['button_cancel'] 							= 'Cancel';
$_['button_setup'] 								= 'Setup';
$_['button_uninstall'] 							= 'Uninstall';

// Success
$_['success_save']        						= 'Success: You have modified module SEO Module Adviser!';
$_['success_install']        					= 'Success: You have installed module SEO Module Adviser!';
$_['success_uninstall']							= 'Success: You have uninstalled module SEO Module Adviser!';

// Error
$_['error_warning']          					= 'Warning: Please check the form carefully for errors!';
$_['error_permission']    						= 'Warning: You do not have permission to modify module SEO Module Adviser!';
$_['error_installed']							= 'Warning: You can not install this module because it is already installed!';
$_['error_dependence_d_seo_module']    			= 'Warning: You can not install this module until you install module SEO Module!';

?>