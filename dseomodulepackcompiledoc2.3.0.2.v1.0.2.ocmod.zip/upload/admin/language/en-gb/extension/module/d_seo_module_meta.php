<?php
// Heading
$_['heading_title']       						= '<span style="color:#449DD0; font-weight:bold">SEO Module Meta</span><span style="font-size:0.9em; color:#999"> by <a href="http://www.opencart.com/index.php?route=extension/extension&filter_username=Dreamvention" style="font-size:1em; color:#999" target="_blank">Dreamvention</a></span>'; 
$_['heading_title_main']  						= 'SEO Module Meta';

// Text
$_['text_edit']            						= 'Edit SEO Module Meta';
$_['text_install']              				= 'Install SEO Module Meta';
$_['text_modules']         						= 'Modules';
$_['text_settings']       						= 'Settings';
$_['text_generator']          					= 'Generator';
$_['text_instructions']   						= 'Instructions';
$_['text_basic_settings'] 						= 'Basic settings';
$_['text_category'] 							= 'Category';
$_['text_product'] 								= 'Product';
$_['text_manufacturer']							= 'Manufacturer';
$_['text_information'] 							= 'Information';
$_['text_search']								= 'Search';
$_['text_special']								= 'Special';
$_['text_setup']								= 'Install SEO Module Meta now';
$_['text_full_setup']							= 'Full';
$_['text_custom_setup']							= 'Custom';
$_['text_all_stores']     						= 'All Stores';
$_['text_all_languages']  						= 'All Languages';
$_['text_yes'] 									= 'Yes';
$_['text_no'] 									= 'No';
$_['text_enabled']          					= 'Enabled';
$_['text_disabled']          					= 'Disabled';
$_['text_transform_none']          				= 'No Transform';
$_['text_transform_lower_to_upper']     		= 'Lower To Upper';
$_['text_transform_upper_to_lower']     		= 'Upper To Lower';
$_['text_seo_module']   						= 'SEO Module';
$_['text_meta']   								= 'Meta';
$_['text_generate_confirm']          			= 'Are you sure you want to generate data for this field?';
$_['text_clear_confirm']          				= 'Are you sure you want to clear all the data for this field. The data will be permanently deleted, this can not be undone?';
$_['text_uninstall_confirm']          			= 'After uninstalling of SEO Module Meta will delete all additional fields in the product, category, manufacturer and information that have been added after installation. Are you sure you want to uninstall SEO Module Meta?';
$_['text_info_setting_category']				= '<h4>What\'s this for?</h4><p>SEO Module Meta will replace your current Category Title with Custom Category Titles on the store page. But to do this, the module needs to know the location of these tags in your HTML. The same goes for the Custom Category Image tag. The module uses Simple HTML DOM extension to trace the location.</p> <p>Opencart has a great variety of templates. There are no standards of selectors for title and image tags. Some developers add different types of tags with different ids or classes. Therefore, you are given the opportunity to add the required selectors yourself. Exmaple: <code>#content h1</code> will search for a tag with id=content inside which it will look for a h1 tag</p>';
$_['text_info_setting_product']					= '<h4>What\'s this for?</h4><p>Just like the category, the SEO Module Meta will replace your current Product Title with Custom Product Titles on the store page.</p>';
$_['text_info_setting_manufacturer']			= '<h4>What\'s this for?</h4><p>Just like the category, the SEO Module Meta will replace your current Manufacturer Title with Custom Manufacturer Titles on the store page</p>';
$_['text_info_setting_information']				= '<h4>What\'s this for?</h4><p>Just like the category, the SEO Module Meta will replace your current Information Title with Custom Information Titles on the store page. </p>';
$_['text_powered_by']               			= 'Tested with <a href="https://shopunity.net/">Shopunity.net</a><br/>Find more extensions at <a href="https://dreamvention.ee/">Dreamvention.com</a>';
$_['text_instructions_full'] 					= '
<div class="row">
	<div class="col-sm-2">
		<ul class="nav nav-pills nav-stacked">
			<li class="active"><a href="#vtab_instruction_install"  data-toggle="tab">Installation and Updating</a></li>
			<li><a href="#vtab_instruction_setting" data-toggle="tab">Settings</a></li>
			<li><a href="#vtab_instruction_generator" data-toggle="tab">Generator</a></li>
		</ul>
	</div>
	<div class="col-sm-10">
		<div class="tab-content">
			<div id="vtab_instruction_install" class="tab-pane active">
				<div class="tab-body">
					<h3>Installation</h3>
					<ol>
						<li>Unzip distribution file.</li>
						<li>Upload everything from the folder <code>UPLOAD</code> into the root folder of you shop.</li>
						<li>Goto admin of your shop and navigate to extensions -> modules -> SEO Module Meta.</li>
						<li>Click install button.</li>
					</ol>
					<div class="bs-callout bs-callout-info">
						<h4>Note!</h4>
						<p>Our installation process requires you to have access to the internet because we will install all the required dependencies before we install the module. Install SEO Module Meta is possible only after installing SEO Module.</p>
					</div>
					<div class="bs-callout bs-callout-warning">
						<h4>Warning!</h4>
						<p>If you get an error on this step, be sure to make you <code>DOWNLOAD</code> folder (usually in system folder of you shop) writable.</p>
					</div>
					<h3>Updating</h3>
					<ol>
						<li>Unzip distribution file.</li>
						<li>Upload everything from the folder <code>UPLOAD</code> into the root folder of you shop.</li>
						<li>Click overwrite for all files.</li>
					</ol>
					<div class="bs-callout bs-callout-info">
						<h4>Note!</h4>
						<p>Although we follow strict standards that do not allow feature updates to cause a full reinstall of the module, still it may happen that major releases require you to uninstall/install the module again before new feature take place.</p>
					</div>
					<div class="bs-callout bs-callout-warning">
						<h4>Warning!</h4>
						<p>If you have made custom corrections to the code, your code will be rewritten and lost once you update the module.</p>
					</div>
				</div>
			</div>
			<div id="vtab_instruction_setting" class="tab-pane">
				<div class="tab-body">
					<h3>Basic Settings</h3>
					<p>Here you can:</p>
					<ol>
						<li>Enable/Disable SEO Module Meta on the pages of your shop by click Status.</li>
						<li>Uninstall SEO Module Meta.</li>
					</ol>
					<div class="bs-callout bs-callout-warning">
						<h4>Warning!</h4>
						<p>After uninstalling of SEO Module Meta will delete all additional fields in the product, category, manufacturer, information and store settings that have been added after installation.</p>
					</div>
					<h3>Store Settings</h3>
					<p>After installing of SEO Module Meta in the admin panel of Opencart in the store settings on the tab "General" will appear new fields:</p>
					<ol>
						<li><strong>Meta Tag Title</strong> is multilingual field, which allows you to specify the meta tag title of home page.</li>
						<li><strong>Meta Tag Description</strong> is multilingual field, which allows you to specify the meta tag description of home page.</li>
						<li><strong>Meta Tag Keywords</strong> is multilingual field, which allows you to specify the meta tag keywords of home page.</li>
						<li><strong>Meta Robots</strong> is multilingual field, which allows the robot to determine, whether it is possible to index home page and to use for search the links provided on the page.</li>
					</ol>
					<h3>Category</h3>
					<p>After installing of SEO Module Meta in the admin panel of Opencart in the category on the tab "General" will appear new fields:</p>
					<ol>
						<li><strong>Custom Title 1</strong> is multilingual field, which allows you to specify the title of the category on the category page different from the page title.</li>
						<li><strong>Custom Title 2</strong> is multilingual field, which allows you to specify the title of the category on the category page different from the page title.</li>
						<li><strong>Custom Image Title</strong> is multilingual field, which allows you specify the attribute "title" of main image of the category on the category page different from the page title.</li>
						<li><strong>Custom Image Alt</strong> is multilingual field, which allows you specify the attribute "alt" of main image of the category on the category page different from the page title.</li>
						<li><strong>Meta Robots</strong> is multilingual field, which allows the robot to determine, whether it is possible to index this category page and to use for search the links provided on the page.</li>
					</ol>
					<p>Opencart has a great variety of templates. There are no standards of selectors for title and image tags of category. Some developers add different types of tags with different ids or classes. Therefore, in the settings of this module, you are given the opportunity themselves to add the required selectors:</p>
					<ol>
						<li><strong>Custom Title 1 tag selector</strong></li>
						<li><strong>Custom Title 2 tag selector</strong></li>
						<li><strong>Custom Image tag selector</strong></li>
					</ol>
					<p>Selector can be represented as class or ID of the tag. We set selectors for the default template of Opencart.</p>
					<h3>Product</h3>
					<p>After installing of SEO Module Meta in the admin panel of Opencart in the product on the tab "General" will appear new fields:</p>
					<ol>
						<li><strong>Custom Title 1</strong> is multilingual field, which allows you to specify the title of the product on the product page different from the page title.</li>
						<li><strong>Custom Title 2</strong> is multilingual field, which allows you to specify the title of the product on the product page different from the page title.</li>
						<li><strong>Custom Image Title</strong> is multilingual field, which allows you specify the attribute title of main image of the product on the product page different from the page title.</li>
						<li><strong>Custom Image Alt</strong> is multilingual field, which allows you specify the attribute alt of main image of the product on the product page different from the page title.</li>
						<li><strong>Meta Robots</strong> is multilingual field, which allows the robot to determine, whether it is possible to index this product page and to use for search the links provided on the page.</li>
					</ol>
					<p>Opencart has a great variety of templates. There are no standards of selectors for title and image tags of product. Some developers add different types of tags with different ids or classes. Therefore, in the settings of this module, you are given the opportunity themselves to add the required selectors:</p>
					<ol>
						<li><strong>Custom Title 1 tag selector</strong></li>
						<li><strong>Custom Title 2 tag selector</strong></li>
						<li><strong>Custom Image tag selector</strong></li>
					</ol>
					<p>Selector can be represented as class or ID of the tag. We set selectors for the default template of Opencart.</p>
					<h3>Manufacturer</h3>
					<p>After installing of SEO Module Meta in the admin panel of Opencart in the manufacturer on the tab "General" will appear new fields:</p>
					<ol>
						<li><strong>Title</strong> is multilingual field, which allows you to specify the title of manufacturer.</li>
						<li><strong>Description</strong> is multilingual field, which allows you to specify the description of manufacturer.</li>
						<li><strong>Meta Tag Title</strong> is multilingual field, which allows you to specify the meta tag title of manufacturer.</li>
						<li><strong>Meta Tag Description</strong> is multilingual field, which allows you to specify the meta tag description of manufacturer.</li>
						<li><strong>Meta Tag Keywords</strong> is multilingual field, which allows you to specify the meta tag keywords of manufacturer.</li>
						<li><strong>Custom Title 1</strong> is multilingual field, which allows you to specify the title of the manufacturer on the manufacturer page different from the page title.</li>
						<li><strong>Custom Title 2</strong> is multilingual field, which allows you to specify the title of the manufacturer on the manufacturer page different from the page title.</li>
						<li><strong>Custom Image Title</strong> is multilingual field, which allows you specify the attribute "title" of main image of the manufacturer on the manufacturer page different from the page title.</li>
						<li><strong>Custom Image Alt</strong> is multilingual field, which allows you specify the attribute "alt" of main image of the manufacturer on the manufacturer page different from the page title.</li>
						<li><strong>Meta Robots</strong> is multilingual field, which allows the robot to determine, whether it is possible to index this manufacturer page and to use for search the links provided on the page.</li>
					</ol>
					<p>Opencart has a great variety of templates. There are no standards of selectors for title tag and tag before description of manufacturer. Some developers add different types of tags with different ids or classes. Therefore, in the settings of this module, you are given the opportunity themselves to add the required selectors:</p>
					<ol>
						<li><strong>Custom Title 1 tag selector</strong></li>
						<li><strong>Custom Title 2 tag selector</strong></li>
						<li><strong>Custom Image tag selector</strong></li>
						<li><strong>Before Description tag selector</strong></li>
					</ol>
					<p>Selector can be represented as class or ID of the tag. We set selectors for the default template of Opencart.</p>
					<h3>Information</h3>
					<p>After installing of SEO Module Meta in the admin panel of Opencart in the information on the tab "General" will appear new fields:</p>
					<ol>
						<li><strong>Custom Title 1</strong> is multilingual field, which allows you to specify the title of the information on the information page different from the page title.</li>
						<li><strong>Custom Title 2</strong> is multilingual field, which allows you to specify the title of the information on the information page different from the page title.</li>
						<li><strong>Meta Robots</strong> is multilingual field, which allows the robot to determine, whether it is possible to index this information page and to use for search the links provided on the page.</li>
					</ol>
					<p>Opencart has a great variety of templates. There are no standards of selectors for title tag of information. Some developers add different types of tags with different ids or classes. Therefore, in the settings of this module, you are given the opportunity themselves to add the required selector:</p>
					<ol>
						<li><strong>Custom title 1 tag selector</strong></li>
						<li><strong>Custom title 2 tag selector</strong></li>
					</ol>
					<p>Selector can be represented as class or ID of the tag. We set selectors for the default template of Opencart.</p>
				</div>
			</div>
			<div id="vtab_instruction_generator" class="tab-pane">
				<div class="tab-body">
					<h3>Category</h3>
					<p>Here you can generate the following fields for categories:</p>
					<ol>
						<li><strong>Meta Tag Title</strong> is multilingual field, which allows you to specify the meta tag title of category.</li>
						<li><strong>Meta Tag Description</strong> is multilingual field, which allows you to specify the meta tag description of category.</li>
						<li><strong>Meta Tag Keywords</strong> is multilingual field, which allows you to specify the meta tag keywords of category.</li>
						<li><strong>Custom Title</strong> is multilingual field, which allows you to specify the title of the category on the category page different from the page title.</li>
						<li><strong>Custom Image Name</strong> is field, which allows you specify the file name of main image of the category on the category page.</li>
						<li><strong>Custom Image Title</strong> is multilingual field, which allows you specify the attribute title of main image of the category on the category page different from the page title.</li>
						<li><strong>Custom Image Alt</strong> is multilingual field, which allows you specify the attribute alt of main image of the category on the category page different from the page title.</li>
					</ol>
					<p>To generate any of these fields, you must fill the multilingual field "Template" and click on the button "Generate". To set a template, you can use shortcodes, that allow you to get the values of other fields of categories and replace shortcode on them. To insert the desired shortcode, just click on its button <span class="btn btn-default btn-xs"><i class="fa fa-plus-circle"></i></span>. For categories you can use the following shortcodes:</p>
					<ol>
						<li><strong>[name]</strong> will be replaced on the category name.</li>
						<li><strong>[parent_name]</strong> will be replaced on the name of the parent category.</li>
						<li><strong>[description]</strong> will be replaced on the certain number of sentences from the category description. You will need to enter the total number of sentences.</li>
						<li><strong>[target_keyword]</strong> will be replaced on the certain target keyword from this category. You will need to enter the number of target keyword.</li>
						<li><strong>[sample_products]</strong> will be replaced on the names of sample products from this category. You will need to enter the total number of products and separator between them.</li>
						<li><strong>[total_products]</strong> will be replaced on the total number of products from this category.</li>
						<li><strong>[store_name]</strong> will be replaced on the store name.</li>
						<li><strong>[store_title]</strong> will be replaced on the multilingual store title.</li>
					</ol>
					<h3>Product</h3>
					<p>Here you can generate the following fields for products:</p>
					<ol>
						<li><strong>Meta Tag Title</strong> is multilingual field, which allows you to specify the meta tag title of product.</li>
						<li><strong>Meta Tag Description</strong> is multilingual field, which allows you to specify the meta tag description of product.</li>
						<li><strong>Meta Tag Keywords</strong> is multilingual field, which allows you to specify the meta tag keywords of product.</li>
						<li><strong>Tags</strong> is multilingual field, which allows you to specify the tags of product.</li>
						<li><strong>Custom Title</strong> is multilingual field, which allows you to specify the title of the product on the product page different from the page title.</li>
						<li><strong>Custom Image Name</strong> is field, which allows you specify the file name of main image of the product on the product page.</li>
						<li><strong>Custom Image Title</strong> is multilingual field, which allows you specify the attribute title of main image of the product on the product page different from the page title.</li>
						<li><strong>Custom Image Alt</strong> is multilingual field, which allows you specify the attribute alt of main image of the product on the product page different from the page title.</li>
					</ol>
					<p>To generate any of these fields, you must fill the multilingual field "Template" and click on the button "Generate". To set a template, you can use shortcodes, that allow you to get the values of other fields of products and replace shortcode on them. To insert the desired shortcode, just click on its button <span class="btn btn-default btn-xs"><i class="fa fa-plus-circle"></i></span>. For products you can use the following shortcodes:</p>
					<ol>
						<li><strong>[name]</strong> will be replaced on the product name.</li>
						<li><strong>[description]</strong> will be replaced on the certain number of sentences from the product description. You will need to enter the total number of sentences.</li>
						<li><strong>[target_keyword]</strong> will be replaced on the certain target keyword from this product. You will need to enter the number of target keyword.</li>
						<li><strong>[category]</strong> will be replaced on the name of one of the categories containing this product.</li>
						<li><strong>[model]</strong> will be replaced on the product model.</li>
						<li><strong>[sku]</strong> will be replaced on the product sku.</li>
						<li><strong>[upc]</strong> will be replaced on the product upc.</li>
						<li><strong>[manufacturer]</strong> will be replaced on the manufacturer name of this product.</li>
						<li><strong>[store_name]</strong> will be replaced on the store name.</li>
						<li><strong>[store_title]</strong> will be replaced on the multilingual store title.</li>
					</ol>
					<h3>Manufacturer</h3>
					<p>Here you can generate the following fields for manufacturers:</p>
					<ol>
						<li><strong>Meta Tag Title</strong> is multilingual field, which allows you to specify the meta tag title of manufacturer.</li>
						<li><strong>Meta Tag Description</strong> is multilingual field, which allows you to specify the meta tag description of manufacturer.</li>
						<li><strong>Meta Tag Keywords</strong> is multilingual field, which allows you to specify the meta tag keywords of manufacturer.</li>
						<li><strong>Custom Title</strong> is multilingual field, which allows you to specify the title of the manufacturer on the manufacturer page different from the page title.</li>
						<li><strong>Custom Image Name</strong> is field, which allows you specify the file name of main image of the manufacturer on the manufacturer page.</li>
						<li><strong>Custom Image Title</strong> is multilingual field, which allows you specify the attribute title of main image of the manufacturer on the manufacturer page different from the page title.</li>
						<li><strong>Custom Image Alt</strong> is multilingual field, which allows you specify the attribute alt of main image of the manufacturer on the manufacturer page different from the page title.</li>
					</ol>
					<p>To generate any of these fields, you must fill the multilingual field "Template" and click on the button "Generate". To set a template, you can use shortcodes, that allow you to get the values of other fields of manufacturers and replace shortcode on them. To insert the desired shortcode, just click on its button <span class="btn btn-default btn-xs"><i class="fa fa-plus-circle"></i></span>. For manufacturers you can use the following shortcodes:</p>
					<ol>
						<li><strong>[name]</strong> will be replaced on the manufacturer title or name.</li>
						<li><strong>[description]</strong> will be replaced on the certain number of sentences from the manufacturer description. You will need to enter the total number of sentences.</li>
						<li><strong>[target_keyword]</strong> will be replaced on the certain target keyword from this manufacturer. You will need to enter the number of target keyword.</li>
						<li><strong>[sample_products]</strong> will be replaced on the names of sample products from this manufacturer. You will need to enter the total number of products and separator between them.</li>
						<li><strong>[total_products]</strong> will be replaced on the total number of products from this manufacturer.</li>
						<li><strong>[store_name]</strong> will be replaced on the store name.</li>
						<li><strong>[store_title]</strong> will be replaced on the multilingual store title.</li>
					</ol>
					<h3>Information</h3>
					<p>Here you can generate the following fields for informations:</p>
					<ol>
						<li><strong>Meta Tag Title</strong> is multilingual field, which allows you to specify the meta tag title of information.</li>
						<li><strong>Meta Tag Description</strong> is multilingual field, which allows you to specify the meta tag description of information.</li>
						<li><strong>Meta Tag Keywords</strong> is multilingual field, which allows you to specify the meta tag keywords of information.</li>
						<li><strong>Custom Title</strong> is multilingual field, which allows you to specify the title of the information on the information page different from the page title.</li>
					</ol>
					<p>To generate any of these fields, you must fill the multilingual field "Template" and click on the button "Generate". To set a template, you can use shortcodes, that allow you to get the values of other fields of informations and replace shortcode on them. To insert the desired shortcode, just click on its button <span class="btn btn-default btn-xs"><i class="fa fa-plus-circle"></i></span>. For informations you can use the following shortcodes:</p>
					<ol>
						<li><strong>[name]</strong> will be replaced on the information title.</li>
						<li><strong>[description]</strong> will be replaced on the certain number of sentences from the information description. You will need to enter the total number of sentences.</li>
						<li><strong>[target_keyword]</strong> will be replaced on the certain target keyword from this information. You will need to enter the number of target keyword.</li>
						<li><strong>[store_name]</strong> will be replaced on the store name.</li>
						<li><strong>[store_title]</strong> will be replaced on the multilingual store title.</li>
					</ol>
					<div class="bs-callout bs-callout-info">
						<h4>Note!</h4>
						<p>To generate you can also use the following options:</p>
						<ol>
							<li><strong>Transform Language Symbols</strong> converts the language characters to large or small characters.</li>
							<li><strong>Translit Symbols</strong> converts special characters (%, &, ", etc.) to the characters shown in the module Translit.</li>
							<li><strong>Translit Language Symbols</strong> converts language characters to the characters shown in the module Translit.</li>
						</ol>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>';
$_['text_not_found'] = '
<div class="jumbotron">
	<h1>Please install Shopunity</h1>
	<p>Before you can use this module you will need to install Shopunity. Simply download the archive for your version of opencart and install it view Extension Installer or unzip the archive and upload all the files into your root folder from the UPLOAD folder.</p>
	<p><a class="btn btn-primary btn-lg" href="https://shopunity.net/download" target="_blank">Download</a></p>
</div>';	

// Features
$_['text_dashboard_widget_for_duplicate_and_empty_meta_titles']		= 'Dashboard widget for duplicate and empty Meta Titles';
$_['text_translit_symbols_and_letters_to_latin']					= 'Translit symbols and letters to latin';
$_['text_meta_robots_field_per_page']								= 'Meta Robots field per page';
$_['text_edit_meta_information_for_all_pages']						= 'Edit Meta information for all pages';
$_['text_seo_module_meta_api']										= 'SEO Module Meta API';
$_['text_autogenerate_meta_information']							= 'Autogenerate meta information';
$_['text_autogenerate-product-tags']								= 'Autogenerate product tags';
$_['text_autogenerate_heading_titles']								= 'Autogenerate heading titles';
$_['text_autogenerate_image_information']							= 'Autogenerate image information';
$_['text_clear_all_metas']											= 'Clear all Metas';
$_['text_overwrite_old_metas']										= 'Overwrite old metas';
	
// Entry
$_['entry_status']        						= 'Status';
$_['entry_meta_title_page_template'] 			= 'Page in Meta Title Template';
$_['entry_meta_description_page_template'] 		= 'Page in Meta Description Template';
$_['entry_uninstall']							= 'Uninstall Module';
$_['entry_custom_title_1_class']				= 'Custom Title 1 tag selector';
$_['entry_custom_title_2_class']				= 'Custom Title 2 tag selector';
$_['entry_custom_image_class']					= 'Custom Image tag selector';
$_['entry_before_description_class']			= 'Place Description after this selector';
$_['entry_meta_title_page'] 					= 'Page in Meta Title';
$_['entry_meta_description_page'] 				= 'Page in Meta Description';
$_['entry_template']							= 'Template';
$_['entry_translit_symbol']						= 'Translit Symbols';
$_['entry_translit_language_symbol']			= 'Translit Language Symbols';
$_['entry_transform_language_symbol']			= 'Transform Language Symbols';
$_['entry_trim_symbol']							= 'Trim Symbols';
$_['entry_overwrite']							= 'Overwrite old values';
$_['entry_generation']          				= 'Generation';

// Help
$_['help_setup']								= 'SEO module meta gives ultimate control over your SEO meta data. You can mass generate titles, descriptions, keywords, custom titles and image names using predefined list of placeholders for unique customization. It is a professional tool and unless treated with care, can create unpredictible results, so please read the instructions tab and tooltips to learn more. Click setup!';
$_['help_full_setup']							= 'Full Setup will install all available SEO modules and automatically generate meta data and SEO URLs for all pages of your store. Recommended for installing on the new store.';
$_['help_custom_setup']							= 'Custom Setup will install only required SEO modules. All further settings you have to do manually. Recommended for installing on the work store.';
$_['help_meta_title_page_template'] 			= 'Page in Meta Title Template is multilingual field, in which you can use the page number shortcode([page_number]), that allow you to get page numbers and replace shortcode with them.';
$_['help_meta_description_page_template'] 		= 'Page in Meta Description Template is multilingual field, in which you can use the page number shortcode([page_number]), that allow you to get page numbers and replace shortcode with them.';
$_['help_meta_title_page'] 						= 'Enable/disable page in the Meta Title.';
$_['help_meta_description_page'] 				= 'Enable/disable page in the Meta Description.';
$_['help_template'] 							= 'Template is multilingual field, in which you can use shortcodes, that allow you to get the values of other fields and replace shortcode with them.';
$_['help_translit_symbol'] 						= 'Translit Symbols converts special characters (%, &, #, etc.) to the characters shown in the module Translit.';
$_['help_translit_language_symbol'] 			= 'Translit Language Symbols converts language characters to the characters shown in the module Translit.';
$_['help_transform_language_symbol'] 			= 'Transform Language Symbols converts the language characters to large or small characters.';
$_['help_trim_symbol'] 							= 'Trim Symbols truncates the characters located at the beginning, at the end and which are duplicated in the middle of the text. These characters shown in the module Translit.';
$_['help_overwrite'] 							= 'If this is off, only empty values will be generated. If the parameter is on, both empty and populated values will be overwritten. Be careful with that!';

// Button		
$_['button_save'] 								= 'Save';
$_['button_save_and_stay'] 						= 'Save and Stay';
$_['button_cancel'] 							= 'Cancel';
$_['button_setup'] 								= 'Setup';
$_['button_uninstall'] 							= 'Uninstall';
$_['button_submit'] 							= 'Submit';
$_['button_generate'] 							= 'Generate';
$_['button_clear'] 								= 'Clear all';

// Success
$_['success_save']        						= 'Success: You have modified module SEO Module Meta!';
$_['success_install']        					= 'Success: You have installed module SEO Module Meta!';
$_['success_uninstall']							= 'Success: You have uninstalled module SEO Module Meta!';
$_['success_generate']        					= 'Success: You have generated Fields!';
$_['success_clear']        						= 'Success: You have cleared Fields!';

// Error
$_['error_warning']          					= 'Warning: Please check the form carefully for errors!';
$_['error_permission']    						= 'Warning: You do not have permission to modify module SEO Module Meta!';
$_['error_installed']							= 'Warning: You can not install this module because it is already installed!';
$_['error_dependence_d_seo_module']    	= 'Warning: You can not install this module until you install module SEO Module!';

?>