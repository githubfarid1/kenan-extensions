<?php
// Heading
$_['heading_title']       				= '<span style="color:#449DD0; font-weight:bold">SEO Module Manager</span><span style="font-size:0.9em; color:#999"> by <a href="http://www.opencart.com/index.php?route=extension/extension&filter_username=Dreamvention" style="font-size:1em; color:#999" target="_blank">Dreamvention</a></span>'; 
$_['heading_title_main']  				= 'SEO Module Manager';

// Text
$_['text_edit']            				= 'Edit SEO Module Manager';
$_['text_install']              		= 'Install SEO Module Manager';
$_['text_modules']         				= 'Modules';
$_['text_overview_list']       			= 'Overview List';
$_['text_export_import']       			= 'Export & Import';
$_['text_settings']       				= 'Settings';
$_['text_instructions']   				= 'Instructions';
$_['text_export']						= 'Export';
$_['text_import']						= 'Import';
$_['text_setup']						= 'Install SEO Module Manager now';
$_['text_full_setup']					= 'Full';
$_['text_custom_setup']					= 'Custom';
$_['text_all_stores']     				= 'All Stores';
$_['text_all_languages']  				= 'All Languages';
$_['text_yes'] 							= 'Yes';
$_['text_no'] 							= 'No';
$_['text_enabled']          			= 'Enabled';
$_['text_disabled']          			= 'Disabled';
$_['text_basic_settings']            	= 'Basic Settings';
$_['text_seo_module']   				= 'SEO Module';
$_['text_manager']   					= 'Manager';
$_['text_uninstall_confirm']          	= 'Are you sure you want to uninstall SEO Module Manager?';
$_['text_powered_by']               	= 'Tested with <a href="https://shopunity.net/">Shopunity.net</a><br/>Find more extensions at <a href="https://dreamvention.ee/">Dreamvention.com</a>';
$_['text_instructions_full'] 			= '
<div class="row">
	<div class="col-sm-2">
		<ul class="nav nav-pills nav-stacked">
			<li class="active"><a href="#vtab_instruction_install"  data-toggle="tab">Installation and Updating</a></li>
			<li><a href="#vtab_instruction_setting" data-toggle="tab">Settings</a></li>
			<li><a href="#vtab_instruction_list_element" data-toggle="tab">List of pages</a></li>
			<li><a href="#vtab_instruction_export_import" data-toggle="tab">Export & Import</a></li>
		</ul>
	</div>
	<div class="col-sm-10">
		<div class="tab-content">
			<div id="vtab_instruction_install" class="tab-pane active">
				<div class="tab-body">
					<h3>Installation</h3>
					<ol>
						<li>Unzip distribution file.</li>
						<li>Upload everything from the folder <code>UPLOAD</code> into the root folder of you shop.</li>
						<li>Goto admin of your shop and navigate to extensions -> modules -> SEO Module Manager.</li>
						<li>Click install button.</li>
					</ol>
					<div class="bs-callout bs-callout-info">
						<h4>Note!</h4>
						<p>Our installation process requires you to have access to the internet because we will install all the required dependencies before we install the module. Install SEO Module Manager is possible only after installing SEO Module.</p>
					</div>
					<div class="bs-callout bs-callout-warning">
						<h4>Warning!</h4>
						<p>If you get an error on this step, be sure to make you <code>DOWNLOAD</code> folder (usually in system folder of you shop) writable.</p>
					</div>
					<h3>Updating</h3>
					<ol>
						<li>Unzip distribution file.</li>
						<li>Upload everything from the folder <code>UPLOAD</code> into the root folder of you shop.</li>
						<li>Click overwrite for all files.</li>
					</ol>
					<div class="bs-callout bs-callout-info">
						<h4>Note!</h4>
						<p>Although we follow strict standards that do not allow feature updates to cause a full reinstall of the module, still it may happen that major releases require you to uninstall/install the module again before new feature take place.</p>
					</div>
					<div class="bs-callout bs-callout-warning">
						<h4>Warning!</h4>
						<p>If you have made custom corrections to the code, your code will be rewritten and lost once you update the module.</p>
					</div>
				</div>
			</div>
			<div id="vtab_instruction_setting" class="tab-pane">
				<div class="tab-body">
					<h3>Basic Settings</h3>
					<p>Here you can:</p>
					<ol>
						<li>Specify in the field "List Items Per Page" the maximum number of items in the list on the tab "List of pages".</li>
						<li>Uninstall SEO Module Manager.</li>
					</ol>
					<h3>Category</h3>
					<p>Here you can set some fields of category, which you would like to see on the tab "List of pages" and in the export file.</p>
					<h3>Product</h3>
					<p>Here you can set some fields of product, which you would like to see on the tab "List of pages" and in the export file.</p>
					<h3>Manufacturer</h3>
					<p>Here you can set some fields of manufacturer, which you would like to see on the tab "List of pages" and in the export file.</p>
					<h3>Information</h3>
					<p>Here you can set some fields of information, which you would like to see on the tab "List of pages" and in the export file.</p>
					<div class="bs-callout bs-callout-info">
						<h4>Note!</h4>
						<p>Maximun number of fields on the tab "List of pages" and in the export file, depends on the installed SEO modules, such as SEO Module Meta and SEO Module URL.</p>
					</div>
				</div>
			</div>
			<div id="vtab_instruction_list_element" class="tab-pane">
				<div class="tab-body">
					<h3>List of pages</h3>
					<p>Here you can:</p>
					<ol>
						<li>View and edit the values of fields of categories, products, manufacturers and informations, specified on the tab "Settings" for different languages. To edit, you need to click on the field table cell, change the value of field and press button <span class="btn btn-primary btn-xs"><i class="fa fa-save"></i></span>. If you decide not to save the new value, press button <span class="btn btn-danger btn-xs"><i class="fa fa-remove"></i></span>.</li>
						<li>Filter categories, products, manufacturers and informations on different fields. To do this, you need to write the values under the titles of those fields, for which you want to filter, and press button <span class="btn btn-primary btn-xs"><i class="fa fa-search"></i> Filter</span>.</li>
					</ol>
				</div>
			</div>
			<div id="vtab_instruction_export_import" class="tab-pane">
				<div class="tab-body">
					<h3>Export</h3>
					<p>Export is used to upload the values of fields of categories, products, manufacturers and informations, specified on the tab "Settings", to Excel file. To export on the tab "Export", press button "Export".</p>
					<h3>Import</h3>
					<p>Import is used to download the values of fields of categories, products, manufacturers and informations from Excel file. To import on the tab "Import", choose the xls file and press button "Import".</p>
				</div>
			</div>
		</div>
	</div>
</div>';
$_['text_not_found'] = '
<div class="jumbotron">
	<h1>Please install Shopunity</h1>
	<p>Before you can use this module you will need to install Shopunity. Simply download the archive for your version of opencart and install it view Extension Installer or unzip the archive and upload all the files into your root folder from the UPLOAD folder.</p>
	<p><a class="btn btn-primary btn-lg" href="https://shopunity.net/download" target="_blank">Download</a></p>
</div>';

// Features
$_['text_export_import_of_all_seo_parameters']			= 'Export & Import of all SEO Parameters';
$_['text_manage_all_seo_data_for_all_pages']			= 'Manage all SEO data for all pages';
$_['text_flexible_settings_for_overview']				= 'Flexible settings for overview';
$_['text_flexible_settings-for-export-import-to-excel']	= 'Flexible settings for Export & Import to Excel';
$_['text_seo_module_manager_api']						= 'SEO Module Manager API';

// Column	
$_['column_field']						= 'Field';
$_['column_list_status']				= 'List Status';
$_['column_export_status']				= 'Export Status';	

// Entry
$_['entry_status']        				= 'Status';
$_['entry_uninstall']					= 'Uninstall Module';
$_['entry_list_limit']        			= 'List Items Per Page';
$_['entry_store']        				= 'Choose Store';
$_['entry_sheet']        				= 'Choose Sheets';
$_['entry_export']        				= 'Export to File';
$_['entry_upload']        				= 'Upload File';
$_['entry_import']        				= 'Import from File';

// Help
$_['help_setup']						= 'SEO module Manager is an awesome tool to edit all your SEO data. It has a personal API that allows other modules to extend its editable fields. It also allows you to export to excel, edit and import back in only to update the data. Export/import is also extendable with API. It is the tool every SEO expert dreams of. Click setup!';
$_['help_full_setup']					= 'Full Setup will install all available SEO modules and automatically generate meta data and SEO URLs for all pages of your store. Recommended for installing on the new store.';
$_['help_custom_setup']					= 'Custom Setup will install only required SEO modules. All further settings you have to do manually. Recommended for installing on the work store.';

// Button		
$_['button_save'] 						= 'Save';
$_['button_save_and_stay'] 				= 'Save and Stay';
$_['button_cancel'] 					= 'Cancel';
$_['button_setup'] 						= 'Setup';
$_['button_uninstall'] 					= 'Uninstall';	
$_['button_filter'] 					= 'Filter';
$_['button_clear_filter'] 				= 'Clear filter';
$_['button_export'] 					= 'Export';
$_['button_import'] 					= 'Import';

// Success
$_['success_save']        				= 'Success: You have modified settings for the module SEO Module Manager!';
$_['success_install']        			= 'Success: You have installed module SEO Module Manager!';
$_['success_uninstall']					= 'Success: You have uninstalled module SEO Module Manager!';
$_['success_import']        			= 'Success: You have successfully imported your data!';

// Error
$_['error_warning']          			= 'Warning: Please check the form carefully for errors!';
$_['error_permission']    				= 'Warning: You do not have permission to modify module SEO Module Manager!';
$_['error_installed']					= 'Warning: You can not install this module because it is already installed!';
$_['error_dependence_d_seo_module']    	= 'Warning: You can not install this module until you install module SEO Module!';
$_['error_upload_name']					= 'Warning: Missing file name for upload!';
$_['error_upload_ext']					= 'Warning: Uploaded file has not one of the \'.xls\', \'.xlsx\' or \'.ods\' file name extensions, it might not be a spreadsheet file!';

?>