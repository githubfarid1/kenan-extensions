<?php
// Text
$_['text_meta_title_empty']						= 'Meta Title Empty';
$_['text_meta_title_duplicate']					= 'Meta Title Duplicate';
$_['text_meta_title_target_keyword']			= 'Meta Title Target Keyword';
$_['text_meta_title_length']					= 'Meta Title Length';
$_['text_meta_description_empty']				= 'Meta Description Empty';
$_['text_meta_description_target_keyword']		= 'Meta Description Target Keyword';
$_['text_meta_description_length']				= 'Meta Description Length';
$_['text_custom_title_1_target_keyword']		= 'Custom Title 1 Target Keyword';
$_['text_custom_title_2_target_keyword']		= 'Custom Title 2 Target Keyword';
$_['text_meta_robots_no_index']					= 'Meta Robots NO INDEX';
$_['text_meta_robots_no_follow']				= 'Meta Robots NO FOLLOW';

// Help
$_['help_meta_title_empty']						= 'Your Meta Title is empty. Please fill the field Meta Title.';
$_['help_meta_title_duplicate']					= 'You have duplicate Meta Titles. Try to avoid duplicates in the field Meta Title.';
$_['help_meta_title_target_keyword']			= 'You have not used all of the Target Keywords in the Meta Title. Try adding more Target Keywords to Meta Title.';
$_['help_meta_title_length']					= 'Your Meta Title is too long. Try reducing to 60 symbols.';
$_['help_meta_description_empty']				= 'Your Meta Description is empty. Please fill the field Meta Description.';
$_['help_meta_description_target_keyword']		= 'You have not used all of the Target Keywords in the Meta Description. Try adding more Target Keywords to Meta Description.';
$_['help_meta_description_length']				= 'Your Meta Description is too long. Try reducing to 160 symbols.';
$_['help_custom_title_1_target_keyword']		= 'You have not used all of the Target Keywords in the Custom Title 1 (h1). Try adding more Target Keywords to Custom Title 1 (h1).';
$_['help_custom_title_2_target_keyword']		= 'You have not used all of the Target Keywords in the Custom Title 2 (h2). Try adding more Target Keywords to Custom Title 2 (h2).';
$_['help_meta_robots_no_index']					= 'Your Meta Robots is set to noindex. This page will not be seen to search engines.';
$_['help_meta_robots_no_follow']				= 'Your Meta Robots is set to nofollow. All forwarding links from this page will not pass juice to other pages.';

?>