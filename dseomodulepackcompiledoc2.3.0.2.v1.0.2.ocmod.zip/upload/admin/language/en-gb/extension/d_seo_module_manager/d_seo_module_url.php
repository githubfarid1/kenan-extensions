<?php
// Text
$_['text_category_id']							= 'Category ID';
$_['text_url_keyword']							= 'URL Keyword';

?>