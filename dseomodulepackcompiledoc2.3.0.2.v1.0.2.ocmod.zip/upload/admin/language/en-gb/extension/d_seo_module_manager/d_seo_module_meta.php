<?php
// Text
$_['text_category_name']						= 'Category Name';
$_['text_product_name']							= 'Product Name';
$_['text_manufacturer_name']					= 'Manufacturer Name';
$_['text_information_title']					= 'Information Title';
$_['text_description']							= 'Description';
$_['text_tag']									= 'Tags';
$_['text_meta_title']							= 'Meta Tag Title';
$_['text_meta_description']						= 'Meta Tag Description';
$_['text_meta_keyword']							= 'Meta Tag Keywords';
$_['text_meta_robots']							= 'Meta Robots';
$_['text_custom_title_1']						= 'Custom Title 1';
$_['text_custom_title_2']						= 'Custom Title 2';
$_['text_custom_image_title']					= 'Custom Image Title';
$_['text_custom_image_alt']						= 'Custom Image Alt';

?>