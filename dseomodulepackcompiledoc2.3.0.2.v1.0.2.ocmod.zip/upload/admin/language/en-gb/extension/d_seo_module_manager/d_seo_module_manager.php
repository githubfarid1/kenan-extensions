<?php
// Text
$_['text_category']						= 'Category';
$_['text_product']						= 'Product';
$_['text_manufacturer']					= 'Manufacturer';
$_['text_information']					= 'Information';
$_['text_category_id']					= 'Category ID';
$_['text_category_name']				= 'Category Name';
$_['text_product_id']					= 'Product ID';
$_['text_product_name']					= 'Product Name';
$_['text_manufacturer_id']				= 'Manufacturer ID';
$_['text_manufacturer_name']			= 'Manufacturer Name';
$_['text_information_id']				= 'Information ID';
$_['text_information_title']			= 'Information Title';
$_['text_description']					= 'Description';
$_['text_meta_title']					= 'Meta Title';
$_['text_meta_description']				= 'Meta Description';
$_['text_meta_keyword']					= 'Meta Keyword';
$_['text_tag']							= 'Tags';

?>