<?php
// Heading
$_['heading_title_main']  						= 'SEO Module Adviser';

// Text
$_['text_seo_rating']							= 'SEO Rating';
$_['text_enable_status']						= 'Enable Status of SEO Module Adviser';

// Help
$_['help_seo_rating']							= 'SEO Rating indicates the rating of the page for the current language for SEO. It takes a value from 0 to 100.';
$_['help_enable_status']						= 'Enable status of the module SEO Module Adviser.';

?>