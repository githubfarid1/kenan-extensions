<?php
// Heading
$_['heading_title_main']  				= 'SEO Module Manager';

?>