<?php
class ControllerExtensionDSEOModuleDSEOModuleAdviser extends Controller {
	private $codename = 'd_seo_module_adviser';
	private $route = 'extension/d_seo_module/d_seo_module_adviser';
	private $config_file = 'd_seo_module_adviser';
	private $error = array();
			
	/*
	*	Functions for SEO Module.
	*/	
	public function menu() {
		$_language = new Language();
		$_language->load($this->route);
		
		$url_token = '';
		
		if (isset($this->session->data['token'])) {
			$url_token .= 'token=' . $this->session->data['token'];
		}
		
		if (isset($this->session->data['user_token'])) {
			$url_token .= 'user_token=' . $this->session->data['user_token'];
		}
		
		$menu = array();

		if ($this->user->hasPermission('access', 'extension/module/' . $this->codename)) {
			$menu[] = array(
				'name'	   		=> $_language->get('heading_title_main'),
				'href'     		=> $this->url->link('extension/module/' . $this->codename, $url_token, true),
				'sort_order' 	=> 11,
				'children' 		=> array()
			);
		}

		return $menu;
	}
		
	public function setting_tab_general_language() {
		$this->load->model('extension/module/' . $this->codename);
				
		if (file_exists(DIR_APPLICATION . 'model/extension/module/d_twig_manager.php')) {
			$this->load->model('extension/module/d_twig_manager');
			
			$this->model_extension_module_d_twig_manager->installCompatibility();
		}
		
		$stores = $this->{'model_extension_module_' . $this->codename}->getStores();
		$languages = $this->{'model_extension_module_' . $this->codename}->getLanguages();
		
		$field_info = $this->load->controller('extension/module/d_seo_module/getFieldInfo');
				
		if (isset($field_info['sheet']['custom_page']['field'])) {
			$data['fields'] = $field_info['sheet']['custom_page']['field'];
		} else {
			$data['fields'] = array();
		}
					
		$data['adviser_elements'] = array();
		$data['rating'] = array();
				
		$route = 'common/home';
		$store_id = 0;
			
		$adviser_info = $this->load->controller('extension/module/d_seo_module_adviser/getAdviserInfo', $route);
		
		if (isset($adviser_info['adviser_elements'][$store_id]) && isset($adviser_info['rating'][$store_id])) {
			$data['adviser_elements'] = $adviser_info['adviser_elements'][$store_id];
			$data['rating'] = $adviser_info['rating'][$store_id];
		}
				
		$html_tab_general_language = array();
		
		foreach ($languages as $language) {			
			$data['language_id'] = $language['language_id'];				
				
			$html_tab_general_language[$data['language_id']] = $this->load->view($this->route . '/setting_tab_general_language', $data);
		}
		
		return $html_tab_general_language;
	}
	
	public function store_form_tab_general_language() {		
		$this->load->model('extension/module/' . $this->codename);
				
		if (file_exists(DIR_APPLICATION . 'model/extension/module/d_twig_manager.php')) {
			$this->load->model('extension/module/d_twig_manager');
			
			$this->model_extension_module_d_twig_manager->installCompatibility();
		}
		
		$stores = $this->{'model_extension_module_' . $this->codename}->getStores();
		$languages = $this->{'model_extension_module_' . $this->codename}->getLanguages();
		
		$field_info = $this->load->controller('extension/module/d_seo_module/getFieldInfo');
				
		if (isset($field_info['sheet']['custom_page']['field'])) {
			$data['fields'] = $field_info['sheet']['custom_page']['field'];
		} else {
			$data['fields'] = array();
		}
					
		$data['adviser_elements'] = array();
		$data['rating'] = array();
		
		if (isset($this->request->get['store_id'])) {
			$route = 'common/home';
			$store_id = $this->request->get['store_id'];
				
			$adviser_info = $this->load->controller('extension/module/d_seo_module_adviser/getAdviserInfo', $route);
		
			if (isset($adviser_info['adviser_elements'][$store_id]) && isset($adviser_info['rating'][$store_id])) {
				$data['adviser_elements'] = $adviser_info['adviser_elements'][$store_id];
				$data['rating'] = $adviser_info['rating'][$store_id];
			}
		}
		
		$html_tab_general_language = array();
		
		foreach ($languages as $language) {			
			$data['language_id'] = $language['language_id'];				
				
			$html_tab_general_language[$data['language_id']] = $this->load->view($this->route . '/store_form_tab_general_language', $data);
		}
		
		return $html_tab_general_language;
	}
		
	public function category_form_tab_general_language() {				
		$this->load->model('extension/module/' . $this->codename);
				
		if (file_exists(DIR_APPLICATION . 'model/extension/module/d_twig_manager.php')) {
			$this->load->model('extension/module/d_twig_manager');
			
			$this->model_extension_module_d_twig_manager->installCompatibility();
		}
		
		$languages = $this->{'model_extension_module_' . $this->codename}->getLanguages();
		
		$field_info = $this->load->controller('extension/module/d_seo_module/getFieldInfo');
				
		if (isset($field_info['sheet']['category']['field'])) {
			$data['fields'] = $field_info['sheet']['category']['field'];
		} else {
			$data['fields'] = array();
		}
		
		$data['adviser_elements'] = array();
		$data['rating'] = array();
		
		if (isset($this->request->get['category_id'])) {
			$route = 'category_id=' . $this->request->get['category_id'];
			
			$adviser_info = $this->load->controller('extension/module/d_seo_module_adviser/getAdviserInfo', $route);
		
			if (isset($adviser_info['adviser_elements']) && isset($adviser_info['rating'])) {
				$data['adviser_elements'] = $adviser_info['adviser_elements'];
				$data['rating'] = $adviser_info['rating'];
			}
		}
				
		$data['store_id'] = 0;
		
		$html_tab_general_language = array();
		
		foreach ($languages as $language) {			
			$data['language_id'] = $language['language_id'];				
				
			$html_tab_general_language[$data['language_id']] = $this->load->view($this->route . '/category_form_tab_general_language', $data);
		}
		
		return $html_tab_general_language;
	}
	
	public function category_form_tab_general_store_language() {				
		$this->load->model('extension/module/' . $this->codename);
				
		if (file_exists(DIR_APPLICATION . 'model/extension/module/d_twig_manager.php')) {
			$this->load->model('extension/module/d_twig_manager');
			
			$this->model_extension_module_d_twig_manager->installCompatibility();
		}
		
		$stores = $this->{'model_extension_module_' . $this->codename}->getStores();
		$languages = $this->{'model_extension_module_' . $this->codename}->getLanguages();
		
		$field_info = $this->load->controller('extension/module/d_seo_module/getFieldInfo');
				
		if (isset($field_info['sheet']['category']['field'])) {
			$data['fields'] = $field_info['sheet']['category']['field'];
		} else {
			$data['fields'] = array();
		}
						
		$data['adviser_elements'] = array();
		$data['rating'] = array();
		
		if (isset($this->request->get['category_id'])) {
			$route = 'category_id=' . $this->request->get['category_id'];
			
			$adviser_info = $this->load->controller('extension/module/d_seo_module_adviser/getAdviserInfo', $route);
		
			if (isset($adviser_info['adviser_elements']) && isset($adviser_info['rating'])) {
				$data['adviser_elements'] = $adviser_info['adviser_elements'];
				$data['rating'] = $adviser_info['rating'];
			}
		}
		
		$html_tab_general_language = array();
		
		foreach ($stores as $store) {
			$data['store_id'] = $store['store_id'];
			
			foreach ($languages as $language) {	
				$data['language_id'] = $language['language_id'];				
				
				$html_tab_general_store_language[$data['store_id']][$data['language_id']] = $this->load->view($this->route . '/category_form_tab_general_store_language', $data);
			}
		}
			
		return $html_tab_general_store_language;
	}
		
	public function product_form_tab_general_language() {				
		$this->load->model('extension/module/' . $this->codename);
		
		if (file_exists(DIR_APPLICATION . 'model/extension/module/d_twig_manager.php')) {
			$this->load->model('extension/module/d_twig_manager');
			
			$this->model_extension_module_d_twig_manager->installCompatibility();
		}		
		
		$stores = $this->{'model_extension_module_' . $this->codename}->getStores();
		$languages = $this->{'model_extension_module_' . $this->codename}->getLanguages();
		
		$field_info = $this->load->controller('extension/module/d_seo_module/getFieldInfo');
				
		if (isset($field_info['sheet']['product']['field'])) {
			$data['fields'] = $field_info['sheet']['product']['field'];
		} else {
			$data['fields'] = array();
		}
					
		$data['adviser_elements'] = array();
		$data['rating'] = array();
				
		if (isset($this->request->get['product_id'])) {
			$route = 'product_id=' . $this->request->get['product_id'];
			
			$adviser_info = $this->load->controller('extension/module/d_seo_module_adviser/getAdviserInfo', $route);
		
			if (isset($adviser_info['adviser_elements']) && isset($adviser_info['rating'])) {
				$data['adviser_elements'] = $adviser_info['adviser_elements'];
				$data['rating'] = $adviser_info['rating'];
			}
		}
		
		$data['store_id'] = 0;
		
		$html_tab_general_language = array();
		
		foreach ($languages as $language) {			
			$data['language_id'] = $language['language_id'];				
				
			$html_tab_general_language[$data['language_id']] = $this->load->view($this->route . '/product_form_tab_general_language', $data);
		}
		
		return $html_tab_general_language;
	}
	
	public function product_form_tab_general_store_language() {				
		$this->load->model('extension/module/' . $this->codename);
				
		if (file_exists(DIR_APPLICATION . 'model/extension/module/d_twig_manager.php')) {
			$this->load->model('extension/module/d_twig_manager');
			
			$this->model_extension_module_d_twig_manager->installCompatibility();
		}
		
		$stores = $this->{'model_extension_module_' . $this->codename}->getStores();
		$languages = $this->{'model_extension_module_' . $this->codename}->getLanguages();
		
		$field_info = $this->load->controller('extension/module/d_seo_module/getFieldInfo');
				
		if (isset($field_info['sheet']['product']['field'])) {
			$data['fields'] = $field_info['sheet']['product']['field'];
		} else {
			$data['fields'] = array();
		}
		
		$data['adviser_elements'] = array();
		$data['rating'] = array();
				
		if (isset($this->request->get['product_id'])) {
			$route = 'product_id=' . $this->request->get['product_id'];
			
			$adviser_info = $this->load->controller('extension/module/d_seo_module_adviser/getAdviserInfo', $route);
		
			if (isset($adviser_info['adviser_elements']) && isset($adviser_info['rating'])) {
				$data['adviser_elements'] = $adviser_info['adviser_elements'];
				$data['rating'] = $adviser_info['rating'];
			}
		}
		
		$html_tab_general_language = array();
		
		foreach ($stores as $store) {
			$data['store_id'] = $store['store_id'];
			
			foreach ($languages as $language) {	
				$data['language_id'] = $language['language_id'];				
				
				$html_tab_general_store_language[$data['store_id']][$data['language_id']] = $this->load->view($this->route . '/product_form_tab_general_store_language', $data);
			}
		}
			
		return $html_tab_general_store_language;
	}
	
	public function manufacturer_form_tab_general_language() {				
		$this->load->model('extension/module/' . $this->codename);
				
		if (file_exists(DIR_APPLICATION . 'model/extension/module/d_twig_manager.php')) {
			$this->load->model('extension/module/d_twig_manager');
			
			$this->model_extension_module_d_twig_manager->installCompatibility();
		}
		
		$stores = $this->{'model_extension_module_' . $this->codename}->getStores();
		$languages = $this->{'model_extension_module_' . $this->codename}->getLanguages();
		
		$field_info = $this->load->controller('extension/module/d_seo_module/getFieldInfo');
				
		if (isset($field_info['sheet']['manufacturer']['field'])) {
			$data['fields'] = $field_info['sheet']['manufacturer']['field'];
		} else {
			$data['fields'] = array();
		}
					
		$data['adviser_elements'] = array();
		$data['rating'] = array();
				
		if (isset($this->request->get['manufacturer_id'])) {
			$route = 'manufacturer_id=' . $this->request->get['manufacturer_id'];
			
			$adviser_info = $this->load->controller('extension/module/d_seo_module_adviser/getAdviserInfo', $route);
		
			if (isset($adviser_info['adviser_elements']) && isset($adviser_info['rating'])) {
				$data['adviser_elements'] = $adviser_info['adviser_elements'];
				$data['rating'] = $adviser_info['rating'];
			}
		}
		
		$data['store_id'] = 0;
		
		$html_tab_general_language = array();
		
		foreach ($languages as $language) {			
			$data['language_id'] = $language['language_id'];				
				
			$html_tab_general_language[$data['language_id']] = $this->load->view($this->route . '/manufacturer_form_tab_general_language', $data);
		}
		
		return $html_tab_general_language;
	}
	
	public function manufacturer_form_tab_general_store_language() {				
		$this->load->model('extension/module/' . $this->codename);
				
		if (file_exists(DIR_APPLICATION . 'model/extension/module/d_twig_manager.php')) {
			$this->load->model('extension/module/d_twig_manager');
			
			$this->model_extension_module_d_twig_manager->installCompatibility();
		}
		
		$stores = $this->{'model_extension_module_' . $this->codename}->getStores();
		$languages = $this->{'model_extension_module_' . $this->codename}->getLanguages();
		
		$field_info = $this->load->controller('extension/module/d_seo_module/getFieldInfo');
				
		if (isset($field_info['sheet']['manufacturer']['field'])) {
			$data['fields'] = $field_info['sheet']['manufacturer']['field'];
		} else {
			$data['fields'] = array();
		}
		
		$data['adviser_elements'] = array();
		$data['rating'] = array();
				
		if (isset($this->request->get['manufacturer_id'])) {
			$route = 'manufacturer_id=' . $this->request->get['manufacturer_id'];
			
			$adviser_info = $this->load->controller('extension/module/d_seo_module_adviser/getAdviserInfo', $route);
		
			if (isset($adviser_info['adviser_elements']) && isset($adviser_info['rating'])) {
				$data['adviser_elements'] = $adviser_info['adviser_elements'];
				$data['rating'] = $adviser_info['rating'];
			}
		}
		
		$html_tab_general_language = array();
		
		foreach ($stores as $store) {
			$data['store_id'] = $store['store_id'];
			
			foreach ($languages as $language) {	
				$data['language_id'] = $language['language_id'];				
				
				$html_tab_general_store_language[$data['store_id']][$data['language_id']] = $this->load->view($this->route . '/manufacturer_form_tab_general_store_language', $data);
			}
		}
			
		return $html_tab_general_store_language;
	}
	
	public function information_form_tab_general_language() {				
		$this->load->model('extension/module/' . $this->codename);
				
		if (file_exists(DIR_APPLICATION . 'model/extension/module/d_twig_manager.php')) {
			$this->load->model('extension/module/d_twig_manager');
			
			$this->model_extension_module_d_twig_manager->installCompatibility();
		}
		
		$stores = $this->{'model_extension_module_' . $this->codename}->getStores();
		$languages = $this->{'model_extension_module_' . $this->codename}->getLanguages();
		
		$field_info = $this->load->controller('extension/module/d_seo_module/getFieldInfo');
				
		if (isset($field_info['sheet']['information']['field'])) {
			$data['fields'] = $field_info['sheet']['information']['field'];
		} else {
			$data['fields'] = array();
		}
					
		$data['adviser_elements'] = array();
		$data['rating'] = array();
				
		if (isset($this->request->get['information_id'])) {
			$route = 'information_id=' . $this->request->get['information_id'];
			
			$adviser_info = $this->load->controller('extension/module/d_seo_module_adviser/getAdviserInfo', $route);
		
			if (isset($adviser_info['adviser_elements']) && isset($adviser_info['rating'])) {
				$data['adviser_elements'] = $adviser_info['adviser_elements'];
				$data['rating'] = $adviser_info['rating'];
			}
		}
		
		$data['store_id'] = 0;
		
		$html_tab_general_language = array();
		
		foreach ($languages as $language) {			
			$data['language_id'] = $language['language_id'];				
				
			$html_tab_general_language[$data['language_id']] = $this->load->view($this->route . '/information_form_tab_general_language', $data);
		}
		
		return $html_tab_general_language;
	}
	
	public function information_form_tab_general_store_language() {				
		$this->load->model('extension/module/' . $this->codename);
		
		if (file_exists(DIR_APPLICATION . 'model/extension/module/d_twig_manager.php')) {
			$this->load->model('extension/module/d_twig_manager');
			
			$this->model_extension_module_d_twig_manager->installCompatibility();
		}		
				
		$stores = $this->{'model_extension_module_' . $this->codename}->getStores();
		$languages = $this->{'model_extension_module_' . $this->codename}->getLanguages();
		
		$field_info = $this->load->controller('extension/module/d_seo_module/getFieldInfo');
				
		if (isset($field_info['sheet']['information']['field'])) {
			$data['fields'] = $field_info['sheet']['information']['field'];
		} else {
			$data['fields'] = array();
		}
		
		$data['adviser_elements'] = array();
		$data['rating'] = array();
				
		if (isset($this->request->get['information_id'])) {
			$route = 'information_id=' . $this->request->get['information_id'];
			
			$adviser_info = $this->load->controller('extension/module/d_seo_module_adviser/getAdviserInfo', $route);
		
			if (isset($adviser_info['adviser_elements']) && isset($adviser_info['rating'])) {
				$data['adviser_elements'] = $adviser_info['adviser_elements'];
				$data['rating'] = $adviser_info['rating'];
			}
		}
		
		$html_tab_general_language = array();
		
		foreach ($stores as $store) {
			$data['store_id'] = $store['store_id'];
			
			foreach ($languages as $language) {	
				$data['language_id'] = $language['language_id'];				
				
				$html_tab_general_store_language[$data['store_id']][$data['language_id']] = $this->load->view($this->route . '/information_form_tab_general_store_language', $data);
			}
		}
			
		return $html_tab_general_store_language;
	}
	
	public function control_extensions() {
		$_language = new Language();
		$_language->load($this->route);
		
		$url_token = '';
		
		if (isset($this->session->data['token'])) {
			$url_token .= 'token=' . $this->session->data['token'];
		}
		
		if (isset($this->session->data['user_token'])) {
			$url_token .= 'user_token=' . $this->session->data['user_token'];
		}
		
		$control_extensions = array();

		$control_extensions[] = array(
			'code'				=> $this->codename,
			'name'	   			=> $_language->get('heading_title_main'),
			'image'				=> $this->codename . '/logo.svg',
			'href'     			=> $this->url->link('extension/module/' . $this->codename, $url_token, true),
			'sort_order' 		=> 11
		);
				
		return $control_extensions;
	}
	
	public function control_install_extension() {
		$this->load->controller('extension/module/' . $this->codename . '/installExtension');
			
		$json = $this->response->getOutput();
			
		if ($json) {
			$data = json_decode($json, true);
			
			return $data;
		}
		
		return false;
	}
	
	public function control_elements($data) {
		$_language = new Language();
		$_language->load($this->route);
		
		$this->load->model('extension/module/' . $this->codename);
		$this->load->model('setting/setting');
		
		$url_token = '';
		
		if (isset($this->session->data['token'])) {
			$url_token .= 'token=' . $this->session->data['token'];
		}
		
		if (isset($this->session->data['user_token'])) {
			$url_token .= 'user_token=' . $this->session->data['user_token'];
		}
		
		// Setting 						
		$setting = $this->model_setting_setting->getSetting('module_' . $this->codename);
		$status = isset($setting['module_' . $this->codename . '_status']) ? $setting['module_' . $this->codename . '_status'] : false;
		$setting = isset($setting['module_' . $this->codename . '_setting']) ? $setting['module_' . $this->codename . '_setting'] : array();
		
		$control_elements = array();
		
		if (!$status) {
			$control_elements[] = array(
				'extension_code' 		=> $this->codename,
				'extension_name' 		=> $_language->get('heading_title_main'),
				'element_code'			=> 'enable_status',
				'name'					=> $_language->get('text_enable_status'),
				'description'			=> $_language->get('help_enable_status'),
				'confirm'				=> false,
				'href'					=> $this->url->link('extension/module/' . $this->codename . '/setting', $url_token, true),
				'implemented'			=> isset($setting['control_element']['enable_status']['implemented']) ? 1 : 0,
				'weight'				=> 1
			);
		}
								
		return $control_elements;
	}
	
	public function control_execute_element($data) {
		$this->load->model('extension/module/' . $this->codename);
		$this->load->model('setting/setting');
		
		// Setting
		$setting = $this->model_setting_setting->getSetting('module_' . $this->codename);
								
		if ($data['element_code'] == 'enable_status') {
			$setting['module_' . $this->codename . '_status'] = 1;
			$setting['module_' . $this->codename . '_setting']['control_element']['enable_status']['implemented'] = 1;
			
			$this->model_setting_setting->editSetting('module_' . $this->codename, $setting);
		}
						
		$result['error'] = $this->error;
		
		return $result;
	}
		
	public function field_config() {
		$_language = new Language();
		$_language->load($this->route);
		
		$_config = new Config();
		$_config->load($this->config_file);
		$field_setting = ($_config->get($this->codename . '_field_setting')) ? $_config->get($this->codename . '_field_setting') : array();

		foreach ($field_setting['sheet'] as $sheet) {				
			foreach ($sheet['field'] as $field) {
				if (substr($field['name'], 0, strlen('text_')) == 'text_') {
					$field_setting['sheet'][$sheet['code']]['field'][$field['code']]['name'] = $_language->get($field['name']);
				}
				
				if (substr($field['description'], 0, strlen('help_')) == 'help_') {
					$field_setting['sheet'][$sheet['code']]['field'][$field['code']]['description'] = $_language->get($field['description']);
				}
			}
		}
					
		return $field_setting;
	}
}