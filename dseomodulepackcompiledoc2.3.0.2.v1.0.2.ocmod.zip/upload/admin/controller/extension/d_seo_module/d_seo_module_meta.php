<?php
class ControllerExtensionDSEOModuleDSEOModuleMeta extends Controller {
	private $codename = 'd_seo_module_meta';
	private $route = 'extension/d_seo_module/d_seo_module_meta';
	private $config_file = 'd_seo_module_meta';
	private $error = array();
		
	/*
	*	Functions for SEO Module.
	*/	
	public function menu() {
		$_language = new Language();
		$_language->load($this->route);
		
		$url_token = '';
		
		if (isset($this->session->data['token'])) {
			$url_token .= 'token=' . $this->session->data['token'];
		}
		
		if (isset($this->session->data['user_token'])) {
			$url_token .= 'user_token=' . $this->session->data['user_token'];
		}
		
		$menu = array();

		if ($this->user->hasPermission('access', 'extension/module/' . $this->codename)) {
			$menu[] = array(
				'name'	   		=> $_language->get('heading_title_main'),
				'href'     		=> $this->url->link('extension/module/' . $this->codename, $url_token, true),
				'sort_order' 	=> 2,
				'children' 		=> array()
			);
		}

		return $menu;
	}
	
	public function dashboard() {
		$dashboards = array();
		
		if ($this->user->hasPermission('access', 'extension/module/' . $this->codename)) {
			$dashboards[] = array(
				'html' 			=> $this->load->controller('extension/dashboard/d_seo_module_meta_title/dashboard'),
				'width' 		=> 12,
				'sort_order' 	=> 30
			);
		}

		return $dashboards;
	}
		
	public function language_add_language($data) {
		$this->load->model($this->route);
		
		$this->{'model_extension_d_seo_module_' . $this->codename}->addLanguage($data);
	}
	
	public function language_delete_language($data) {
		$this->load->model($this->route);
		
		$this->{'model_extension_d_seo_module_' . $this->codename}->deleteLanguage($data);
	}
		
	public function setting_tab_general_language() {
		$this->load->model($this->route);
		$this->load->model('extension/module/' . $this->codename);
		
		if (file_exists(DIR_APPLICATION . 'model/extension/module/d_twig_manager.php')) {
			$this->load->model('extension/module/d_twig_manager');
			
			$this->model_extension_module_d_twig_manager->installCompatibility();
		}
		
		$languages = $this->{'model_extension_module_' . $this->codename}->getLanguages();
		
		$field_info = $this->load->controller('extension/module/d_seo_module/getFieldInfo');
		
		if (isset($field_info['sheet']['custom_page']['field'])) {
			$data['fields'] = $field_info['sheet']['custom_page']['field'];
		} else {
			$data['fields'] = array();
		}
		
		$data['error'] = ($this->config->get($this->codename . '_error')) ? $this->config->get($this->codename . '_error') : array();
							
		if (isset($this->request->post['meta_data'])) {
			$data['meta_data'] = $this->request->post['meta_data'];
		} else {
			$data['meta_data'] = $this->{'model_extension_d_seo_module_' . $this->codename}->getHomeMetaData();
		}
		
		$html_tab_general_language = array();
				
		foreach ($languages as $language) {
			$data['language_id'] = $language['language_id'];
		
			$html_tab_general_language[$data['language_id']] = $this->load->view($this->route . '/setting_tab_general_language', $data);
		}
		
		return $html_tab_general_language;
	}
	
	public function setting_script() {		
		if (file_exists(DIR_APPLICATION . 'model/extension/module/d_twig_manager.php')) {
			$this->load->model('extension/module/d_twig_manager');
			
			$this->model_extension_module_d_twig_manager->installCompatibility();
		}
		
		return $this->load->view($this->route . '/setting_script');
	}
	
	public function setting_validate($error) {		
		unset($error['meta_title']);
		
		if (isset($this->request->post['meta_data'])) {		
			$_language = new Language();
			$_language->load($this->route);
			
			foreach ($this->request->post['meta_data'] as $language_id => $meta_data) {
				if (isset($meta_data['meta_title']) && ((utf8_strlen($meta_data['meta_title']) < 3) || (utf8_strlen($meta_data['meta_title']) > 255))) {
					$error['meta_data'][$language_id]['meta_title'] = $_language->get('error_meta_title');
				}
			}

			$this->config->set($this->codename . '_error', $error);
		}
				
		return $error;
	}

	public function setting_edit_setting($data) {
		$this->load->model($this->route);
				
		$this->{'model_extension_d_seo_module_' . $this->codename}->saveHomeMetaData($data);
		
		$language_id = (int)$this->config->get('config_language_id');
		
		if (isset($this->request->post['meta_data'][$language_id]['meta_title'])) {
			$this->request->post['config_meta_title'] = $this->request->post['meta_data'][$language_id]['meta_title'];
		}
	}	
	
	public function store_form_tab_general_language() {		
		$this->load->model($this->route);
		$this->load->model('extension/module/' . $this->codename);
		
		if (file_exists(DIR_APPLICATION . 'model/extension/module/d_twig_manager.php')) {
			$this->load->model('extension/module/d_twig_manager');
			
			$this->model_extension_module_d_twig_manager->installCompatibility();
		}
		
		$languages = $this->{'model_extension_module_' . $this->codename}->getLanguages();
		
		$field_info = $this->load->controller('extension/module/d_seo_module/getFieldInfo');
		
		if (isset($field_info['sheet']['custom_page']['field'])) {
			$data['fields'] = $field_info['sheet']['custom_page']['field'];
		} else {
			$data['fields'] = array();
		}
		
		$data['error'] = ($this->config->get($this->codename . '_error')) ? $this->config->get($this->codename . '_error') : array();
							
		if (isset($this->request->post['meta_data'])) {
			$data['meta_data'] = $this->request->post['meta_data'];
		} elseif (isset($this->request->get['store_id'])) {
			$data['meta_data'] = $this->{'model_extension_d_seo_module_' . $this->codename}->getHomeMetaData($this->request->get['store_id']);
		} else {
			$data['meta_data'] = array();
		}
					
		$html_tab_general_language = array();
						
		foreach ($languages as $language) {
			$data['language_id'] = $language['language_id'];
		
			$html_tab_general_language[$data['language_id']] = $this->load->view($this->route . '/store_form_tab_general_language', $data);
		}
		
		return $html_tab_general_language;
	}
	
	public function store_form_script() {		
		if (file_exists(DIR_APPLICATION . 'model/extension/module/d_twig_manager.php')) {
			$this->load->model('extension/module/d_twig_manager');
			
			$this->model_extension_module_d_twig_manager->installCompatibility();
		}
		
		return $this->load->view($this->route . '/store_form_script');
	}
	
	public function store_validate_form($error) {		
		unset($error['meta_title']);
		
		if (isset($this->request->post['meta_data'])) {		
			$_language = new Language();
			$_language->load($this->route);
			
			foreach ($this->request->post['meta_data'] as $language_id => $meta_data) {
				if (isset($meta_data['meta_title']) && ((utf8_strlen($meta_data['meta_title']) < 3) || (utf8_strlen($meta_data['meta_title']) > 255))) {
					$error['meta_data'][$language_id]['meta_title'] = $_language->get('error_meta_title');
				}
			}
						
			$this->config->set($this->codename . '_error', $error);
		}
				
		return $error;
	}
	
	public function store_add_store($data) {
		$this->load->model($this->route);
		
		$this->{'model_extension_d_seo_module_' . $this->codename}->saveHomeMetaData($data);
		
		$language_id = (int)$this->config->get('config_language_id');
		
		if (isset($this->request->post['meta_data'][$language_id]['meta_title'])) {
			$this->request->post['config_meta_title'] = $this->request->post['meta_data'][$language_id]['meta_title'];
		}
	}
	
	public function store_edit_store($data) {
		$this->load->model($this->route);
		
		$this->{'model_extension_d_seo_module_' . $this->codename}->saveHomeMetaData($data);
		
		$language_id = (int)$this->config->get('config_language_id');
		
		if (isset($this->request->post['meta_data'][$language_id]['meta_title'])) {
			$this->request->post['config_meta_title'] = $this->request->post['meta_data'][$language_id]['meta_title'];
		}
	}
	
	public function store_delete_store($data) {
		$this->load->model($this->route);
		
		$this->{'model_extension_d_seo_module_' . $this->codename}->deleteStore($data);
	}
	
	public function category_form_tab_general_language() {		
		$this->load->model($this->route);
		$this->load->model('extension/module/' . $this->codename);
		
		if (file_exists(DIR_APPLICATION . 'model/extension/module/d_twig_manager.php')) {
			$this->load->model('extension/module/d_twig_manager');
			
			$this->model_extension_module_d_twig_manager->installCompatibility();
		}
		
		$languages = $this->{'model_extension_module_' . $this->codename}->getLanguages();
		
		$field_info = $this->load->controller('extension/module/d_seo_module/getFieldInfo');
		
		if (isset($field_info['sheet']['category']['field'])) {
			$data['fields'] = $field_info['sheet']['category']['field'];
		} else {
			$data['fields'] = array();
		}
		
		$data['error'] = ($this->config->get($this->codename . '_error')) ? $this->config->get($this->codename . '_error') : array();
										
		if (isset($this->request->post['meta_data'])) {
			$data['meta_data'] = $this->request->post['meta_data'];
		} elseif (isset($this->request->get['category_id'])) {
			$data['meta_data'] = $this->{'model_extension_d_seo_module_' . $this->codename}->getCategoryMetaData($this->request->get['category_id']);
		} else {
			$data['meta_data'] = array();
		}
		
		$data['store_id'] = 0;
			
		$html_tab_general_language = array();
				
		foreach ($languages as $language) {
			$data['language_id'] = $language['language_id'];
		
			$html_tab_general_language[$data['language_id']] = $this->load->view($this->route . '/category_form_tab_general_language', $data);
		}
				
		return $html_tab_general_language;
	}
	
	public function category_form_tab_general_store_language() {
		$this->load->model($this->route);
		$this->load->model('extension/module/' . $this->codename);
		
		if (file_exists(DIR_APPLICATION . 'model/extension/module/d_twig_manager.php')) {
			$this->load->model('extension/module/d_twig_manager');
			
			$this->model_extension_module_d_twig_manager->installCompatibility();
		}
		
		$stores = $this->{'model_extension_module_' . $this->codename}->getStores();
		$languages = $this->{'model_extension_module_' . $this->codename}->getLanguages();
		
		$field_info = $this->load->controller('extension/module/d_seo_module/getFieldInfo');
		
		if (isset($field_info['sheet']['category']['field'])) {
			$data['fields'] = $field_info['sheet']['category']['field'];
		} else {
			$data['fields'] = array();
		}
		
		$data['error'] = ($this->config->get($this->codename . '_error')) ? $this->config->get($this->codename . '_error') : array();
										
		if (isset($this->request->post['meta_data'])) {
			$data['meta_data'] = $this->request->post['meta_data'];
		} elseif (isset($this->request->get['category_id'])) {
			$data['meta_data'] = $this->{'model_extension_d_seo_module_' . $this->codename}->getCategoryMetaData($this->request->get['category_id']);
		} else {
			$data['meta_data'] = array();
		}
				
		$html_tab_general_store_language = array();
		
		foreach ($stores as $store) {
			$data['store_id'] = $store['store_id'];		
		
			foreach ($languages as $language) {
				$data['language_id'] = $language['language_id'];
		
				$html_tab_general_store_language[$data['store_id']][$data['language_id']] = $this->load->view($this->route . '/category_form_tab_general_store_language', $data);
			}
		}
		
		return $html_tab_general_store_language;
	}
	
	public function category_validate_form($error) {
		if (isset($this->request->post['meta_data'])) {		
			$_language = new Language();
			$_language->load($this->route);
			
			foreach ($this->request->post['meta_data'] as $store_id => $language_meta_data) {
				foreach ($language_meta_data as $language_id => $meta_data) {
					if ($store_id) {
						if (isset($meta_data['name']) && ((utf8_strlen($meta_data['name']) < 2) || (utf8_strlen($meta_data['name']) > 255))) {
							$error['meta_data'][$store_id][$language_id]['name'] = $_language->get('error_category_name');
						}

						if (isset($meta_data['meta_title']) && ((utf8_strlen($meta_data['meta_title']) < 3) || (utf8_strlen($meta_data['meta_title']) > 255))) {
							$error['meta_data'][$store_id][$language_id]['meta_title'] = $_language->get('error_meta_title');
						}
					}
				}
			}
		}
		
		$this->config->set($this->codename . '_error', $error);
				
		return $error;
	}	
	
	public function category_add_category($data) {
		$this->load->model($this->route);
		
		$this->{'model_extension_d_seo_module_' . $this->codename}->saveCategoryMetaData($data);
	}
	
	public function category_edit_category($data) {
		$this->load->model($this->route);
		
		$this->{'model_extension_d_seo_module_' . $this->codename}->saveCategoryMetaData($data);
	}
	
	public function category_delete_category($data) {
		$this->load->model($this->route);
		
		$this->{'model_extension_d_seo_module_' . $this->codename}->deleteCategoryMetaData($data);
	}
				
	public function product_form_tab_general_language() {		
		$this->load->model($this->route);
		$this->load->model('extension/module/' . $this->codename);
		
		if (file_exists(DIR_APPLICATION . 'model/extension/module/d_twig_manager.php')) {
			$this->load->model('extension/module/d_twig_manager');
			
			$this->model_extension_module_d_twig_manager->installCompatibility();
		}
		
		$languages = $this->{'model_extension_module_' . $this->codename}->getLanguages();
		
		$field_info = $this->load->controller('extension/module/d_seo_module/getFieldInfo');
		
		if (isset($field_info['sheet']['product']['field'])) {
			$data['fields'] = $field_info['sheet']['product']['field'];
		} else {
			$data['fields'] = array();
		}
		
		$data['error'] = ($this->config->get($this->codename . '_error')) ? $this->config->get($this->codename . '_error') : array();
				
		if (isset($this->request->post['meta_data'])) {
			$data['meta_data'] = $this->request->post['meta_data'];
		} elseif (isset($this->request->get['product_id'])) {
			$data['meta_data'] = $this->{'model_extension_d_seo_module_' . $this->codename}->getProductMetaData($this->request->get['product_id']);
		} else {
			$data['meta_data'] = array();
		}
		
		$data['store_id'] = 0;
		
		$html_tab_general_language = array();
				
		foreach ($languages as $language) {
			$data['language_id'] = $language['language_id'];
		
			$html_tab_general_language[$data['language_id']] = $this->load->view($this->route . '/product_form_tab_general_language', $data);
		}
				
		return $html_tab_general_language;
	}
	
	public function product_form_tab_general_store_language() {
		$this->load->model($this->route);
		$this->load->model('extension/module/' . $this->codename);
		
		if (file_exists(DIR_APPLICATION . 'model/extension/module/d_twig_manager.php')) {
			$this->load->model('extension/module/d_twig_manager');
			
			$this->model_extension_module_d_twig_manager->installCompatibility();
		}
		
		$stores = $this->{'model_extension_module_' . $this->codename}->getStores();
		$languages = $this->{'model_extension_module_' . $this->codename}->getLanguages();
		
		$field_info = $this->load->controller('extension/module/d_seo_module/getFieldInfo');
		
		if (isset($field_info['sheet']['product']['field'])) {
			$data['fields'] = $field_info['sheet']['product']['field'];
		} else {
			$data['fields'] = array();
		}
		
		$data['error'] = ($this->config->get($this->codename . '_error')) ? $this->config->get($this->codename . '_error') : array();
										
		if (isset($this->request->post['meta_data'])) {
			$data['meta_data'] = $this->request->post['meta_data'];
		} elseif (isset($this->request->get['product_id'])) {
			$data['meta_data'] = $this->{'model_extension_d_seo_module_' . $this->codename}->getProductMetaData($this->request->get['product_id']);
		} else {
			$data['meta_data'] = array();
		}
		
		$html_tab_general_store_language = array();
		
		foreach ($stores as $store) {
			$data['store_id'] = $store['store_id'];		
		
			foreach ($languages as $language) {
				$data['language_id'] = $language['language_id'];
		
				$html_tab_general_store_language[$data['store_id']][$data['language_id']] = $this->load->view($this->route . '/product_form_tab_general_store_language', $data);
			}
		}
		
		return $html_tab_general_store_language;
	}
	
	public function product_validate_form($error) {
		if (isset($this->request->post['meta_data'])) {		
			$_language = new Language();
			$_language->load($this->route);
			
			foreach ($this->request->post['meta_data'] as $store_id => $language_meta_data) {
				foreach ($language_meta_data as $language_id => $meta_data) {
					if ($store_id) {
						if (isset($meta_data['name']) && ((utf8_strlen($meta_data['name']) < 3) || (utf8_strlen($meta_data['name']) > 255))) {
							$error['meta_data'][$store_id][$language_id]['name'] = $_language->get('error_product_name');
						}

						if (isset($meta_data['meta_title']) && ((utf8_strlen($meta_data['meta_title']) < 3) || (utf8_strlen($meta_data['meta_title']) > 255))) {
							$error['meta_data'][$store_id][$language_id]['meta_title'] = $_language->get('error_meta_title');
						}
					}
				}
			}
		}
		
		$this->config->set($this->codename . '_error', $error);
				
		return $error;
	}
	
	public function product_add_product($data) {
		$this->load->model($this->route);
		
		$this->{'model_extension_d_seo_module_' . $this->codename}->saveProductMetaData($data);
	}
	
	public function product_edit_product($data) {
		$this->load->model($this->route);
		
		$this->{'model_extension_d_seo_module_' . $this->codename}->saveProductMetaData($data);
	}
	
	public function product_delete_product($data) {
		$this->load->model($this->route);
		
		$this->{'model_extension_d_seo_module_' . $this->codename}->deleteProductMetaData($data);
	}
		
	public function manufacturer_form_tab_general_language() {		
		$this->load->model($this->route);
		$this->load->model('extension/module/' . $this->codename);
		
		if (file_exists(DIR_APPLICATION . 'model/extension/module/d_twig_manager.php')) {
			$this->load->model('extension/module/d_twig_manager');
			
			$this->model_extension_module_d_twig_manager->installCompatibility();
		}
		
		$languages = $this->{'model_extension_module_' . $this->codename}->getLanguages();
		
		$field_info = $this->load->controller('extension/module/d_seo_module/getFieldInfo');
		
		if (isset($field_info['sheet']['manufacturer']['field'])) {
			$data['fields'] = $field_info['sheet']['manufacturer']['field'];
		} else {
			$data['fields'] = array();
		}
		
		$data['error'] = ($this->config->get($this->codename . '_error')) ? $this->config->get($this->codename . '_error') : array();
					
		if (isset($this->request->post['meta_data'])) {
			$data['meta_data'] = $this->request->post['meta_data'];
		} elseif (isset($this->request->get['manufacturer_id'])) {
			$data['meta_data'] = $this->{'model_extension_d_seo_module_' . $this->codename}->getManufacturerMetaData($this->request->get['manufacturer_id']);
		} else {
			$data['meta_data'] = array();
		}
		
		$data['store_id'] = 0;
			
		$html_tab_general_language = array();
				
		foreach ($languages as $language) {
			$data['language_id'] = $language['language_id'];
		
			$html_tab_general_language[$data['language_id']] = $this->load->view($this->route . '/manufacturer_form_tab_general_language', $data);
		}
				
		return $html_tab_general_language;
	}
	
	public function manufacturer_form_tab_general_store_language() {		
		$this->load->model($this->route);
		$this->load->model('extension/module/' . $this->codename);
		
		if (file_exists(DIR_APPLICATION . 'model/extension/module/d_twig_manager.php')) {
			$this->load->model('extension/module/d_twig_manager');
			
			$this->model_extension_module_d_twig_manager->installCompatibility();
		}
		
		$stores = $this->{'model_extension_module_' . $this->codename}->getStores();
		$languages = $this->{'model_extension_module_' . $this->codename}->getLanguages();
		
		$field_info = $this->load->controller('extension/module/d_seo_module/getFieldInfo');
		
		if (isset($field_info['sheet']['manufacturer']['field'])) {
			$data['fields'] = $field_info['sheet']['manufacturer']['field'];
		} else {
			$data['fields'] = array();
		}
		
		$data['error'] = ($this->config->get($this->codename . '_error')) ? $this->config->get($this->codename . '_error') : array();
										
		if (isset($this->request->post['meta_data'])) {
			$data['meta_data'] = $this->request->post['meta_data'];
		} elseif (isset($this->request->get['manufacturer_id'])) {
			$data['meta_data'] = $this->{'model_extension_d_seo_module_' . $this->codename}->getManufacturerMetaData($this->request->get['manufacturer_id']);
		} else {
			$data['meta_data'] = array();
		}
		
		$html_tab_general_store_language = array();
		
		foreach ($stores as $store) {
			$data['store_id'] = $store['store_id'];		
		
			foreach ($languages as $language) {
				$data['language_id'] = $language['language_id'];
		
				$html_tab_general_store_language[$data['store_id']][$data['language_id']] = $this->load->view($this->route . '/manufacturer_form_tab_general_store_language', $data);
			}
		}
		
		return $html_tab_general_store_language;
	}
	
	public function manufacturer_form_style() {		
		if (file_exists(DIR_APPLICATION . 'model/extension/module/d_twig_manager.php')) {
			$this->load->model('extension/module/d_twig_manager');
			
			$this->model_extension_module_d_twig_manager->installCompatibility();
		}
		
		return $this->load->view($this->route . '/manufacturer_form_style');
	}
	
	public function manufacturer_form_script() {		
		if (file_exists(DIR_APPLICATION . 'model/extension/module/d_twig_manager.php')) {
			$this->load->model('extension/module/d_twig_manager');
			
			$this->model_extension_module_d_twig_manager->installCompatibility();
		}
		
		return $this->load->view($this->route . '/manufacturer_form_script');
	}
	
	public function manufacturer_validate_form($error) {
		unset($error['name']);
		
		if (isset($this->request->post['meta_data'])) {		
			$_language = new Language();
			$_language->load($this->route);
			
			foreach ($this->request->post['meta_data'] as $store_id => $language_meta_data) {
				foreach ($language_meta_data as $language_id => $meta_data) {
					if (isset($meta_data['name']) && ((utf8_strlen($meta_data['name']) < 2) || (utf8_strlen($meta_data['name']) > 64))) {
						$error['meta_data'][$store_id][$language_id]['name'] = $_language->get('error_manufacturer_name');
						$error['warning'] = $_language->get('error_warning');
					}

					if (isset($meta_data['meta_title']) && ((utf8_strlen($meta_data['meta_title']) < 3) || (utf8_strlen($meta_data['meta_title']) > 255))) {
						$error['meta_data'][$store_id][$language_id]['meta_title'] = $_language->get('error_meta_title');
						$error['warning'] = $_language->get('error_warning');
					}
				}
			}
		}
		
		$this->config->set($this->codename . '_error', $error);
				
		return $error;
	}
	
	public function manufacturer_add_manufacturer($data) {
		$this->load->model($this->route);
		
		$this->{'model_extension_d_seo_module_' . $this->codename}->saveManufacturerMetaData($data);
	}
	
	public function manufacturer_edit_manufacturer($data) {
		$this->load->model($this->route);
		
		$this->{'model_extension_d_seo_module_' . $this->codename}->saveManufacturerMetaData($data);
	}
	
	public function manufacturer_delete_manufacturer($data) {
		$this->load->model($this->route);
		
		$this->{'model_extension_d_seo_module_' . $this->codename}->deleteManufacturerMetaData($data);
	}
			
	public function information_form_tab_general_language() {		
		$this->load->model($this->route);
		$this->load->model('extension/module/' . $this->codename);
		
		if (file_exists(DIR_APPLICATION . 'model/extension/module/d_twig_manager.php')) {
			$this->load->model('extension/module/d_twig_manager');
			
			$this->model_extension_module_d_twig_manager->installCompatibility();
		}
		
		$languages = $this->{'model_extension_module_' . $this->codename}->getLanguages();
		
		$field_info = $this->load->controller('extension/module/d_seo_module/getFieldInfo');
		
		if (isset($field_info['sheet']['information']['field'])) {
			$data['fields'] = $field_info['sheet']['information']['field'];
		} else {
			$data['fields'] = array();
		}
		
		$data['error'] = ($this->config->get($this->codename . '_error')) ? $this->config->get($this->codename . '_error') : array();
						
		if (isset($this->request->post['meta_data'])) {
			$data['meta_data'] = $this->request->post['meta_data'];
		} elseif (isset($this->request->get['information_id'])) {
			$data['meta_data'] = $this->{'model_extension_d_seo_module_' . $this->codename}->getInformationMetaData($this->request->get['information_id']);
		} else {
			$data['meta_data'] = array();
		}
		
		$data['store_id'] = 0;
			
		$html_tab_general_language = array();
				
		foreach ($languages as $language) {
			$data['language_id'] = $language['language_id'];
		
			$html_tab_general_language[$data['language_id']] = $this->load->view($this->route . '/information_form_tab_general_language', $data);
		}
				
		return $html_tab_general_language;
	}
	
	public function information_form_tab_general_store_language() {		
		$this->load->model($this->route);
		$this->load->model('extension/module/' . $this->codename);
		
		if (file_exists(DIR_APPLICATION . 'model/extension/module/d_twig_manager.php')) {
			$this->load->model('extension/module/d_twig_manager');
			
			$this->model_extension_module_d_twig_manager->installCompatibility();
		}
		
		$stores = $this->{'model_extension_module_' . $this->codename}->getStores();
		$languages = $this->{'model_extension_module_' . $this->codename}->getLanguages();
		
		$field_info = $this->load->controller('extension/module/d_seo_module/getFieldInfo');
		
		if (isset($field_info['sheet']['information']['field'])) {
			$data['fields'] = $field_info['sheet']['information']['field'];
		} else {
			$data['fields'] = array();
		}
		
		$data['error'] = ($this->config->get($this->codename . '_error')) ? $this->config->get($this->codename . '_error') : array();
								
		if (isset($this->request->post['meta_data'])) {
			$data['meta_data'] = $this->request->post['meta_data'];
		} elseif (isset($this->request->get['information_id'])) {
			$data['meta_data'] = $this->{'model_extension_d_seo_module_' . $this->codename}->getInformationMetaData($this->request->get['information_id']);
		} else {
			$data['meta_data'] = array();
		}
		
		$html_tab_general_store_language = array();
		
		foreach ($stores as $store) {
			$data['store_id'] = $store['store_id'];		
		
			foreach ($languages as $language) {
				$data['language_id'] = $language['language_id'];
		
				$html_tab_general_store_language[$data['store_id']][$data['language_id']] = $this->load->view($this->route . '/information_form_tab_general_store_language', $data);
			}
		}
		
		return $html_tab_general_store_language;
	}
	
	public function information_validate_form($error) {
		if (isset($this->request->post['meta_data'])) {		
			$_language = new Language();
			$_language->load($this->route);
			
			foreach ($this->request->post['meta_data'] as $store_id => $language_meta_data) {
				foreach ($language_meta_data as $language_id => $meta_data) {
					if ($store_id) {
						if (isset($meta_data['title']) && ((utf8_strlen($meta_data['title']) < 3) || (utf8_strlen($meta_data['title']) > 64))) {
							$error['meta_data'][$store_id][$language_id]['title'] = $_language->get('error_information_title');
						}
						
						if (isset($meta_data['description']) && (utf8_strlen($meta_data['description']) < 3)) {
							$error['meta_data'][$store_id][$language_id]['description'] = $_language->get('error_description');
						}
						
						if (isset($meta_data['meta_title']) && ((utf8_strlen($meta_data['meta_title']) < 3) || (utf8_strlen($meta_data['meta_title']) > 255))) {
							$error['meta_data'][$store_id][$language_id]['meta_title'] = $_language->get('error_meta_title');
						}
					}
				}
			}
		}
		
		$this->config->set($this->codename . '_error', $error);
				
		return $error;
	}
	
	public function information_add_information($data) {
		$this->load->model($this->route);
		
		$this->{'model_extension_d_seo_module_' . $this->codename}->saveInformationMetaData($data);
	}
	
	public function information_edit_information($data) {
		$this->load->model($this->route);
		
		$this->{'model_extension_d_seo_module_' . $this->codename}->saveInformationMetaData($data);
	}
	
	public function information_delete_information($data) {
		$this->load->model($this->route);
		
		$this->{'model_extension_d_seo_module_' . $this->codename}->deleteInformationMetaData($data);
	}
	
	public function control_extensions() {
		$_language = new Language();
		$_language->load($this->route);
		
		$url_token = '';
		
		if (isset($this->session->data['token'])) {
			$url_token .= 'token=' . $this->session->data['token'];
		}
		
		if (isset($this->session->data['user_token'])) {
			$url_token .= 'user_token=' . $this->session->data['user_token'];
		}
		
		$control_extensions = array();

		$control_extensions[] = array(
			'code'				=> $this->codename,
			'name'	   			=> $_language->get('heading_title_main'),
			'image'				=> $this->codename . '/logo.svg',
			'href'     			=> $this->url->link('extension/module/' . $this->codename, $url_token, true),
			'sort_order' 		=> 2
		);
				
		return $control_extensions;
	}
	
	public function control_install_extension() {
		$this->load->controller('extension/module/' . $this->codename . '/installExtension');
			
		$json = $this->response->getOutput();
			
		if ($json) {
			$data = json_decode($json, true);
			
			return $data;
		}
		
		return false;
	}
	
	public function control_elements($data) {
		$_language = new Language();
		$_language->load($this->route);
		
		$this->load->model('extension/module/' . $this->codename);
		$this->load->model('setting/setting');
		
		$url_token = '';
		
		if (isset($this->session->data['token'])) {
			$url_token .= 'token=' . $this->session->data['token'];
		}
		
		if (isset($this->session->data['user_token'])) {
			$url_token .= 'user_token=' . $this->session->data['user_token'];
		}
		
		// Setting 				
		$config_generator_setting = array();
										
		$installed_seo_meta_extensions = $this->{'model_extension_module_' . $this->codename}->getInstalledSEOMetaExtensions();
		
		foreach ($installed_seo_meta_extensions as $installed_seo_meta_extension) {
			$info = $this->load->controller('extension/' . $this->codename . '/' . $installed_seo_meta_extension . '/meta_generator_config');
			if ($info) $config_generator_setting = array_replace_recursive($config_generator_setting, $info);
		}
		
		$setting = $this->model_setting_setting->getSetting('module_' . $this->codename, $data['store_id']);
		$status = isset($setting['module_' . $this->codename . '_status']) ? $setting['module_' . $this->codename . '_status'] : false;
		$generator_setting = isset($setting['module_' . $this->codename . '_generator_setting']) ? $setting['module_' . $this->codename . '_generator_setting'] : array();
		$setting = isset($setting['module_' . $this->codename . '_setting']) ? $setting['module_' . $this->codename . '_setting'] : array();
		
		if (!empty($generator_setting)) {
			$config_generator_setting = array_replace_recursive($config_generator_setting, $generator_setting);
		}
		
		$generator_setting = $config_generator_setting;
		
		$control_elements = array();
		
		if (!$status) {
			$control_elements[] = array(
				'extension_code' 		=> $this->codename,
				'extension_name' 		=> $_language->get('heading_title_main'),
				'element_code'			=> 'enable_status',
				'name'					=> $_language->get('text_enable_status'),
				'description'			=> $_language->get('help_enable_status'),
				'confirm'				=> false,
				'href'					=> $this->url->link('extension/module/' . $this->codename . '/setting', $url_token, true),
				'implemented'			=> isset($setting['control_element']['enable_status']['implemented']) ? 1 : 0,
				'weight'				=> 1
			);
		}
		
		$generator_setting['sheet'] = $this->{'model_extension_module_' . $this->codename}->sortArrayByColumn($generator_setting['sheet'], 'sort_order');
						
		foreach ($generator_setting['sheet'] as $sheet) {
			if (isset($sheet['code']) && isset($sheet['name']) && (isset($sheet['field']))) {				
				$sheet['field'] = $this->{'model_extension_module_' . $this->codename}->sortArrayByColumn($sheet['field'], 'sort_order');
				
				foreach ($sheet['field'] as $field) {
					if (isset($field['code']) && isset($field['name'])) {
						if (($field['code'] == 'meta_title') || ($field['code'] == 'meta_description')) {
							if ($field['code'] == 'meta_title') $weight = 0.8;
							if ($field['code'] == 'meta_description') $weight = 0.7;
							
							$control_elements[] = array(
								'extension_code' 		=> $this->codename,
								'extension_name' 		=> $_language->get('heading_title_main'),
								'element_code'			=> 'generate_' . $field['code'] . '_' . $sheet['code'],
								'name'					=> sprintf($_language->get('text_generate'), $sheet['name'], $field['name']),
								'description'			=> sprintf($_language->get('help_generate'), $field['name'], $sheet['name']),
								'confirm'				=> $_language->get('text_generate_confirm'),
								'href'					=> $this->url->link('extension/module/' . $this->codename . '/generator', $url_token, true),
								'implemented'			=> isset($setting['control_element']['generate_' . $field['code'] . '_' . $sheet['code']]['implemented']) ? 1 : 0,
								'weight'				=> $weight
							);
						}
					}
				}
			}
		}
						
		return $control_elements;
	}
	
	public function control_execute_element($data) {				
		$this->load->model('extension/module/' . $this->codename);
		$this->load->model('setting/setting');
		
		$languages = $this->{'model_extension_module_' . $this->codename}->getLanguages();
		
		// Setting 				
		$config_generator_setting = array();
										
		$installed_seo_meta_extensions = $this->{'model_extension_module_' . $this->codename}->getInstalledSEOMetaExtensions();
		
		foreach ($installed_seo_meta_extensions as $installed_seo_meta_extension) {
			$info = $this->load->controller('extension/' . $this->codename . '/' . $installed_seo_meta_extension . '/meta_generator_config');
			if ($info) $config_generator_setting = array_replace_recursive($config_generator_setting, $info);
		}
		
		$setting = $this->model_setting_setting->getSetting('module_' . $this->codename, $data['store_id']);
		$status = isset($setting['module_' . $this->codename . '_status']) ? $setting['module_' . $this->codename . '_status'] : false;
		$generator_setting = isset($setting['module_' . $this->codename . '_generator_setting']) ? $setting['module_' . $this->codename . '_generator_setting'] : array();
						
		if (!empty($generator_setting)) {
			$config_generator_setting = array_replace_recursive($config_generator_setting, $generator_setting);
		}
		
		$generator_setting = $config_generator_setting;
				
		if ($data['element_code'] == 'enable_status') {
			$setting['module_' . $this->codename . '_status'] = 1;
			$setting['module_' . $this->codename . '_setting']['control_element']['enable_status']['implemented'] = 1;
			
			$this->model_setting_setting->editSetting('module_' . $this->codename, $setting, $data['store_id']);
		}
		
		if (strpos($data['element_code'], 'generate_meta_title') === 0) {
			$sheet_code = str_replace('generate_meta_title_', '', $data['element_code']);
			$field_code = 'meta_title';
		}
		
		if (strpos($data['element_code'], 'generate_meta_description') === 0) {
			$sheet_code = str_replace('generate_meta_description_', '', $data['element_code']);
			$field_code = 'meta_description';
		}
		
		if (isset($sheet_code) && isset($field_code) && isset($generator_setting['sheet'][$sheet_code]['field'][$field_code])) {
			$field_setting = $generator_setting['sheet'][$sheet_code]['field'][$field_code];
			$field_data = array();
						
			if (isset($field_setting['multi_language']) && $field_setting['multi_language']) {
				foreach ($languages as $language) {
					if (isset($field_setting['template'][$language['language_id']])) {
						$field_data['template'][$language['language_id']] = $field_setting['template'][$language['language_id']];
					} elseif (isset($field_setting['template_default'])) {
						$field_data['template'][$language['language_id']] = $field_setting['template_default'];
					}
				}
			} else {
				if (isset($field_setting['template'])) {
					$field_data['template'] = $field_setting['template'];
				} elseif (isset($field_settingd['template_default'])) {
					$field_data['template'] = $field_setting['template_default'];
				}
			}
				
			if (isset($field_setting['translit_symbol_status'])) {
				$field_data['translit_symbol_status'] = $field_setting['translit_symbol_status'];
			}
				
			if (isset($field_setting['translit_language_symbol_status'])) {
				$field_data['translit_language_symbol_status'] = $field_setting['translit_language_symbol_status'];
			}
				
			if (isset($field_setting['transform_language_symbol_id'])) {
				$field_data['transform_language_symbol_id'] = $field_setting['transform_language_symbol_id'];
			}
				
			if (isset($field_setting['overwrite'])) {
				$field_data['overwrite'] = $field_setting['overwrite'];
			}				
						
			$generator_data['store_id'] = $data['store_id'];
			$generator_data['sheet'][$sheet_code]['field'][$field_code] = $field_data;	
		
			foreach ($installed_seo_meta_extensions as $installed_seo_meta_extension) {
				$info = $this->load->controller('extension/' . $this->codename . '/' . $installed_seo_meta_extension . '/meta_generator_generate_fields', $generator_data);
				
				if (isset($info['error'])) {
					$this->error = array_replace_recursive($this->error, $info['error']);
				}			
			}
			
			if (!$this->error) {
				$setting['module_' . $this->codename . '_setting']['control_element']['generate_' . $field_code . '_' . $sheet_code]['implemented'] = 1;
			
				$this->model_setting_setting->editSetting('module_' . $this->codename, $setting, $data['store_id']);
			}
		}
				
		$result['error'] = $this->error;
		
		return $result;
	}

	public function field_config() {
		$_language = new Language();
		$_language->load($this->route);
		
		$_config = new Config();
		$_config->load($this->config_file);
		$field_setting = ($_config->get($this->codename . '_field_setting')) ? $_config->get($this->codename . '_field_setting') : array();

		foreach ($field_setting['sheet'] as $sheet) {				
			foreach ($sheet['field'] as $field) {
				if (substr($field['name'], 0, strlen('text_')) == 'text_') {
					$field_setting['sheet'][$sheet['code']]['field'][$field['code']]['name'] = $_language->get($field['name']);
				}
				
				if (substr($field['description'], 0, strlen('help_')) == 'help_') {
					$field_setting['sheet'][$sheet['code']]['field'][$field['code']]['description'] = $_language->get($field['description']);
				}
			}
		}
					
		return $field_setting;
	}
	
	public function field_elements($filter_data) {
		$this->load->model($this->route);
		
		return $this->{'model_extension_d_seo_module_' . $this->codename}->getFieldElements($filter_data);
	}	
}