<?php
class ControllerExtensionDSEOModuleDSEOModuleManager extends Controller {
	private $codename = 'd_seo_module_manager';
	private $route = 'extension/d_seo_module/d_seo_module_manager';
	private $config_file = 'd_seo_module_manager';
	private $error = array();
	
	/*
	*	Functions for SEO Module.
	*/		
	public function menu() {
		$_language = new Language();
		$_language->load($this->route);
		
		$url_token = '';
		
		if (isset($this->session->data['token'])) {
			$url_token .= 'token=' . $this->session->data['token'];
		}
		
		if (isset($this->session->data['user_token'])) {
			$url_token .= 'user_token=' . $this->session->data['user_token'];
		}
		
		$menu = array();

		if ($this->user->hasPermission('access', 'extension/module/' . $this->codename)) {
			$menu[] = array(
				'name'	   		=> $_language->get('heading_title_main'),
				'href'     		=> $this->url->link('extension/module/' . $this->codename, $url_token, true),
				'sort_order' 	=> 10,
				'children' 		=> array()
			);
		}

		return $menu;
	}
	
	public function control_extensions() {
		$_language = new Language();
		$_language->load($this->route);
		
		$url_token = '';
		
		if (isset($this->session->data['token'])) {
			$url_token .= 'token=' . $this->session->data['token'];
		}
		
		if (isset($this->session->data['user_token'])) {
			$url_token .= 'user_token=' . $this->session->data['user_token'];
		}
		
		$control_extensions = array();

		$control_extensions[] = array(
			'code'				=> $this->codename,
			'name'	   			=> $_language->get('heading_title_main'),
			'image'				=> $this->codename . '/logo.svg',
			'href'     			=> $this->url->link('extension/module/' . $this->codename, $url_token, true),
			'sort_order' 		=> 10
		);
				
		return $control_extensions;
	}
	
	public function control_install_extension() {
		$this->load->controller('extension/module/' . $this->codename . '/installExtension');
			
		$json = $this->response->getOutput();
			
		if ($json) {
			$data = json_decode($json, true);
			
			return $data;
		}
		
		return false;
	}
}