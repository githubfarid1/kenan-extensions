<?php
class ControllerExtensionModuleDSEOModuleManager extends Controller {
	private $codename = 'd_seo_module_manager';
	private $route = 'extension/module/d_seo_module_manager';
	private $config_file = 'd_seo_module_manager';
	private $extension = array();
	private $error = array();
		
	public function __construct($registry) {
		parent::__construct($registry);

		$this->d_shopunity = (file_exists(DIR_SYSTEM . 'library/d_shopunity/extension/d_shopunity.json'));
		$this->extension = json_decode(file_get_contents(DIR_SYSTEM . 'library/d_shopunity/extension/' . $this->codename . '.json'), true);
	}
		
	public function index() {
		$this->setting();
	}
	
	public function setting() {
		$this->load->language($this->route);
		
		$this->load->model($this->route);
		$this->load->model('setting/setting');
		$this->load->model('localisation/language');
		
		if ($this->d_shopunity) {		
			$this->load->model('extension/d_shopunity/mbooth');
				
			$this->model_extension_d_shopunity_mbooth->validateDependencies($this->codename);
		}
		
		if (file_exists(DIR_APPLICATION . 'model/extension/module/d_twig_manager.php')) {
			$this->load->model('extension/module/d_twig_manager');
			
			$this->model_extension_module_d_twig_manager->installCompatibility();
		}
		
		if (isset($this->request->get['store_id'])) { 
			$store_id = $this->request->get['store_id']; 
		} else {  
			$store_id = 0;
		}
		
		$url_token = '';
		
		if (isset($this->session->data['token'])) {
			$url_token .=  'token=' . $this->session->data['token'];
		}
		
		if (isset($this->session->data['user_token'])) {
			$url_token .=  'user_token=' . $this->session->data['user_token'];
		}
		
		$url_store = 'store_id=' . $store_id;
		
		// Styles and Scripts
		$this->document->addStyle('view/stylesheet/d_bootstrap_extra/bootstrap.css');
		$this->document->addScript('view/javascript/d_bootstrap_switch/js/bootstrap-switch.min.js');
        $this->document->addStyle('view/javascript/d_bootstrap_switch/css/bootstrap-switch.css');
		$this->document->addStyle('view/stylesheet/d_admin_style/core/normalize/normalize.css');
		$this->document->addStyle('view/stylesheet/d_admin_style/themes/light/light.css');
		$this->document->addStyle('view/stylesheet/d_seo_module.css');
				
		// Heading
		$this->document->setTitle($this->language->get('heading_title_main'));
		$data['heading_title'] = $this->language->get('heading_title_main');
		
		// Variable
		$data['codename'] = $this->codename;
		$data['route'] = $this->route;
		$data['version'] = $this->extension['version'];
		$data['extension_id'] = $this->extension['extension_id'];
		$data['config'] = $this->config_file;
		$data['d_shopunity'] = $this->d_shopunity;
		$data['url_token'] = $url_token;
		$data['store_id'] = $store_id;
		$data['stores'] = $this->{'model_extension_module_' . $this->codename}->getStores();
		
		$installed_seo_extensions = $this->{'model_extension_module_' . $this->codename}->getInstalledSEOExtensions();
		$data['installed'] = in_array($this->codename, $installed_seo_extensions) ? true : false;
		
		if (isset($this->request->server['HTTPS']) && (($this->request->server['HTTPS'] == 'on') || ($this->request->server['HTTPS'] == '1'))) {
			$data['server'] = HTTPS_SERVER;
			$data['catalog'] = HTTPS_CATALOG;
		} else {
			$data['server'] = HTTP_SERVER;
			$data['catalog'] = HTTP_CATALOG;
		}
						
		// Action
		$data['href_setting'] = $this->url->link($this->route . '/setting', $url_token . '&' . $url_store, true);
		$data['href_overview_list'] = $this->url->link($this->route . '/overview_list', $url_token . '&' . $url_store, true);
		$data['href_export_import'] = $this->url->link($this->route . '/export_import', $url_token . '&' . $url_store, true);
		$data['href_instruction'] = $this->url->link($this->route . '/instruction', $url_token . '&' . $url_store, true);
		
		$data['module_link'] = $this->url->link($this->route, $url_token . '&' . $url_store, true);
		$data['action'] = $this->url->link($this->route . '/save', $url_token . '&' . $url_store, true);
		$data['setup'] = $this->url->link($this->route . '/setupExtension', $url_token, true);
		$data['install'] = $this->url->link($this->route . '/installExtension', $url_token, true);
		$data['uninstall'] = $this->url->link($this->route . '/uninstallExtension', $url_token, true);
		
		if (VERSION >= '3.0.0.0') {
			$data['cancel'] = $this->url->link('marketplace/extension', $url_token . '&type=module', true);
		} elseif (VERSION >= '2.3.0.0') {
			$data['cancel'] = $this->url->link('extension/extension', $url_token . '&type=module', true);
		} else {
			$data['cancel'] = $this->url->link('extension/module', $url_token, true);
		}
		
		// Tab
		$data['text_settings'] = $this->language->get('text_settings');
		$data['text_overview_list'] = $this->language->get('text_overview_list');
		$data['text_export_import'] = $this->language->get('text_export_import');
		$data['text_instructions'] = $this->language->get('text_instructions');
		$data['text_instructions_full'] = $this->language->get('text_instructions_full');
		$data['text_basic_settings'] = $this->language->get('text_basic_settings');
		$data['text_uninstall_confirm'] = $this->language->get('text_uninstall_confirm');
		
		// Button
		$data['button_save'] = $this->language->get('button_save');
		$data['button_save_and_stay'] = $this->language->get('button_save_and_stay');
		$data['button_cancel'] = $this->language->get('button_cancel');	
		$data['button_setup'] = $this->language->get('button_setup');
		$data['button_uninstall'] = $this->language->get('button_uninstall');
		
		// Column
		$data['column_field'] = $this->language->get('column_field');
		$data['column_list_status'] = $this->language->get('column_list_status');
		$data['column_export_status'] = $this->language->get('column_export_status');
		
		// Entry
		$data['entry_status'] = $this->language->get('entry_status');
		$data['entry_uninstall'] = $this->language->get('entry_uninstall');
		$data['entry_list_limit'] = $this->language->get('entry_list_limit');
								
		// Text
		$data['text_edit'] = $this->language->get('text_edit');
		$data['text_install'] = $this->language->get('text_install');
		$data['text_setup'] = $this->language->get('text_setup');
		$data['text_full_setup'] = $this->language->get('text_full_setup');
		$data['text_custom_setup'] = $this->language->get('text_custom_setup');
		$data['text_yes'] = $this->language->get('text_yes');
		$data['text_no'] = $this->language->get('text_no');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['text_powered_by'] = $this->language->get('text_powered_by');
					
		// Help
		$data['help_setup'] = $this->language->get('help_setup');
		$data['help_full_setup'] = $this->language->get('help_full_setup');
		$data['help_custom_setup'] = $this->language->get('help_custom_setup');
		
		// Notification
		foreach ($this->error as $key => $error) {
			$data['error'][$key] = $error;
		}
		
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		
		// Breadcrumbs
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', $url_token, true)
		);
				
		if (VERSION >= '3.0.0.0') {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_modules'),
				'href' => $this->url->link('marketplace/extension', $url_token . '&type=module', true)
			);
		} elseif (VERSION >= '2.3.0.0') {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_modules'),
				'href' => $this->url->link('extension/extension', $url_token . '&type=module', true)
			);
		} else {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_modules'),
				'href' => $this->url->link('extension/module', $url_token, true)
			);
		}

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_seo_module'),
			'href' => $this->url->link('extension/module/d_seo_module', $url_token . '&' . $url_store, true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_manager'),
			'href' => $this->url->link($this->route, $url_token . '&' . $url_store, true)
		);
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		if ($data['installed']) {		
			// Setting 		
			$data['setting'] = array();
		
			$installed_seo_manager_extensions = $this->{'model_extension_module_' . $this->codename}->getInstalledSEOManagerExtensions();
		
			foreach ($installed_seo_manager_extensions as $installed_seo_manager_extension) {
				$info = $this->load->controller('extension/' . $this->codename . '/' . $installed_seo_manager_extension . '/manager_config');
				if ($info) $data['setting'] = array_replace_recursive($data['setting'], $info);
			}
		
			$setting = $this->model_setting_setting->getSetting('module_' . $this->codename, $store_id);
			$setting = isset($setting['module_' . $this->codename . '_setting']) ? $setting['module_' . $this->codename . '_setting'] : array();
						
			if (!empty($setting)) {
				$data['setting'] = array_replace_recursive($data['setting'], $setting);
			}
				
			$sheets = array();
		
			foreach ($data['setting']['sheet'] as $sheet) {
				if (isset($sheet['code']) && isset($sheet['name']) && isset($sheet['field_index'])) {				
					$fields = array();
				
					if (isset($sheet['field'])) {
						foreach ($sheet['field'] as $field) {
							if (isset($field['code']) && isset($field['name']) && isset($field['type']) && isset($field['list_status']) && isset($field['export_status']) && isset($field['required'])) {
								$fields[] = $field;
							}
						}
					
						$fields = $this->{'model_extension_module_' . $this->codename}->sortArrayByColumn($fields, 'sort_order');
					}
				
					$sheet['field'] = array();
				
					foreach ($fields as $field) {
						$sheet['field'][$field['code']] = $field;
					}
				
					$sheets[] = $sheet;
				}
			}
		
			$data['setting']['sheet'] = $this->{'model_extension_module_' . $this->codename}->sortArrayByColumn($sheets, 'sort_order');
			
			$this->response->setOutput($this->load->view($this->route . '/setting', $data));
		} else {
			// Setting
			$this->config->load($this->config_file);
			$config_feature_setting = ($this->config->get($this->codename . '_feature_setting')) ? $this->config->get($this->codename . '_feature_setting') : array();
		
			$data['features'] = array();
		
			foreach ($config_feature_setting as $feature) {
				if (substr($feature['name'], 0, strlen('text_')) == 'text_') {
					$feature['name'] = $this->language->get($feature['name']);
				}
						
				$data['features'][] = $feature;
			}
			
			$this->response->setOutput($this->load->view($this->route . '/install', $data));
		}
	}
	
	public function overview_list() {
		$this->load->language($this->route);
		
		$this->load->model($this->route);
		$this->load->model('setting/setting');
		$this->load->model('localisation/language');
		
		if ($this->d_shopunity) {		
			$this->load->model('extension/d_shopunity/mbooth');
				
			$this->model_extension_d_shopunity_mbooth->validateDependencies($this->codename);
		}
		
		if (file_exists(DIR_APPLICATION . 'model/extension/module/d_twig_manager.php')) {
			$this->load->model('extension/module/d_twig_manager');
			
			$this->model_extension_module_d_twig_manager->installCompatibility();
		}
		
		if (isset($this->request->get['store_id'])) { 
			$store_id = $this->request->get['store_id']; 
		} else {  
			$store_id = 0;
		}
		
		if (isset($this->request->get['sheet_code'])) { 
			$sheet_code = $this->request->get['sheet_code']; 
		} else {  
			$sheet_code = 'category';
		}
		
		if (isset($this->request->get['language_id'])) { 
			$language_id = $this->request->get['language_id']; 
		} else {  
			$language_id = $this->config->get('config_language_id');;
		}
		
		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		
		$url_token = '';
		
		if (isset($this->session->data['token'])) {
			$url_token .= 'token=' . $this->session->data['token'];
		}
		
		if (isset($this->session->data['user_token'])) {
			$url_token .= 'user_token=' . $this->session->data['user_token'];
		}
		
		$url_store = 'store_id=' . $store_id;	
		$url_sheet = 'sheet_code=' . $sheet_code;		
		$url_language = 'language_id=' . $language_id;
		$url_page = 'page=' . $page;
		
		if (isset($this->request->post['clear_filter'])) {
			if ($this->request->post['clear_filter']) {	
				unset($this->request->post['filter']);
				unset($this->session->data[$this->codename . '_filter_' . $sheet_code]);
			}
		}
		
		if (isset($this->request->post['filter'])) {
			$filter = $this->request->post['filter'];
			$i = 0;
			
			foreach($filter as $value) {
				if ($value) $i++;
			}
			
			if ($i > 0) {
				$this->session->data[$this->codename . '_filter_' . $sheet_code] = $filter;
			} else {
				$filter = array();
				unset($this->session->data[$this->codename . '_filter_' . $sheet_code]);
			}
		} elseif (isset($this->session->data[$this->codename . '_filter_' . $sheet_code])) {
			$filter = $this->session->data[$this->codename . '_filter_' . $sheet_code];
		} else {
			$filter = array();
			unset($this->session->data[$this->codename . '_filter_' . $sheet_code]);
		}
		
		// Styles and Scripts
		$this->document->addStyle('view/stylesheet/d_bootstrap_extra/bootstrap.css');
		$this->document->addScript('view/javascript/d_bootstrap_switch/js/bootstrap-switch.min.js');
        $this->document->addStyle('view/javascript/d_bootstrap_switch/css/bootstrap-switch.css');
		$this->document->addStyle('view/stylesheet/d_admin_style/core/normalize/normalize.css');
		$this->document->addStyle('view/stylesheet/d_admin_style/themes/light/light.css');
		$this->document->addStyle('view/stylesheet/d_seo_module.css');
						
		// Heading
		$this->document->setTitle($this->language->get('heading_title_main'));
		$data['heading_title'] = $this->language->get('heading_title_main');
		
		// Variable
		$data['codename'] = $this->codename;
		$data['route'] = $this->route;
		$data['version'] = $this->extension['version'];
		$data['config'] = $this->config_file;
		$data['d_shopunity'] = $this->d_shopunity;
		$data['store_id'] = $store_id;
		$data['sheet_code'] = $sheet_code;
		$data['language_id'] = $language_id;
		$data['url_token'] = $url_token;
		$data['field_index'] = '';
		$data['stores'] = $this->{'model_extension_module_' . $this->codename}->getStores();
		
		$installed_seo_extensions = $this->{'model_extension_module_' . $this->codename}->getInstalledSEOExtensions();
		$data['installed'] = in_array($this->codename, $installed_seo_extensions) ? true : false;
						
		if (isset($this->request->server['HTTPS']) && (($this->request->server['HTTPS'] == 'on') || ($this->request->server['HTTPS'] == '1'))) {
			$data['server'] = HTTPS_SERVER;
			$data['catalog'] = HTTPS_CATALOG;
		} else {
			$data['server'] = HTTP_SERVER;
			$data['catalog'] = HTTP_CATALOG;
		}
								
		// Action
		$data['href_setting'] = $this->url->link($this->route . '/setting', $url_token . '&' . $url_store, true);
		$data['href_overview_list'] = $this->url->link($this->route . '/overview_list', $url_token . '&' . $url_store, true);
		$data['href_export_import'] = $this->url->link($this->route . '/export_import', $url_token . '&' . $url_store, true);
		$data['href_instruction'] = $this->url->link($this->route . '/instruction', $url_token . '&' . $url_store, true);
		
		$data['module_link'] = $this->url->link($this->route, $url_token . '&' . $url_store, true);
		$data['action'] = $this->url->link($this->route . '/overview_list', $url_token . '&' . $url_store . '&' . $url_sheet . '&' . $url_language, true);
		$data['store_url'] = $this->url->link($this->route . '/overview_list', $url_token . '&' . $url_sheet . '&' . $url_language, true);
		$data['setup'] = $this->url->link($this->route . '/setupExtension', $url_token, true);
		$data['install'] = $this->url->link($this->route . '/installExtension', $url_token, true);
		
		if (VERSION >= '3.0.0.0') {
			$data['cancel'] = $this->url->link('marketplace/extension', $url_token . '&type=module', true);
		} elseif (VERSION >= '2.3.0.0') {
			$data['cancel'] = $this->url->link('extension/extension', $url_token . '&type=module', true);
		} else {
			$data['cancel'] = $this->url->link('extension/module', $url_token, true);
		}
		
		// Tab
		$data['text_settings'] = $this->language->get('text_settings');
		$data['text_overview_list'] = $this->language->get('text_overview_list');
		$data['text_export_import'] = $this->language->get('text_export_import');
		$data['text_instructions'] = $this->language->get('text_instructions');
		$data['text_instructions_full'] = $this->language->get('text_instructions_full');
		
		// Button
		$data['button_cancel'] = $this->language->get('button_cancel');
		$data['button_setup'] = $this->language->get('button_setup');
		$data['button_filter'] = $this->language->get('button_filter');
		$data['button_clear_filter'] = $this->language->get('button_clear_filter');
				
		// Entry
		$data['entry_status'] = $this->language->get('entry_status');
						
		// Text
		$data['text_edit'] = $this->language->get('text_edit');
		$data['text_install'] = $this->language->get('text_install');
		$data['text_setup'] = $this->language->get('text_setup');
		$data['text_full_setup'] = $this->language->get('text_full_setup');
		$data['text_custom_setup'] = $this->language->get('text_custom_setup');
		$data['text_yes'] = $this->language->get('text_yes');
		$data['text_no'] = $this->language->get('text_no');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['text_powered_by'] = $this->language->get('text_powered_by');
		$data['text_no_results'] = $this->language->get('text_no_results');
		
		// Help
		$data['help_setup'] = $this->language->get('help_setup');
		$data['help_full_setup'] = $this->language->get('help_full_setup');
		$data['help_custom_setup'] = $this->language->get('help_custom_setup');
				
		// Notification
		foreach ($this->error as $key => $error) {
			$data['error'][$key] = $error;
		}
		
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		
		// Breadcrumbs
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', $url_token, true)
		);

		if (VERSION >= '3.0.0.0') {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_modules'),
				'href' => $this->url->link('marketplace/extension', $url_token . '&type=module', true)
			);
		} elseif (VERSION >= '2.3.0.0') {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_modules'),
				'href' => $this->url->link('extension/extension', $url_token . '&type=module', true)
			);
		} else {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_modules'),
				'href' => $this->url->link('extension/module', $url_token, true)
			);
		}

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_seo_module'),
			'href' => $this->url->link('extension/module/d_seo_module', $url_token . '&' . $url_store, true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_manager'),
			'href' => $this->url->link($this->route, $url_token . '&' . $url_store, true)
		);
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		if ($data['installed']) {		
			// Setting 		
			$data['setting'] = array();
		
			$installed_seo_manager_extensions = $this->{'model_extension_module_' . $this->codename}->getInstalledSEOManagerExtensions();
		
			foreach ($installed_seo_manager_extensions as $installed_seo_manager_extension) {
				$info = $this->load->controller('extension/' . $this->codename . '/' . $installed_seo_manager_extension . '/manager_config');
				if ($info) $data['setting'] = array_replace_recursive($data['setting'], $info);
			}
		
			$setting = $this->model_setting_setting->getSetting('module_' . $this->codename, $store_id);
			$setting = isset($setting['module_' . $this->codename . '_setting']) ? $setting['module_' . $this->codename . '_setting'] : array();
										
			if (!empty($setting)) {
				$data['setting'] = array_replace_recursive($data['setting'], $setting);
			}
		
			$languages = $this->{'model_extension_module_' . $this->codename}->getLanguages();
	
			foreach ($languages as &$language) {
				$language['url'] = $this->url->link($this->route . '/overview_list', $url_token . '&' . $url_store . '&' . $url_sheet . '&language_id=' . 	$language['language_id'] . '&' . $url_page, true);
			}
						
			$sheets = array();
				
			foreach ($data['setting']['sheet'] as $sheet) {
				if (isset($sheet['code']) && isset($sheet['icon']) && isset($sheet['name']) && isset($sheet['sort_order']) && isset($sheet['field_index'])) {
					if ($sheet['code'] == $sheet_code) {
						$data['field_index'] = $sheet['field_index'];
					}
								
					$sheets[] = array(
						'code'			=> $sheet['code'],
						'icon'			=> $sheet['icon'],
						'name'			=> $sheet['name'],
						'sort_order'	=> $sheet['sort_order'],
						'field_index' 	=> $sheet['field_index'],
						'url'			=> $this->url->link($this->route . '/overview_list', $url_token . '&' . $url_store . '&sheet_code=' . $sheet['code'] . '&' . $url_language, true)
					);
				}
			}
			
			$sheets = $this->{'model_extension_module_' . $this->codename}->sortArrayByColumn($sheets, 'sort_order');
				
			$fields = array();
		
			if (isset($data['setting']['sheet'][$sheet_code]['field'])) {
				foreach ($data['setting']['sheet'][$sheet_code]['field'] as $field) {
					if (isset($field['code']) && isset($field['name']) && isset($field['type']) && isset($field['list_status']) && isset($field['required'])) {
						if ($field['list_status'] || $field['required']) {
							$fields[] = $field;
						}
					}
				}
			
				$fields = $this->{'model_extension_module_' . $this->codename}->sortArrayByColumn($fields, 'sort_order');
			}
		
			$filter_data = array(
				'store_id'			=> $store_id,
				'sheet_code'		=> $sheet_code,
				'language_id'		=> $language_id,
				'fields'			=> $fields,
				'filter'	  	  	=> $filter
			);
		
			$elements = array();
		
			foreach ($installed_seo_manager_extensions as $installed_seo_manager_extension) {
				$info = $this->load->controller('extension/' . $this->codename . '/' . $installed_seo_manager_extension . '/manager_list_elements', $filter_data);
			
				if ($info != '') {
					if ($elements) {
						foreach ($elements as $element_id => $element) {
							if (isset($info[$element_id])) {
								$elements[$element_id] = array_replace_recursive($element, $info[$element_id]);
							} else {
								unset($elements[$element_id]);
							}
						}
					} else {
						$elements = $info;
					}
				}
			}
				
			$data['elements'] = array();
		
			$i = 0;
			
			foreach ($elements as $element) {
				if (($i >= (($page - 1) * $data['setting']['list_limit'])) && ($i < ((($page - 1) * $data['setting']['list_limit']) + $data['setting']['list_limit']))) {
					$data['elements'][] = $element;
				}
			
				$i++;
			
				if ($i == ((($page - 1) * $data['setting']['list_limit']) + $data['setting']['list_limit'])) break;
			}
			
			$pagination = new Pagination();
			$pagination->total = count($elements);
			$pagination->page = $page;
			$pagination->limit = $data['setting']['list_limit'];
			$pagination->url = $this->url->link($this->route . '/overview_list', $url_token . '&' . $url_store . '&' . $url_sheet . '&' . $url_language . '&page={page}', true);

			$data['pagination'] = $pagination->render();

			$data['results'] = sprintf($this->language->get('text_pagination'), (count($elements)) ? (($page - 1) * $data['setting']['list_limit']) + 1 : 0, ((($page - 1) * $data['setting']['list_limit']) > (count($elements) - $data['setting']['list_limit'])) ? count($elements) : ((($page - 1) * $data['setting']['list_limit']) + $data['setting']['list_limit']), count($elements), ceil(count($elements) / $data['setting']['list_limit']));
			
			$data['languages'] = $languages;
			$data['sheets'] = $sheets;
			$data['fields'] = $fields;
			$data['filter'] = $filter;
			
			$this->response->setOutput($this->load->view($this->route . '/overview_list', $data));
		} else {
			// Setting
			$this->config->load($this->config_file);
			$config_feature_setting = ($this->config->get($this->codename . '_feature_setting')) ? $this->config->get($this->codename . '_feature_setting') : array();
		
			$data['features'] = array();
		
			foreach ($config_feature_setting as $feature) {
				if (substr($feature['name'], 0, strlen('text_')) == 'text_') {
					$feature['name'] = $this->language->get($feature['name']);
				}
						
				$data['features'][] = $feature;
			}
			
			$this->response->setOutput($this->load->view($this->route . '/install', $data));
		}
	}
	
	public function export_import() {
		$this->load->language($this->route);
		
		$this->load->model($this->route);
		$this->load->model('setting/setting');
		$this->load->model('localisation/language');
		
		if ($this->d_shopunity) {		
			$this->load->model('extension/d_shopunity/mbooth');
				
			$this->model_extension_d_shopunity_mbooth->validateDependencies($this->codename);
		}
		
		if (file_exists(DIR_APPLICATION . 'model/extension/module/d_twig_manager.php')) {
			$this->load->model('extension/module/d_twig_manager');
			
			$this->model_extension_module_d_twig_manager->installCompatibility();
		}
		
		if (isset($this->request->get['store_id'])) { 
			$store_id = $this->request->get['store_id']; 
		} else {  
			$store_id = 0;
		}
		
		$url_token = '';
		
		if (isset($this->session->data['token'])) {
			$url_token .= 'token=' . $this->session->data['token'];
		}
		
		if (isset($this->session->data['user_token'])) {
			$url_token .= 'user_token=' . $this->session->data['user_token'];
		}
		
		$url_store = 'store_id=' . $store_id;
		
		// Styles and Scripts
		$this->document->addStyle('view/stylesheet/d_bootstrap_extra/bootstrap.css');
		$this->document->addScript('view/javascript/d_bootstrap_switch/js/bootstrap-switch.min.js');
        $this->document->addStyle('view/javascript/d_bootstrap_switch/css/bootstrap-switch.css');
		$this->document->addStyle('view/stylesheet/d_admin_style/core/normalize/normalize.css');
		$this->document->addStyle('view/stylesheet/d_admin_style/themes/light/light.css');
		$this->document->addStyle('view/stylesheet/d_seo_module.css');
				
		// Heading
		$this->document->setTitle($this->language->get('heading_title_main'));
		$data['heading_title'] = $this->language->get('heading_title_main');
		
		// Variable
		$data['codename'] = $this->codename;
		$data['route'] = $this->route;
		$data['version'] = $this->extension['version'];
		$data['config'] = $this->config_file;
		$data['d_shopunity'] = $this->d_shopunity;
		$data['store_id'] = $store_id;
		$data['stores'] = $this->{'model_extension_module_' . $this->codename}->getStores();
		
		$installed_seo_extensions = $this->{'model_extension_module_' . $this->codename}->getInstalledSEOExtensions();
		$data['installed'] = in_array($this->codename, $installed_seo_extensions) ? true : false;
		
		if (isset($this->request->server['HTTPS']) && (($this->request->server['HTTPS'] == 'on') || ($this->request->server['HTTPS'] == '1'))) {
			$data['server'] = HTTPS_SERVER;
			$data['catalog'] = HTTPS_CATALOG;
		} else {
			$data['server'] = HTTP_SERVER;
			$data['catalog'] = HTTP_CATALOG;
		}
						
		// Action
		$data['href_setting'] = $this->url->link($this->route . '/setting', $url_token . '&' . $url_store, true);
		$data['href_overview_list'] = $this->url->link($this->route . '/overview_list', $url_token . '&' . $url_store, true);
		$data['href_export_import'] = $this->url->link($this->route . '/export_import', $url_token . '&' . $url_store, true);
		$data['href_instruction'] = $this->url->link($this->route . '/instruction', $url_token . '&' . $url_store, true);
		
		$data['module_link'] = $this->url->link($this->route, $url_token . '&' . $url_store, true);
		$data['setup'] = $this->url->link($this->route . '/setupExtension', $url_token, true);
		$data['install'] = $this->url->link($this->route . '/installExtension', $url_token, true);
		$data['export'] = $this->url->link($this->route . '/export', $url_token, true);
		$data['import'] = $this->url->link($this->route . '/import', $url_token, true);
		
		if (VERSION >= '3.0.0.0') {
			$data['cancel'] = $this->url->link('marketplace/extension', $url_token . '&type=module', true);
		} elseif (VERSION >= '2.3.0.0') {
			$data['cancel'] = $this->url->link('extension/extension', $url_token . '&type=module', true);
		} else {
			$data['cancel'] = $this->url->link('extension/module', $url_token, true);
		}
		
		// Tab
		$data['text_settings'] = $this->language->get('text_settings');
		$data['text_overview_list'] = $this->language->get('text_overview_list');
		$data['text_export_import'] = $this->language->get('text_export_import');
		$data['text_instructions'] = $this->language->get('text_instructions');
		$data['text_instructions_full'] = $this->language->get('text_instructions_full');
		
		$data['text_export'] = $this->language->get('text_export');
		$data['text_import'] = $this->language->get('text_import');
		
		// Button
		$data['button_cancel'] = $this->language->get('button_cancel');	
		$data['button_setup'] = $this->language->get('button_setup');
		$data['button_export'] = $this->language->get('button_export');
		$data['button_import'] = $this->language->get('button_import');
						
		// Entry
		$data['entry_store'] = $this->language->get('entry_store');
		$data['entry_sheet'] = $this->language->get('entry_sheet');
		$data['entry_export'] = $this->language->get('entry_export');
		$data['entry_upload'] = $this->language->get('entry_upload');
		$data['entry_import'] = $this->language->get('entry_import');
								
		// Text
		$data['text_edit'] = $this->language->get('text_edit');
		$data['text_install'] = $this->language->get('text_install');
		$data['text_setup'] = $this->language->get('text_setup');
		$data['text_full_setup'] = $this->language->get('text_full_setup');
		$data['text_custom_setup'] = $this->language->get('text_custom_setup');
		$data['text_yes'] = $this->language->get('text_yes');
		$data['text_no'] = $this->language->get('text_no');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['text_powered_by'] = $this->language->get('text_powered_by');
		
		// Help
		$data['help_setup'] = $this->language->get('help_setup');
		$data['help_full_setup'] = $this->language->get('help_full_setup');
		$data['help_custom_setup'] = $this->language->get('help_custom_setup');
								
		// Notification
		foreach ($this->error as $key => $error) {
			$data['error'][$key] = $error;
		}
		
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		
		// Breadcrumbs
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', $url_token, true)
		);

		if (VERSION >= '3.0.0.0') {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_modules'),
				'href' => $this->url->link('marketplace/extension', $url_token . '&type=module', true)
			);
		} elseif (VERSION >= '2.3.0.0') {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_modules'),
				'href' => $this->url->link('extension/extension', $url_token . '&type=module', true)
			);
		} else {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_modules'),
				'href' => $this->url->link('extension/module', $url_token, true)
			);
		}

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_seo_module'),
			'href' => $this->url->link('extension/module/d_seo_module', $url_token . '&' . $url_store, true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_manager'),
			'href' => $this->url->link($this->route, $url_token . '&' . $url_store, true)
		);
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		if ($data['installed']) {		
			// Setting 		
			$data['setting'] = array();
		
			$installed_seo_manager_extensions = $this->{'model_extension_module_' . $this->codename}->getInstalledSEOManagerExtensions();
		
			foreach ($installed_seo_manager_extensions as $installed_seo_manager_extension) {
				$info = $this->load->controller('extension/' . $this->codename . '/' . $installed_seo_manager_extension . '/manager_config');
				if ($info) $data['setting'] = array_replace_recursive($data['setting'], $info);
			}
		
			$setting = $this->model_setting_setting->getSetting('module_' . $this->codename, $store_id);
			$setting = isset($setting['module_' . $this->codename . '_setting']) ? $setting['module_' . $this->codename . '_setting'] : array();
										
			if (!empty($setting)) {
				$data['setting'] = array_replace_recursive($data['setting'], $setting);
			}
		
			$sheets = array();
				
			foreach ($data['setting']['sheet'] as $sheet) {
				if (isset($sheet['code']) && isset($sheet['name']) && isset($sheet['field_index'])) {				
					$sheets[] = $sheet;
				}
			}
		
			$data['setting']['sheet'] = $this->{'model_extension_module_' . $this->codename}->sortArrayByColumn($sheets, 'sort_order');
			
			$this->response->setOutput($this->load->view($this->route . '/export_import', $data));
		} else {
			// Setting
			$this->config->load($this->config_file);
			$config_feature_setting = ($this->config->get($this->codename . '_feature_setting')) ? $this->config->get($this->codename . '_feature_setting') : array();
		
			$data['features'] = array();
		
			foreach ($config_feature_setting as $feature) {
				if (substr($feature['name'], 0, strlen('text_')) == 'text_') {
					$feature['name'] = $this->language->get($feature['name']);
				}
						
				$data['features'][] = $feature;
			}
			
			$this->response->setOutput($this->load->view($this->route . '/install', $data));
		}
	}
		
	public function instruction() {
		$this->load->language($this->route);
		
		$this->load->model($this->route);
		$this->load->model('setting/setting');
		$this->load->model('localisation/language');
		
		if ($this->d_shopunity) {		
			$this->load->model('extension/d_shopunity/mbooth');
				
			$this->model_extension_d_shopunity_mbooth->validateDependencies($this->codename);
		}
		
		if (file_exists(DIR_APPLICATION . 'model/extension/module/d_twig_manager.php')) {
			$this->load->model('extension/module/d_twig_manager');
			
			$this->model_extension_module_d_twig_manager->installCompatibility();
		}
		
		if (isset($this->request->get['store_id'])) { 
			$store_id = $this->request->get['store_id']; 
		} else {  
			$store_id = 0;
		}
		
		$url_token = '';
		
		if (isset($this->session->data['token'])) {
			$url_token .= 'token=' . $this->session->data['token'];
		}
		
		if (isset($this->session->data['user_token'])) {
			$url_token .= 'user_token=' . $this->session->data['user_token'];
		}
		
		$url_store = 'store_id=' . $store_id;
		
		// Styles and Scripts
		$this->document->addStyle('view/stylesheet/d_bootstrap_extra/bootstrap.css');
		$this->document->addScript('view/javascript/d_bootstrap_switch/js/bootstrap-switch.min.js');
        $this->document->addStyle('view/javascript/d_bootstrap_switch/css/bootstrap-switch.css');
		$this->document->addStyle('view/stylesheet/d_admin_style/core/normalize/normalize.css');
		$this->document->addStyle('view/stylesheet/d_admin_style/themes/light/light.css');
		$this->document->addStyle('view/stylesheet/d_seo_module.css');
				
		// Heading
		$this->document->setTitle($this->language->get('heading_title_main'));
		$data['heading_title'] = $this->language->get('heading_title_main');
		
		// Variable
		$data['codename'] = $this->codename;
		$data['route'] = $this->route;
		$data['version'] = $this->extension['version'];
		$data['config'] = $this->config_file;
		$data['d_shopunity'] = $this->d_shopunity;
		$data['store_id'] = $store_id;
						
		$installed_seo_extensions = $this->{'model_extension_module_' . $this->codename}->getInstalledSEOExtensions();
		$data['installed'] = in_array($this->codename, $installed_seo_extensions) ? true : false;
								
		if (isset($this->request->server['HTTPS']) && (($this->request->server['HTTPS'] == 'on') || ($this->request->server['HTTPS'] == '1'))) {
			$data['server'] = HTTPS_SERVER;
			$data['catalog'] = HTTPS_CATALOG;
		} else {
			$data['server'] = HTTP_SERVER;
			$data['catalog'] = HTTP_CATALOG;
		}
						
		// Action
		$data['href_setting'] = $this->url->link($this->route . '/setting', $url_token . '&' . $url_store, true);
		$data['href_overview_list'] = $this->url->link($this->route . '/overview_list', $url_token . '&' . $url_store, true);
		$data['href_export_import'] = $this->url->link($this->route . '/export_import', $url_token . '&' . $url_store, true);
		$data['href_instruction'] = $this->url->link($this->route . '/instruction', $url_token . '&' . $url_store, true);
		
		$data['setup'] = $this->url->link($this->route . '/setupExtension', $url_token, true);
		$data['install'] = $this->url->link($this->route . '/installExtension', $url_token, true);
		
		if (VERSION >= '3.0.0.0') {
			$data['cancel'] = $this->url->link('marketplace/extension', $url_token . '&type=module', true);
		} elseif (VERSION >= '2.3.0.0') {
			$data['cancel'] = $this->url->link('extension/extension', $url_token . '&type=module', true);
		} else {
			$data['cancel'] = $this->url->link('extension/module', $url_token, true);
		}
		
		// Tab
		$data['text_settings'] = $this->language->get('text_settings');
		$data['text_overview_list'] = $this->language->get('text_overview_list');
		$data['text_export_import'] = $this->language->get('text_export_import');
		$data['text_instructions'] = $this->language->get('text_instructions');
		$data['text_instructions_full'] = $this->language->get('text_instructions_full');
				
		// Button
		$data['button_cancel'] = $this->language->get('button_cancel');	
		$data['button_setup'] = $this->language->get('button_setup');
								
		// Text
		$data['text_edit'] = $this->language->get('text_edit');
		$data['text_install'] = $this->language->get('text_install');
		$data['text_setup'] = $this->language->get('text_setup');
		$data['text_full_setup'] = $this->language->get('text_full_setup');
		$data['text_custom_setup'] = $this->language->get('text_custom_setup');
		$data['text_yes'] = $this->language->get('text_yes');
		$data['text_no'] = $this->language->get('text_no');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['text_powered_by'] = $this->language->get('text_powered_by');
		
		// Help
		$data['help_setup'] = $this->language->get('help_setup');
		$data['help_full_setup'] = $this->language->get('help_full_setup');
		$data['help_custom_setup'] = $this->language->get('help_custom_setup');
		
		// Notification
		foreach ($this->error as $key => $error) {
			$data['error'][$key] = $error;
		}
		
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		
		// Breadcrumbs
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', $url_token, true)
		);

		if (VERSION >= '3.0.0.0') {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_modules'),
				'href' => $this->url->link('marketplace/extension', $url_token . '&type=module', true)
			);
		} elseif (VERSION >= '2.3.0.0') {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_modules'),
				'href' => $this->url->link('extension/extension', $url_token . '&type=module', true)
			);
		} else {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_modules'),
				'href' => $this->url->link('extension/module', $url_token, true)
			);
		}

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_seo_module'),
			'href' => $this->url->link('extension/module/d_seo_module', $url_token . '&' . $url_store, true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_manager'),
			'href' => $this->url->link($this->route, $url_token . '&' . $url_store, true)
		);
												
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		if ($data['installed']) {
			$this->response->setOutput($this->load->view($this->route . '/instruction', $data));
		} else {
			// Setting
			$this->config->load($this->config_file);
			$config_feature_setting = ($this->config->get($this->codename . '_feature_setting')) ? $this->config->get($this->codename . '_feature_setting') : array();
		
			$data['features'] = array();
		
			foreach ($config_feature_setting as $feature) {
				if (substr($feature['name'], 0, strlen('text_')) == 'text_') {
					$feature['name'] = $this->language->get($feature['name']);
				}
						
				$data['features'][] = $feature;
			}
			
			$this->response->setOutput($this->load->view($this->route . '/install', $data));
		}
	}
	
	public function save() {
		$this->load->language($this->route);
		
		$this->load->model($this->route);
		$this->load->model('setting/setting');
		
		if (isset($this->request->get['store_id'])) { 
			$store_id = $this->request->get['store_id']; 
		} else {  
			$store_id = 0;
		}
		
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$old_setting = $this->model_setting_setting->getSetting('module_' . $this->codename, $store_id);
			
			$new_setting = array_replace_recursive($old_setting, $this->request->post);
						
			$this->model_setting_setting->editSetting('module_' . $this->codename, $new_setting, $store_id);
			
			$save_data = array(
				'old_setting'		=> $old_setting,
				'new_setting'		=> $new_setting,
				'store_id'			=> $store_id
			);			

			$installed_seo_manager_extensions = $this->{'model_extension_module_' . $this->codename}->getInstalledSEOManagerExtensions();
		
			foreach ($installed_seo_manager_extensions as $installed_seo_manager_extension) {
				$this->load->controller('extension/' . $this->codename . '/' . $installed_seo_manager_extension . '/save', $save_data);
			}

			$data['success'] = $this->language->get('success_save');
		}
						
		$data['error'] = $this->error;
				
		$this->response->setOutput(json_encode($data));
	}
		
	public function editElementField() {
		$this->load->language($this->route);
		
		$this->load->model($this->route);
		
		if (isset($this->request->get['store_id'])) { 
			$store_id = $this->request->get['store_id']; 
		} else {  
			$store_id = 0;
		}
				
		if (isset($this->request->post['sheet_code']) && isset($this->request->post['language_id']) && isset($this->request->post['element_id']) && isset($this->request->post['field_code']) && isset($this->request->post['value'])) {
			$element_data = array(
				'store_id'		=> $store_id,
				'sheet_code'	=> $this->request->post['sheet_code'],
				'language_id'	=> $this->request->post['language_id'],
				'element_id'	=> $this->request->post['element_id'],
				'field_code'	=> $this->request->post['field_code'],
				'value'			=> $this->request->post['value']
			);
					
			$installed_seo_manager_extensions = $this->{'model_extension_module_' . $this->codename}->getInstalledSEOManagerExtensions();
		
			foreach ($installed_seo_manager_extensions as $installed_seo_manager_extension) {
				$info = $this->load->controller('extension/' . $this->codename . '/' . $installed_seo_manager_extension . '/manager_edit_element_field', $element_data);
				
				if (isset($info['error'])) {
					$this->error = array_replace_recursive($this->error, $info['error']);
				}
			}
			
			$data['value'] = $this->request->post['value'];
		}
		
		$data['error'] = $this->error;	
		
		$this->response->setOutput(json_encode($data));
	}
	
	public function export() {
		$this->load->language($this->route);
		
		$this->load->model($this->route);
		$this->load->model('setting/setting');
		$this->load->model('localisation/language');
		
		if (isset($this->request->post['store_id'])) { 
			$store_id = $this->request->post['store_id']; 
		} else {  
			$store_id = 0;
		}
		
		if (isset($this->request->post['sheet_codes'])) { 
			$sheet_codes = $this->request->post['sheet_codes']; 
		} else {  
			$sheet_codes = array();
		}
												
		// Setting		
		$config_setting = array();
		
		$installed_seo_manager_extensions = $this->{'model_extension_module_' . $this->codename}->getInstalledSEOManagerExtensions();
		
		foreach ($installed_seo_manager_extensions as $installed_seo_manager_extension) {
			$info = $this->load->controller('extension/' . $this->codename . '/' . $installed_seo_manager_extension . '/manager_config');
			if ($info) $config_setting = array_replace_recursive($config_setting, $info);
		}
		
		$setting = $this->model_setting_setting->getSetting('module_' . $this->codename, $store_id);
		$setting = isset($setting['module_' . $this->codename . '_setting']) ? $setting['module_' . $this->codename . '_setting'] : array();
		
		if (!empty($setting)) {
			$config_setting = array_replace_recursive($config_setting, $setting);
		}
		
		$setting = $config_setting;
		
		$sheets = $this->{'model_extension_module_' . $this->codename}->sortArrayByColumn($setting['sheet'], 'sort_order');
		
		$store = $this->{'model_extension_module_' . $this->codename}->getStore($store_id);
		$languages = $this->{'model_extension_module_' . $this->codename}->getLanguages();
		
		if (file_exists(DIR_SYSTEM . 'library/d_excel_reader_writer.php')) {
			$d_excel_reader_writer = new d_excel_reader_writer();
							
			foreach ($sheets as $sheet) {
				if (isset($sheet['code']) && isset($sheet['name']) && isset($sheet['field_index'])) {
					if (in_array($sheet['code'], $sheet_codes)) {
						$fields = array();
						
						if (isset($sheet['field'])) {
							foreach ($sheet['field'] as $field) {
								if (isset($field['code']) && isset($field['name']) && isset($field['type']) && isset($field['export_status']) && isset($field['required'])) {
									if ($field['export_status'] || $field['required']) {
										$fields[] = $field;
									}
								}
							}
							
							$fields = $this->{'model_extension_module_' . $this->codename}->sortArrayByColumn($fields, 'sort_order');
						}
					
						$export_data = array(
							'store_id'			=> $store_id,
							'sheet_code'		=> $sheet['code'],
							'fields'			=> $fields
						);
			
						$export_elements = array();
				
						foreach ($installed_seo_manager_extensions as $installed_seo_manager_extension) {
							$info = $this->load->controller('extension/' . $this->codename . '/' . $installed_seo_manager_extension . '/manager_export_elements', $export_data);
						
							if ($info) {
								if ($export_elements) {
									foreach ($export_elements as $element_id => $export_element) {
										if (isset($info[$element_id])) {
											$export_elements[$element_id] = array_replace_recursive($export_element, $info[$element_id]);
										} 
									}
								} else {
									$export_elements = $info;
								}
							}
						}
								
						// Set the column widths
						$column_widths = array();
						
						foreach ($fields as $field) {
							if ($field['multi_language']) {
								foreach ($languages as $language) {
									$column_widths[] = max(strlen($field['code']) + 4, 30) + 1;
								}
							} else {
								$column_widths[] = max(strlen($field['code']) + 4, 30) + 1;
							}
						}
						
						$d_excel_reader_writer->setColumnWidths($column_widths);
				
						// The heading row and column styles
						$header = array();
											
						foreach ($fields as $field) {
							if ($field['multi_language']) {
								foreach ($languages as $language) {
									$header[$field['code'] . '(' . $language['code'] . ')'] = 'string';
								}
							} else {
								$header[$field['code']] = 'string';
							}	
						}
					
						$d_excel_reader_writer->writeSheetHeader($sheet['code'], $header);

						// The actual elements data					
						foreach ($export_elements as $element_id => $export_element) {
							$data = array();
						
							foreach ($fields as $field) {
								if ($field['multi_language']) {
									foreach ($languages as $language) {
										if (isset($export_element[$field['code']][$language['language_id']])) {
											$data[] = html_entity_decode($export_element[$field['code']][$language['language_id']], ENT_QUOTES, 'UTF-8');
										} else {
											$data[] = '';
										}
									}
								} else {
									if (isset($export_element[$field['code']])) {
										$data[] = html_entity_decode($export_element[$field['code']], ENT_QUOTES, 'UTF-8');
									} else {
										$data[] = '';
									}
								}
							}
						
							$d_excel_reader_writer->writeSheetRow($sheet['code'], $data);
						}
					}
				}
			}
					
			$filename = $this->codename . ' ' . $store['name'] . ' ' . date('Y-m-d') . '.xlsx';
		
			$this->response->addHeader('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
			$this->response->addHeader('Content-Disposition: attachment;filename="' . $filename . '"');
			$this->response->addHeader('Cache-Control: max-age=0');
			
			$this->response->setOutput($d_excel_reader_writer->writeToString());
		}
	}
	
	public function import() {
		$this->load->language($this->route);
		
		$this->load->model($this->route);
		$this->load->model('setting/setting');
		$this->load->model('localisation/language');
		
		if (isset($this->request->post['store_id'])) { 
			$store_id = $this->request->post['store_id']; 
		} else {  
			$store_id = 0;
		}
		
		if (isset($this->request->post['sheet_codes'])) { 
			$sheet_codes = $this->request->post['sheet_codes']; 
		} else {  
			$sheet_codes = array();
		}
														
		// Setting 		
		$config_setting = array();
		
		$installed_seo_manager_extensions = $this->{'model_extension_module_' . $this->codename}->getInstalledSEOManagerExtensions();
		
		foreach ($installed_seo_manager_extensions as $installed_seo_manager_extension) {
			$info = $this->load->controller('extension/' . $this->codename . '/' . $installed_seo_manager_extension . '/manager_config');
			if ($info) $config_setting = array_replace_recursive($config_setting, $info);
		}
		
		$setting = $this->model_setting_setting->getSetting('module_' . $this->codename, $store_id);
		$setting = isset($setting['module_' . $this->codename . '_setting']) ? $setting['module_' . $this->codename . '_setting'] : array();
		
		if (!empty($setting)) {
			$config_setting = array_replace_recursive($config_setting, $setting);
		}
		
		$setting = $config_setting;
		
		$sheets = $this->{'model_extension_module_' . $this->codename}->sortArrayByColumn($setting['sheet'], 'sort_order');
		
		$languages = $this->{'model_extension_module_' . $this->codename}->getLanguages();
		
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && ($this->validateImport())) {
			if ((isset($this->request->files['upload'])) && (is_uploaded_file($this->request->files['upload']['tmp_name'])) && file_exists(DIR_SYSTEM . 'library/d_excel_reader_writer.php')) {
				$filepath = $this->request->files['upload']['tmp_name'];
				$filename = $this->request->files['upload']['name'];
				$mimetype = $this->request->files['upload']['type'];
				
				$d_excel_reader_writer = new d_excel_reader_writer();
				
				// parse uploaded spreadsheet file
				$reader = $d_excel_reader_writer->readFromFile($filepath, $filename, $mimetype);
								
				// get worksheet if there
				$sheet_codes = $reader->Sheets();
				
				// get worksheet if there				
				foreach ($sheets as $sheet) {
					if (isset($sheet['code']) && isset($sheet['name'])) {
						foreach ($sheet_codes as $sheet_index => $sheet_code) {
							if ($sheet_code == $sheet['code']) {				
								$reader->ChangeSheet($sheet_index);
						
								$elements = array();
								$header = array();
						
								foreach ($reader as $row => $row_data) {
									if (!$header) {
										$header = $row_data;
										
										continue;
									}
							
									foreach ($header as $col => $col_data) {
										$cell = isset($row_data[$col]) ? $row_data[$col] : '';
										$elements[$row][$header[$col]] = htmlspecialchars($cell);
									}
								}
						
								$import_elements = array();
						
								foreach ($elements as $element) {
									$element_id = 0;
							
									if (isset($element[$sheet['field_index']]) && $element[$sheet['field_index']]) {
										$element_id = $element[$sheet['field_index']];
									} else {
										continue;
									}
							
									if (isset($sheet['field'])) {
										foreach ($sheet['field'] as $field) {
											if (isset($field['code'])) {
												if ($field['multi_language']) {
													foreach ($languages as $language) {
														if (isset($element[$field['code'] . '(' . $language['code'] . ')'])) {
															$import_elements[$element_id][$field['code']][$language['language_id']] = $element[$field['code'] . '(' . $language['code'] . ')'];
														}
													}
												} else {
													if (isset($element[$field['code']])) {
														$import_elements[$element_id][$field['code']] = $element[$field['code']];
													}
												}
											}
										}
									}
								}
								
								$import_data = array(
									'store_id'			=> $store_id,
									'sheet_code'		=> $sheet['code'],
									'fields'			=> $sheet['field'],
									'elements'			=> $import_elements
								);
										
								foreach ($installed_seo_manager_extensions as $installed_seo_manager_extension) {
									$info = $this->load->controller('extension/' . $this->codename . '/' . $installed_seo_manager_extension . '/manager_import_elements', $import_data);
							
									if (isset($info['error'])) {
										$this->error = array_replace_recursive($this->error, $info['error']);
									}
								}
							}
						}
					}
				}
			}
		}
		
		$data['error'] = $this->error;
		
		if (!$this->error) {
			$data['success'] = $this->language->get('success_import');
		}
				
		$this->response->setOutput(json_encode($data));
	}
	
	public function setupExtension() {
		$this->load->model($this->route);
		
		$info = $this->load->controller('extension/d_seo_module/d_seo_module/control_setup_extension');
		
		$this->load->language($this->route);
		
		if (isset($info['error'])) {
			$this->error = array_replace_recursive($this->error, $info['error']);
		}
		
		if (!$this->error) {
			$data['success'] = $this->language->get('success_install');
		}
		
		$data['error'] = $this->error;

		$this->response->setOutput(json_encode($data));
	}
		
	public function installExtension() {
		$this->load->language($this->route);
		
		$this->load->model('user/user_group');
				
		if ($this->validateInstall()) {
			if (file_exists(DIR_APPLICATION . 'model/extension/d_opencart_patch/extension.php') && file_exists(DIR_APPLICATION . 'model/extension/d_opencart_patch/user.php')) {
				$this->load->model('extension/d_opencart_patch/extension');			
				$this->load->model('extension/d_opencart_patch/user');			
				
				$user_group_id = $this->model_extension_d_opencart_patch_user->getGroupId();
				
				// Install SEO Module Manager
				if (!$this->model_extension_d_opencart_patch_extension->isInstalled('d_seo_module_manager')) {
					$this->model_extension_d_opencart_patch_extension->install('module', 'd_seo_module_manager');
				
					$this->model_user_user_group->addPermission($user_group_id, 'access', 'extension/module/d_seo_module_manager');
					$this->model_user_user_group->addPermission($user_group_id, 'modify', 'extension/module/d_seo_module_manager');
				}
			}
			
			$data['success'] = $this->language->get('success_install');
		}
		
		$data['error'] = $this->error;
		
		$this->response->setOutput(json_encode($data));
	}
	
	public function uninstallExtension() {
		$this->load->language($this->route);
				
		if ($this->validateUninstall()) {
			$data['success'] = $this->language->get('success_uninstall');
		}
						
		$data['error'] = $this->error;
				
		$this->response->setOutput(json_encode($data));
	}
	
	public function install() {
		$this->load->model($this->route);
		
		if ($this->d_shopunity) {
			$this->load->model('extension/d_shopunity/mbooth');
			
			$this->model_extension_d_shopunity_mbooth->installDependencies($this->codename);  
		}
	}
		
	/*
	*	Validator Functions.
	*/	 	
	private function validate($permission = 'modify') {				
		if (!$this->user->hasPermission($permission, $this->route)) {
			$this->error['warning'] = $this->language->get('error_permission');
			
			return false;
		}
		
		return true;
	}
	
	private function validateImport($permission = 'modify') {				
		if (!$this->user->hasPermission($permission, $this->route)) {
			$this->error['warning'] = $this->language->get('error_permission');
			
			return false;
		}
		
		if (!isset($this->request->files['upload']['name']) || !$this->request->files['upload']['name']) {
			$this->error['warning'] = $this->language->get('error_upload_name');
			
			return false;
		}
		
		$ext = strtolower(pathinfo($this->request->files['upload']['name'], PATHINFO_EXTENSION));
		
		if (($ext != 'xls') && ($ext != 'xlsx') && ($ext != 'ods')) {
			$this->error['warning'] = $this->language->get('error_upload_ext');
			
			return false;
		}

		return true;
	}
	
	private function validateInstall($permission = 'modify') {
		$this->load->model($this->route);
				
		$installed_seo_extensions = $this->{'model_extension_module_' . $this->codename}->getInstalledSEOExtensions();
		
		if (in_array($this->codename, $installed_seo_extensions)) {
			$this->error['warning'] = $this->language->get('error_installed');
			
			return false;
		}
		
		if (!in_array('d_seo_module', $installed_seo_extensions)) {
			$info = $this->load->controller('extension/d_seo_module/d_seo_module/control_install_extension');
			
			$this->load->language($this->route);
			
			if ($info) {	
				if ($info['error']) {
					$this->error = $info['error'];
				
					return false;
				} else {
					$installed_seo_extensions = $this->{'model_extension_module_' . $this->codename}->getInstalledSEOExtensions();
				} 
			} else {
				$this->error['warning'] = $this->language->get('error_dependence_d_seo_module');
				
				return false;
			}
		}
		
		$installed_seo_extensions[] = $this->codename;
		
		$this->{'model_extension_module_' . $this->codename}->saveSEOExtensions($installed_seo_extensions);
										
		return true;
	}
	
	private function validateUninstall($permission = 'modify') {
		$this->load->model($this->route);
				
		$installed_seo_extensions = $this->{'model_extension_module_' . $this->codename}->getInstalledSEOExtensions();
		
		$key = array_search($this->codename, $installed_seo_extensions);
		if ($key !== false) unset($installed_seo_extensions[$key]);
		
		$this->{'model_extension_module_' . $this->codename}->saveSEOExtensions($installed_seo_extensions);

		return true;
	}
}