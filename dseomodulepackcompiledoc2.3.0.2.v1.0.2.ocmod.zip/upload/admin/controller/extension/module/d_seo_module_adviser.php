<?php
class ControllerExtensionModuleDSEOModuleAdviser extends Controller {
	private $codename = 'd_seo_module_adviser';
	private $route = 'extension/module/d_seo_module_adviser';
	private $config_file = 'd_seo_module_adviser';
	private $extension = array();
	private $error = array(); 
		
	public function __construct($registry) {
		parent::__construct($registry);

		$this->d_shopunity = (file_exists(DIR_SYSTEM . 'library/d_shopunity/extension/d_shopunity.json'));
		$this->extension = json_decode(file_get_contents(DIR_SYSTEM . 'library/d_shopunity/extension/' . $this->codename . '.json'), true);
	}
	
	public function index() {
		$this->setting();
	}
		
	public function setting() {
		$this->load->language($this->route);

		$this->load->model($this->route);
		$this->load->model('setting/setting');
		$this->load->model('localisation/language');
		
		if ($this->d_shopunity) {		
			$this->load->model('extension/d_shopunity/mbooth');
				
			$this->model_extension_d_shopunity_mbooth->validateDependencies($this->codename);
		}
		
		if (file_exists(DIR_APPLICATION . 'model/extension/module/d_twig_manager.php')) {
			$this->load->model('extension/module/d_twig_manager');
			
			$this->model_extension_module_d_twig_manager->installCompatibility();
		}
		
		$url_token = '';
		
		if (isset($this->session->data['token'])) {
			$url_token .=  'token=' . $this->session->data['token'];
		}
		
		if (isset($this->session->data['user_token'])) {
			$url_token .=  'user_token=' . $this->session->data['user_token'];
		}

		// Styles and Scripts
		$this->document->addStyle('view/stylesheet/d_bootstrap_extra/bootstrap.css');
		$this->document->addScript('view/javascript/d_bootstrap_switch/js/bootstrap-switch.min.js');
        $this->document->addStyle('view/javascript/d_bootstrap_switch/css/bootstrap-switch.css');
		$this->document->addStyle('view/stylesheet/d_admin_style/core/normalize/normalize.css');
		$this->document->addStyle('view/stylesheet/d_admin_style/themes/light/light.css');
		$this->document->addStyle('view/stylesheet/d_seo_module.css');

		// Heading
		$this->document->setTitle($this->language->get('heading_title_main'));
		$data['heading_title'] = $this->language->get('heading_title_main');

		// Variable
		$data['codename'] = $this->codename;
		$data['route'] = $this->route;
		$data['version'] = $this->extension['version'];
		$data['extension_id'] = $this->extension['extension_id'];
		$data['config'] = $this->config_file;
		$data['d_shopunity'] = $this->d_shopunity;
		$data['url_token'] = $url_token;
		$data['stores'] = $this->{'model_extension_module_' . $this->codename}->getStores();
		$data['languages'] = $this->{'model_extension_module_' . $this->codename}->getLanguages();

		$installed_seo_extensions = $this->{'model_extension_module_' . $this->codename}->getInstalledSEOExtensions();
		$data['installed'] = in_array($this->codename, $installed_seo_extensions) ? true : false;

		if (isset($this->request->server['HTTPS']) && (($this->request->server['HTTPS'] == 'on') || ($this->request->server['HTTPS'] == '1'))) {
			$data['server'] = HTTPS_SERVER;
			$data['catalog'] = HTTPS_CATALOG;
		} else {
			$data['server'] = HTTP_SERVER;
			$data['catalog'] = HTTP_CATALOG;
		}
		
		// Action
		$data['href_setting'] = $this->url->link($this->route . '/setting', $url_token, true);
		$data['href_instruction'] = $this->url->link($this->route . '/instruction', $url_token, true);
		
		$data['module_link'] = $this->url->link($this->route, $url_token, true);
		$data['action'] = $this->url->link($this->route . '/save', $url_token, true);
		$data['setup'] = $this->url->link($this->route . '/setupExtension', $url_token, true);
		$data['install'] = $this->url->link($this->route . '/installExtension', $url_token, true);
		$data['uninstall'] = $this->url->link($this->route . '/uninstallExtension', $url_token, true);
		
		if (VERSION >= '3.0.0.0') {
			$data['cancel'] = $this->url->link('marketplace/extension', $url_token . '&type=module', true);
		} elseif (VERSION >= '2.3.0.0') {
			$data['cancel'] = $this->url->link('extension/extension', $url_token . '&type=module', true);
		} else {
			$data['cancel'] = $this->url->link('extension/module', $url_token, true);
		}
		
		// Tab
		$data['text_settings'] = $this->language->get('text_settings');
		$data['text_instructions'] = $this->language->get('text_instructions');
		$data['text_instructions_full'] = $this->language->get('text_instructions_full');
		
		// Button
		$data['button_save'] = $this->language->get('button_save');
		$data['button_save_and_stay'] = $this->language->get('button_save_and_stay');
		$data['button_cancel'] = $this->language->get('button_cancel');
		$data['button_setup'] = $this->language->get('button_setup');
		$data['button_uninstall'] = $this->language->get('button_uninstall');
		
		// Entry
		$data['entry_status'] = $this->language->get('entry_status');
		$data['entry_uninstall'] = $this->language->get('entry_uninstall');
		
		// Text
		$data['text_edit'] = $this->language->get('text_edit');
		$data['text_install'] = $this->language->get('text_install');
		$data['text_setup'] = $this->language->get('text_setup');
		$data['text_full_setup'] = $this->language->get('text_full_setup');
		$data['text_custom_setup'] = $this->language->get('text_custom_setup');
		$data['text_yes'] = $this->language->get('text_yes');
		$data['text_no'] = $this->language->get('text_no');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['text_powered_by'] = $this->language->get('text_powered_by');
		$data['text_uninstall_confirm'] = $this->language->get('text_uninstall_confirm');
		
		// Help
		$data['help_setup'] = $this->language->get('help_setup');
		$data['help_full_setup'] = $this->language->get('help_full_setup');
		$data['help_custom_setup'] = $this->language->get('help_custom_setup');
		
		// Notification
		foreach ($this->error as $key => $error) {
			$data['error'][$key] = $error;
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		// Breadcrumbs
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', $url_token, true)
		);
				
		if (VERSION >= '3.0.0.0') {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_modules'),
				'href' => $this->url->link('marketplace/extension', $url_token . '&type=module', true)
			);
		} elseif (VERSION >= '2.3.0.0') {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_modules'),
				'href' => $this->url->link('extension/extension', $url_token . '&type=module', true)
			);
		} else {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_modules'),
				'href' => $this->url->link('extension/module', $url_token, true)
			);
		}

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_seo_module'),
			'href' => $this->url->link('extension/module/d_seo_module', $url_token, true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_adviser'),
			'href' => $this->url->link($this->route, $url_token, true)
		);
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		if ($data['installed']) {
			// Setting 		
			$this->config->load($this->config_file);
			$data['setting'] = ($this->config->get($this->codename . '_setting')) ? $this->config->get($this->codename . '_setting') : array();
		
			$setting = $this->model_setting_setting->getSetting('module_' . $this->codename);
			$status = isset($setting['module_' . $this->codename . '_status']) ? $setting['module_' . $this->codename . '_status'] : false;
			$setting = isset($setting['module_' . $this->codename . '_setting']) ? $setting['module_' . $this->codename . '_setting'] : array();
		
			$data['status'] = $status;
								
			if (!empty($setting)) {
				$data['setting'] = array_replace_recursive($data['setting'], $setting);
			}
			
			$this->response->setOutput($this->load->view($this->route . '/setting', $data));
		} else {
			// Setting
			$this->config->load($this->config_file);
			$config_feature_setting = ($this->config->get($this->codename . '_feature_setting')) ? $this->config->get($this->codename . '_feature_setting') : array();
		
			$data['features'] = array();
		
			foreach ($config_feature_setting as $feature) {
				if (substr($feature['name'], 0, strlen('text_')) == 'text_') {
					$feature['name'] = $this->language->get($feature['name']);
				}
						
				$data['features'][] = $feature;
			}
			
			$this->response->setOutput($this->load->view($this->route . '/install', $data));
		}
	}
	
	public function instruction() {
		$this->load->language($this->route);
		
		$this->load->model($this->route);
		$this->load->model('setting/setting');
		$this->load->model('localisation/language');
		
		if ($this->d_shopunity) {		
			$this->load->model('extension/d_shopunity/mbooth');
				
			$this->model_extension_d_shopunity_mbooth->validateDependencies($this->codename);
		}
		
		if (file_exists(DIR_APPLICATION . 'model/extension/module/d_twig_manager.php')) {
			$this->load->model('extension/module/d_twig_manager');
			
			$this->model_extension_module_d_twig_manager->installCompatibility();
		}
				
		$url_token = '';
		
		if (isset($this->session->data['token'])) {
			$url_token .= 'token=' . $this->session->data['token'];
		}
		
		if (isset($this->session->data['user_token'])) {
			$url_token .= 'user_token=' . $this->session->data['user_token'];
		}
				
		// Styles and Scripts
		$this->document->addStyle('view/stylesheet/d_bootstrap_extra/bootstrap.css');
		$this->document->addScript('view/javascript/d_bootstrap_switch/js/bootstrap-switch.min.js');
        $this->document->addStyle('view/javascript/d_bootstrap_switch/css/bootstrap-switch.css');
		$this->document->addStyle('view/stylesheet/d_admin_style/core/normalize/normalize.css');
		$this->document->addStyle('view/stylesheet/d_admin_style/themes/light/light.css');
		$this->document->addStyle('view/stylesheet/d_seo_module.css');
				
		// Heading
		$this->document->setTitle($this->language->get('heading_title_main'));
		$data['heading_title'] = $this->language->get('heading_title_main');
		
		// Variable
		$data['codename'] = $this->codename;
		$data['route'] = $this->route;
		$data['version'] = $this->extension['version'];
		$data['config'] = $this->config_file;
		$data['d_shopunity'] = $this->d_shopunity;
								
		$installed_seo_extensions = $this->{'model_extension_module_' . $this->codename}->getInstalledSEOExtensions();
		$data['installed'] = in_array($this->codename, $installed_seo_extensions) ? true : false;
						
		if (isset($this->request->server['HTTPS']) && (($this->request->server['HTTPS'] == 'on') || ($this->request->server['HTTPS'] == '1'))) {
			$data['server'] = HTTPS_SERVER;
			$data['catalog'] = HTTPS_CATALOG;
		} else {
			$data['server'] = HTTP_SERVER;
			$data['catalog'] = HTTP_CATALOG;
		}
				
		// Action
		$data['href_setting'] = $this->url->link($this->route . '/setting', $url_token, true);
		$data['href_instruction'] = $this->url->link($this->route . '/instruction', $url_token, true);
		
		$data['setup'] = $this->url->link($this->route . '/setupExtension', $url_token, true);
		$data['install'] = $this->url->link($this->route . '/installExtension', $url_token, true);
		
		if (VERSION >= '3.0.0.0') {
			$data['cancel'] = $this->url->link('marketplace/extension', $url_token . '&type=module', true);
		} elseif (VERSION >= '2.3.0.0') {
			$data['cancel'] = $this->url->link('extension/extension', $url_token . '&type=module', true);
		} else {
			$data['cancel'] = $this->url->link('extension/module', $url_token, true);
		}
				
		// Tab
		$data['text_settings'] = $this->language->get('text_settings');
		$data['text_instructions'] = $this->language->get('text_instructions');
						
		// Button
		$data['button_cancel'] = $this->language->get('button_cancel');
		$data['button_setup'] = $this->language->get('button_setup');
										
		// Text
		$data['text_edit'] = $this->language->get('text_edit');
		$data['text_install'] = $this->language->get('text_install');
		$data['text_setup'] = $this->language->get('text_setup');
		$data['text_full_setup'] = $this->language->get('text_full_setup');
		$data['text_custom_setup'] = $this->language->get('text_custom_setup');
		$data['text_yes'] = $this->language->get('text_yes');
		$data['text_no'] = $this->language->get('text_no');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['text_powered_by'] = $this->language->get('text_powered_by');
		$data['text_instructions_full'] = $this->language->get('text_instructions_full');
				
		// Help
		$data['help_setup'] = $this->language->get('help_setup');
		$data['help_full_setup'] = $this->language->get('help_full_setup');
		$data['help_custom_setup'] = $this->language->get('help_custom_setup');
								
		// Notification
		foreach ($this->error as $key => $error) {
			$data['error'][$key] = $error;
		}
		
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		
		// Breadcrumbs
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', $url_token, true)
		);

		if (VERSION >= '3.0.0.0') {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_modules'),
				'href' => $this->url->link('marketplace/extension', $url_token . '&type=module', true)
			);
		} elseif (VERSION >= '2.3.0.0') {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_modules'),
				'href' => $this->url->link('extension/extension', $url_token . '&type=module', true)
			);
		} else {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_modules'),
				'href' => $this->url->link('extension/module', $url_token, true)
			);
		}

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_seo_module'),
			'href' => $this->url->link('extension/module/d_seo_module', $url_token, true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_adviser'),
			'href' => $this->url->link($this->route, $url_token, true)
		);
								
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		if ($data['installed']) {
			$this->response->setOutput($this->load->view($this->route . '/instruction', $data));
		} else {
			// Setting
			$this->config->load($this->config_file);
			$config_feature_setting = ($this->config->get($this->codename . '_feature_setting')) ? $this->config->get($this->codename . '_feature_setting') : array();
		
			$data['features'] = array();
		
			foreach ($config_feature_setting as $feature) {
				if (substr($feature['name'], 0, strlen('text_')) == 'text_') {
					$feature['name'] = $this->language->get($feature['name']);
				}
						
				$data['features'][] = $feature;
			}
			
			$this->response->setOutput($this->load->view($this->route . '/install', $data));
		}
	}
			
	public function save() {
		$this->load->language($this->route);
		
		$this->load->model($this->route);
		$this->load->model('setting/setting');
				
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$old_setting = $this->model_setting_setting->getSetting('module_' . $this->codename);
			
			$new_setting = array_replace_recursive($old_setting, $this->request->post);
						
			if (isset($this->request->post['module_' . $this->codename . '_status']) && $this->request->post['module_' . $this->codename . '_status']) {
				$new_setting['module_' . $this->codename . '_setting']['control_element']['enable_status']['implemented'] = 1;
			}
						
			$this->model_setting_setting->editSetting('module_' . $this->codename, $new_setting);
			
			$save_data = array(
				'old_setting'		=> $old_setting,
				'new_setting'		=> $new_setting
			);			

			$installed_seo_adviser_extensions = $this->{'model_extension_module_' . $this->codename}->getInstalledSEOAdviserExtensions();
		
			foreach ($installed_seo_adviser_extensions as $installed_seo_adviser_extension) {
				$this->load->controller('extension/' . $this->codename . '/' . $installed_seo_adviser_extension . '/save', $save_data);
			}

			$data['success'] = $this->language->get('success_save');
		}
						
		$data['error'] = $this->error;
				
		$this->response->setOutput(json_encode($data));
	}
	
	public function setupExtension() {
		$this->load->model($this->route);
		
		$info = $this->load->controller('extension/d_seo_module/d_seo_module/control_setup_extension');
		
		$this->load->language($this->route);
		
		if (isset($info['error'])) {
			$this->error = array_replace_recursive($this->error, $info['error']);
		}
		
		if (!$this->error) {
			$data['success'] = $this->language->get('success_install');
		}
		
		$data['error'] = $this->error;

		$this->response->setOutput(json_encode($data));
	}
			
	public function installExtension() {
		$this->load->language($this->route);
		
		$this->load->model($this->route);
		$this->load->model('setting/setting');
		$this->load->model('user/user_group');
						
		if ($this->validateInstall()) {					
			if (file_exists(DIR_APPLICATION . 'model/extension/d_opencart_patch/extension.php') && file_exists(DIR_APPLICATION . 'model/extension/d_opencart_patch/user.php')) {
				$this->load->model('extension/d_opencart_patch/extension');			
				$this->load->model('extension/d_opencart_patch/user');
				
				$user_group_id = $this->model_extension_d_opencart_patch_user->getGroupId();
				
				// Install SEO Module Adviser
				if (!$this->model_extension_d_opencart_patch_extension->isInstalled('d_seo_module_adviser')) {
					$this->model_extension_d_opencart_patch_extension->install('module', 'd_seo_module_adviser');
				
					$this->model_user_user_group->addPermission($user_group_id, 'access', 'extension/module/d_seo_module_adviser');
					$this->model_user_user_group->addPermission($user_group_id, 'modify', 'extension/module/d_seo_module_adviser');
				}
				
				$setting = $this->model_setting_setting->getSetting('module_' . $this->codename);
										
				$setting['module_' . $this->codename . '_status'] = 1;
				$setting['module_' . $this->codename . '_setting']['control_element']['enable_status']['implemented'] = 1;
			
				$this->model_setting_setting->editSetting('module_' . $this->codename, $setting);
								
				// Install Toolbar
				if (file_exists(DIR_APPLICATION . 'controller/extension/module/d_toolbar.php')) {
					if (!$this->model_extension_d_opencart_patch_extension->isInstalled('d_toolbar')) {
						$this->model_extension_d_opencart_patch_extension->install('module', 'd_toolbar');
									
						$this->model_user_user_group->addPermission($user_group_id, 'access', 'extension/module/d_toolbar');
						$this->model_user_user_group->addPermission($user_group_id, 'modify', 'extension/module/d_toolbar');
					
						$this->load->controller('extension/module/d_toolbar/install');
					}
					
					$setting = $this->model_setting_setting->getSetting('module_d_toolbar');
					
					$setting['module_d_toolbar_status'] = 1;
					$setting['module_d_toolbar_setting']['widget']['seo_rating'] = array('status' => 1, 'sort_order' => 10); 
													
					$this->model_setting_setting->editSetting('module_d_toolbar', $setting);
				}
			}
			
			$data['success'] = $this->language->get('success_install');
		}
		
		$data['error'] = $this->error;
				
		$this->response->setOutput(json_encode($data));
	}
	
	public function uninstallExtension() {
		$this->load->language($this->route);
						
		if ($this->validateUninstall()) {			
			$data['success'] = $this->language->get('success_uninstall');
		}
						
		$data['error'] = $this->error;
				
		$this->response->setOutput(json_encode($data));
	}
	
	public function install() {
		if ($this->d_shopunity) {
			$this->load->model('extension/d_shopunity/mbooth');
			
			$this->model_extension_d_shopunity_mbooth->installDependencies($this->codename);
		}
	}
	
	/*
	*	Return Adviser Info.
	*/	
	public function getAdviserInfo($route) {			
		$this->load->model($this->route);
				
		$adviser_info['adviser_elements'] = array();
		$adviser_info['rating'] = array();
		
		if ($route) {				
			if ($this->config->get($this->codename . '_info_' . $route)) {
				$adviser_info = $this->config->get($this->codename . '_info_' . $route);
			} else {												
				$stores = $this->{'model_extension_module_' . $this->codename}->getStores();
				$languages = $this->{'model_extension_module_' . $this->codename}->getLanguages();
				$installed_seo_adviser_extensions = $this->{'model_extension_module_' . $this->codename}->getInstalledSEOAdviserExtensions();
				
				foreach ($installed_seo_adviser_extensions as $installed_seo_adviser_extension) {
					$adviser_elements = $this->load->controller('extension/' . $this->codename . '/' . $installed_seo_adviser_extension . '/adviser_elements', $route);
				
					foreach ($stores as $store) {
						foreach ($languages as $language) {
							if (!isset($adviser_info['adviser_elements'][$store['store_id']][$language['language_id']])) $adviser_info['adviser_elements'][$store['store_id']][$language['language_id']] = array();
					
							if (isset($adviser_elements[$store['store_id']][$language['language_id']])) {
								$adviser_info['adviser_elements'][$store['store_id']][$language['language_id']] = array_merge($adviser_info['adviser_elements'][$store['store_id']][$language['language_id']], $adviser_elements[$store['store_id']][$language['language_id']]);
							}
						}
					}
				}

				foreach ($stores as $store) {
					foreach ($languages as $language) {	
						if (isset($adviser_info['adviser_elements'][$store['store_id']][$language['language_id']])) {
							$adviser_info['adviser_elements'][$store['store_id']][$language['language_id']] = $this->{'model_extension_module_' . $this->codename}->sortArrayByColumn($adviser_info['adviser_elements'][$store['store_id']][$language['language_id']], 'rating');
				
							$total_rating = 0;
							$total_weight = 0;
			
							foreach ($adviser_info['adviser_elements'][$store['store_id']][$language['language_id']] as $adviser_element) {
								$total_rating += $adviser_element['rating'] * $adviser_element['weight'];
								$total_weight += $adviser_element['weight'];
							}
						
							if ($total_weight) {
								$adviser_info['rating'][$store['store_id']][$language['language_id']] = $total_rating / $total_weight;
							} else {
								$adviser_info['rating'][$store['store_id']][$language['language_id']] = 0;
							}
						}
					}
				}
			
				$this->config->set($this->codename . '_info_' . $route, $adviser_info);
			}
		}
				
		return $adviser_info;
	}
											
	/*
	*	Validator Functions.
	*/		 	
	private function validate($permission = 'modify') {				
		if (!$this->user->hasPermission($permission, $this->route)) {
			$this->error['warning'] = $this->language->get('error_permission');
			
			return false;
		}
		
		return true;
	}	
	
	private function validateInstall($permission = 'modify') {
		$this->load->model($this->route);
				
		$installed_seo_extensions = $this->{'model_extension_module_' . $this->codename}->getInstalledSEOExtensions();
		
		if (in_array($this->codename, $installed_seo_extensions)) {
			$this->error['warning'] = $this->language->get('error_installed');
			
			return false;
		}
		
		if (!in_array('d_seo_module', $installed_seo_extensions)) {
			$info = $this->load->controller('extension/d_seo_module/d_seo_module/control_install_extension');
			
			$this->load->language($this->route);
			
			if ($info) {		
				if ($info['error']) {
					$this->error = $info['error'];
				
					return false;
				} else {
					$installed_seo_extensions = $this->{'model_extension_module_' . $this->codename}->getInstalledSEOExtensions();
				} 
			} else {
				$this->error['warning'] = $this->language->get('error_dependence_d_seo_module');
				
				return false;
			}
		}
		
		$installed_seo_extensions[] = $this->codename;
		
		$this->{'model_extension_module_' . $this->codename}->saveSEOExtensions($installed_seo_extensions);
										
		return true;
	}
	
	private function validateUninstall($permission = 'modify') {
		$this->load->model($this->route);
								
		$installed_seo_extensions = $this->{'model_extension_module_' . $this->codename}->getInstalledSEOExtensions();
		
		$key = array_search($this->codename, $installed_seo_extensions);
		if ($key !== false) unset($installed_seo_extensions[$key]);
		
		$this->{'model_extension_module_' . $this->codename}->saveSEOExtensions($installed_seo_extensions);

		return true;
	}
}