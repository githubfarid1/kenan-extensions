<?php
class ControllerExtensionDSEOModuleMetaTitleDSEOModuleMetaTitle extends Controller {
	private $codename = 'd_seo_module_meta_title';
	private $route = 'extension/d_seo_module_meta_title/d_seo_module_meta_title';
	private $config_file = 'd_seo_module_meta_title';
	private $error = array();
	
	/*
	*	Functions for SEO Module Meta Title.
	*/	
	public function edit_meta_element($meta_element_data) {
		$this->load->model($this->route);
		
		return $this->{'model_extension_d_seo_module_meta_title_' . $this->codename}->editMetaElement($meta_element_data);
	}
	
	public function meta_elements() {	
		$this->load->model($this->route);
		
		return $this->{'model_extension_d_seo_module_meta_title_' . $this->codename}->getMetaElements();
	}
				
	public function store_meta_elements_links($store_meta_elements) {	
		$url_token = '';
		
		if (isset($this->session->data['token'])) {
			$url_token .= 'token=' . $this->session->data['token'];
		}
		
		if (isset($this->session->data['user_token'])) {
			$url_token .= 'user_token=' . $this->session->data['user_token'];
		}
		
		foreach ($store_meta_elements as $store_id => $meta_elements) {
			foreach ($meta_elements as $meta_element_key => $meta_element) {
				if (strpos($meta_element['route'], 'category_id') === 0) {
					$route_arr = explode("category_id=", $meta_element['route']);
				
					if (isset($route_arr[1])) {
						$category_id = $route_arr[1];
						$store_meta_elements[$store_id][$meta_element_key]['link'] = $this->url->link('catalog/category/edit', $url_token . '&category_id=' . $category_id, true);
					}
				} elseif (strpos($meta_element['route'], 'product_id') === 0) {
					$route_arr = explode("product_id=", $meta_element['route']);
				
					if (isset($route_arr[1])) {
						$product_id = $route_arr[1];
						$store_meta_elements[$store_id][$meta_element_key]['link'] = $this->url->link('catalog/product/edit', $url_token . '&product_id=' . $product_id, true);
					}
				} elseif (strpos($meta_element['route'], 'manufacturer_id') === 0) {
					$route_arr = explode("manufacturer_id=", $meta_element['route']);
				
					if (isset($route_arr[1])) {
						$manufacturer_id = $route_arr[1];
						$store_meta_elements[$store_id][$meta_element_key]['link'] = $this->url->link('catalog/manufacturer/edit', $url_token . '&manufacturer_id=' . $manufacturer_id, true);
					}
				} elseif (strpos($meta_element['route'], 'information_id') === 0) {
					$route_arr = explode("information_id=", $meta_element['route']);
				
					if (isset($route_arr[1])) {
						$information_id = $route_arr[1];
						$store_meta_elements[$store_id][$meta_element_key]['link'] = $this->url->link('catalog/information/edit', $url_token . '&information_id=' . $information_id, true);
					}
				}
			}
		}
		
		return $store_meta_elements;
	}
}
