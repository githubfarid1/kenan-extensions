<?php
class ControllerExtensionDToolbarDSEOModuleAdviser extends Controller {
	private $codename = 'd_seo_module_adviser';
	private $route = 'extension/d_toolbar/d_seo_module_adviser';
	private $config_file = 'd_seo_module_adviser';
	private $error = array(); 
		
	/*
	*	Functions for Toolbar.
	*/	
	public function toolbar_config() {	
		$_language = new Language();
		$_language->load($this->route);
				
		$this->config->load($this->config_file);
		$toolbar_setting = ($this->config->get($this->codename . '_toolbar_setting')) ? $this->config->get($this->codename . '_toolbar_setting') : array();
		
		foreach ($toolbar_setting['widget'] as $widget) {
			if (substr($widget['name'], 0, strlen('text_')) == 'text_') {
				$toolbar_setting['widget'][$widget['code']]['name'] = $_language->get($widget['name']);
			}
		}
							
		return $toolbar_setting;
	}
}