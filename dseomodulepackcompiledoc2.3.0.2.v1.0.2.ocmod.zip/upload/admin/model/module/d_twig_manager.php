<?php
/*  DEPRECATED!!! DO NOT USE!!!
*   location: admin/model
*/
require_once(DIR_APPLICATION.'model/extension/module/d_twig_manager.php');
class ModelModuleDTwigManager extends ModelExtensionModuleDTwigManager
{   
    public function __construct($registry)
    {
        parent::__construct($registry);
    }
}