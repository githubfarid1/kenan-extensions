<?php
class ModelExtensionDashboardDSEOModuleMetaTitle extends Model {
	private $codename = 'd_seo_module_meta_title';
	
	/*
	*	Return Store Duplicate Meta Elements.
	*/
	public function getStoreDuplicateMetaElements($meta_elements) {				
		$routes = array();
		
		foreach ($meta_elements as $meta_element) {
			foreach($meta_element['meta_title'] as $store_id => $language_meta_title) {
				foreach($language_meta_title as $meta_title) {
					if ($meta_title) {
						$routes[$store_id][$meta_title][] = $meta_element['route'];
					}
				}
			}
		}
		
		$store_duplicate_meta_elements = array();
		
		foreach ($meta_elements as $meta_element) {
			foreach($meta_element['meta_title'] as $store_id => $language_meta_title) {
				foreach($language_meta_title as $language_id => $meta_title) {
					if (isset($routes[$store_id][$meta_title]) && (count($routes[$store_id][$meta_title]) > 1) && (reset($routes[$store_id][$meta_title]) != end($routes[$store_id][$meta_title]))) {
						if (!isset($store_duplicate_meta_elements[$store_id][$meta_element['route']])) {
							$store_duplicate_meta_elements[$store_id][$meta_element['route']] = $meta_element;						
						}
						
						$store_duplicate_meta_elements[$store_id][$meta_element['route']]['meta_title_duplicate'][$store_id][$language_id] = 1;
					}
				}
			}
		}
		
		foreach ($meta_elements as $meta_element) {
			foreach($meta_element['meta_title'] as $store_id => $language_meta_title) {
				foreach($language_meta_title as $language_id => $meta_title) {
					if (isset($routes[$store_id][$meta_title]) && (count($routes[$store_id][$meta_title]) > 1) && (reset($routes[$store_id][$meta_title]) == end($routes[$store_id][$meta_title]))) {
						if (!isset($store_duplicate_meta_elements[$store_id][$meta_element['route']])) {
							$store_duplicate_meta_elements[$store_id][$meta_element['route']] = $meta_element;						
						}
						
						$store_duplicate_meta_elements[$store_id][$meta_element['route']]['meta_title_duplicate'][$store_id][$language_id] = 1;
					}
				}
			}
		}
			
		return $store_duplicate_meta_elements;
	}
	
	/*
	*	Return Store Empty Meta Elements.
	*/
	public function getStoreEmptyMetaElements($meta_elements) {				
		$stores = $this->getStores();
		$languages = $this->getLanguages();
				
		$store_empty_meta_elements = array();
		
		foreach ($meta_elements as $meta_element) {
			foreach ($stores as $store) {
				foreach ($languages as $language) {
					if (!isset($meta_element['meta_title'][$store['store_id']][$language['language_id']]) || (isset($meta_element['meta_title'][$store['store_id']][$language['language_id']]) && !$meta_element['meta_title'][$store['store_id']][$language['language_id']])) {
						if (!isset($store_empty_meta_elements[$store['store_id']][$meta_element['route']])) {
							$store_empty_meta_elements[$store['store_id']][$meta_element['route']] = $meta_element;
						}
					}
				}
			}
		}
		
		return $store_empty_meta_elements;
	}
	
	/*
	*	Return list of installed SEO Meta Title extensions.
	*/
	public function getInstalledSEOMetaTitleExtensions() {
		$this->load->model('setting/setting');
				
		$installed_extensions = array();
		
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "extension ORDER BY code");
		
		foreach ($query->rows as $result) {
			$installed_extensions[] = $result['code'];
		}
				
		$installed_seo_meta_title_extensions = array();
		
		$files = glob(DIR_APPLICATION . 'controller/extension/' . $this->codename . '/*.php');
		
		if ($files) {
			foreach ($files as $file) {
				$installed_seo_meta_title_extension = basename($file, '.php');
				
				if (in_array($installed_seo_meta_title_extension, $installed_extensions)) {
					$installed_seo_meta_title_extensions[] = $installed_seo_meta_title_extension;
				}
			}
		}
		
		return $installed_seo_meta_title_extensions;
	}
		
	/*
	*	Return list of languages.
	*/
	public function getLanguages() {
		$this->load->model('localisation/language');
		
		$languages = $this->model_localisation_language->getLanguages();
		
		foreach ($languages as $key => $language) {
            if (VERSION >= '2.2.0.0') {
                $languages[$key]['flag'] = 'language/' . $language['code'] . '/' . $language['code'] . '.png';
            } else {
                $languages[$key]['flag'] = 'view/image/flags/' . $language['image'];
            }
        }
				
		return $languages;
	}
	
	/*
	*	Return list of stores.
	*/
	public function getStores() {
		$this->load->model('setting/store');
		
		$result = array();
		
		$result[] = array(
			'store_id' => 0, 
			'name' => $this->config->get('config_name')
		);
		
		$stores = $this->model_setting_store->getStores();
		
		if ($stores) {			
			foreach ($stores as $store) {
				$result[] = array(
					'store_id' => $store['store_id'],
					'name' => $store['name']	
				);
			}	
		}
		
		return $result;
	}
}
?>