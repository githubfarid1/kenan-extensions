<?php
class ModelExtensionDSEOModuleMetaDSEOModuleMeta extends Model {
	private $codename = 'd_seo_module_meta';
	
	/*
	*	Generate Fields.
	*/
	public function generateFields($data) {				
		$this->load->model('extension/module/' . $this->codename);
		
		$store = $this->{'model_extension_module_' . $this->codename}->getStore($data['store_id']);
		$languages = $this->{'model_extension_module_' . $this->codename}->getLanguages();
								
		$field_info = $this->load->controller('extension/module/d_seo_module/getFieldInfo');
		
		$field_data = array(
			'field_code' => 'meta_data',
			'filter' => array(
				'route' => 'common/home',
				'store_id' => $data['store_id']
			)
		);
			
		$meta_data = $this->load->controller('extension/module/d_seo_module/getFieldElements', $field_data);
						
		if (file_exists(DIR_APPLICATION . 'model/extension/module/d_translit.php')) {
			$this->load->model('extension/module/d_translit');
			
			$translit_data = true;
		} else {
			$translit_data = false;
		}
										
		if (isset($data['sheet']['category']['field'])) {															
			$field = array();
			$implode = array();
						
			if (isset($data['sheet']['category']['field']['meta_title']) && isset($field_info['sheet']['category']['field']['meta_title']['multi_store']) && isset($field_info['sheet']['category']['field']['meta_title']['multi_store_status'])) {
				$field = $data['sheet']['category']['field']['meta_title'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['category']['field']['meta_title']['multi_store'] && $field_info['sheet']['category']['field']['meta_title']['multi_store_status']) ? "md2.meta_title" : "cd.meta_title";
			}
			
			if (isset($data['sheet']['category']['field']['meta_description']) && isset($field_info['sheet']['category']['field']['meta_description']['multi_store']) && isset($field_info['sheet']['category']['field']['meta_description']['multi_store_status'])) {
				$field = $data['sheet']['category']['field']['meta_description'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['category']['field']['meta_description']['multi_store'] && $field_info['sheet']['category']['field']['meta_description']['multi_store_status']) ? "md2.meta_description" : "cd.meta_description";
			}
			
			if (isset($data['sheet']['category']['field']['meta_keyword']) && isset($field_info['sheet']['category']['field']['meta_keyword']['multi_store']) && isset($field_info['sheet']['category']['field']['meta_keyword']['multi_store_status'])) {
				$field = $data['sheet']['category']['field']['meta_keyword'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['category']['field']['meta_keyword']['multi_store'] && $field_info['sheet']['category']['field']['meta_keyword']['multi_store_status']) ? "md2.meta_keyword" : "cd.meta_keyword";
			}
			
			if (isset($data['sheet']['category']['field']['custom_title_1']) && isset($field_info['sheet']['category']['field']['custom_title_1']['multi_store']) && isset($field_info['sheet']['category']['field']['custom_title_1']['multi_store_status'])) {
				$field = $data['sheet']['category']['field']['custom_title_1'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['category']['field']['custom_title_1']['multi_store'] && $field_info['sheet']['category']['field']['custom_title_1']['multi_store_status']) ? "md2.custom_title_1" : "md.custom_title_1";
			}
			
			if (isset($data['sheet']['category']['field']['custom_title_2']) && isset($field_info['sheet']['category']['field']['custom_title_2']['multi_store']) && isset($field_info['sheet']['category']['field']['custom_title_2']['multi_store_status'])) {
				$field = $data['sheet']['category']['field']['custom_title_2'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['category']['field']['custom_title_2']['multi_store'] && $field_info['sheet']['category']['field']['custom_title_2']['multi_store_status']) ? "md2.custom_title_2" : "md.custom_title_2";
			}
			
			if (isset($data['sheet']['category']['field']['custom_image_name'])) {
				$field = $data['sheet']['category']['field']['custom_image_name'];
				$implode[] = "c.image";
			}
			
			if (isset($data['sheet']['category']['field']['custom_image_title']) && isset($field_info['sheet']['category']['field']['custom_image_title']['multi_store']) && isset($field_info['sheet']['category']['field']['custom_image_title']['multi_store_status'])) {
				$field = $data['sheet']['category']['field']['custom_image_title'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['category']['field']['custom_image_title']['multi_store'] && $field_info['sheet']['category']['field']['custom_image_title']['multi_store_status']) ? "md2.custom_image_title" : "md.custom_image_title";
			}
			
			if (isset($data['sheet']['category']['field']['custom_image_alt']) && isset($field_info['sheet']['category']['field']['custom_image_alt']['multi_store']) && isset($field_info['sheet']['category']['field']['custom_image_alt']['multi_store_status'])) {
				$field = $data['sheet']['category']['field']['custom_image_alt'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['category']['field']['custom_image_alt']['multi_store'] && $field_info['sheet']['category']['field']['custom_image_alt']['multi_store_status']) ? "md2.custom_image_alt" : "md.custom_image_alt";
			}
			
			if (isset($field_info['sheet']['category']['field']['name']['multi_store']) && isset($field_info['sheet']['category']['field']['name']['multi_store_status'])) {
				$implode[] = ($data['store_id'] && $field_info['sheet']['category']['field']['name']['multi_store'] && $field_info['sheet']['category']['field']['name']['multi_store_status']) ? "md2.name" : "cd.name";
				$implode[] = ($data['store_id'] && $field_info['sheet']['category']['field']['name']['multi_store'] && $field_info['sheet']['category']['field']['name']['multi_store_status']) ? "md3.name as parent_name" : "cd2.name as parent_name";
			}
			
			if (isset($field_info['sheet']['category']['field']['description']['multi_store']) && isset($field_info['sheet']['category']['field']['description']['multi_store_status'])) {
				$implode[] = ($data['store_id'] && $field_info['sheet']['category']['field']['description']['multi_store'] && $field_info['sheet']['category']['field']['description']['multi_store_status']) ? "md2.description" : "cd.description";
			}
			
			if (isset($field_info['sheet']['product']['field']['name']['multi_store']) && isset($field_info['sheet']['product']['field']['name']['multi_store_status'])) {
				$implode[] = ($data['store_id'] && $field_info['sheet']['product']['field']['name']['multi_store'] && $field_info['sheet']['product']['field']['name']['multi_store']['name']['multi_store_status']) ? "GROUP_CONCAT(DISTINCT md4.name ORDER BY pc.product_id SEPARATOR '|') as product_sample" : "GROUP_CONCAT(DISTINCT pd.name ORDER BY pc.product_id SEPARATOR '|') as product_sample";
			}
			
			$implode[] = "COUNT(DISTINCT pc.product_id) as product_total";

			$categories = array();
						
			if ($field) {				
				$field_template = isset($field['template']) ? $field['template'] : '';
				$field_overwrite = isset($field['overwrite']) ? $field['overwrite'] : 1;
				
				if ($translit_data) {
					$translit_data = array(
						'translit_symbol_status' => isset($field['translit_symbol_status']) ? $field['translit_symbol_status'] : 1,
						'translit_language_symbol_status' => isset($field['translit_language_symbol_status']) ? $field['translit_language_symbol_status'] : 1,
						'transform_language_symbol_id' => isset($field['transform_language_symbol_id']) ? $field['transform_language_symbol_id'] : 0
					);
				}
				
				$field_data = array(
					'field_code' => 'target_keyword',
					'filter' => array('store_id' => $data['store_id'])
				);
			
				$target_keywords = $this->load->controller('extension/module/d_seo_module/getFieldElements', $field_data);
																
				$query = $this->db->query("SELECT cd.category_id, cd.language_id, " . implode(', ', $implode) . " FROM " . DB_PREFIX . "category c LEFT JOIN " . DB_PREFIX . "category_description cd ON (cd.category_id = c.category_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md ON (md.route = CONCAT('category_id=', c.category_id) AND md.store_id = '0' AND md.language_id = cd.language_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md2 ON (md2.route = CONCAT('category_id=', c.category_id) AND md2.store_id = '" . (int)$data['store_id'] . "' AND md2.language_id = cd.language_id) LEFT JOIN " . DB_PREFIX . "category_description cd2 ON (cd2.category_id = c.parent_id AND cd2.language_id = cd.language_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md3 ON (md3.route = CONCAT('category_id=', c.parent_id) AND md3.store_id = '" . (int)$data['store_id'] . "' AND md3.language_id = cd.language_id) LEFT JOIN " . DB_PREFIX . "product_to_category pc ON (pc.category_id = cd.category_id) LEFT JOIN " . DB_PREFIX . "product_description pd ON (pd.product_id = pc.product_id AND pd.language_id = cd.language_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md4 ON (md4.route = CONCAT('product_id=', pc.product_id) AND md4.store_id = '" . (int)$data['store_id'] . "' AND md4.language_id = cd.language_id) GROUP BY c.category_id, cd.language_id");
						
				foreach ($query->rows as $result) {
					$categories[$result['category_id']]['category_id'] = $result['category_id'];
				
					foreach ($result as $field => $value) {
						if (($field != 'category_id') && ($field != 'language_id')) {
							$categories[$result['category_id']][$field][$result['language_id']] = $value;
						}
					}
				}
			}
							
			foreach ($categories as $category) {
				foreach ($languages as $language) {
					if (isset($target_keywords['category_id=' . $category['category_id']][$data['store_id']][$language['language_id']])) {
						$target_keyword = $target_keywords['category_id=' . $category['category_id']][$data['store_id']][$language['language_id']];
					} else {
						$target_keyword = array();
					}
					
					if (isset($meta_data['common/home'][$data['store_id']][$language['language_id']]['meta_title'])) {
						$store_title = $meta_data['common/home'][$data['store_id']][$language['language_id']]['meta_title'];
					} else {
						$store_title = '';
					}
					
					if (is_array($field_template)) {
						$field_new = $field_template[$language['language_id']]; 
					} else {
						$field_new = $field_template; 
					}
					
					$field_new = strtr($field_new, array(
						'[name]' => $category['name'][$language['language_id']], 
						'[parent_name]' => $category['parent_name'][$language['language_id']], 
						'[total_products]' => $category['product_total'][$language['language_id']],
						'[store_name]' => $store['name'],
						'[store_title]' => $store_title
					));
					$field_new = $this->replaceDescription($field_new, $category['description'][$language['language_id']]);
					$field_new = $this->replaceSampleProducts($field_new, $category['product_sample'][$language['language_id']]);
					$field_new = $this->replaceTargetKeyword($field_new, $target_keyword);
					
					if ($translit_data) {
						$field_new = $this->model_extension_module_d_translit->translit($field_new, $translit_data);
					}
										
					if (isset($data['sheet']['category']['field']['custom_image_name']) && isset($category['image'][$language['language_id']]) && ($category['image'][$language['language_id']]) && file_exists(DIR_IMAGE . $category['image'][$language['language_id']]) && ($language == reset($languages))) {
						$file_info = pathinfo(DIR_IMAGE . $category['image'][$language['language_id']]);
						
						if (($field_new != $file_info['filename']) && ($field_overwrite)) {
							rename(DIR_IMAGE . $category['image'][$language['language_id']], $file_info['dirname'] . '/' . $this->db->escape($field_new) . '.' . $file_info['extension']);
							
							$this->db->query("UPDATE " . DB_PREFIX . "category SET image = '" . str_replace(DIR_IMAGE, '', $file_info['dirname']) . '/' . $this->db->escape($field_new) . '.' . $file_info['extension'] . "' WHERE category_id = '" . (int)$category['category_id'] . "'");
						}
					}
																									
					if (isset($data['sheet']['category']['field']['meta_title']) && isset($category['meta_title'][$language['language_id']]) && isset($field_info['sheet']['category']['field']['meta_title']['multi_store']) && isset($field_info['sheet']['category']['field']['meta_title']['multi_store_status'])) {
						if (($field_new != $category['meta_title'][$language['language_id']]) && ($field_overwrite || !$category['meta_title'][$language['language_id']])) {
							if ($data['store_id'] && $field_info['sheet']['category']['field']['meta_title']['multi_store'] && $field_info['sheet']['category']['field']['meta_title']['multi_store_status']) {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET meta_title = '" . $this->db->escape($field_new) . "' WHERE route='category_id=" . (int)$category['category_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='category_id=" . (int)$category['category_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', meta_title = '" . $this->db->escape($field_new) . "'");
								}
							} else {
								$this->db->query("UPDATE " . DB_PREFIX . "category_description SET meta_title = '" . $this->db->escape($field_new) . "' WHERE category_id = '" . (int)$category['category_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
							}
						}
					}
					
					if (isset($data['sheet']['category']['field']['meta_description']) && isset($category['meta_description'][$language['language_id']]) && isset($field_info['sheet']['category']['field']['meta_description']['multi_store']) && isset($field_info['sheet']['category']['field']['meta_description']['multi_store_status'])) {
						if (($field_new != $category['meta_description'][$language['language_id']]) && ($field_overwrite || !$category['meta_description'][$language['language_id']])) {
							if ($data['store_id'] && $field_info['sheet']['category']['field']['meta_description']['multi_store'] && $field_info['sheet']['category']['field']['meta_description']['multi_store_status']) {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET meta_description = '" . $this->db->escape($field_new) . "' WHERE route='category_id=" . (int)$category['category_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='category_id=" . (int)$category['category_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', meta_description = '" . $this->db->escape($field_new) . "'");
								}
							} else {
								$this->db->query("UPDATE " . DB_PREFIX . "category_description SET meta_description = '" . $this->db->escape($field_new) . "' WHERE category_id = '" . (int)$category['category_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
							}
						}
					}
					
					if (isset($data['sheet']['category']['field']['meta_keyword']) && isset($category['meta_keyword'][$language['language_id']]) && isset($field_info['sheet']['category']['field']['meta_keyword']['multi_store']) && isset($field_info['sheet']['category']['field']['meta_keyword']['multi_store_status'])) {
						if (($field_new != $category['meta_keyword'][$language['language_id']]) && ($field_overwrite || !$category['meta_keyword'][$language['language_id']])) {
							if ($data['store_id'] && $field_info['sheet']['category']['field']['meta_keyword']['multi_store'] && $field_info['sheet']['category']['field']['meta_keyword']['multi_store_status']) {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET meta_keyword = '" . $this->db->escape($field_new) . "' WHERE route='category_id=" . (int)$category['category_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='category_id=" . (int)$category['category_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', meta_keyword = '" . $this->db->escape($field_new) . "'");
								}
							} else {
								$this->db->query("UPDATE " . DB_PREFIX . "category_description SET meta_keyword = '" . $this->db->escape($field_new) . "' WHERE category_id = '" . (int)$category['category_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
							}
						}
					}
					
					if (isset($data['sheet']['category']['field']['custom_title_1']) && isset($category['custom_title_1'][$language['language_id']]) && isset($field_info['sheet']['category']['field']['custom_title_1']['multi_store']) && isset($field_info['sheet']['category']['field']['custom_title_1']['multi_store_status'])) {
						if (($field_new != $category['custom_title_1'][$language['language_id']]) && ($field_overwrite || !$category['custom_title_1'][$language['language_id']])) {
							if ($data['store_id'] && $field_info['sheet']['category']['field']['custom_title_1']['multi_store'] && $field_info['sheet']['category']['field']['custom_title_1']['multi_store_status']) {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_1 = '" . $this->db->escape($field_new) . "' WHERE route='category_id=" . (int)$category['category_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='category_id=" . (int)$category['category_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', custom_title_1 = '" . $this->db->escape($field_new) . "'");
								}
							} else {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_1 = '" . $this->db->escape($field_new) . "' WHERE route='category_id=" . (int)$category['category_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='category_id=" . (int)$category['category_id'] . "', store_id = '0', language_id = '" . (int)$language['language_id'] . "', custom_title_1 = '" . $this->db->escape($field_new) . "'");
								}
							}
						}
					}
					
					if (isset($data['sheet']['category']['field']['custom_title_2']) && isset($category['custom_title_2'][$language['language_id']]) && isset($field_info['sheet']['category']['field']['custom_title_2']['multi_store']) && isset($field_info['sheet']['category']['field']['custom_title_2']['multi_store_status'])) {
						if (($field_new != $category['custom_title_2'][$language['language_id']]) && ($field_overwrite || !$category['custom_title_2'][$language['language_id']])) {
							if ($data['store_id'] && $field_info['sheet']['category']['field']['custom_title_2']['multi_store'] && $field_info['sheet']['category']['field']['custom_title_2']['multi_store_status']) {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_2 = '" . $this->db->escape($field_new) . "' WHERE route='category_id=" . (int)$category['category_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='category_id=" . (int)$category['category_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', custom_title_2 = '" . $this->db->escape($field_new) . "'");
								}
							} else {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_2 = '" . $this->db->escape($field_new) . "' WHERE route='category_id=" . (int)$category['category_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='category_id=" . (int)$category['category_id'] . "', store_id = '0', language_id = '" . (int)$language['language_id'] . "', custom_title_2 = '" . $this->db->escape($field_new) . "'");
								}
							}
						}
					}
					
					if (isset($data['sheet']['category']['field']['custom_image_title']) && isset($category['custom_image_title'][$language['language_id']]) && isset($field_info['sheet']['category']['field']['custom_image_title']['multi_store']) && isset($field_info['sheet']['category']['field']['custom_image_title']['multi_store_status'])) {
						if (($field_new != $category['custom_image_title'][$language['language_id']]) && ($field_overwrite || !$category['custom_image_title'][$language['language_id']])) {
							if ($data['store_id'] && $field_info['sheet']['category']['field']['custom_image_title']['multi_store'] && $field_info['sheet']['category']['field']['custom_image_title']['multi_store_status']) {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_image_title = '" . $this->db->escape($field_new) . "' WHERE route='category_id=" . (int)$category['category_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='category_id=" . (int)$category['category_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', custom_image_title = '" . $this->db->escape($field_new) . "'");
								}
							} else {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_image_title = '" . $this->db->escape($field_new) . "' WHERE route='category_id=" . (int)$category['category_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='category_id=" . (int)$category['category_id'] . "', store_id = '0', language_id = '" . (int)$language['language_id'] . "', custom_image_title = '" . $this->db->escape($field_new) . "'");
								}
							}
						}
					}
					
					if (isset($data['sheet']['category']['field']['custom_image_alt']) && isset($category['custom_image_alt'][$language['language_id']]) && isset($field_info['sheet']['category']['field']['custom_image_alt']['multi_store']) && isset($field_info['sheet']['category']['field']['custom_image_alt']['multi_store_status'])) {
						if (($field_new != $category['custom_image_alt'][$language['language_id']]) && ($field_overwrite || !$category['custom_image_alt'][$language['language_id']])) {
							if ($data['store_id'] && $field_info['sheet']['category']['field']['custom_image_alt']['multi_store'] && $field_info['sheet']['category']['field']['custom_image_alt']['multi_store_status']) {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_image_alt = '" . $this->db->escape($field_new) . "' WHERE route='category_id=" . (int)$category['category_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='category_id=" . (int)$category['category_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', custom_image_alt = '" . $this->db->escape($field_new) . "'");
								}
							} else {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_image_alt = '" . $this->db->escape($field_new) . "' WHERE route='category_id=" . (int)$category['category_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='category_id=" . (int)$category['category_id'] . "', store_id = '0', language_id = '" . (int)$language['language_id'] . "', custom_image_alt = '" . $this->db->escape($field_new) . "'");
								}
							}
						}
					}
				}		
			}
		}
		
		if (isset($data['sheet']['product']['field'])) {
			$field = array();
			$implode = array();
			
			if (isset($data['sheet']['product']['field']['meta_title']) && isset($field_info['sheet']['product']['field']['meta_title']['multi_store']) && isset($field_info['sheet']['product']['field']['meta_title']['multi_store_status'])) {
				$field = $data['sheet']['product']['field']['meta_title'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['product']['field']['meta_title']['multi_store'] && $field_info['sheet']['product']['field']['meta_title']['multi_store_status']) ? "md2.meta_title" : "pd.meta_title";
			}
			
			if (isset($data['sheet']['product']['field']['meta_description']) && isset($field_info['sheet']['product']['field']['meta_description']['multi_store']) && isset($field_info['sheet']['product']['field']['meta_description']['multi_store_status'])) {
				$field = $data['sheet']['product']['field']['meta_description'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['product']['field']['meta_description']['multi_store'] && $field_info['sheet']['product']['field']['meta_description']['multi_store_status']) ? "md2.meta_description" : "pd.meta_description";
			}
			
			if (isset($data['sheet']['product']['field']['meta_keyword']) && isset($field_info['sheet']['product']['field']['meta_keyword']['multi_store']) && isset($field_info['sheet']['product']['field']['meta_keyword']['multi_store_status'])) {
				$field = $data['sheet']['product']['field']['meta_keyword'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['product']['field']['meta_keyword']['multi_store'] && $field_info['sheet']['product']['field']['meta_keyword']['multi_store_status']) ? "md2.meta_keyword" : "pd.meta_keyword";
			}
			
			if (isset($data['sheet']['product']['field']['tag']) && isset($field_info['sheet']['product']['field']['tag']['multi_store']) && isset($field_info['sheet']['product']['field']['tag']['multi_store_status'])) {
				$field = $data['sheet']['product']['field']['tag'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['product']['field']['tag']['multi_store'] && $field_info['sheet']['product']['field']['tag']['multi_store_status']) ? "md2.tag" : "pd.tag";
			}
			
			if (isset($data['sheet']['product']['field']['custom_title_1']) && isset($field_info['sheet']['product']['field']['custom_title_1']['multi_store']) && isset($field_info['sheet']['product']['field']['custom_title_1']['multi_store_status'])) {
				$field = $data['sheet']['product']['field']['custom_title_1'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['product']['field']['custom_title_1']['multi_store'] && $field_info['sheet']['product']['field']['custom_title_1']['multi_store_status']) ? "md2.custom_title_1" : "md.custom_title_1";
			}
			
			if (isset($data['sheet']['product']['field']['custom_title_2']) && isset($field_info['sheet']['product']['field']['custom_title_2']['multi_store']) && isset($field_info['sheet']['product']['field']['custom_title_2']['multi_store_status'])) {
				$field = $data['sheet']['product']['field']['custom_title_2'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['product']['field']['custom_title_2']['multi_store'] && $field_info['sheet']['product']['field']['custom_title_2']['multi_store_status']) ? "md2.custom_title_2" : "md.custom_title_2";
			}
			
			if (isset($data['sheet']['product']['field']['custom_image_name'])) {
				$field = $data['sheet']['product']['field']['custom_image_name'];
				$implode[] = "p.image";
			}
			
			if (isset($data['sheet']['product']['field']['custom_image_title']) && isset($field_info['sheet']['product']['field']['custom_image_title']['multi_store']) && isset($field_info['sheet']['product']['field']['custom_image_title']['multi_store_status'])) {
				$field = $data['sheet']['product']['field']['custom_image_title'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['product']['field']['custom_image_title']['multi_store'] && $field_info['sheet']['product']['field']['custom_image_title']['multi_store_status']) ? "md2.custom_image_title" : "md.custom_image_title";
			}
			
			if (isset($data['sheet']['product']['field']['custom_image_alt']) && isset($field_info['sheet']['product']['field']['custom_image_alt']['multi_store']) && isset($field_info['sheet']['product']['field']['custom_image_alt']['multi_store_status'])) {
				$field = $data['sheet']['product']['field']['custom_image_alt'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['product']['field']['custom_image_alt']['multi_store'] && $field_info['sheet']['product']['field']['custom_image_alt']['multi_store_status']) ? "md2.custom_image_alt" : "md.custom_image_alt";
			}
			
			if (isset($field_info['sheet']['product']['field']['name']['multi_store']) && isset($field_info['sheet']['product']['field']['name']['multi_store_status'])) {
				$implode[] = ($data['store_id'] && $field_info['sheet']['product']['field']['name']['multi_store'] && $field_info['sheet']['product']['field']['name']['multi_store_status']) ? "md2.name" : "pd.name";
			}
			
			if (isset($field_info['sheet']['product']['field']['description']['multi_store']) && isset($field_info['sheet']['product']['field']['description']['multi_store_status'])) {
				$implode[] = ($data['store_id'] && $field_info['sheet']['product']['field']['description']['multi_store'] && $field_info['sheet']['product']['field']['description']['multi_store_status']) ? "md2.description" : "pd.description";
			}
			
			if (isset($field_info['sheet']['category']['field']['name']['multi_store']) && isset($field_info['sheet']['category']['field']['name']['multi_store_status'])) {
				$implode[] = ($data['store_id'] && $field_info['sheet']['category']['field']['name']['multi_store'] && $field_info['sheet']['category']['field']['name']['multi_store_status']) ? "md3.name as category_name" : "cd.name as category_name";
			}
			
			if (isset($field_info['sheet']['manufacturer']['field']['name']['multi_store']) && isset($field_info['sheet']['manufacturer']['field']['name']['multi_store_status'])) {
				$implode[] = ($data['store_id'] && $field_info['sheet']['manufacturer']['field']['name']['multi_store'] && $field_info['sheet']['manufacturer']['field']['name']['multi_store_status']) ? "md5.name as manufacturer_name" : "md4.name as manufacturer_name";
			}
						
			$implode[] = "p.model";
			$implode[] = "p.sku";
			$implode[] = "p.upc";

			$products = array();			
			
			if ($field) {
				$field_template = isset($field['template']) ? $field['template'] : '';
				$field_overwrite = isset($field['overwrite']) ? $field['overwrite'] : 1;
				
				if ($translit_data) {
					$translit_data = array(
						'translit_symbol_status' => isset($field['translit_symbol_status']) ? $field['translit_symbol_status'] : 1,
						'translit_language_symbol_status' => isset($field['translit_language_symbol_status']) ? $field['translit_language_symbol_status'] : 1,
						'transform_language_symbol_id' => isset($field['transform_language_symbol_id']) ? $field['transform_language_symbol_id'] : 0
					);
				}
				
				$field_data = array(
					'field_code' => 'target_keyword',
					'filter' => array('store_id' => $data['store_id'])
				);
			
				$target_keywords = $this->load->controller('extension/module/d_seo_module/getFieldElements', $field_data);
							
				$query = $this->db->query("SELECT pd.product_id, pd.language_id, " . implode(', ', $implode) . " FROM " . DB_PREFIX . "product p LEFT JOIN " . DB_PREFIX . "product_description pd ON (pd.product_id = p.product_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md ON (md.route = CONCAT('product_id=', p.product_id) AND md.store_id = '0' AND md.language_id = pd.language_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md2 ON (md2.route = CONCAT('product_id=', p.product_id) AND md2.store_id = '" . (int)$data['store_id'] . "' AND md2.language_id = pd.language_id) LEFT JOIN " . DB_PREFIX . "product_to_category pc ON (pc.product_id = pd.product_id) LEFT JOIN " . DB_PREFIX . "category_description cd ON (cd.category_id = pc.category_id AND cd.language_id = pd.language_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md3 ON (md3.route = CONCAT('category_id=', pc.category_id) AND md3.store_id = '" . (int)$data['store_id'] . "' AND md3.language_id = pd.language_id) LEFT JOIN " . DB_PREFIX . "manufacturer m ON (m.manufacturer_id = p.manufacturer_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md4 ON (md4.route = CONCAT('manufacturer_id=', m.manufacturer_id) AND md4.store_id = '0' AND md4.language_id = pd.language_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md5 ON (md5.route = CONCAT('manufacturer_id=', m.manufacturer_id) AND md5.store_id = '" . (int)$data['store_id'] . "' AND md5.language_id = pd.language_id ) GROUP BY p.product_id, pd.language_id");
				
				foreach ($query->rows as $result) {
					$products[$result['product_id']]['product_id'] = $result['product_id'];
				
					foreach ($result as $field => $value) {
						if (($field != 'product_id') && ($field != 'language_id')) {
							$products[$result['product_id']][$field][$result['language_id']] = $value;
						}
					}
				}
			}

			foreach ($products as $product) {
				foreach ($languages as $language) {					
					if (isset($target_keywords['product_id=' . $product['product_id']][$data['store_id']][$language['language_id']])) {
						$target_keyword = $target_keywords['product_id=' . $product['product_id']][$data['store_id']][$language['language_id']];
					} else {
						$target_keyword = array();
					}
					
					if (isset($store['title'][$language['language_id']])) {
						$store_title = $store['title'][$language['language_id']];
					} else {
						$store_title = '';
					}
					
					if (is_array($field_template)) {
						$field_new = $field_template[$language['language_id']]; 
					} else {
						$field_new = $field_template; 
					}
										
					$field_new = strtr($field_new, array(
						'[name]' => $product['name'][$language['language_id']], 
						'[category]' => $product['category_name'][$language['language_id']], 
						'[model]' => $product['model'][$language['language_id']],
						'[sku]' => $product['sku'][$language['language_id']],
						'[upc]' => $product['upc'][$language['language_id']],
						'[manufacturer]' => $product['manufacturer_name'][$language['language_id']],
						'[store_name]' => $store['name'],
						'[store_title]' => $store_title
					));
					$field_new = $this->replaceDescription($field_new, $product['description'][$language['language_id']]);
					$field_new = $this->replaceTargetKeyword($field_new, $target_keyword);
					
					if ($translit_data) {
						$field_new = $this->model_extension_module_d_translit->translit($field_new, $translit_data);
					}
																																			
					if (isset($data['sheet']['product']['field']['custom_image_name']) && isset($product['image'][$language['language_id']]) && ($product['image'][$language['language_id']]) && file_exists(DIR_IMAGE . $product['image'][$language['language_id']]) && ($language == reset($languages))) {
						$file_info = pathinfo(DIR_IMAGE . $product['image'][$language['language_id']]);
						
						if (($field_new != $file_info['filename']) && ($field_overwrite)) {
							rename(DIR_IMAGE . $product['image'][$language['language_id']], $file_info['dirname'] . '/' . $this->db->escape($field_new) . '.' . $file_info['extension']);
							
							$this->db->query("UPDATE " . DB_PREFIX . "product SET image = '" . str_replace(DIR_IMAGE, '', $file_info['dirname']) . '/' . $this->db->escape($field_new) . '.' . $file_info['extension'] . "' WHERE product_id = '" . (int)$product['product_id'] . "'");
						}
					}
					
					if (isset($data['sheet']['product']['field']['meta_title']) && isset($product['meta_title'][$language['language_id']]) && isset($field_info['sheet']['product']['field']['meta_title']['multi_store']) && isset($field_info['sheet']['product']['field']['meta_title']['multi_store_status'])) {
						if (($field_new != $product['meta_title'][$language['language_id']]) && ($field_overwrite || !$product['meta_title'][$language['language_id']])) {
							if ($data['store_id'] && $field_info['sheet']['product']['field']['meta_title']['multi_store'] && $field_info['sheet']['product']['field']['meta_title']['multi_store_status']) {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET meta_title = '" . $this->db->escape($field_new) . "' WHERE route='product_id=" . (int)$product['product_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='product_id=" . (int)$product['product_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', meta_title = '" . $this->db->escape($field_new) . "'");
								}
							} else {
								$this->db->query("UPDATE " . DB_PREFIX . "product_description SET meta_title = '" . $this->db->escape($field_new) . "' WHERE product_id = '" . (int)$product['product_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
							}
						}
					}					
										
					if (isset($data['sheet']['product']['field']['meta_description']) && isset($product['meta_description'][$language['language_id']]) && isset($field_info['sheet']['product']['field']['meta_description']['multi_store']) && isset($field_info['sheet']['product']['field']['meta_description']['multi_store_status'])) {
						if (($field_new != $product['meta_description'][$language['language_id']]) && ($field_overwrite || !$product['meta_description'][$language['language_id']])) {
							if ($data['store_id'] && $field_info['sheet']['product']['field']['meta_description']['multi_store'] && $field_info['sheet']['product']['field']['meta_description']['multi_store_status']) {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET meta_description = '" . $this->db->escape($field_new) . "' WHERE route='product_id=" . (int)$product['product_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='product_id=" . (int)$product['product_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', meta_description = '" . $this->db->escape($field_new) . "'");
								}
							} else {
								$this->db->query("UPDATE " . DB_PREFIX . "product_description SET meta_description = '" . $this->db->escape($field_new) . "' WHERE product_id = '" . (int)$product['product_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
							}
						}
					}
					
					if (isset($data['sheet']['product']['field']['meta_keyword']) && isset($product['meta_keyword'][$language['language_id']]) && isset($field_info['sheet']['product']['field']['meta_keyword']['multi_store']) && isset($field_info['sheet']['product']['field']['meta_keyword']['multi_store_status'])) {
						if (($field_new != $product['meta_keyword'][$language['language_id']]) && ($field_overwrite || !$product['meta_keyword'][$language['language_id']])) {
							if ($data['store_id'] && $field_info['sheet']['product']['field']['meta_keyword']['multi_store'] && $field_info['sheet']['product']['field']['meta_keyword']['multi_store_status']) {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET meta_keyword = '" . $this->db->escape($field_new) . "' WHERE route='product_id=" . (int)$product['product_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='product_id=" . (int)$product['product_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', meta_keyword = '" . $this->db->escape($field_new) . "'");
								}
							} else {
								$this->db->query("UPDATE " . DB_PREFIX . "product_description SET meta_keyword = '" . $this->db->escape($field_new) . "' WHERE product_id = '" . (int)$product['product_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
							}
						}
					}
					
					if (isset($data['sheet']['product']['field']['tag']) && isset($product['tag'][$language['language_id']]) && isset($field_info['sheet']['product']['field']['tag']['multi_store']) && isset($field_info['sheet']['product']['field']['tag']['multi_store_status'])) {
						if (($field_new != $product['tag'][$language['language_id']]) && ($field_overwrite || !$product['tag'][$language['language_id']])) {
							if ($data['store_id'] && $field_info['sheet']['product']['field']['tag']['multi_store'] && $field_info['sheet']['product']['field']['tag']['multi_store_status']) {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET tag = '" . $this->db->escape($field_new) . "' WHERE route='product_id=" . (int)$product['product_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='product_id=" . (int)$product['product_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', tag = '" . $this->db->escape($field_new) . "'");
								}
							} else {
								$this->db->query("UPDATE " . DB_PREFIX . "product_description SET tag = '" . $this->db->escape($field_new) . "' WHERE product_id = '" . (int)$product['product_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
							}
						}
					}
					
					if (isset($data['sheet']['product']['field']['custom_title_1']) && isset($product['custom_title_1'][$language['language_id']]) && isset($field_info['sheet']['product']['field']['custom_title_1']['multi_store']) && isset($field_info['sheet']['product']['field']['custom_title_1']['multi_store_status'])) {
						if (($field_new != $product['custom_title_1'][$language['language_id']]) && ($field_overwrite || !$product['custom_title_1'][$language['language_id']])) {
							if ($data['store_id'] && $field_info['sheet']['product']['field']['custom_title_1']['multi_store'] && $field_info['sheet']['product']['field']['custom_title_1']['multi_store_status']) {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_1 = '" . $this->db->escape($field_new) . "' WHERE route='product_id=" . (int)$product['product_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='product_id=" . (int)$product['product_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', custom_title_1 = '" . $this->db->escape($field_new) . "'");
								}
							} else {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_1 = '" . $this->db->escape($field_new) . "' WHERE route='product_id=" . (int)$product['product_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='product_id=" . (int)$product['product_id'] . "', store_id = '0', language_id = '" . (int)$language['language_id'] . "', custom_title_1 = '" . $this->db->escape($field_new) . "'");
								}
							}
						}
					}
					
					if (isset($data['sheet']['product']['field']['custom_title_2']) && isset($product['custom_title_2'][$language['language_id']]) && isset($field_info['sheet']['product']['field']['custom_title_2']['multi_store']) && isset($field_info['sheet']['product']['field']['custom_title_2']['multi_store_status'])) {
						if (($field_new != $product['custom_title_2'][$language['language_id']]) && ($field_overwrite || !$product['custom_title_2'][$language['language_id']])) {
							if ($data['store_id'] && $field_info['sheet']['product']['field']['custom_title_2']['multi_store'] && $field_info['sheet']['product']['field']['custom_title_2']['multi_store_status']) {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_2 = '" . $this->db->escape($field_new) . "' WHERE route='product_id=" . (int)$product['product_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='product_id=" . (int)$product['product_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', custom_title_2 = '" . $this->db->escape($field_new) . "'");
								}
							} else {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_2 = '" . $this->db->escape($field_new) . "' WHERE route='product_id=" . (int)$product['product_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='product_id=" . (int)$product['product_id'] . "', store_id = '0', language_id = '" . (int)$language['language_id'] . "', custom_title_2 = '" . $this->db->escape($field_new) . "'");
								}
							}
						}
					}
				
					if (isset($data['sheet']['product']['field']['custom_image_title']) && isset($product['custom_image_title'][$language['language_id']]) && isset($field_info['sheet']['product']['field']['custom_image_title']['multi_store']) && isset($field_info['sheet']['product']['field']['custom_image_title']['multi_store_status'])) {
						if (($field_new != $product['custom_image_title'][$language['language_id']]) && ($field_overwrite || !$product['custom_image_title'][$language['language_id']])) {
							if ($data['store_id'] && $field_info['sheet']['product']['field']['custom_image_title']['multi_store'] && $field_info['sheet']['product']['field']['custom_image_title']['multi_store_status']) {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_image_title = '" . $this->db->escape($field_new) . "' WHERE route='product_id=" . (int)$product['product_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='product_id=" . (int)$product['product_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', custom_image_title = '" . $this->db->escape($field_new) . "'");
								}
							} else {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_image_title = '" . $this->db->escape($field_new) . "' WHERE route='product_id=" . (int)$product['product_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='product_id=" . (int)$product['product_id'] . "', store_id = '0', language_id = '" . (int)$language['language_id'] . "', custom_image_title = '" . $this->db->escape($field_new) . "'");
								}
							}
						}
					}
										
					if (isset($data['sheet']['product']['field']['custom_image_alt']) && isset($product['custom_image_alt'][$language['language_id']]) && isset($field_info['sheet']['product']['field']['custom_image_alt']['multi_store']) && isset($field_info['sheet']['product']['field']['custom_image_alt']['multi_store_status'])) {
						if (($field_new != $product['custom_image_alt'][$language['language_id']]) && ($field_overwrite || !$product['custom_image_alt'][$language['language_id']])) {
							if ($data['store_id'] && $field_info['sheet']['product']['field']['custom_image_alt']['multi_store'] && $field_info['sheet']['product']['field']['custom_image_alt']['multi_store_status']) {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_image_alt = '" . $this->db->escape($field_new) . "' WHERE route='product_id=" . (int)$product['product_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='product_id=" . (int)$product['product_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', custom_image_alt = '" . $this->db->escape($field_new) . "'");
								}
							} else {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_image_alt = '" . $this->db->escape($field_new) . "' WHERE route='product_id=" . (int)$product['product_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='product_id=" . (int)$product['product_id'] . "', store_id = '0', language_id = '" . (int)$language['language_id'] . "', custom_image_alt = '" . $this->db->escape($field_new) . "'");
								}
							}
						}
					}
				}		
			}	
		}
		
		if (isset($data['sheet']['manufacturer']['field'])) {
			$field = array();
			$implode = array();
			
			if (isset($data['sheet']['manufacturer']['field']['meta_title']) && isset($field_info['sheet']['manufacturer']['field']['meta_title']['multi_store']) && isset($field_info['sheet']['manufacturer']['field']['meta_title']['multi_store_status'])) {
				$field = $data['sheet']['manufacturer']['field']['meta_title'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['manufacturer']['field']['meta_title']['multi_store'] && $field_info['sheet']['manufacturer']['field']['meta_title']['multi_store_status']) ? "md2.meta_title" : "md.meta_title";
			}
			
			if (isset($data['sheet']['manufacturer']['field']['meta_description']) && isset($field_info['sheet']['manufacturer']['field']['meta_description']['multi_store']) && isset($field_info['sheet']['manufacturer']['field']['meta_description']['multi_store_status'])) {
				$field = $data['sheet']['manufacturer']['field']['meta_description'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['manufacturer']['field']['meta_description']['multi_store'] && $field_info['sheet']['manufacturer']['field']['meta_description']['multi_store_status']) ? "md2.meta_description" : "md.meta_description";
			}
			
			if (isset($data['sheet']['manufacturer']['field']['meta_keyword']) && isset($field_info['sheet']['manufacturer']['field']['meta_keyword']['multi_store']) && isset($field_info['sheet']['manufacturer']['field']['meta_keyword']['multi_store_status'])) {
				$field = $data['sheet']['manufacturer']['field']['meta_keyword'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['manufacturer']['field']['meta_keyword']['multi_store'] && $field_info['sheet']['manufacturer']['field']['meta_keyword']['multi_store_status']) ? "md2.meta_keyword" : "md.meta_keyword";
			}
			
			if (isset($data['sheet']['manufacturer']['field']['custom_title_1']) && isset($field_info['sheet']['manufacturer']['field']['custom_title_1']['multi_store']) && isset($field_info['sheet']['manufacturer']['field']['custom_title_1']['multi_store_status'])) {
				$field = $data['sheet']['manufacturer']['field']['custom_title_1'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['manufacturer']['field']['custom_title_1']['multi_store'] && $field_info['sheet']['manufacturer']['field']['custom_title_1']['multi_store_status']) ? "md2.custom_title_1" : "md.custom_title_1";
			}
			
			if (isset($data['sheet']['manufacturer']['field']['custom_title_2']) && isset($field_info['sheet']['manufacturer']['field']['custom_title_2']['multi_store']) && isset($field_info['sheet']['manufacturer']['field']['custom_title_2']['multi_store_status'])) {
				$field = $data['sheet']['manufacturer']['field']['custom_title_2'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['manufacturer']['field']['custom_title_2']['multi_store'] && $field_info['sheet']['manufacturer']['field']['custom_title_2']['multi_store_status']) ? "md2.custom_title_2" : "md.custom_title_2";
			}
						
			if (isset($data['sheet']['manufacturer']['field']['custom_image_name'])) {
				$field = $data['sheet']['manufacturer']['field']['custom_image_name'];
				$implode[] = "m.image";
			}
			
			if (isset($data['sheet']['manufacturer']['field']['custom_image_title']) && isset($field_info['sheet']['manufacturer']['field']['custom_image_title']['multi_store']) && isset($field_info['sheet']['manufacturer']['field']['custom_image_title']['multi_store_status'])) {
				$field = $data['sheet']['manufacturer']['field']['custom_image_title'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['manufacturer']['field']['custom_image_title']['multi_store'] && $field_info['sheet']['manufacturer']['field']['custom_image_title']['multi_store_status']) ? "md2.custom_image_title" : "md.custom_image_title";
			}
			
			if (isset($data['sheet']['manufacturer']['field']['custom_image_alt']) && isset($field_info['sheet']['manufacturer']['field']['custom_image_alt']['multi_store']) && isset($field_info['sheet']['manufacturer']['field']['custom_image_alt']['multi_store_status'])) {
				$field = $data['sheet']['manufacturer']['field']['custom_image_alt'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['manufacturer']['field']['custom_image_alt']['multi_store'] && $field_info['sheet']['manufacturer']['field']['custom_image_alt']['multi_store_status']) ? "md2.custom_image_alt" : "md.custom_image_alt";
			}
			
			if (isset($field_info['sheet']['manufacturer']['field']['name']['multi_store']) && isset($field_info['sheet']['manufacturer']['field']['name']['multi_store_status'])) {
				$implode[] = ($data['store_id'] && $field_info['sheet']['manufacturer']['field']['name']['multi_store'] && $field_info['sheet']['manufacturer']['field']['name']['multi_store_status']) ? "md2.name" : "md.name";
			}
			
			if (isset($field_info['sheet']['manufacturer']['field']['description']['multi_store']) && isset($field_info['sheet']['manufacturer']['field']['description']['multi_store_status'])) {
				$implode[] = ($data['store_id'] && $field_info['sheet']['manufacturer']['field']['description']['multi_store'] && $field_info['sheet']['manufacturer']['field']['description']['multi_store_status']) ? "md2.description" : "md.description";
			}
			
			if (isset($field_info['sheet']['product']['field']['name']['multi_store']) && isset($field_info['sheet']['product']['field']['name']['multi_store_status'])) {
				$implode[] = ($data['store_id'] && $field_info['sheet']['product']['field']['name']['multi_store'] && $field_info['sheet']['product']['field']['name']['multi_store_status']) ? "GROUP_CONCAT(DISTINCT md3.name ORDER BY p.product_id SEPARATOR '|') as product_sample" : "GROUP_CONCAT(DISTINCT pd.name ORDER BY p.product_id SEPARATOR '|') as product_sample";
			}
			
			$implode[] = "COUNT(DISTINCT p.product_id) as product_total";
			
			$manufacturers = array();
			
			if ($field) {
				$field_template = isset($field['template']) ? $field['template'] : '';
				$field_overwrite = isset($field['overwrite']) ? $field['overwrite'] : 1;
				
				if ($translit_data) {
					$translit_data = array(
						'translit_symbol_status' => isset($field['translit_symbol_status']) ? $field['translit_symbol_status'] : 1,
						'translit_language_symbol_status' => isset($field['translit_language_symbol_status']) ? $field['translit_language_symbol_status'] : 1,
						'transform_language_symbol_id' => isset($field['transform_language_symbol_id']) ? $field['transform_language_symbol_id'] : 0
					);
				}
							
				$field_data = array(
					'field_code' => 'target_keyword',
					'filter' => array('store_id' => $data['store_id'])
				);
			
				$target_keywords = $this->load->controller('extension/module/d_seo_module/getFieldElements', $field_data);
												
				$query = $this->db->query("SELECT m.manufacturer_id, l.language_id, " . implode(', ', $implode) . " FROM " . DB_PREFIX . "manufacturer m CROSS JOIN " . DB_PREFIX . "language l LEFT JOIN " . DB_PREFIX . "d_meta_data md ON (md.route = CONCAT('manufacturer_id=', m.manufacturer_id) AND md.store_id = '0' AND md.language_id = l.language_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md2 ON (md2.route = CONCAT('manufacturer_id=', m.manufacturer_id) AND md2.store_id = '" . (int)$data['store_id'] . "' AND md2.language_id = l.language_id) LEFT JOIN " . DB_PREFIX . "product p ON (p.manufacturer_id = m.manufacturer_id) LEFT JOIN " . DB_PREFIX . "product_description pd ON (pd.product_id = p.product_id AND pd.language_id = l.language_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md3 ON (md3.route = CONCAT('product_id=', p.product_id) AND md3.store_id = '" . (int)$data['store_id'] . "' AND md3.language_id = l.language_id ) GROUP BY m.manufacturer_id, l.language_id");
							
				foreach ($query->rows as $result) {
					$manufacturers[$result['manufacturer_id']]['manufacturer_id'] = $result['manufacturer_id'];
				
					foreach ($result as $field => $value) {
						if (($field != 'manufacturer_id') && ($field != 'language_id')) {
							$manufacturers[$result['manufacturer_id']][$field][$result['language_id']] = $value;
						}
					}
				}
			}

			foreach ($manufacturers as $manufacturer) {
				foreach ($languages as $language) {					
					if (isset($target_keywords['manufacturer_id=' . $manufacturer['manufacturer_id']][$data['store_id']][$language['language_id']])) {
						$target_keyword = $target_keywords['manufacturer_id=' . $manufacturer['manufacturer_id']][$data['store_id']][$language['language_id']];
					} else {
						$target_keyword = array();
					}
					
					if (isset($store['title'][$language['language_id']])) {
						$store_title = $store['title'][$language['language_id']];
					} else {
						$store_title = '';
					}
					
					if (is_array($field_template)) {
						$field_new = $field_template[$language['language_id']]; 
					} else {
						$field_new = $field_template; 
					}
					
					$field_new = strtr($field_new, array(
						'[name]' => $manufacturer['name'][$language['language_id']], 
						'[total_products]' => $manufacturer['product_total'][$language['language_id']],
						'[store_name]' => $store['name'],
						'[store_title]' => $store_title
					));
					$field_new = $this->replaceDescription($field_new, $manufacturer['description'][$language['language_id']]);
					$field_new = $this->replaceSampleProducts($field_new, $manufacturer['product_sample'][$language['language_id']]);
					$field_new = $this->replaceTargetKeyword($field_new, $target_keyword);
					
					if ($translit_data) {
						$field_new = $this->model_extension_module_d_translit->translit($field_new, $translit_data);
					}
					
					if (isset($data['sheet']['manufacturer']['field']['custom_image_name']) && isset($manufacturer['image'][$language['language_id']]) && ($manufacturer['image'][$language['language_id']]) && file_exists(DIR_IMAGE . $manufacturer['image'][$language['language_id']]) && ($language == reset($languages))) {
						$file_info = pathinfo(DIR_IMAGE . $manufacturer['image'][$language['language_id']]);
						
						if (($field_new != $file_info['filename']) && ($field_overwrite)) {
							rename(DIR_IMAGE . $manufacturer['image'][$language['language_id']], $file_info['dirname'] . '/' . $this->db->escape($field_new) . '.' . $file_info['extension']);
							
							$this->db->query("UPDATE " . DB_PREFIX . "manufacturer SET image = '" . str_replace(DIR_IMAGE, '', $file_info['dirname']) . '/' . $this->db->escape($field_new) . '.' . $file_info['extension'] . "' WHERE manufacturer_id = '" . (int)$manufacturer['manufacturer_id'] . "'");
						}
					}
					
					if (isset($data['sheet']['manufacturer']['field']['meta_title']) && isset($manufacturer['meta_title'][$language['language_id']]) && isset($field_info['sheet']['manufacturer']['field']['meta_title']['multi_store']) && isset($field_info['sheet']['manufacturer']['field']['meta_title']['multi_store_status'])) {
						if (($field_new != $manufacturer['meta_title'][$language['language_id']]) && ($field_overwrite || !$manufacturer['meta_title'][$language['language_id']])) {
							if ($data['store_id'] && $field_info['sheet']['manufacturer']['field']['meta_title']['multi_store'] && $field_info['sheet']['manufacturer']['field']['meta_title']['multi_store_status']) {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET meta_title = '" . $this->db->escape($field_new) . "' WHERE route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', meta_title = '" . $this->db->escape($field_new) . "'");
								}
							} else {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET meta_title = '" . $this->db->escape($field_new) . "' WHERE route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "', store_id = '0', language_id = '" . (int)$language['language_id'] . "', meta_title = '" . $this->db->escape($field_new) . "'");
								}
							}
						}
					}		
					
					if (isset($data['sheet']['manufacturer']['field']['meta_description']) && isset($manufacturer['meta_description'][$language['language_id']]) && isset($field_info['sheet']['manufacturer']['field']['meta_description']['multi_store']) && isset($field_info['sheet']['manufacturer']['field']['meta_description']['multi_store_status'])) {
						if (($field_new != $manufacturer['meta_description'][$language['language_id']]) && ($field_overwrite || !$manufacturer['meta_description'][$language['language_id']])) {
							if ($data['store_id'] && $field_info['sheet']['manufacturer']['field']['meta_description']['multi_store'] && $field_info['sheet']['manufacturer']['field']['meta_description']['multi_store_status']) {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET meta_description = '" . $this->db->escape($field_new) . "' WHERE route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', meta_description = '" . $this->db->escape($field_new) . "'");
								}
							} else {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET meta_description = '" . $this->db->escape($field_new) . "' WHERE route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "', store_id = '0', language_id = '" . (int)$language['language_id'] . "', meta_description = '" . $this->db->escape($field_new) . "'");
								}
							}
						}
					}
					
					if (isset($data['sheet']['manufacturer']['field']['meta_keyword']) && isset($manufacturer['meta_keyword'][$language['language_id']]) && isset($field_info['sheet']['manufacturer']['field']['meta_keyword']['multi_store']) && isset($field_info['sheet']['manufacturer']['field']['meta_keyword']['multi_store_status'])) {
						if (($field_new != $manufacturer['meta_keyword'][$language['language_id']]) && ($field_overwrite || !$manufacturer['meta_keyword'][$language['language_id']])) {
							if ($data['store_id'] && $field_info['sheet']['manufacturer']['field']['meta_keyword']['multi_store'] && $field_info['sheet']['manufacturer']['field']['meta_keyword']['multi_store_status']) {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET meta_keyword = '" . $this->db->escape($field_new) . "' WHERE route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', meta_keyword = '" . $this->db->escape($field_new) . "'");
								}
							} else {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET meta_keyword = '" . $this->db->escape($field_new) . "' WHERE route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "', store_id = '0', language_id = '" . (int)$language['language_id'] . "', meta_keyword = '" . $this->db->escape($field_new) . "'");
								}
							}
						}
					}
					
					if (isset($data['sheet']['manufacturer']['field']['custom_title_1']) && isset($manufacturer['custom_title_1'][$language['language_id']]) && isset($field_info['sheet']['manufacturer']['field']['custom_title_1']['multi_store']) && isset($field_info['sheet']['manufacturer']['field']['custom_title_1']['multi_store_status'])) {
						if (($field_new != $manufacturer['custom_title_1'][$language['language_id']]) && ($field_overwrite || !$manufacturer['custom_title_1'][$language['language_id']])) {
							if ($data['store_id'] && $field_info['sheet']['manufacturer']['field']['custom_title_1']['multi_store'] && $field_info['sheet']['manufacturer']['field']['custom_title_1']['multi_store_status']) {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_1 = '" . $this->db->escape($field_new) . "' WHERE route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', custom_title_1 = '" . $this->db->escape($field_new) . "'");
								}
							} else {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_1 = '" . $this->db->escape($field_new) . "' WHERE route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "', store_id = '0', language_id = '" . (int)$language['language_id'] . "', custom_title_1 = '" . $this->db->escape($field_new) . "'");
								}
							}
						}
					}
					
					if (isset($data['sheet']['manufacturer']['field']['custom_title_2']) && isset($manufacturer['custom_title_2'][$language['language_id']]) && isset($field_info['sheet']['manufacturer']['field']['custom_title_2']['multi_store']) && isset($field_info['sheet']['manufacturer']['field']['custom_title_2']['multi_store_status'])) {
						if (($field_new != $manufacturer['custom_title_2'][$language['language_id']]) && ($field_overwrite || !$manufacturer['custom_title_2'][$language['language_id']])) {
							if ($data['store_id'] && $field_info['sheet']['manufacturer']['field']['custom_title_2']['multi_store'] && $field_info['sheet']['manufacturer']['field']['custom_title_2']['multi_store_status']) {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_2 = '" . $this->db->escape($field_new) . "' WHERE route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', custom_title_2 = '" . $this->db->escape($field_new) . "'");
								}
							} else {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_2 = '" . $this->db->escape($field_new) . "' WHERE route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "', store_id = '0', language_id = '" . (int)$language['language_id'] . "', custom_title_2 = '" . $this->db->escape($field_new) . "'");
								}
							}
						}
					}
					
					if (isset($data['sheet']['manufacturer']['field']['custom_image_title']) && isset($manufacturer['custom_image_title'][$language['language_id']]) && isset($field_info['sheet']['manufacturer']['field']['custom_image_title']['multi_store']) && isset($field_info['sheet']['manufacturer']['field']['custom_image_title']['multi_store_status'])) {
						if (($field_new != $manufacturer['custom_image_title'][$language['language_id']]) && ($field_overwrite || !$manufacturer['custom_image_title'][$language['language_id']])) {
							if ($data['store_id'] && $field_info['sheet']['manufacturer']['field']['custom_image_title']['multi_store'] && $field_info['sheet']['manufacturer']['field']['custom_image_title']['multi_store_status']) {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_image_title = '" . $this->db->escape($field_new) . "' WHERE route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', custom_image_title = '" . $this->db->escape($field_new) . "'");
								}
							} else {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_image_title = '" . $this->db->escape($field_new) . "' WHERE route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "', store_id = '0', language_id = '" . (int)$language['language_id'] . "', custom_image_title = '" . $this->db->escape($field_new) . "'");
								}
							}
						}
					}
					
					if (isset($data['sheet']['manufacturer']['field']['custom_image_alt']) && isset($manufacturer['custom_image_alt'][$language['language_id']]) && isset($field_info['sheet']['manufacturer']['field']['custom_image_alt']['multi_store']) && isset($field_info['sheet']['manufacturer']['field']['custom_image_alt']['multi_store_status'])) {
						if (($field_new != $manufacturer['custom_image_alt'][$language['language_id']]) && ($field_overwrite || !$manufacturer['custom_image_alt'][$language['language_id']])) {
							if ($data['store_id'] && $field_info['sheet']['manufacturer']['field']['custom_image_alt']['multi_store'] && $field_info['sheet']['manufacturer']['field']['custom_image_alt']['multi_store_status']) {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_image_alt = '" . $this->db->escape($field_new) . "' WHERE route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', custom_image_alt = '" . $this->db->escape($field_new) . "'");
								}
							} else {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_image_alt = '" . $this->db->escape($field_new) . "' WHERE route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "', store_id = '0', language_id = '" . (int)$language['language_id'] . "', custom_image_alt = '" . $this->db->escape($field_new) . "'");
								}
							}
						}
					}
				}		
			}								
		}
		
		if (isset($data['sheet']['information']['field'])) {
			$field = array();
			$implode = array();
						
			if (isset($data['sheet']['information']['field']['meta_title']) && isset($field_info['sheet']['information']['field']['meta_title']['multi_store']) && isset($field_info['sheet']['information']['field']['meta_title']['multi_store_status'])) {
				$field = $data['sheet']['information']['field']['meta_title'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['information']['field']['meta_title']['multi_store'] && $field_info['sheet']['information']['field']['meta_title']['multi_store_status']) ? "md2.meta_title" : "id.meta_title";
			}
			
			if (isset($data['sheet']['information']['field']['meta_description']) && isset($field_info['sheet']['information']['field']['meta_description']['multi_store']) && isset($field_info['sheet']['information']['field']['meta_description']['multi_store_status'])) {
				$field = $data['sheet']['information']['field']['meta_description'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['information']['field']['meta_description']['multi_store'] && $field_info['sheet']['information']['field']['meta_description']['multi_store_status']) ? "md2.meta_description" : "id.meta_description";
			}
			
			if (isset($data['sheet']['information']['field']['meta_keyword']) && isset($field_info['sheet']['information']['field']['meta_keyword']['multi_store']) && isset($field_info['sheet']['information']['field']['meta_keyword']['multi_store_status'])) {
				$field = $data['sheet']['information']['field']['meta_keyword'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['information']['field']['meta_keyword']['multi_store'] && $field_info['sheet']['information']['field']['meta_keyword']['multi_store_status']) ? "md2.meta_keyword" : "id.meta_keyword";
			}
			
			if (isset($data['sheet']['information']['field']['custom_title_1']) && isset($field_info['sheet']['information']['field']['custom_title_1']['multi_store']) && isset($field_info['sheet']['information']['field']['custom_title_1']['multi_store_status'])) {
				$field = $data['sheet']['information']['field']['custom_title_1'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['information']['field']['custom_title_1']['multi_store'] && $field_info['sheet']['information']['field']['custom_title_1']['multi_store_status']) ? "md2.custom_title_1" : "md.custom_title_1";
			}
			
			if (isset($data['sheet']['information']['field']['custom_title_2']) && isset($field_info['sheet']['information']['field']['custom_title_2']['multi_store']) && isset($field_info['sheet']['information']['field']['custom_title_2']['multi_store_status'])) {
				$field = $data['sheet']['information']['field']['custom_title_2'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['information']['field']['custom_title_2']['multi_store'] && $field_info['sheet']['information']['field']['custom_title_2']['multi_store_status']) ? "md2.custom_title_2" : "md.custom_title_2";
			}
			
			if (isset($field_info['sheet']['information']['field']['title']['multi_store']) && isset($field_info['sheet']['information']['field']['title']['multi_store_status'])) {
				$implode[] = ($data['store_id'] && $field_info['sheet']['information']['field']['title']['multi_store'] && $field_info['sheet']['information']['field']['title']['multi_store_status']) ? "md2.title" : "id.title";
			}
			
			if (isset($field_info['sheet']['information']['field']['description']['multi_store']) && isset($field_info['sheet']['information']['field']['description']['multi_store_status'])) {
				$implode[] = ($data['store_id'] && $field_info['sheet']['information']['field']['description']['multi_store'] && $field_info['sheet']['information']['field']['description']['multi_store_status']) ? "md2.description" : "id.description";
			}
			
			$informations = array();
						
			if ($field) {
				$field_template = isset($field['template']) ? $field['template'] : '';
				$field_overwrite = isset($field['overwrite']) ? $field['overwrite'] : 1;
				
				if ($translit_data) {
					$translit_data = array(
						'translit_symbol_status' => isset($field['translit_symbol_status']) ? $field['translit_symbol_status'] : 1,
						'translit_language_symbol_status' => isset($field['translit_language_symbol_status']) ? $field['translit_language_symbol_status'] : 1,
						'transform_language_symbol_id' => isset($field['transform_language_symbol_id']) ? $field['transform_language_symbol_id'] : 0
					);
				}
				
				$field_data = array(
					'field_code' => 'target_keyword',
					'filter' => array('store_id' => $data['store_id'])
				);
			
				$target_keywords = $this->load->controller('extension/module/d_seo_module/getFieldElements', $field_data);
							
				$query = $this->db->query("SELECT id.information_id, id.language_id, " . implode(', ', $implode) . " FROM " . DB_PREFIX . "information i LEFT JOIN " . DB_PREFIX . "information_description id ON (id.information_id = i.information_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md ON (md.route = CONCAT('information_id=', i.information_id) AND md.store_id = '0' AND md.language_id = id.language_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md2 ON (md2.route = CONCAT('information_id=', i.information_id) AND md2.store_id = '" . (int)$data['store_id'] . "' AND md2.language_id = id.language_id) GROUP BY i.information_id, id.language_id");
							
				foreach ($query->rows as $result) {
					$informations[$result['information_id']]['information_id'] = $result['information_id'];
				
					foreach ($result as $field => $value) {
						if (($field != 'information_id') && ($field != 'language_id')) {
							$informations[$result['information_id']][$field][$result['language_id']] = $value;
						}
					}
				}
			}
											
			foreach ($informations as $information) {
				foreach ($languages as $language) {
					if (isset($target_keywords['information_id=' . $information['information_id']][$data['store_id']][$language['language_id']])) {
						$target_keyword = $target_keywords['information_id=' . $information['information_id']][$data['store_id']][$language['language_id']];
					} else {
						$target_keyword = array();
					}
					
					if (isset($store['title'][$language['language_id']])) {
						$store_title = $store['title'][$language['language_id']];
					} else {
						$store_title = '';
					}
					
					if (is_array($field_template)) {
						$field_new = $field_template[$language['language_id']]; 
					} else {
						$field_new = $field_template; 
					}
					
					$field_new = strtr($field_new, array(
						'[title]' => $information['title'][$language['language_id']], 
						'[store_name]' => $store['name'],
						'[store_title]' => $store_title
					));
					$field_new = $this->replaceDescription($field_new, $information['description'][$language['language_id']]);
					$field_new = $this->replaceTargetKeyword($field_new, $target_keyword);
					
					if ($translit_data) {
						$field_new = $this->model_extension_module_d_translit->translit($field_new, $translit_data);
					}
					
					if (isset($data['sheet']['information']['field']['meta_title']) && isset($information['meta_title'][$language['language_id']]) && isset($field_info['sheet']['information']['field']['meta_title']['multi_store']) && isset($field_info['sheet']['information']['field']['meta_title']['multi_store_status'])) {
						if (($field_new != $information['meta_title'][$language['language_id']]) && ($field_overwrite || !$information['meta_title'][$language['language_id']])) {
							if ($data['store_id'] && $field_info['sheet']['information']['field']['meta_title']['multi_store'] && $field_info['sheet']['information']['field']['meta_title']['multi_store_status']) {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET meta_title = '" . $this->db->escape($field_new) . "' WHERE route='information_id=" . (int)$information['information_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='information_id=" . (int)$information['information_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', meta_title = '" . $this->db->escape($field_new) . "'");
								}
							} else {
								$this->db->query("UPDATE " . DB_PREFIX . "information_description SET meta_title = '" . $this->db->escape($field_new) . "' WHERE information_id = '" . (int)$information['information_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
							}
						}
					}
										
					if (isset($data['sheet']['information']['field']['meta_description']) && isset($information['meta_description'][$language['language_id']]) && isset($field_info['sheet']['information']['field']['meta_description']['multi_store']) && isset($field_info['sheet']['information']['field']['meta_description']['multi_store_status'])) {
						if (($field_new != $information['meta_description'][$language['language_id']]) && ($field_overwrite || !$information['meta_description'][$language['language_id']])) {
							if ($data['store_id'] && $field_info['sheet']['information']['field']['meta_description']['multi_store'] && $field_info['sheet']['information']['field']['meta_description']['multi_store_status']) {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET meta_description = '" . $this->db->escape($field_new) . "' WHERE route='information_id=" . (int)$information['information_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='information_id=" . (int)$information['information_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', meta_description = '" . $this->db->escape($field_new) . "'");
								}
							} else {
								$this->db->query("UPDATE " . DB_PREFIX . "information_description SET meta_description = '" . $this->db->escape($field_new) . "' WHERE information_id = '" . (int)$information['information_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
							}
						}
					}
					
					if (isset($data['sheet']['information']['field']['meta_keyword']) && isset($information['meta_keyword'][$language['language_id']]) && isset($field_info['sheet']['information']['field']['meta_keyword']['multi_store']) && isset($field_info['sheet']['information']['field']['meta_keyword']['multi_store_status'])) {
						if (($field_new != $information['meta_keyword'][$language['language_id']]) && ($field_overwrite || !$information['meta_keyword'][$language['language_id']])) {
							if ($data['store_id'] && $field_info['sheet']['information']['field']['meta_keyword']['multi_store'] && $field_info['sheet']['information']['field']['meta_keyword']['multi_store_status']) {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET meta_keyword = '" . $this->db->escape($field_new) . "' WHERE route='information_id=" . (int)$information['information_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='information_id=" . (int)$information['information_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', meta_keyword = '" . $this->db->escape($field_new) . "'");
								}
							} else {
								$this->db->query("UPDATE " . DB_PREFIX . "information_description SET meta_keyword = '" . $this->db->escape($field_new) . "' WHERE information_id = '" . (int)$information['information_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
							}
						}
					}
					
					if (isset($data['sheet']['information']['field']['custom_title_1']) && isset($information['custom_title_1'][$language['language_id']]) && isset($field_info['sheet']['information']['field']['custom_title_1']['multi_store']) && isset($field_info['sheet']['information']['field']['custom_title_1']['multi_store_status'])) {
						if (($field_new != $information['custom_title_1'][$language['language_id']]) && ($field_overwrite || !$information['custom_title_1'][$language['language_id']])) {
							if ($data['store_id'] && $field_info['sheet']['information']['field']['custom_title_1']['multi_store'] && $field_info['sheet']['information']['field']['custom_title_1']['multi_store_status']) {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_1 = '" . $this->db->escape($field_new) . "' WHERE route='information_id=" . (int)$information['information_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='information_id=" . (int)$information['information_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', custom_title_1 = '" . $this->db->escape($field_new) . "'");
								}
							} else {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_1 = '" . $this->db->escape($field_new) . "' WHERE route='information_id=" . (int)$information['information_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='information_id=" . (int)$information['information_id'] . "', store_id = '0', language_id = '" . (int)$language['language_id'] . "', custom_title_1 = '" . $this->db->escape($field_new) . "'");
								}
							}
						}
					}
					
					if (isset($data['sheet']['information']['field']['custom_title_2']) && isset($information['custom_title_2'][$language['language_id']]) && isset($field_info['sheet']['information']['field']['custom_title_2']['multi_store']) && isset($field_info['sheet']['information']['field']['custom_title_2']['multi_store_status'])) {
						if (($field_new != $information['custom_title_2'][$language['language_id']]) && ($field_overwrite || !$information['custom_title_2'][$language['language_id']])) {
							if ($data['store_id'] && $field_info['sheet']['information']['field']['custom_title_2']['multi_store'] && $field_info['sheet']['information']['field']['custom_title_2']['multi_store_status']) {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_2 = '" . $this->db->escape($field_new) . "' WHERE route='information_id=" . (int)$information['information_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='information_id=" . (int)$information['information_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', custom_title_2 = '" . $this->db->escape($field_new) . "'");
								}
							} else {
								$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_2 = '" . $this->db->escape($field_new) . "' WHERE route='information_id=" . (int)$information['information_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
								
								if (!$this->db->countAffected()) {			
									$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='information_id=" . (int)$information['information_id'] . "', store_id = '0', language_id = '" . (int)$language['language_id'] . "', custom_title_2 = '" . $this->db->escape($field_new) . "'");
								}
							}
						}
					}
				}		
			}
		}
	}
	
	/*
	*	Clear Fields.
	*/
	public function clearFields($data) {				
		$this->load->model('extension/module/' . $this->codename);
		
		$store = $this->{'model_extension_module_' . $this->codename}->getStore($data['store_id']);
		$languages = $this->{'model_extension_module_' . $this->codename}->getLanguages();
								
		$field_info = $this->load->controller('extension/module/d_seo_module/getFieldInfo');
												
		if (isset($data['sheet']['category']['field'])) {							
			$field = array();
			$implode = array();
			
			if (isset($data['sheet']['category']['field']['meta_title']) && isset($field_info['sheet']['category']['field']['meta_title']['multi_store']) && isset($field_info['sheet']['category']['field']['meta_title']['multi_store_status'])) {
				$field = $data['sheet']['category']['field']['meta_title'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['category']['field']['meta_title']['multi_store'] && $field_info['sheet']['category']['field']['meta_title']['multi_store_status']) ? "md2.meta_title" : "cd.meta_title";
			}
			
			if (isset($data['sheet']['category']['field']['meta_description']) && isset($field_info['sheet']['category']['field']['meta_description']['multi_store']) && isset($field_info['sheet']['category']['field']['meta_description']['multi_store_status'])) {
				$field = $data['sheet']['category']['field']['meta_description'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['category']['field']['meta_description']['multi_store'] && $field_info['sheet']['category']['field']['meta_description']['multi_store_status']) ? "md2.meta_description" : "cd.meta_description";
			}
			
			if (isset($data['sheet']['category']['field']['meta_keyword']) && isset($field_info['sheet']['category']['field']['meta_keyword']['multi_store']) && isset($field_info['sheet']['category']['field']['meta_keyword']['multi_store_status'])) {
				$field = $data['sheet']['category']['field']['meta_keyword'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['category']['field']['meta_keyword']['multi_store'] && $field_info['sheet']['category']['field']['meta_keyword']['multi_store_status']) ? "md2.meta_keyword" : "cd.meta_keyword";
			}
			
			if (isset($data['sheet']['category']['field']['custom_title_1']) && isset($field_info['sheet']['category']['field']['custom_title_1']['multi_store']) && isset($field_info['sheet']['category']['field']['custom_title_1']['multi_store_status'])) {
				$field = $data['sheet']['category']['field']['custom_title_1'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['category']['field']['custom_title_1']['multi_store'] && $field_info['sheet']['category']['field']['custom_title_1']['multi_store_status']) ? "md2.custom_title_1" : "md.custom_title_1";
			}
			
			if (isset($data['sheet']['category']['field']['custom_title_2']) && isset($field_info['sheet']['category']['field']['custom_title_2']['multi_store']) && isset($field_info['sheet']['category']['field']['custom_title_2']['multi_store_status'])) {
				$field = $data['sheet']['category']['field']['custom_title_2'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['category']['field']['custom_title_2']['multi_store'] && $field_info['sheet']['category']['field']['custom_title_2']['multi_store_status']) ? "md2.custom_title_2" : "md.custom_title_2";
			}
			
			if (isset($data['sheet']['category']['field']['custom_image_name'])) {
				$field = $data['sheet']['category']['field']['custom_image_name'];
				$implode[] = "c.image";
			}
			
			if (isset($data['sheet']['category']['field']['custom_image_title']) && isset($field_info['sheet']['category']['field']['custom_image_title']['multi_store']) && isset($field_info['sheet']['category']['field']['custom_image_title']['multi_store_status'])) {
				$field = $data['sheet']['category']['field']['custom_image_title'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['category']['field']['custom_image_title']['multi_store'] && $field_info['sheet']['category']['field']['custom_image_title']['multi_store_status']) ? "md2.custom_image_title" : "md.custom_image_title";
			}
			
			if (isset($data['sheet']['category']['field']['custom_image_alt']) && isset($field_info['sheet']['category']['field']['custom_image_alt']['multi_store']) && isset($field_info['sheet']['category']['field']['custom_image_alt']['multi_store_status'])) {
				$field = $data['sheet']['category']['field']['custom_image_alt'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['category']['field']['custom_image_alt']['multi_store'] && $field_info['sheet']['category']['field']['custom_image_alt']['multi_store_status']) ? "md2.custom_image_alt" : "md.custom_image_alt";
			}
						
			$categories = array();
			
			if ($field) {
				$query = $this->db->query("SELECT cd.category_id, cd.language_id, " . implode(', ', $implode) . " FROM " . DB_PREFIX . "category c LEFT JOIN " . DB_PREFIX . "category_description cd ON (cd.category_id = c.category_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md ON (md.route = CONCAT('category_id=', c.category_id) AND md.store_id = '0' AND md.language_id = cd.language_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md2 ON (md2.route = CONCAT('category_id=', c.category_id) AND md2.store_id = '" . (int)$data['store_id'] . "' AND md2.language_id = cd.language_id) GROUP BY c.category_id, cd.language_id");
							
				foreach ($query->rows as $result) {
					$categories[$result['category_id']]['category_id'] = $result['category_id'];
				
					foreach ($result as $field => $value) {
						if (($field != 'category_id') && ($field != 'language_id')) {
							$categories[$result['category_id']][$field][$result['language_id']] = $value;
						}
					}
				}
			}
							
			foreach ($categories as $category) {
				foreach ($languages as $language) {
					if (isset($data['sheet']['category']['field']['custom_image_name']) && isset($category['image'][$language['language_id']]) && ($category['image'][$language['language_id']]) && ($language == reset($languages))) {
						$this->db->query("UPDATE " . DB_PREFIX . "category SET image = '' WHERE category_id = '" . (int)$category['category_id'] . "'");
					}
					
					if (isset($data['sheet']['category']['field']['meta_title']) && isset($category['meta_title'][$language['language_id']]) && isset($field_info['sheet']['category']['field']['meta_title']['multi_store']) && isset($field_info['sheet']['category']['field']['meta_title']['multi_store_status'])) {
						if ($data['store_id'] && $field_info['sheet']['category']['field']['meta_title']['multi_store'] && $field_info['sheet']['category']['field']['meta_title']['multi_store_status']) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET meta_title = '' WHERE route='category_id=" . (int)$category['category_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						} else {
							$this->db->query("UPDATE " . DB_PREFIX . "category_description SET meta_title = '' WHERE category_id = '" . (int)$category['category_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						}
					}
					
					if (isset($data['sheet']['category']['field']['meta_description']) && isset($category['meta_description'][$language['language_id']]) && isset($field_info['sheet']['category']['field']['meta_description']['multi_store']) && isset($field_info['sheet']['category']['field']['meta_description']['multi_store_status'])) {
						if ($data['store_id'] && $field_info['sheet']['category']['field']['meta_description']['multi_store'] && $field_info['sheet']['category']['field']['meta_description']['multi_store_status']) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET meta_description = '' WHERE route='category_id=" . (int)$category['category_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						} else {
							$this->db->query("UPDATE " . DB_PREFIX . "category_description SET meta_description = '' WHERE category_id = '" . (int)$category['category_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						}
					}
					
					if (isset($data['sheet']['category']['field']['meta_keyword']) && isset($category['meta_keyword'][$language['language_id']]) && isset($field_info['sheet']['category']['field']['meta_keyword']['multi_store']) && isset($field_info['sheet']['category']['field']['meta_keyword']['multi_store_status'])) {
						if ($data['store_id'] && $field_info['sheet']['category']['field']['meta_keyword']['multi_store'] && $field_info['sheet']['category']['field']['meta_keyword']['multi_store_status']) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET meta_keyword = '' WHERE route='category_id=" . (int)$category['category_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						} else {
							$this->db->query("UPDATE " . DB_PREFIX . "category_description SET meta_keyword = '' WHERE category_id = '" . (int)$category['category_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						}
					}
					
					if (isset($data['sheet']['category']['field']['custom_title_1']) && isset($category['custom_title_1'][$language['language_id']]) && isset($field_info['sheet']['category']['field']['custom_title_1']['multi_store']) && isset($field_info['sheet']['category']['field']['custom_title_1']['multi_store_status'])) {
						if ($data['store_id'] && $field_info['sheet']['category']['field']['custom_title_1']['multi_store'] && $field_info['sheet']['category']['field']['custom_title_1']['multi_store_status']) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_1 = '' WHERE route='category_id=" . (int)$category['category_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						} else {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_1 = '' WHERE route='category_id=" . (int)$category['category_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
						}
					}
					
					if (isset($data['sheet']['category']['field']['custom_title_2']) && isset($category['custom_title_2'][$language['language_id']]) && isset($field_info['sheet']['category']['field']['custom_title_2']['multi_store']) && isset($field_info['sheet']['category']['field']['custom_title_2']['multi_store_status'])) {
						if ($data['store_id'] && $field_info['sheet']['category']['field']['custom_title_2']['multi_store'] && $field_info['sheet']['category']['field']['custom_title_2']['multi_store_status']) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_2 = '' WHERE route='category_id=" . (int)$category['category_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						} else {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_2 = '' WHERE route='category_id=" . (int)$category['category_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
						}
					}
					
					if (isset($data['sheet']['category']['field']['custom_image_title']) && isset($category['custom_image_title'][$language['language_id']]) && isset($field_info['sheet']['category']['field']['custom_image_title']['multi_store']) && isset($field_info['sheet']['category']['field']['custom_image_title']['multi_store_status'])) {
						if ($data['store_id'] && $field_info['sheet']['category']['field']['custom_image_title']['multi_store'] && $field_info['sheet']['category']['field']['custom_image_title']['multi_store_status']) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_image_title = '' WHERE route='category_id=" . (int)$category['category_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						} else {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_image_title = '' WHERE route='category_id=" . (int)$category['category_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
						}
					}
					
					if (isset($data['sheet']['category']['field']['custom_image_alt']) && isset($category['custom_image_alt'][$language['language_id']]) && isset($field_info['sheet']['category']['field']['custom_image_alt']['multi_store']) && isset($field_info['sheet']['category']['field']['custom_image_alt']['multi_store_status'])) {
						if ($data['store_id'] && $field_info['sheet']['category']['field']['custom_image_alt']['multi_store'] && $field_info['sheet']['category']['field']['custom_image_alt']['multi_store_status']) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_image_alt = '' WHERE route='category_id=" . (int)$category['category_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						} else {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_image_alt = '' WHERE route='category_id=" . (int)$category['category_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
						}
					}
				}		
			}
		}
		
		if (isset($data['sheet']['product']['field'])) {
			$field = array();
			$implode = array();
			
			if (isset($data['sheet']['product']['field']['meta_title']) && isset($field_info['sheet']['product']['field']['meta_title']['multi_store']) && isset($field_info['sheet']['product']['field']['meta_title']['multi_store_status'])) {
				$field = $data['sheet']['product']['field']['meta_title'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['product']['field']['meta_title']['multi_store'] && $field_info['sheet']['product']['field']['meta_title']['multi_store_status']) ? "md2.meta_title" : "pd.meta_title";
			}
			
			if (isset($data['sheet']['product']['field']['meta_description']) && isset($field_info['sheet']['product']['field']['meta_description']['multi_store']) && isset($field_info['sheet']['product']['field']['meta_description']['multi_store_status'])) {
				$field = $data['sheet']['product']['field']['meta_description'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['product']['field']['meta_description']['multi_store'] && $field_info['sheet']['product']['field']['meta_description']['multi_store_status']) ? "md2.meta_description" : "pd.meta_description";
			}
			
			if (isset($data['sheet']['product']['field']['meta_keyword']) && isset($field_info['sheet']['product']['field']['meta_keyword']['multi_store']) && isset($field_info['sheet']['product']['field']['meta_keyword']['multi_store_status'])) {
				$field = $data['sheet']['product']['field']['meta_keyword'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['product']['field']['meta_keyword']['multi_store'] && $field_info['sheet']['product']['field']['meta_keyword']['multi_store_status']) ? "md2.meta_keyword" : "pd.meta_keyword";
			}
			
			if (isset($data['sheet']['product']['field']['tag']) && isset($field_info['sheet']['product']['field']['tag']['multi_store']) && isset($field_info['sheet']['product']['field']['tag']['multi_store_status'])) {
				$field = $data['sheet']['product']['field']['tag'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['product']['field']['tag']['multi_store'] && $field_info['sheet']['product']['field']['tag']['multi_store_status']) ? "md2.tag" : "pd.tag";
			}
			
			if (isset($data['sheet']['product']['field']['custom_title_1']) && isset($field_info['sheet']['product']['field']['custom_title_1']['multi_store']) && isset($field_info['sheet']['product']['field']['custom_title_1']['multi_store_status'])) {
				$field = $data['sheet']['product']['field']['custom_title_1'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['product']['field']['custom_title_1']['multi_store'] && $field_info['sheet']['product']['field']['custom_title_1']['multi_store_status']) ? "md2.custom_title_1" : "md.custom_title_1";
			}
			
			if (isset($data['sheet']['product']['field']['custom_title_2']) && isset($field_info['sheet']['product']['field']['custom_title_2']['multi_store']) && isset($field_info['sheet']['product']['field']['custom_title_2']['multi_store_status'])) {
				$field = $data['sheet']['product']['field']['custom_title_2'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['product']['field']['custom_title_2']['multi_store'] && $field_info['sheet']['product']['field']['custom_title_2']['multi_store_status']) ? "md2.custom_title_2" : "md.custom_title_2";
			}
			
			if (isset($data['sheet']['product']['field']['custom_image_name'])) {
				$field = $data['sheet']['product']['field']['custom_image_name'];
				$implode[] = "p.image";
			}
			
			if (isset($data['sheet']['product']['field']['custom_image_title']) && isset($field_info['sheet']['product']['field']['custom_image_title']['multi_store']) && isset($field_info['sheet']['product']['field']['custom_image_title']['multi_store_status'])) {
				$field = $data['sheet']['product']['field']['custom_image_title'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['product']['field']['custom_image_title']['multi_store'] && $field_info['sheet']['product']['field']['custom_image_title']['multi_store_status']) ? "md2.custom_image_title" : "md.custom_image_title";
			}
			
			if (isset($data['sheet']['product']['field']['custom_image_alt']) && isset($field_info['sheet']['product']['field']['custom_image_alt']['multi_store']) && isset($field_info['sheet']['product']['field']['custom_image_alt']['multi_store_status'])) {
				$field = $data['sheet']['product']['field']['custom_image_alt'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['product']['field']['custom_image_alt']['multi_store'] && $field_info['sheet']['product']['field']['custom_image_alt']['multi_store_status']) ? "md2.custom_image_alt" : "md.custom_image_alt";
			}
									
			$products = array();
			
			if ($field) {
				$query = $this->db->query("SELECT pd.product_id, pd.language_id, " . implode(', ', $implode) . " FROM " . DB_PREFIX . "product p LEFT JOIN " . DB_PREFIX . "product_description pd ON (pd.product_id = p.product_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md ON (md.route = CONCAT('product_id=', p.product_id) AND md.store_id = '0' AND md.language_id = pd.language_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md2 ON (md2.route = CONCAT('product_id=', p.product_id) AND md2.store_id = '" . (int)$data['store_id'] . "' AND md2.language_id = pd.language_id) GROUP BY p.product_id, pd.language_id");
				
				foreach ($query->rows as $result) {
					$products[$result['product_id']]['product_id'] = $result['product_id'];
				
					foreach ($result as $field => $value) {
						if (($field != 'product_id') && ($field != 'language_id')) {
							$products[$result['product_id']][$field][$result['language_id']] = $value;
						}
					}
				}
			}
			
			foreach ($products as $product) {
				foreach ($languages as $language) {
					if (isset($data['sheet']['product']['field']['custom_image_name']) && isset($product['image'][$language['language_id']]) && ($product['image'][$language['language_id']]) && ($language == reset($languages))) {
						$this->db->query("UPDATE " . DB_PREFIX . "product SET image = '' WHERE product_id = '" . (int)$product['product_id'] . "'");
					}
										
					if (isset($data['sheet']['product']['field']['meta_title']) && isset($product['meta_title'][$language['language_id']]) && isset($field_info['sheet']['product']['field']['meta_title']['multi_store']) && isset($field_info['sheet']['product']['field']['meta_title']['multi_store_status'])) {
						if ($data['store_id'] && $field_info['sheet']['product']['field']['meta_title']['multi_store'] && $field_info['sheet']['product']['field']['meta_title']['multi_store_status']) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET meta_title = '' WHERE route='product_id=" . (int)$product['product_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						} else {
							$this->db->query("UPDATE " . DB_PREFIX . "product_description SET meta_title = '' WHERE product_id = '" . (int)$product['product_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						}
					}					
										
					if (isset($data['sheet']['product']['field']['meta_description']) && isset($product['meta_description'][$language['language_id']]) && isset($field_info['sheet']['product']['field']['meta_description']['multi_store']) && isset($field_info['sheet']['product']['field']['meta_description']['multi_store_status'])) {
						if ($data['store_id'] && $field_info['sheet']['product']['field']['meta_description']['multi_store'] && $field_info['sheet']['product']['field']['meta_description']['multi_store_status']) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET meta_description = '' WHERE route='product_id=" . (int)$product['product_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						} else {
							$this->db->query("UPDATE " . DB_PREFIX . "product_description SET meta_description = '' WHERE product_id = '" . (int)$product['product_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						}
					}
					
					if (isset($data['sheet']['product']['field']['meta_keyword']) && isset($product['meta_keyword'][$language['language_id']]) && isset($field_info['sheet']['product']['field']['meta_keyword']['multi_store']) && isset($field_info['sheet']['product']['field']['meta_keyword']['multi_store_status'])) {
						if ($data['store_id'] && $field_info['sheet']['product']['field']['meta_keyword']['multi_store'] && $field_info['sheet']['product']['field']['meta_keyword']['multi_store_status']) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET meta_keyword = '' WHERE route='product_id=" . (int)$product['product_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						} else {
							$this->db->query("UPDATE " . DB_PREFIX . "product_description SET meta_keyword = '' WHERE product_id = '" . (int)$product['product_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						}
					}
					
					if (isset($data['sheet']['product']['field']['tag']) && isset($product['tag'][$language['language_id']]) && isset($field_info['sheet']['product']['field']['tag']['multi_store']) && isset($field_info['sheet']['product']['field']['tag']['multi_store_status'])) {
						if ($data['store_id'] && $field_info['sheet']['product']['field']['tag']['multi_store'] && $field_info['sheet']['product']['field']['tag']['multi_store_status']) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET tag = '' WHERE route='product_id=" . (int)$product['product_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						} else {
							$this->db->query("UPDATE " . DB_PREFIX . "product_description SET tag = '' WHERE product_id = '" . (int)$product['product_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						}
					}
					
					if (isset($data['sheet']['product']['field']['custom_title_1']) && isset($product['custom_title_1'][$language['language_id']]) && isset($field_info['sheet']['product']['field']['custom_title_1']['multi_store']) && isset($field_info['sheet']['product']['field']['custom_title_1']['multi_store_status'])) {
						if ($data['store_id'] && $field_info['sheet']['product']['field']['custom_title_1']['multi_store'] && $field_info['sheet']['product']['field']['custom_title_1']['multi_store_status']) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_1 = '' WHERE route='product_id=" . (int)$product['product_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						} else {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_1 = '' WHERE route='product_id=" . (int)$product['product_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
						}
					}
					
					if (isset($data['sheet']['product']['field']['custom_title_2']) && isset($product['custom_title_2'][$language['language_id']]) && isset($field_info['sheet']['product']['field']['custom_title_2']['multi_store']) && isset($field_info['sheet']['product']['field']['custom_title_2']['multi_store_status'])) {
						if ($data['store_id'] && $field_info['sheet']['product']['field']['custom_title_2']['multi_store'] && $field_info['sheet']['product']['field']['custom_title_2']['multi_store_status']) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_2 = '' WHERE route='product_id=" . (int)$product['product_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						} else {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_2 = '' WHERE route='product_id=" . (int)$product['product_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
						}
					}
				
					if (isset($data['sheet']['product']['field']['custom_image_title']) && isset($product['custom_image_title'][$language['language_id']]) && isset($field_info['sheet']['product']['field']['custom_image_title']['multi_store']) && isset($field_info['sheet']['product']['field']['custom_image_title']['multi_store_status'])) {
						if ($data['store_id'] && $field_info['sheet']['product']['field']['custom_image_title']['multi_store'] && $field_info['sheet']['product']['field']['custom_image_title']['multi_store_status']) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_image_title = '' WHERE route='product_id=" . (int)$product['product_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						} else {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_image_title = '' WHERE route='product_id=" . (int)$product['product_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
						}
					}
										
					if (isset($data['sheet']['product']['field']['custom_image_alt']) && isset($product['custom_image_alt'][$language['language_id']]) && isset($field_info['sheet']['product']['field']['custom_image_alt']['multi_store']) && isset($field_info['sheet']['product']['field']['custom_image_alt']['multi_store_status'])) {
						if ($data['store_id'] && $field_info['sheet']['product']['field']['custom_image_alt']['multi_store'] && $field_info['sheet']['product']['field']['custom_image_alt']['multi_store_status']) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_image_alt = '' WHERE route='product_id=" . (int)$product['product_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						} else {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_image_alt = '' WHERE route='product_id=" . (int)$product['product_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
						}
					}
				}		
			}	
		}
		
		if (isset($data['sheet']['manufacturer']['field'])) {
			$field = array();
			$implode = array();
			
			if (isset($data['sheet']['manufacturer']['field']['meta_title']) && isset($field_info['sheet']['manufacturer']['field']['meta_title']['multi_store']) && isset($field_info['sheet']['manufacturer']['field']['meta_title']['multi_store_status'])) {
				$field = $data['sheet']['manufacturer']['field']['meta_title'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['manufacturer']['field']['meta_title']['multi_store'] && $field_info['sheet']['manufacturer']['field']['meta_title']['multi_store_status']) ? "md2.meta_title" : "md.meta_title";
			}
			
			if (isset($data['sheet']['manufacturer']['field']['meta_description']) && isset($field_info['sheet']['manufacturer']['field']['meta_description']['multi_store']) && isset($field_info['sheet']['manufacturer']['field']['meta_description']['multi_store_status'])) {
				$field = $data['sheet']['manufacturer']['field']['meta_description'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['manufacturer']['field']['meta_description']['multi_store'] && $field_info['sheet']['manufacturer']['field']['meta_description']['multi_store_status']) ? "md2.meta_description" : "md.meta_description";
			}
			
			if (isset($data['sheet']['manufacturer']['field']['meta_keyword']) && isset($field_info['sheet']['manufacturer']['field']['meta_keyword']['multi_store']) && isset($field_info['sheet']['manufacturer']['field']['meta_keyword']['multi_store_status'])) {
				$field = $data['sheet']['manufacturer']['field']['meta_keyword'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['manufacturer']['field']['meta_keyword']['multi_store'] && $field_info['sheet']['manufacturer']['field']['meta_keyword']['multi_store_status']) ? "md2.meta_keyword" : "md.meta_keyword";
			}
			
			if (isset($data['sheet']['manufacturer']['field']['custom_title_1']) && isset($field_info['sheet']['manufacturer']['field']['custom_title_1']['multi_store']) && isset($field_info['sheet']['manufacturer']['field']['custom_title_1']['multi_store_status'])) {
				$field = $data['sheet']['manufacturer']['field']['custom_title_1'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['manufacturer']['field']['custom_title_1']['multi_store'] && $field_info['sheet']['manufacturer']['field']['custom_title_1']['multi_store_status']) ? "md2.custom_title_1" : "md.custom_title_1";
			}
			
			if (isset($data['sheet']['manufacturer']['field']['custom_title_2']) && isset($field_info['sheet']['manufacturer']['field']['custom_title_2']['multi_store']) && isset($field_info['sheet']['manufacturer']['field']['custom_title_2']['multi_store_status'])) {
				$field = $data['sheet']['manufacturer']['field']['custom_title_2'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['manufacturer']['field']['custom_title_2']['multi_store'] && $field_info['sheet']['manufacturer']['field']['custom_title_2']['multi_store_status']) ? "md2.custom_title_2" : "md.custom_title_2";
			}
						
			if (isset($data['sheet']['manufacturer']['field']['custom_image_name'])) {
				$field = $data['sheet']['manufacturer']['field']['custom_image_name'];
				$implode[] = "m.image";
			}
			
			if (isset($data['sheet']['manufacturer']['field']['custom_image_title']) && isset($field_info['sheet']['manufacturer']['field']['custom_image_title']['multi_store']) && isset($field_info['sheet']['manufacturer']['field']['custom_image_title']['multi_store_status'])) {
				$field = $data['sheet']['manufacturer']['field']['custom_image_title'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['manufacturer']['field']['custom_image_title']['multi_store'] && $field_info['sheet']['manufacturer']['field']['custom_image_title']['multi_store_status']) ? "md2.custom_image_title" : "md.custom_image_title";
			}
			
			if (isset($data['sheet']['manufacturer']['field']['custom_image_alt']) && isset($field_info['sheet']['manufacturer']['field']['custom_image_alt']['multi_store']) && isset($field_info['sheet']['manufacturer']['field']['custom_image_alt']['multi_store_status'])) {
				$field = $data['sheet']['manufacturer']['field']['custom_image_alt'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['manufacturer']['field']['custom_image_alt']['multi_store'] && $field_info['sheet']['manufacturer']['field']['custom_image_alt']['multi_store_status']) ? "md2.custom_image_alt" : "md.custom_image_alt";
			}
						
			$manufacturers = array();
			
			if ($field) {				
				$query = $this->db->query("SELECT m.manufacturer_id, l.language_id, " . implode(', ', $implode) . " FROM " . DB_PREFIX . "manufacturer m CROSS JOIN " . DB_PREFIX . "language l LEFT JOIN " . DB_PREFIX . "d_meta_data md ON (md.route = CONCAT('manufacturer_id=', m.manufacturer_id) AND md.store_id = '0' AND md.language_id = l.language_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md2 ON (md2.route = CONCAT('manufacturer_id=', m.manufacturer_id) AND md2.store_id = '" . (int)$data['store_id'] . "' AND md2.language_id = l.language_id) GROUP BY m.manufacturer_id, l.language_id");
				
				foreach ($query->rows as $result) {
					$manufacturers[$result['manufacturer_id']]['manufacturer_id'] = $result['manufacturer_id'];
				
					foreach ($result as $field => $value) {
						if (($field != 'manufacturer_id') && ($field != 'language_id')) {
							$manufacturers[$result['manufacturer_id']][$field][$result['language_id']] = $value;
						}
					}
				}
			}
			
			foreach ($manufacturers as $manufacturer) {
				foreach ($languages as $language) {					
					if (isset($data['sheet']['manufacturer']['field']['custom_image_name']) && isset($manufacturer['image'][$language['language_id']]) && ($manufacturer['image'][$language['language_id']]) && ($language == reset($languages))) {
						$this->db->query("UPDATE " . DB_PREFIX . "manufacturer SET image = '' WHERE manufacturer_id = '" . (int)$manufacturer['manufacturer_id'] . "'");
					}
										
					if (isset($data['sheet']['manufacturer']['field']['meta_title']) && isset($manufacturer['meta_title'][$language['language_id']]) && isset($field_info['sheet']['manufacturer']['field']['meta_title']['multi_store']) && isset($field_info['sheet']['manufacturer']['field']['meta_title']['multi_store_status'])) {
						if ($data['store_id'] && $field_info['sheet']['manufacturer']['field']['meta_title']['multi_store'] && $field_info['sheet']['manufacturer']['field']['meta_title']['multi_store_status']) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET meta_title = '' WHERE route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						} else {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET meta_title = '' WHERE route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
						}
					}		
					
					if (isset($data['sheet']['manufacturer']['field']['meta_description']) && isset($manufacturer['meta_description'][$language['language_id']]) && isset($field_info['sheet']['manufacturer']['field']['meta_description']['multi_store']) && isset($field_info['sheet']['manufacturer']['field']['meta_description']['multi_store_status'])) {
						if ($data['store_id'] && $field_info['sheet']['manufacturer']['field']['meta_description']['multi_store'] && $field_info['sheet']['manufacturer']['field']['meta_description']['multi_store_status']) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET meta_description = '' WHERE route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						} else {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET meta_description = '' WHERE route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
						}
					}
					
					if (isset($data['sheet']['manufacturer']['field']['meta_keyword']) && isset($manufacturer['meta_keyword'][$language['language_id']]) && isset($field_info['sheet']['manufacturer']['field']['meta_keyword']['multi_store']) && isset($field_info['sheet']['manufacturer']['field']['meta_keyword']['multi_store_status'])) {
						if ($data['store_id'] && $field_info['sheet']['manufacturer']['field']['meta_keyword']['multi_store'] && $field_info['sheet']['manufacturer']['field']['meta_keyword']['multi_store_status']) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET meta_keyword = '' WHERE route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						} else {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET meta_keyword = '' WHERE route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
						}
					}
					
					if (isset($data['sheet']['manufacturer']['field']['custom_title_1']) && isset($manufacturer['custom_title_1'][$language['language_id']]) && isset($field_info['sheet']['manufacturer']['field']['custom_title_1']['multi_store']) && isset($field_info['sheet']['manufacturer']['field']['custom_title_1']['multi_store_status'])) {
						if ($data['store_id'] && $field_info['sheet']['manufacturer']['field']['custom_title_1']['multi_store'] && $field_info['sheet']['manufacturer']['field']['custom_title_1']['multi_store_status']) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_1 = '' WHERE route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						} else {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_1 = '' WHERE route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
						}
					}
					
					if (isset($data['sheet']['manufacturer']['field']['custom_title_2']) && isset($manufacturer['custom_title_2'][$language['language_id']]) && isset($field_info['sheet']['manufacturer']['field']['custom_title_2']['multi_store']) && isset($field_info['sheet']['manufacturer']['field']['custom_title_2']['multi_store_status'])) {
						if ($data['store_id'] && $field_info['sheet']['manufacturer']['field']['custom_title_2']['multi_store'] && $field_info['sheet']['manufacturer']['field']['custom_title_2']['multi_store_status']) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_2 = '' WHERE route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						} else {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_2 = '' WHERE route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
						}
					}
					
					if (isset($data['sheet']['manufacturer']['field']['custom_image_title']) && isset($manufacturer['custom_image_title'][$language['language_id']]) && isset($field_info['sheet']['manufacturer']['field']['custom_image_title']['multi_store']) && isset($field_info['sheet']['manufacturer']['field']['custom_image_title']['multi_store_status'])) {
						if ($data['store_id'] && $field_info['sheet']['manufacturer']['field']['custom_image_title']['multi_store'] && $field_info['sheet']['manufacturer']['field']['custom_image_title']['multi_store_status']) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_image_title = '' WHERE route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						} else {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_image_title = '' WHERE route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
						}
					}
					
					if (isset($data['sheet']['manufacturer']['field']['custom_image_alt']) && isset($manufacturer['custom_image_alt'][$language['language_id']]) && isset($field_info['sheet']['manufacturer']['field']['custom_image_alt']['multi_store']) && isset($field_info['sheet']['manufacturer']['field']['custom_image_alt']['multi_store_status'])) {
						if ($data['store_id'] && $field_info['sheet']['manufacturer']['field']['custom_image_alt']['multi_store'] && $field_info['sheet']['manufacturer']['field']['custom_image_alt']['multi_store_status']) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_image_alt = '' WHERE route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						} else {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_image_alt = '' WHERE route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
						}
					}
				}		
			}								
		}
		
		if (isset($data['sheet']['information']['field'])) {
			$field = array();
			$implode = array();
			
			if (isset($data['sheet']['information']['field']['meta_title']) && isset($field_info['sheet']['information']['field']['meta_title']['multi_store']) && isset($field_info['sheet']['information']['field']['meta_title']['multi_store_status'])) {
				$field = $data['sheet']['information']['field']['meta_title'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['information']['field']['meta_title']['multi_store'] && $field_info['sheet']['information']['field']['meta_title']['multi_store_status']) ? "md2.meta_title" : "id.meta_title";
			}
			
			if (isset($data['sheet']['information']['field']['meta_description']) && isset($field_info['sheet']['information']['field']['meta_description']['multi_store']) && isset($field_info['sheet']['information']['field']['meta_description']['multi_store_status'])) {
				$field = $data['sheet']['information']['field']['meta_description'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['information']['field']['meta_description']['multi_store'] && $field_info['sheet']['information']['field']['meta_description']['multi_store_status']) ? "md2.meta_description" : "id.meta_description";
			}
			
			if (isset($data['sheet']['information']['field']['meta_keyword']) && isset($field_info['sheet']['information']['field']['meta_keyword']['multi_store']) && isset($field_info['sheet']['information']['field']['meta_keyword']['multi_store_status'])) {
				$field = $data['sheet']['information']['field']['meta_keyword'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['information']['field']['meta_keyword']['multi_store'] && $field_info['sheet']['information']['field']['meta_keyword']['multi_store_status']) ? "md2.meta_keyword" : "id.meta_keyword";
			}
			
			if (isset($data['sheet']['information']['field']['custom_title_1']) && isset($field_info['sheet']['information']['field']['custom_title_1']['multi_store']) && isset($field_info['sheet']['information']['field']['custom_title_1']['multi_store_status'])) {
				$field = $data['sheet']['information']['field']['custom_title_1'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['information']['field']['custom_title_1']['multi_store'] && $field_info['sheet']['information']['field']['custom_title_1']['multi_store_status']) ? "md2.custom_title_1" : "md.custom_title_1";
			}
			
			if (isset($data['sheet']['information']['field']['custom_title_2']) && isset($field_info['sheet']['information']['field']['custom_title_2']['multi_store']) && isset($field_info['sheet']['information']['field']['custom_title_2']['multi_store_status'])) {
				$field = $data['sheet']['information']['field']['custom_title_2'];
				$implode[] = ($data['store_id'] && $field_info['sheet']['information']['field']['custom_title_2']['multi_store'] && $field_info['sheet']['information']['field']['custom_title_2']['multi_store_status']) ? "md2.custom_title_2" : "md.custom_title_2";
			}
						
			$informations = array();
			
			if ($field) {			
				$query = $this->db->query("SELECT id.information_id, id.language_id, " . implode(', ', $implode) . " FROM " . DB_PREFIX . "information i LEFT JOIN " . DB_PREFIX . "information_description id ON (id.information_id = i.information_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md ON (md.route = CONCAT('information_id=', i.information_id) AND md.store_id = '0' AND md.language_id = id.language_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md2 ON (md2.route = CONCAT('information_id=', i.information_id) AND md2.store_id = '" . (int)$data['store_id'] . "' AND md2.language_id = id.language_id) GROUP BY i.information_id, id.language_id");
			
				foreach ($query->rows as $result) {
					$informations[$result['information_id']]['information_id'] = $result['information_id'];
				
					foreach ($result as $field => $value) {
						if (($field != 'information_id') && ($field != 'language_id')) {
							$informations[$result['information_id']][$field][$result['language_id']] = $value;
						}
					}
				}
			}
												
			foreach ($informations as $information) {
				foreach ($languages as $language) {
					if (isset($data['sheet']['information']['field']['meta_title']) && isset($information['meta_title'][$language['language_id']]) && isset($field_info['sheet']['information']['field']['meta_title']['multi_store']) && isset($field_info['sheet']['information']['field']['meta_title']['multi_store_status'])) {
						if ($data['store_id'] && $field_info['sheet']['information']['field']['meta_title']['multi_store'] && $field_info['sheet']['information']['field']['meta_title']['multi_store_status']) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET meta_title = '' WHERE route='information_id=" . (int)$information['information_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						} else {
							$this->db->query("UPDATE " . DB_PREFIX . "information_description SET meta_title = '' WHERE information_id = '" . (int)$information['information_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						}
					}
										
					if (isset($data['sheet']['information']['field']['meta_description']) && isset($information['meta_description'][$language['language_id']]) && isset($field_info['sheet']['information']['field']['meta_description']['multi_store']) && isset($field_info['sheet']['information']['field']['meta_description']['multi_store_status'])) {
						if ($data['store_id'] && $field_info['sheet']['information']['field']['meta_description']['multi_store'] && $field_info['sheet']['information']['field']['meta_description']['multi_store_status']) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET meta_description = '' WHERE route='information_id=" . (int)$information['information_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						} else {
							$this->db->query("UPDATE " . DB_PREFIX . "information_description SET meta_description = '' WHERE information_id = '" . (int)$information['information_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						}
					}
					
					if (isset($data['sheet']['information']['field']['meta_keyword']) && isset($information['meta_keyword'][$language['language_id']]) && isset($field_info['sheet']['information']['field']['meta_keyword']['multi_store']) && isset($field_info['sheet']['information']['field']['meta_keyword']['multi_store_status'])) {
						if ($data['store_id'] && $field_info['sheet']['information']['field']['meta_keyword']['multi_store'] && $field_info['sheet']['information']['field']['meta_keyword']['multi_store_status']) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET meta_keyword = '' WHERE route='information_id=" . (int)$information['information_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						} else {
							$this->db->query("UPDATE " . DB_PREFIX . "information_description SET meta_keyword = '' WHERE information_id = '" . (int)$information['information_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						}
					}
					
					if (isset($data['sheet']['information']['field']['custom_title_1']) && isset($information['custom_title_1'][$language['language_id']]) && isset($field_info['sheet']['information']['field']['custom_title_1']['multi_store']) && isset($field_info['sheet']['information']['field']['custom_title_1']['multi_store_status'])) {
						if ($data['store_id'] && $field_info['sheet']['information']['field']['custom_title_1']['multi_store'] && $field_info['sheet']['information']['field']['custom_title_1']['multi_store_status']) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_1 = '' WHERE route='information_id=" . (int)$information['information_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						} else {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_1 = '' WHERE route='information_id=" . (int)$information['information_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
						}
					}
					
					if (isset($data['sheet']['information']['field']['custom_title_2']) && isset($information['custom_title_2'][$language['language_id']]) && isset($field_info['sheet']['information']['field']['custom_title_2']['multi_store']) && isset($field_info['sheet']['information']['field']['custom_title_2']['multi_store_status'])) {
						if ($data['store_id'] && $field_info['sheet']['information']['field']['custom_title_2']['multi_store'] && $field_info['sheet']['information']['field']['custom_title_2']['multi_store_status']) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_2 = '' WHERE route='information_id=" . (int)$information['information_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						} else {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET custom_title_2 = '' WHERE route='information_id=" . (int)$information['information_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
						}
					}
				}		
			}
		}
	}
		
	/*
	*	Replace Description.
	*/		
	private function replaceDescription($field_template, $description) {
		$field_template = preg_replace_callback('/\[description#sentences=([0-9]+)\]/', function($matches) use ($description) {
			$replacement_description = '';
			
			$sentence_total = $matches[1]; 
			
			$sentences = preg_split('/[.!?]/', htmlentities(strip_tags(html_entity_decode($description))));
			
			$i = 0;
				
			foreach ($sentences as $sentence) {
				$replacement_description .= $sentence . '.';
				
				$i++;
				
				if ($i >= $sentence_total) break;
			}
						
			return $replacement_description;
			
		}, $field_template);
		
		return $field_template;
	}
		
	/*
	*	Replace Sample Products.
	*/		
	private function replaceSampleProducts($field_template, $product_sample) {
		$field_template = preg_replace_callback('/\[sample_products#total=([0-9]+)#separator=(.+?)\]/', function ($matches) use ($product_sample) {
			$replacement_sample_products = '';
						
			$product_total = $matches[1];
			$product_separator = $matches[2]; 
			
			$sample_products = explode('|', $product_sample);
			
			$i = 0;
					
			foreach ($sample_products as $sample_product) {
				$replacement_sample_products .= $sample_product;
				
				$i++;
				
				if ($i >= $product_total) break;
				
				$replacement_sample_products .= $product_separator;
			}
						
			return $replacement_sample_products;
			
		}, $field_template);
		
		return $field_template;
	}
	
	/*
	*	Replace Target Keyword.
	*/		
	private function replaceTargetKeyword($field_template, $target_keyword) {
		$field_template = preg_replace_callback('/\[target_keyword#number=([0-9]+)\]/', function($matches) use ($target_keyword) {
			$replacement_target_keyword = '';
			
			$number = $matches[1];
				
			if (isset($target_keyword[$number])) {
				$replacement_target_keyword = $target_keyword[$number];
			}
						
			return $replacement_target_keyword;
			
		}, $field_template);
		
		return $field_template;
	}
}
?>