<?php
class ModelExtensionModuleDSEOModuleMeta extends Model {
	private $codename = 'd_seo_module_meta';
		
	/*
	*	Save SEO extensions.
	*/
	public function saveSEOExtensions($seo_extensions) {
		$this->load->model('setting/setting');
		
		$setting['d_seo_extension_install'] = $seo_extensions;
		
		$this->model_setting_setting->editSetting('d_seo_extension', $setting);
	}
	
	/*
	*	Return list of installed SEO extensions.
	*/
	public function getInstalledSEOExtensions() {
		$this->load->model('setting/setting');
				
		$installed_extensions = array();
		
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "extension ORDER BY code");
		
		foreach ($query->rows as $result) {
			$installed_extensions[] = $result['code'];
		}
		
		$installed_seo_extensions = $this->model_setting_setting->getSetting('d_seo_extension');
		$installed_seo_extensions = isset($installed_seo_extensions['d_seo_extension_install']) ? $installed_seo_extensions['d_seo_extension_install'] : array();
		
		$seo_extensions = array();
		
		$files = glob(DIR_APPLICATION . 'controller/extension/d_seo_module/*.php');
		
		if ($files) {
			foreach ($files as $file) {
				$seo_extension = basename($file, '.php');
				
				if (in_array($seo_extension, $installed_extensions) && in_array($seo_extension, $installed_seo_extensions)) {
					$seo_extensions[] = $seo_extension;
				}
			}
		}
		
		return $seo_extensions;
	}
	
	/*
	*	Return list of installed SEO Meta extensions.
	*/
	public function getInstalledSEOMetaExtensions() {
		$this->load->model('setting/setting');
				
		$installed_extensions = array();
		
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "extension ORDER BY code");
		
		foreach ($query->rows as $result) {
			$installed_extensions[] = $result['code'];
		}
		
		$installed_seo_extensions = $this->model_setting_setting->getSetting('d_seo_extension');
		$installed_seo_extensions = isset($installed_seo_extensions['d_seo_extension_install']) ? $installed_seo_extensions['d_seo_extension_install'] : array();
		
		$seo_meta_extensions = array();
		
		$files = glob(DIR_APPLICATION . 'controller/extension/' . $this->codename . '/*.php');
		
		if ($files) {
			foreach ($files as $file) {
				$seo_meta_extension = basename($file, '.php');
				
				if (in_array($seo_meta_extension, $installed_extensions) && in_array($seo_meta_extension, $installed_seo_extensions)) {
					$seo_meta_extensions[] = $seo_meta_extension;
				}
			}
		}
		
		return $seo_meta_extensions;
	}
			
	/*
	*	Return list of languages.
	*/
	public function getLanguages() {
		$this->load->model('localisation/language');
		
		$languages = $this->model_localisation_language->getLanguages();
		
		foreach ($languages as $key => $language) {
            if (VERSION >= '2.2.0.0') {
                $languages[$key]['flag'] = 'language/' . $language['code'] . '/' . $language['code'] . '.png';
            } else {
                $languages[$key]['flag'] = 'view/image/flags/' . $language['image'];
            }
        }
		
		return $languages;
	}
	
	/*
	*	Return list of stores.
	*/
	public function getStores() {
		$this->load->model('setting/store');
		
		$result = array();
		
		$result[] = array(
			'store_id' => 0, 
			'name' => $this->config->get('config_name')
		);
		
		$stores = $this->model_setting_store->getStores();
		
		if ($stores) {			
			foreach ($stores as $store) {
				$result[] = array(
					'store_id' => $store['store_id'],
					'name' => $store['name']	
				);
			}	
		}
		
		return $result;
	}
	
	/*
	*	Return store.
	*/
	public function getStore($store_id) {
		$this->load->model('setting/store');
		
		$result = array();
		
		if ($store_id == 0) {
			$result = array(
				'store_id' => 0, 
				'name' => $this->config->get('config_name'),
				'url' => HTTP_CATALOG,
				'ssl' => HTTPS_CATALOG
			);
		} else {
			$store = $this->model_setting_store->getStore($store_id);
			
			$result = array(
				'store_id' => $store['store_id'],
				'name' => $store['name'],
				'url' => $store['url'],
				'ssl' => $store['ssl']
			);
		}
				
		return $result;
	}
		
	/*
	*	Sort Array By Column.
	*/
	public function sortArrayByColumn($arr, $col, $dir = SORT_ASC) {
		$sort_col = array();
		$sort_key = array();
		
		foreach ($arr as $key => $row) {
			$sort_key[$key] = $key;
			
			if (isset($row[$col])) {
				$sort_col[$key] = $row[$col];
			} else {
				$sort_col[$key] = '';
			}
		}
		
		array_multisort($sort_col, $dir, $sort_key, SORT_ASC, $arr);
		
		return $arr;
	}
		
	/*
	*	Install.
	*/	
	public function installExtension() {
		$this->load->model('setting/setting');
		
		$stores = $this->getStores();
		$languages = $this->getLanguages();
		
		$custom_page_exception_routes = $this->load->controller('extension/module/d_seo_module_meta/getCustomPageExceptionRoutes');
				
		$this->db->query("CREATE TABLE IF NOT EXISTS " . DB_PREFIX . "d_meta_data (route VARCHAR(255) NOT NULL, store_id INT(11) NOT NULL, language_id INT(11) NOT NULL, name VARCHAR(255) NOT NULL, title VARCHAR(255) NOT NULL, description TEXT NOT NULL, meta_title VARCHAR(255) NOT NULL, meta_description TEXT NOT NULL, meta_keyword TEXT NOT NULL, tag TEXT NOT NULL, custom_title_1 VARCHAR(255) NOT NULL, custom_title_2 VARCHAR(255) NOT NULL, custom_image_title VARCHAR(255) NOT NULL, custom_image_alt VARCHAR(255) NOT NULL, meta_robots VARCHAR(32) NOT NULL DEFAULT 'index,follow', PRIMARY KEY (route, store_id, language_id)) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci");
		
		$add = '';
		
		if ($custom_page_exception_routes) {
			$add = " AND route NOT IN ('" . implode("', '", $custom_page_exception_routes) . "')";
		}
				
		$this->db->query("DELETE FROM " . DB_PREFIX . "d_meta_data WHERE route LIKE 'category_id=%' OR route LIKE 'product_id=%' OR route LIKE 'manufacturer_id=%' OR route LIKE 'information_id=%' OR (route LIKE '%/%'" . $add . ")");
						
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "category_description");
		
		foreach ($query->rows as $result) {
			foreach ($stores as $store) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route = 'category_id=" . (int)$result['category_id'] . "', store_id = '" . (int)$store['store_id'] . "', language_id='" . (int)$result['language_id'] . "'");
			}
		}
		
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_description");
		
		foreach ($query->rows as $result) {
			foreach ($stores as $store) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route = 'product_id=" . (int)$result['product_id'] . "', store_id = '" . (int)$store['store_id'] . "', language_id='" . (int)$result['language_id'] . "'");
			}
		}
		
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "manufacturer");
		
		foreach ($query->rows as $result) {
			foreach ($stores as $store) {
				foreach ($languages as $language) {
					if ($store['store_id']) {
						$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route = 'manufacturer_id=" . (int)$result['manufacturer_id'] . "', store_id = '" . (int)$store['store_id'] . "', language_id='" . (int)$language['language_id'] . "'");
					} else {
						$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route = 'manufacturer_id=" . (int)$result['manufacturer_id'] . "', store_id = '" . (int)$store['store_id'] . "', language_id='" . (int)$language['language_id'] . "', name = '" . $this->db->escape($result['name']) . "'");
					}
				}
			}
		}
		
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "information_description");
		
		foreach ($query->rows as $result) {
			foreach ($stores as $store) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route = 'information_id=" . (int)$result['information_id'] . "', store_id = '" . (int)$store['store_id'] . "', language_id='" . (int)$result['language_id'] . "'");
			}
		}
		
		foreach ($stores as $store) {
			$setting = $this->model_setting_setting->getSetting('config', $store['store_id']);
			
			$implode = array();
			
			if (isset($setting['config_meta_title'])) {
				$implode[] = "meta_title = '" . $this->db->escape($setting['config_meta_title']) . "'";
			}
			
			if (isset($setting['config_meta_description'])) {
				$implode[] = "meta_description = '" . $this->db->escape($setting['config_meta_description']) . "'";
			}
			
			if (isset($setting['config_meta_keyword'])) {
				$implode[] = "meta_keyword = '" . $this->db->escape($setting['config_meta_keyword']) . "'";
			}
			
			if ($implode) {
				foreach ($languages as $language) {
					$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route = 'common/home', store_id='" . (int)$store['store_id'] . "', language_id='" . (int)$language['language_id'] . "', " . implode(', ', $implode));
				}
			}
		}
	}
	
	/*
	*	Uninstall.
	*/
	public function uninstallExtension() {
		$custom_page_exception_routes = $this->load->controller('extension/module/d_seo_module_meta/getCustomPageExceptionRoutes');
		
		$add = '';
		
		if ($custom_page_exception_routes) {
			$add = " AND route NOT IN ('" . implode("', '", $custom_page_exception_routes) . "')";
		}
		
		$this->db->query("DELETE FROM " . DB_PREFIX . "d_meta_data WHERE route LIKE 'category_id=%' OR route LIKE 'product_id=%' OR route LIKE 'manufacturer_id=%' OR route LIKE 'information_id=%' OR (route LIKE '%/%'" . $add . ")");
	}
}
?>