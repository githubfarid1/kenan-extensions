<?php
class ModelExtensionDSEOModuleManagerDSEOModuleManager extends Model {
	private $codename = 'd_seo_module_manager';
	
	/*
	*	Return List Elements for Manager.
	*/
	public function getListElements($data) {			
		$url_token = '';
		
		if (isset($this->session->data['token'])) {
			$url_token .=  'token=' . $this->session->data['token'];
		}
		
		if (isset($this->session->data['user_token'])) {
			$url_token .=  'user_token=' . $this->session->data['user_token'];
		}
		
		$field_info = $this->load->controller('extension/module/d_seo_module/getFieldInfo');
				
		if ($data['sheet_code'] == 'category') {
			$implode = array();
			$implode[] = "c.category_id";
			
			foreach ($data['fields'] as $field) {				
				if (!(isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'])) {
					if ($field['code'] == 'name') {
						$implode[] = "cd.name";
					}
							
					if ($field['code'] == 'description') {
						$implode[] = "cd.description";
					}
				
					if ($field['code'] == 'meta_title') {
						$implode[] = "cd.meta_title";
					}
				
					if ($field['code'] == 'meta_description') {
						$implode[] = "cd.meta_description";
					}
				
					if ($field['code'] == 'meta_keyword') {
						$implode[] = "cd.meta_keyword";
					}
				}
			}
									
			$sql = "SELECT " . implode(', ', $implode) . " FROM " . DB_PREFIX . "category c LEFT JOIN " . DB_PREFIX . "category_description cd ON (cd.category_id = c.category_id AND cd.language_id = '" . (int)$data['language_id'] . "') LEFT JOIN " . DB_PREFIX . "category_description cd2 ON (cd2.category_id = c.category_id)";
			
			$implode = array();
			
			foreach ($data['filter'] as $field_code => $filter) {
				if (!empty($filter) && !(isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'])) {
					if ($field_code == 'category_id') {
						$implode[] = "c.category_id = '" . (int)($filter) . "'";
					}
					
					if ($field_code == 'name') {
						$implode[] = "cd2.name LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'description') {
						$implode[] = "cd2.description LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'meta_title') {
						$implode[] = "cd2.meta_title LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'meta_description') {
						$implode[] = "cd2.meta_description LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'meta_keyword') {
						$implode[] = "cd2.meta_keyword LIKE '%" . $this->db->escape($filter) . "%'";
					}
				}
			}
			
			if ($implode) {
				$sql .= " WHERE " . implode(' AND ', $implode);
			}

			$sql .= " GROUP BY c.category_id";
						
			$query = $this->db->query($sql);
			
			$categories = array();
			
			foreach ($query->rows as $result) {
				$categories[$result['category_id']] = $result;
				$categories[$result['category_id']]['link'] = $this->url->link('catalog/category/edit', $url_token . '&category_id=' . $result['category_id'], true);
			}

			return $categories;				
		}
		
		if ($data['sheet_code'] == 'product') {
			$implode = array();
			$implode[] = "p.product_id";
			
			foreach ($data['fields'] as $field) {
				if (!(isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'])) {
					if ($field['code'] == 'name') {
						$implode[] = "pd.name";
					}
				
					if ($field['code'] == 'description') {
						$implode[] = "pd.description";
					}
				
					if ($field['code'] == 'meta_title') {
						$implode[] = "pd.meta_title";
					}
				
					if ($field['code'] == 'meta_description') {
						$implode[] = "pd.meta_description";
					}
				
					if ($field['code'] == 'meta_keyword') {
						$implode[] = "pd.meta_keyword";
					}
				
					if ($field['code'] == 'tag') {
						$implode[] = "pd.tag";
					}
				}
			}
			
			$sql = "SELECT " . implode(', ', $implode) . " FROM " . DB_PREFIX . "product p LEFT JOIN " . DB_PREFIX . "product_description pd ON (pd.product_id = p.product_id AND pd.language_id = '" . (int)$data['language_id'] . "') LEFT JOIN " . DB_PREFIX . "product_description pd2 ON (pd2.product_id = p.product_id)";
			
			$implode = array();

			foreach ($data['filter'] as $field_code => $filter) {
				if (!empty($filter) && !(isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'])) {
					if ($field_code == 'product_id') {
						$implode[] = "p.product_id = '" . (int)($filter) . "'";
					}
					
					if ($field_code == 'name') {
						$implode[] = "pd2.name LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'description') {
						$implode[] = "pd2.description LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'meta_title') {
						$implode[] = "pd2.meta_title LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'meta_description') {
						$implode[] = "pd2.meta_description LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'meta_keyword') {
						$implode[] = "pd2.meta_keyword LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'tag') {
						$implode[] = "pd2.tag LIKE '%" . $this->db->escape($filter) . "%'";
					}
				}
			}
			
			if ($implode) {
				$sql .= " WHERE " . implode(' AND ', $implode);
			}

			$sql .= " GROUP BY p.product_id";
						
			$query = $this->db->query($sql);
			
			$products = array();
			
			foreach ($query->rows as $result) {
				$products[$result['product_id']] = $result;
				$products[$result['product_id']]['link'] = $this->url->link('catalog/product/edit', $url_token . '&product_id=' . $result['product_id'], true);
			}

			return $products;				
		}
		
		if ($data['sheet_code'] == 'manufacturer') {
			$implode = array();
			$implode[] = "m.manufacturer_id";
			
			foreach ($data['fields'] as $field) {
				if (!(isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && !(isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_language']) && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_language'])) {
					if ($field['code'] == 'name') {
						$implode[] = "m.name";
					}
				}
			}
			
			$sql = "SELECT " . implode(', ', $implode) . " FROM " . DB_PREFIX . "manufacturer m";
			
			$implode = array();
			
			foreach ($data['filter'] as $field_code => $filter) {
				if (!empty($filter) && !(isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && !(isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_language']) && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_language'])) {
					if ($field_code == 'manufacturer_id') {
						$implode[] = "m.manufacturer_id = '" . (int)($filter) . "'";
					}
					
					if ($field_code == 'name') {
						$implode[] = "m.name LIKE '%" . $this->db->escape($filter) . "%'";
					}
				}
			}
			
			if ($implode) {
				$sql .= " WHERE " . implode(' AND ', $implode);
			}

			$sql .= " GROUP BY m.manufacturer_id";
						
			$query = $this->db->query($sql);
			
			$manufacturers = array();
			
			foreach ($query->rows as $result) {
				$manufacturers[$result['manufacturer_id']] = $result;
				$manufacturers[$result['manufacturer_id']]['link'] = $this->url->link('catalog/manufacturer/edit', $url_token . '&manufacturer_id=' . $result['manufacturer_id'], true);
			}

			return $manufacturers;				
		}
		
		if ($data['sheet_code'] == 'information') {
			$implode = array();
			$implode[] = "i.information_id";
			
			foreach ($data['fields'] as $field) {
				if (!(isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'])) {
					if ($field['code'] == 'title') {
						$implode[] = "id.title";
					}
				
					if ($field['code'] == 'description') {
						$implode[] = "id.description";
					}
				
					if ($field['code'] == 'meta_title') {
						$implode[] = "id.meta_title";
					}
				
					if ($field['code'] == 'meta_description') {
						$implode[] = "id.meta_description";
					}
				
					if ($field['code'] == 'meta_keyword') {
						$implode[] = "id.meta_keyword";
					}
				}
			}
			
			$sql = "SELECT " . implode(', ', $implode) . " FROM " . DB_PREFIX . "information i LEFT JOIN " . DB_PREFIX . "information_description id ON (id.information_id = i.information_id AND id.language_id = '" . (int)$data['language_id'] . "') LEFT JOIN " . DB_PREFIX . "information_description id2 ON (id2.information_id = i.information_id)";
			
			$implode = array();
			
			foreach ($data['filter'] as $field_code => $filter) {
				if (!empty($filter) && !(isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'])) {
					if ($field_code == 'information_id') {
						$implode[] = "i.information_id = '" . (int)($filter) . "'";
					}
					
					if ($field_code == 'title') {
						$implode[] = "id2.title LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'description') {
						$implode[] = "id2.description LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'meta_title') {
						$implode[] = "id2.meta_title LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'meta_description') {
						$implode[] = "id2.meta_description LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'meta_keyword') {
						$implode[] = "id2.meta_keyword LIKE '%" . $this->db->escape($filter) . "%'";
					}
				}
			}
			
			if ($implode) {
				$sql .= " WHERE " . implode(' AND ', $implode);
			}

			$sql .= " GROUP BY i.information_id";
						
			$query = $this->db->query($sql);
			
			$informations = array();
			
			foreach ($query->rows as $result) {
				$informations[$result['information_id']] = $result;
				$informations[$result['information_id']]['link'] = $this->url->link('catalog/information/edit', $url_token . '&information_id=' . $result['information_id'], true);
			}

			return $informations;				
		}
	}
	
	/*
	*	Edit Element Field for Manager.
	*/
	public function editElementField($element) {				
		$field_info = $this->load->controller('extension/module/d_seo_module/getFieldInfo');
				
		if ($element['sheet_code'] == 'category') {
			if ((($element['field_code'] == 'name') || ($element['field_code'] == 'description') || ($element['field_code'] == 'meta_title') || ($element['field_code'] == 'meta_description') || ($element['field_code'] == 'meta_keyword')) && !(isset($field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store']) && $field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store'])) {
				$this->db->query("UPDATE " . DB_PREFIX . "category_description SET " . $this->db->escape($element['field_code']) . " = '" . $this->db->escape($element['value']) . "' WHERE category_id = '" . (int)$element['element_id'] . "' AND language_id = '" . (int)$element['language_id'] . "'");
			}
		}
		
		if ($element['sheet_code'] == 'product') {
			if ((($element['field_code'] == 'name') || ($element['field_code'] == 'description') || ($element['field_code'] == 'meta_title') || ($element['field_code'] == 'meta_description') || ($element['field_code'] == 'meta_keyword') || ($element['field_code'] == 'tag')) && !(isset($field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store']) && $field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store'])) {
				$this->db->query("UPDATE " . DB_PREFIX . "product_description SET " . $this->db->escape($element['field_code']) . " = '" . $this->db->escape($element['value']) . "' WHERE product_id = '" . (int)$element['element_id'] . "' AND language_id = '" . (int)$element['language_id'] . "'");
			}
		}
		
		if ($element['sheet_code'] == 'manufacturer') {
			if (($element['field_code'] == 'name') && !(isset($field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store']) && $field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store'])) {
				$this->db->query("UPDATE " . DB_PREFIX . "manufacturer SET " . $this->db->escape($element['field_code']) . " = '" . $this->db->escape($element['value']) . "' WHERE manufacturer_id = '" . (int)$element['element_id'] . "'");
			}
		}
		
		if ($element['sheet_code'] == 'information') {
			if ((($element['field_code'] == 'title') || ($element['field_code'] == 'description') || ($element['field_code'] == 'meta_title') || ($element['field_code'] == 'meta_description') || ($element['field_code'] == 'meta_keyword')) && !(isset($field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store']) && $field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store'])) {
				$this->db->query("UPDATE " . DB_PREFIX . "information_description SET " . $this->db->escape($element['field_code']) . " = '" . $this->db->escape($element['value']) . "' WHERE information_id = '" . (int)$element['element_id'] . "' AND language_id = '" . (int)$element['language_id'] . "'");
			}
		}
	}
	
	/*
	*	Return Export Elements for Manager.
	*/
	public function getExportElements($data) {
		$this->load->model('extension/module/' . $this->codename);
		
		$languages = $this->{'model_extension_module_' . $this->codename}->getLanguages();
		
		$field_info = $this->load->controller('extension/module/d_seo_module/getFieldInfo');
				
		if ($data['sheet_code'] == 'category') {
			$categories = array();												
			$implode = array();
			
			foreach ($data['fields'] as $field) {
				if (!(isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'])) {
					if ($field['code'] == 'name') {
						$implode[] = "cd.name";
					}
				
					if ($field['code'] == 'description') {
						$implode[] = "cd.description";
					}
				
					if ($field['code'] == 'meta_title') {
						$implode[] = "cd.meta_title";
					}
				
					if ($field['code'] == 'meta_description') {
						$implode[] = "cd.meta_description";
					}
				
					if ($field['code'] == 'meta_keyword') {
						$implode[] = "cd.meta_keyword";
					}
				}
			}
			
			if ($implode) {
				$query = $this->db->query("SELECT cd.category_id, cd.language_id, " . implode(', ', $implode) . " FROM " . DB_PREFIX . "category_description cd");
				
				foreach ($query->rows as $result) {
					$categories[$result['category_id']]['category_id'] = $result['category_id'];
					
					foreach ($result as $field => $value) {
						if (($field != 'category_id') && ($field != 'language_id')) {
							$categories[$result['category_id']][$field][$result['language_id']] = $value;
						}
					}
				}
			}
			
			return $categories;				
		}
		
		if ($data['sheet_code'] == 'product') {
			$products = array();			
			$implode = array();
						
			foreach ($data['fields'] as $field) {
				if (!(isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'])) {
					if ($field['code'] == 'name') {
						$implode[] = "pd.name";
					}
				
					if ($field['code'] == 'description') {
						$implode[] = "pd.description";
					}
				
					if ($field['code'] == 'meta_title') {
						$implode[] = "pd.meta_title";
					}
				
					if ($field['code'] == 'meta_description') {
						$implode[] = "pd.meta_description";
					}
				
					if ($field['code'] == 'meta_keyword') {
						$implode[] = "pd.meta_keyword";
					}
				
					if ($field['code'] == 'tag') {
						$implode[] = "pd.tag";
					}
				}
			}
			
			if ($implode) {
				$query = $this->db->query("SELECT pd.product_id, pd.language_id, " . implode(', ', $implode) . " FROM " . DB_PREFIX . "product_description pd");
		
				foreach ($query->rows as $result) {
					$products[$result['product_id']]['product_id'] = $result['product_id'];
					
					foreach ($result as $field => $value) {
						if (($field != 'product_id') && ($field != 'language_id')) {
							$products[$result['product_id']][$field][$result['language_id']] = $value;
						}
					}
				}
			}

			return $products;				
		}
		
		if ($data['sheet_code'] == 'manufacturer') {
			$manufacturers = array();
			$implode = array();
						
			foreach ($data['fields'] as $field) {
				if (!(isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && !(isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_language']) && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_language'])) {
					if ($field['code'] == 'name') {
						$implode[] = "m.name";
					}
				}
			}
			
			if ($implode) {
				$query = $this->db->query("SELECT m.manufacturer_id, " . implode(', ', $implode) . " FROM " . DB_PREFIX . "manufacturer m");
						
				foreach ($query->rows as $result) {
					$manufacturers[$result['manufacturer_id']] = $result;
				}
			}

			return $manufacturers;				
		}
		
		if ($data['sheet_code'] == 'information') {
			$informations = array();			
			$implode = array();
						
			foreach ($data['fields'] as $field) {
				if (!(isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'])) {
					if ($field['code'] == 'title') {
						$implode[] = "id.title";
					}
				
					if ($field['code'] == 'description') {
						$implode[] = "id.description";
					}
				
					if ($field['code'] == 'meta_title') {
						$implode[] = "id.meta_title";
					}
				
					if ($field['code'] == 'meta_description') {
						$implode[] = "id.meta_description";
					}
				
					if ($field['code'] == 'meta_keyword') {
						$implode[] = "id.meta_keyword";
					}
				}
			}
			
			if ($implode) {
				$query = $this->db->query("SELECT id.information_id, id.language_id, " . implode(', ', $implode) . " FROM " . DB_PREFIX . "information_description id");
		
				foreach ($query->rows as $result) {
					$informations[$result['information_id']]['information_id'] = $result['information_id'];
					
					foreach ($result as $field => $value) {
						if (($field != 'information_id') && ($field != 'language_id')) {
							$informations[$result['information_id']][$field][$result['language_id']] = $value;
						}
					}
				}
			}
			
			return $informations;				
		}
	}
	
	/*
	*	Save Import Elements for Manager.
	*/
	public function saveImportElements($data) {
		$this->load->model('extension/module/' . $this->codename);
		
		$languages = $this->{'model_extension_module_' . $this->codename}->getLanguages();
		
		$field_info = $this->load->controller('extension/module/d_seo_module/getFieldInfo');
				
		if ($data['sheet_code'] == 'category') {
			$categories = array();
			$implode = array();
						
			foreach ($data['fields'] as $field) {
				if (!(isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'])) {
					if ($field['code'] == 'name') {
						$implode[] = "cd.name";
					}
				
					if ($field['code'] == 'description') {
						$implode[] = "cd.description";
					}
				
					if ($field['code'] == 'meta_title') {
						$implode[] = "cd.meta_title";
					}
				
					if ($field['code'] == 'meta_description') {
						$implode[] = "cd.meta_description";
					}
				
					if ($field['code'] == 'meta_keyword') {
						$implode[] = "cd.meta_keyword";
					}
				}
			}
			
			if ($implode) {
				$query = $this->db->query("SELECT cd.category_id, cd.language_id, " . implode(', ', $implode) . " FROM " . DB_PREFIX . "category_description cd");
				
				foreach ($query->rows as $result) {
					$categories[$result['category_id']]['category_id'] = $result['category_id'];
					
					foreach ($result as $field => $value) {
						if (($field != 'category_id') && ($field != 'language_id')) {
							$categories[$result['category_id']][$field][$result['language_id']] = $value;
						}
					}
				}
			}
			
			foreach ($data['elements'] as $element) {
				if (isset($categories[$element['category_id']])) {
					$category = $categories[$element['category_id']];
					
					foreach ($languages as $language) {
						$implode = array();
						
						if (isset($element['name'][$language['language_id']]) && isset($category['name'][$language['language_id']])) {
							if ($element['name'][$language['language_id']] != $category['name'][$language['language_id']]) {
								$implode[] = "name = '" . $this->db->escape($element['name'][$language['language_id']]) . "'";
							}
						}
						
						if (isset($element['description'][$language['language_id']]) && isset($category['description'][$language['language_id']])) {
							if ($element['description'][$language['language_id']] != $category['description'][$language['language_id']]) {
								$implode[] = "description = '" . $this->db->escape($element['description'][$language['language_id']]) . "'";
							}
						}
						
						if (isset($element['meta_title'][$language['language_id']]) && isset($category['meta_title'][$language['language_id']])) {
							if ($element['meta_title'][$language['language_id']] != $category['meta_title'][$language['language_id']]) {
								$implode[] = "meta_title = '" . $this->db->escape($element['meta_title'][$language['language_id']]) . "'";
							}
						}
						
						if (isset($element['meta_description'][$language['language_id']]) && isset($category['meta_description'][$language['language_id']])) {
							if ($element['meta_description'][$language['language_id']] != $category['meta_description'][$language['language_id']]) {
								$implode[] = "meta_description = '" . $this->db->escape($element['meta_description'][$language['language_id']]) . "'";
							}
						}
						
						if (isset($element['meta_keyword'][$language['language_id']]) && isset($category['meta_keyword'][$language['language_id']])) {
							if ($element['meta_keyword'][$language['language_id']] != $category['meta_keyword'][$language['language_id']]) {
								$implode[] = "meta_keyword = '" . $this->db->escape($element['meta_keyword'][$language['language_id']]) . "'";
							}
						}
						
						if ($implode) {
							$this->db->query("UPDATE " . DB_PREFIX . "category_description SET " . implode(', ', $implode) . " WHERE category_id = '" . (int)$category['category_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						}
					}
				}		
			}
		}
		
		if ($data['sheet_code'] == 'product') {
			$products = array();				
			$implode = array();
						
			foreach ($data['fields'] as $field) {
				if (!(isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'])) {
					if ($field['code'] == 'name') {
						$implode[] = "pd.name";
					}
				
					if ($field['code'] == 'description') {
						$implode[] = "pd.description";
					}
				
					if ($field['code'] == 'meta_title') {
						$implode[] = "pd.meta_title";
					}
				
					if ($field['code'] == 'meta_description') {
						$implode[] = "pd.meta_description";
					}
				
					if ($field['code'] == 'meta_keyword') {
						$implode[] = "pd.meta_keyword";
					}
				
					if ($field['code'] == 'tag') {
						$implode[] = "pd.tag";
					}
				}
			}
			
			if ($implode) {
				$query = $this->db->query("SELECT pd.product_id, pd.language_id, " . implode(', ', $implode) . " FROM " . DB_PREFIX . "product_description pd");
		
				foreach ($query->rows as $result) {
					$products[$result['product_id']]['product_id'] = $result['product_id'];
					
					foreach ($result as $field => $value) {
						if (($field != 'product_id') && ($field != 'language_id')) {
							$products[$result['product_id']][$field][$result['language_id']] = $value;
						}
					}
				}
			}
			
			foreach ($data['elements'] as $element) {
				if (isset($products[$element['product_id']])) {
					$product = $products[$element['product_id']];
					
					foreach ($languages as $language) {
						$implode = array();
						
						if (isset($element['name'][$language['language_id']]) && isset($product['name'][$language['language_id']])) {
							if ($element['name'][$language['language_id']] != $product['name'][$language['language_id']]) {
								$implode[] = "name = '" . $this->db->escape($element['name'][$language['language_id']]) . "'";
							}
						}
						
						if (isset($element['description'][$language['language_id']]) && isset($product['description'][$language['language_id']])) {
							if ($element['description'][$language['language_id']] != $product['description'][$language['language_id']]) {
								$implode[] = "description = '" . $this->db->escape($element['description'][$language['language_id']]) . "'";
							}
						}
						
						if (isset($element['meta_title'][$language['language_id']]) && isset($product['meta_title'][$language['language_id']])) {
							if ($element['meta_title'][$language['language_id']] != $product['meta_title'][$language['language_id']]) {
								$implode[] = "meta_title = '" . $this->db->escape($element['meta_title'][$language['language_id']]) . "'";
							}
						}
						
						if (isset($element['meta_description'][$language['language_id']]) && isset($product['meta_description'][$language['language_id']])) {
							if ($element['meta_description'][$language['language_id']] != $product['meta_description'][$language['language_id']]) {
								$implode[] = "meta_description = '" . $this->db->escape($element['meta_description'][$language['language_id']]) . "'";
							}
						}
						
						if (isset($element['meta_keyword'][$language['language_id']]) && isset($product['meta_keyword'][$language['language_id']])) {
							if ($element['meta_keyword'][$language['language_id']] != $product['meta_keyword'][$language['language_id']]) {
								$implode[] = "meta_keyword = '" . $this->db->escape($element['meta_keyword'][$language['language_id']]) . "'";
							}
						}
						
						if (isset($element['tag'][$language['language_id']]) && isset($product['tag'][$language['language_id']])) {
							if ($element['tag'][$language['language_id']] != $product['tag'][$language['language_id']]) {
								$implode[] = "tag = '" . $this->db->escape($element['tag'][$language['language_id']]) . "'";
							}
						}
						
						if ($implode) {
							$this->db->query("UPDATE " . DB_PREFIX . "product_description SET " . implode(', ', $implode) . " WHERE product_id = '" . (int)$product['product_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						}
					}
				}	
			}			
		}
		
		if ($data['sheet_code'] == 'manufacturer') {
			$manufacturers = array();
			$implode = array();
						
			foreach ($data['fields'] as $field) {
				if (!(isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && !(isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_language']) && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_language'])) {
					if ($field['code'] == 'name') {
						$implode[] = "m.name";
					}
				}
			}
			
			if ($implode) {
				$query = $this->db->query("SELECT m.manufacturer_id, " . implode(', ', $implode) . " FROM " . DB_PREFIX . "manufacturer m");
						
				foreach ($query->rows as $result) {
					$manufacturers[$result['manufacturer_id']] = $result;
				}
			}
			
			foreach ($data['elements'] as $element) {
				if (isset($manufacturers[$element['manufacturer_id']])) {
					$manufacturer = $manufacturers[$element['manufacturer_id']];
					
					if (isset($element['name']) && isset($manufacturer['name'])) {
						$implode = array();
						
						if ($element['name'] != $manufacturer['name']) {
							$implode[] = "name = '" . $this->db->escape($element['name']) . "'";
						}
						
						if ($implode) {
							$this->db->query("UPDATE " . DB_PREFIX . "manufacturer SET " . implode(', ', $implode) . " WHERE manufacturer_id = '" . (int)$manufacturer['manufacturer_id'] . "'");
						}
					}
				}	
			}			
		}
		
		if ($data['sheet_code'] == 'information') {
			$informations = array();			
			$implode = array();
						
			foreach ($data['fields'] as $field) {
				if (!(isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'])) {
					if ($field['code'] == 'title') {
						$implode[] = "id.title";
					}
				
					if ($field['code'] == 'description') {
						$implode[] = "id.description";
					}
				
					if ($field['code'] == 'meta_title') {
						$implode[] = "id.meta_title";
					}
				
					if ($field['code'] == 'meta_description') {
						$implode[] = "id.meta_description";
					}
				
					if ($field['code'] == 'meta_keyword') {
						$implode[] = "id.meta_keyword";
					}
				}
			}
			
			if ($implode) {
				$query = $this->db->query("SELECT id.information_id, id.language_id, " . implode(', ', $implode) . " FROM " . DB_PREFIX . "information_description id");
		
				foreach ($query->rows as $result) {
					$informations[$result['information_id']]['information_id'] = $result['information_id'];
					
					foreach ($result as $field => $value) {
						if (($field != 'information_id') && ($field != 'language_id')) {
							$informations[$result['information_id']][$field][$result['language_id']] = $value;
						}
					}
				}
			}
			
			foreach ($data['elements'] as $element) {
				if (isset($informations[$element['information_id']])) {
					$information = $informations[$element['information_id']];
					
					foreach ($languages as $language) {
						$implode = array();
						
						if (isset($element['title'][$language['language_id']]) && isset($information['title'][$language['language_id']])) {
							if ($element['title'][$language['language_id']] != $information['title'][$language['language_id']]) {
								$implode[] = "title = '" . $this->db->escape($element['title'][$language['language_id']]) . "'";
							}
						}
						
						if (isset($element['description'][$language['language_id']]) && isset($information['description'][$language['language_id']])) {
							if ($element['description'][$language['language_id']] != $information['description'][$language['language_id']]) {
								$implode[] = "description = '" . $this->db->escape($element['description'][$language['language_id']]) . "'";
							}
						}
						
						if (isset($element['meta_title'][$language['language_id']]) && isset($information['meta_title'][$language['language_id']])) {
							if ($element['meta_title'][$language['language_id']] != $information['meta_title'][$language['language_id']]) {
								$implode[] = "meta_title = '" . $this->db->escape($element['meta_title'][$language['language_id']]) . "'";
							}
						}
						
						if (isset($element['meta_description'][$language['language_id']]) && isset($information['meta_description'][$language['language_id']])) {
							if ($element['meta_description'][$language['language_id']] != $information['meta_description'][$language['language_id']]) {
								$implode[] = "meta_description = '" . $this->db->escape($element['meta_description'][$language['language_id']]) . "'";
							}
						}
						
						if (isset($element['meta_keyword'][$language['language_id']]) && isset($information['meta_keyword'][$language['language_id']])) {
							if ($element['meta_keyword'][$language['language_id']] != $information['meta_keyword'][$language['language_id']]) {
								$implode[] = "meta_keyword = '" . $this->db->escape($element['meta_keyword'][$language['language_id']]) . "'";
							}
						}
						
						if ($implode) {
							$this->db->query("UPDATE " . DB_PREFIX . "information_description SET " . implode(', ', $implode) . " WHERE information_id = '" . (int)$information['information_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						}
					}
				}	
			}	
		}
	}
}
?>