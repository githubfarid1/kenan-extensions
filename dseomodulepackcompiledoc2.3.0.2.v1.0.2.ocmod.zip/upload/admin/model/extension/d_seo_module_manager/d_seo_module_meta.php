<?php
class ModelExtensionDSEOModuleManagerDSEOModuleMeta extends Model {
	private $codename = 'd_seo_module_meta';
	
	/*
	*	Return List Elements for Manager.
	*/
	public function getListElements($data) {		
		$field_info = $this->load->controller('extension/module/d_seo_module/getFieldInfo');
				
		if ($data['sheet_code'] == 'category') {
			$implode = array();
			$implode[] = "c.category_id";
						
			foreach ($data['fields'] as $field) {
				if (isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status'])) {
					if ($field['code'] == 'name') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.name" : "cd.name";
					}
							
					if ($field['code'] == 'description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.description" : "cd.description";
					}
				
					if ($field['code'] == 'meta_title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_title" : "cd.meta_title";
					}
				
					if ($field['code'] == 'meta_description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_description" : "cd.meta_description";
					}
				
					if ($field['code'] == 'meta_keyword') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_keyword" : "cd.meta_keyword";
					}
					
					if ($field['code'] == 'custom_title_1') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_title_1" : "md.custom_title_1";
					}

					if ($field['code'] == 'custom_title_2') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_title_2" : "md.custom_title_2";
					}

					if ($field['code'] == 'custom_image_title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_image_title" : "md.custom_image_title";
					}

					if ($field['code'] == 'custom_image_alt') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_image_alt" : "md.custom_image_alt";
					}
					
					if ($field['code'] == 'meta_robots') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_robots" : "md.meta_robots";
					}
				}
			}
					
			$sql = "SELECT " . implode(', ', $implode) . " FROM " . DB_PREFIX . "category c LEFT JOIN " . DB_PREFIX . "category_description cd ON (cd.category_id = c.category_id AND cd.language_id = '" . (int)$data['language_id'] . "') LEFT JOIN " . DB_PREFIX . "d_meta_data md ON (md.route = CONCAT('category_id=', c.category_id) AND md.store_id = '0' AND md.language_id = '" . (int)$data['language_id'] . "') LEFT JOIN " . DB_PREFIX . "d_meta_data md2 ON (md2.route = CONCAT('category_id=', c.category_id) AND md2.store_id = '" . (int)$data['store_id'] . "' AND md2.language_id = '" . (int)$data['language_id'] . "') LEFT JOIN " . DB_PREFIX . "category_description cd2 ON (cd2.category_id = c.category_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md3 ON (md3.route = CONCAT('category_id=', c.category_id) AND md3.store_id = '0') LEFT JOIN " . DB_PREFIX . "d_meta_data md4 ON (md4.route = CONCAT('category_id=', c.category_id) AND md4.store_id = '" . (int)$data['store_id'] . "')";
			
			$implode = array();
			
			foreach ($data['filter'] as $field_code => $filter) {
				if (!empty($filter) && isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status'])) {
					if ($field_code == 'name') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.name LIKE '%" . $this->db->escape($filter) . "%'" : "cd2.name LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.description LIKE '%" . $this->db->escape($filter) . "%'" : "cd2.description LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'meta_title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.meta_title LIKE '%" . $this->db->escape($filter) . "%'" : "cd2.meta_title LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'meta_description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.meta_description LIKE '%" . $this->db->escape($filter) . "%'" : "cd2.meta_description LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'meta_keyword') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.meta_keyword LIKE '%" . $this->db->escape($filter) . "%'" : "cd2.meta_keyword LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'custom_title_1') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.custom_title_1 LIKE '%" . $this->db->escape($filter) . "%'" : "md3.custom_title_1 LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'custom_title_2') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.custom_title_2 LIKE '%" . $this->db->escape($filter) . "%'" : "md3.custom_title_2 LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'custom_image_title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.custom_image_title LIKE '%" . $this->db->escape($filter) . "%'" : "md3.custom_image_title LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'custom_image_alt') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.custom_image_alt LIKE '%" . $this->db->escape($filter) . "%'" : "md3.custom_image_alt LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'meta_robots') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.meta_robots LIKE '%" . $this->db->escape($filter) . "%'" : "md3.meta_robots LIKE '%" . $this->db->escape($filter) . "%'";
					}
				}
			}
			
			if ($implode) {
				$sql .= " WHERE " . implode(' AND ', $implode);
			}

			$sql .= " GROUP BY c.category_id";
			
			$query = $this->db->query($sql);
			
			$categories = array();
			
			foreach ($query->rows as $result) {
				$categories[$result['category_id']] = $result;
			}

			return $categories;	
		}
		
		if ($data['sheet_code'] == 'product') {
			$implode = array();
			$implode[] = "p.product_id";
						
			foreach ($data['fields'] as $field) {
				if (isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status'])) {
					if ($field['code'] == 'name') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.name" : "pd.name";
					}
				
					if ($field['code'] == 'description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.description" : "pd.description";
					}
				
					if ($field['code'] == 'meta_title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_title" : "pd.meta_title";
					}
				
					if ($field['code'] == 'meta_description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_description" : "pd.meta_description";
					}
				
					if ($field['code'] == 'meta_keyword') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_keyword" : "pd.meta_keyword";
					}
				
					if ($field['code'] == 'tag') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.tag" : "pd.tag";
					}
					
					if ($field['code'] == 'custom_title_1') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_title_1" : "md.custom_title_1";
					}
				
					if ($field['code'] == 'custom_title_2') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_title_2" : "md.custom_title_2";
					}
				
					if ($field['code'] == 'custom_image_title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_image_title" : "md.custom_image_title";
					}
				
					if ($field['code'] == 'custom_image_alt') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_image_alt" : "md.custom_image_alt";
					}
				
					if ($field['code'] == 'meta_robots') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_robots" : "md.meta_robots";
					}
				}
			}
		
			$sql = "SELECT " . implode(', ', $implode) . " FROM " . DB_PREFIX . "product p LEFT JOIN " . DB_PREFIX . "product_description pd ON (pd.product_id = p.product_id AND pd.language_id = '" . (int)$data['language_id'] . "') LEFT JOIN " . DB_PREFIX . "d_meta_data md ON (md.route = CONCAT('product_id=', p.product_id) AND md.store_id = '0' AND md.language_id = '" . (int)$data['language_id'] . "') LEFT JOIN " . DB_PREFIX . "d_meta_data md2 ON (md2.route = CONCAT('product_id=', p.product_id) AND md2.store_id = '" . (int)$data['store_id'] . "' AND md2.language_id = '" . (int)$data['language_id'] . "') LEFT JOIN " . DB_PREFIX . "product_description pd2 ON (pd2.product_id = p.product_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md3 ON (md3.route = CONCAT('product_id=', p.product_id) AND md3.store_id = '0') LEFT JOIN " . DB_PREFIX . "d_meta_data md4 ON (md4.route = CONCAT('product_id=', p.product_id) AND md4.store_id = '" . (int)$data['store_id'] . "')";
			
			$implode = array();
			
			foreach ($data['filter'] as $field_code => $filter) {
				if (!empty($filter) && isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status'])) {
					if ($field_code == 'name') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.name LIKE '%" . $this->db->escape($filter) . "%'" : "pd2.name LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.description LIKE '%" . $this->db->escape($filter) . "%'" : "pd2.description LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'meta_title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.meta_title LIKE '%" . $this->db->escape($filter) . "%'" : "pd2.meta_title LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'meta_description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.meta_description LIKE '%" . $this->db->escape($filter) . "%'" : "pd2.meta_description LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'meta_keyword') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.meta_keyword LIKE '%" . $this->db->escape($filter) . "%'" : "pd2.meta_keyword LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'tag') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.tag LIKE '%" . $this->db->escape($filter) . "%'" : "pd2.tag LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'custom_title_1') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.custom_title_1 LIKE '%" . $this->db->escape($filter) . "%'" : "md3.custom_title_1 LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'custom_title_2') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.custom_title_2 LIKE '%" . $this->db->escape($filter) . "%'" : "md3.custom_title_2 LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'custom_image_title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.custom_image_title LIKE '%" . $this->db->escape($filter) . "%'" : "md3.custom_image_title LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'custom_image_alt') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.custom_image_alt LIKE '%" . $this->db->escape($filter) . "%'" : "md3.custom_image_alt LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'meta_robots') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.meta_robots LIKE '%" . $this->db->escape($filter) . "%'" : "md3.meta_robots LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'category_id') {
						$implode[] = "pc.category_id = '" . $this->db->escape($filter) . "'";
					}
					
					if ($field_code == 'url_keyword') {
						$implode[] = "uk2.keyword LIKE '%" . $this->db->escape($filter) . "%'";
					}
				}
			}
			
			if ($implode) {
				$sql .= " WHERE " . implode(' AND ', $implode);
			}

			$sql .= " GROUP BY p.product_id";
			
			$query = $this->db->query($sql);
			
			$products = array();
			
			foreach ($query->rows as $result) {
				$products[$result['product_id']] = $result;
			}

			return $products;	
		}
		
		if ($data['sheet_code'] == 'manufacturer') {
			$implode = array();
			$implode[] = "m.manufacturer_id";
			
			foreach ($data['fields'] as $field) {
				if (isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status'])) {
					if ($field['code'] == 'name') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.name" : "md.name";
					}
					
					if ($field['code'] == 'description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.description" : "md.description";
					}
				
					if ($field['code'] == 'meta_title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_title" : "md.meta_title";
					}
				
					if ($field['code'] == 'meta_description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_description" : "md.meta_description";
					}
				
					if ($field['code'] == 'meta_keyword') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_keyword" : "md.meta_keyword";
					}
				
					if ($field['code'] == 'custom_title_1') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_title_1" : "md.custom_title_1";
					}
					
					if ($field['code'] == 'custom_title_2') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_title_2" : "md.custom_title_2";
					}
					
					if ($field['code'] == 'custom_image_title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_image_title" : "md.custom_image_title";
					}
					
					if ($field['code'] == 'custom_image_alt') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_image_alt" : "md.custom_image_alt";
					}
				
					if ($field['code'] == 'meta_robots') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_robots" : "md.meta_robots";
					}
				}
			}
		
			$sql = "SELECT " . implode(', ', $implode) . " FROM " . DB_PREFIX . "manufacturer m LEFT JOIN " . DB_PREFIX . "d_meta_data md ON (md.route = CONCAT('manufacturer_id=', m.manufacturer_id) AND md.store_id = '0' AND md.language_id = '" . (int)$data['language_id'] . "') LEFT JOIN " . DB_PREFIX . "d_meta_data md2 ON (md2.route = CONCAT('manufacturer_id=', m.manufacturer_id) AND md2.store_id = '" . (int)$data['store_id'] . "' AND md2.language_id = '" . (int)$data['language_id'] . "') LEFT JOIN " . DB_PREFIX . "d_meta_data md3 ON (md3.route = CONCAT('manufacturer_id=', m.manufacturer_id) AND md3.store_id = '0') LEFT JOIN " . DB_PREFIX . "d_meta_data md4 ON (md4.route = CONCAT('manufacturer_id=', m.manufacturer_id) AND md4.store_id = '" . (int)$data['store_id'] . "')";
						
			$implode = array();
			
			foreach ($data['filter'] as $field_code => $filter) {
				if (!empty($filter) && isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status'])) {
					if ($field_code == 'name') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.name LIKE '%" . $this->db->escape($filter) . "%'" : "md3.name LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.description LIKE '%" . $this->db->escape($filter) . "%'" : "md3.description LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'meta_title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.meta_title LIKE '%" . $this->db->escape($filter) . "%'" : "md3.meta_title LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'meta_description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.meta_description LIKE '%" . $this->db->escape($filter) . "%'" : "md3.meta_description LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'meta_keyword') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.meta_keyword LIKE '%" . $this->db->escape($filter) . "%'" : "md3.meta_keyword LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'custom_title_1') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.custom_title_1 LIKE '%" . $this->db->escape($filter) . "%'" : "md3.custom_title_1 LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'custom_title_2') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.custom_title_2 LIKE '%" . $this->db->escape($filter) . "%'" : "md3.custom_title_2 LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'custom_image_title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.custom_image_title LIKE '%" . $this->db->escape($filter) . "%'" : "md3.custom_image_title LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'custom_image_alt') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.custom_image_alt LIKE '%" . $this->db->escape($filter) . "%'" : "md3.custom_image_alt LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'meta_robots') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.meta_robots LIKE '%" . $this->db->escape($filter) . "%'" : "md3.meta_robots LIKE '%" . $this->db->escape($filter) . "%'";
					}
				}
			}
			
			if ($implode) {
				$sql .= " WHERE " . implode(' AND ', $implode);
			}

			$sql .= " GROUP BY m.manufacturer_id";
			
			$query = $this->db->query($sql);
			
			$manufacturers = array();
			
			foreach ($query->rows as $result) {
				$manufacturers[$result['manufacturer_id']] = $result;
			}

			return $manufacturers;	
		}
		
		if ($data['sheet_code'] == 'information') {
			$implode = array();
			$implode[] = "i.information_id";
			
			foreach ($data['fields'] as $field) {
				if (isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status'])) {
					if ($field['code'] == 'title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.title" : "id.title";
					}
					
					if ($field['code'] == 'description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.description" : "id.description";
					}
				
					if ($field['code'] == 'meta_title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_title" : "id.meta_title";
					}
				
					if ($field['code'] == 'meta_description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_description" : "id.meta_description";
					}
				
					if ($field['code'] == 'meta_keyword') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_keyword" : "id.meta_keyword";
					}
					
					if ($field['code'] == 'custom_title_1') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_title_1" : "md.custom_title_1";
					}
				
					if ($field['code'] == 'custom_title_2') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_title_2" : "md.custom_title_2";
					}
				
					if ($field['code'] == 'meta_robots') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_robots" : "md.meta_robots";
					}
				}
			}
		
			$sql = "SELECT " . implode(', ', $implode) . " FROM " . DB_PREFIX . "information i LEFT JOIN " . DB_PREFIX . "information_description id ON (id.information_id = i.information_id AND id.language_id = '" . (int)$data['language_id'] . "') LEFT JOIN " . DB_PREFIX . "d_meta_data md ON (md.route = CONCAT('information_id=', i.information_id) AND md.store_id = '0' AND md.language_id = '" . (int)$data['language_id'] . "') LEFT JOIN " . DB_PREFIX . "d_meta_data md2 ON (md2.route = CONCAT('information_id=', i.information_id) AND md2.store_id = '" . (int)$data['store_id'] . "' AND md2.language_id = '" . (int)$data['language_id'] . "') LEFT JOIN " . DB_PREFIX . "information_description id2 ON (id2.information_id = i.information_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md3 ON (md3.route = CONCAT('information_id=', i.information_id) AND md3.store_id = '0') LEFT JOIN " . DB_PREFIX . "d_meta_data md4 ON (md4.route = CONCAT('information_id=', i.information_id) AND md4.store_id = '" . (int)$data['store_id'] . "')";
			
			$implode = array();
			
			foreach ($data['filter'] as $field_code => $filter) {
				if (!empty($filter) && isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status'])) {
					if ($field_code == 'title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.title LIKE '%" . $this->db->escape($filter) . "%'" : "id2.title LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.description LIKE '%" . $this->db->escape($filter) . "%'" : "id2.description LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'meta_title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.meta_title LIKE '%" . $this->db->escape($filter) . "%'" : "id2.meta_title LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'meta_description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.meta_description LIKE '%" . $this->db->escape($filter) . "%'" : "id2.meta_description LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'meta_keyword') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.meta_keyword LIKE '%" . $this->db->escape($filter) . "%'" : "id2.meta_keyword LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'custom_title_1') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.custom_title_1 LIKE '%" . $this->db->escape($filter) . "%'" : "md3.custom_title_1 LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'custom_title_2') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.custom_title_2 LIKE '%" . $this->db->escape($filter) . "%'" : "md3.custom_title_2 LIKE '%" . $this->db->escape($filter) . "%'";
					}
					
					if ($field_code == 'meta_robots') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md4.meta_robots LIKE '%" . $this->db->escape($filter) . "%'" : "md3.meta_robots LIKE '%" . $this->db->escape($filter) . "%'";
					}
				}
			}
			
			if ($implode) {
				$sql .= " WHERE " . implode(' AND ', $implode);
			}

			$sql .= " GROUP BY i.information_id";
			
			$query = $this->db->query($sql);
			
			$informations = array();
			
			foreach ($query->rows as $result) {
				$informations[$result['information_id']] = $result;
			}

			return $informations;	
		}
	}
	
	/*
	*	Edit Element Field for Manager.
	*/
	public function editElementField($element) {				
		$field_info = $this->load->controller('extension/module/d_seo_module/getFieldInfo');
			
		if ($element['sheet_code'] == 'category') {
			if (($element['field_code'] == 'name') || ($element['field_code'] == 'description') || ($element['field_code'] == 'meta_title') || ($element['field_code'] == 'meta_description') || ($element['field_code'] == 'meta_keyword') && isset($field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store']) && isset($field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store_status'])) {
				if ($element['store_id'] && $field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store'] && $field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store_status']) {
					$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET " . $this->db->escape($element['field_code']) . " = '" . $this->db->escape($element['value']) . "' WHERE route='category_id=" . (int)$element['element_id'] . "' AND store_id = '" . (int)$element['store_id'] . "' AND language_id = '" . (int)$element['language_id'] . "'");
					
					if (!$this->db->countAffected()) {			
						$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='category_id=" . (int)$element['element_id'] . "', store_id = '" . (int)$element['store_id'] . "', language_id = '" . (int)$element['language_id'] . "', " . $this->db->escape($element['field_code']) . " = '" . $this->db->escape($element['value']) . "'");
					}
				} else {
					$this->db->query("UPDATE " . DB_PREFIX . "category_description SET " . $this->db->escape($element['field_code']) . " = '" . $this->db->escape($element['value']) . "' WHERE category_id = '" . (int)$element['element_id'] . "' AND language_id = '" . (int)$element['language_id'] . "'");
				}
			}
			
			if (($element['field_code'] == 'custom_title_1') || ($element['field_code'] == 'custom_title_2') || ($element['field_code'] == 'custom_image_title') || ($element['field_code'] == 'custom_image_alt') || ($element['field_code'] == 'meta_robots') && isset($field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store']) && isset($field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store_status'])) {
				if ($element['store_id'] && $field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store'] && $field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store_status']) {
					$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET " . $this->db->escape($element['field_code']) . " = '" . $this->db->escape($element['value']) . "' WHERE route='category_id=" . (int)$element['element_id'] . "' AND store_id = '" . (int)$element['store_id'] . "' AND language_id = '" . (int)$element['language_id'] . "'");
					
					if (!$this->db->countAffected()) {			
						$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='category_id=" . (int)$element['element_id'] . "', store_id = '" . (int)$element['store_id'] . "', language_id = '" . (int)$element['language_id'] . "', " . $this->db->escape($element['field_code']) . " = '" . $this->db->escape($element['value']) . "'");
					}
				} else {
					$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET " . $this->db->escape($element['field_code']) . " = '" . $this->db->escape($element['value']) . "' WHERE route='category_id=" . (int)$element['element_id'] . "' AND store_id = '0' AND language_id = '" . (int)$element['language_id'] . "'");
					
					if (!$this->db->countAffected()) {			
						$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='category_id=" . (int)$element['element_id'] . "', store_id = '0', language_id = '" . (int)$element['language_id'] . "', " . $this->db->escape($element['field_code']) . " = '" . $this->db->escape($element['value']) . "'");
					}
				}
			}
		}
		
		if ($element['sheet_code'] == 'product') {
			if (($element['field_code'] == 'name') || ($element['field_code'] == 'description') || ($element['field_code'] == 'meta_title') || ($element['field_code'] == 'meta_description') || ($element['field_code'] == 'meta_keyword') || ($element['field_code'] == 'tag') && isset($field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store']) && isset($field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store_status'])) {
				if ($element['store_id'] && $field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store'] && $field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store_status']) {
					$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET " . $this->db->escape($element['field_code']) . " = '" . $this->db->escape($element['value']) . "' WHERE route='product_id=" . (int)$element['element_id'] . "' AND store_id = '" . (int)$element['store_id'] . "' AND language_id = '" . (int)$element['language_id'] . "'");
				
					if (!$this->db->countAffected()) {			
						$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='product_id=" . (int)$element['element_id'] . "', store_id = '" . (int)$element['store_id'] . "', language_id = '" . (int)$element['language_id'] . "', " . $this->db->escape($element['field_code']) . " = '" . $this->db->escape($element['value']) . "'");
					}
				} else {
					$this->db->query("UPDATE " . DB_PREFIX . "product_description SET " . $this->db->escape($element['field_code']) . " = '" . $this->db->escape($element['value']) . "' WHERE product_id = '" . (int)$element['element_id'] . "' AND language_id = '" . (int)$element['language_id'] . "'");
				}
			}
			
			if (($element['field_code'] == 'custom_title_1') || ($element['field_code'] == 'custom_title_2') || ($element['field_code'] == 'custom_image_title') || ($element['field_code'] == 'custom_image_alt') || ($element['field_code'] == 'meta_robots') && isset($field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store']) && isset($field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store_status'])) {
				if ($element['store_id'] && $field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store'] && $field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store_status']) {
					$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET " . $this->db->escape($element['field_code']) . " = '" . $this->db->escape($element['value']) . "' WHERE route='product_id=" . (int)$element['element_id'] . "' AND store_id = '" . (int)$element['store_id'] . "' AND language_id = '" . (int)$element['language_id'] . "'");
				
					if (!$this->db->countAffected()) {			
						$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='product_id=" . (int)$element['element_id'] . "', store_id = '" . (int)$element['store_id'] . "', language_id = '" . (int)$element['language_id'] . "', " . $this->db->escape($element['field_code']) . " = '" . $this->db->escape($element['value']) . "'");
					}
				} else {
					$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET " . $this->db->escape($element['field_code']) . " = '" . $this->db->escape($element['value']) . "' WHERE route='product_id=" . (int)$element['element_id'] . "' AND store_id = '0' AND language_id = '" . (int)$element['language_id'] . "'");
					
					if (!$this->db->countAffected()) {			
						$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='product_id=" . (int)$element['element_id'] . "', store_id = '0', language_id = '" . (int)$element['language_id'] . "', " . $this->db->escape($element['field_code']) . " = '" . $this->db->escape($element['value']) . "'");
					}
				}
			}
		}
		
		if ($element['sheet_code'] == 'manufacturer') {
			if (($element['field_code'] == 'name') || ($element['field_code'] == 'description') || ($element['field_code'] == 'meta_title') || ($element['field_code'] == 'meta_description') || ($element['field_code'] == 'meta_keyword') || ($element['field_code'] == 'custom_title_1') || ($element['field_code'] == 'custom_title_2') || ($element['field_code'] == 'custom_image_title') || ($element['field_code'] == 'custom_image_alt') || ($element['field_code'] == 'meta_robots') && isset($field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store']) && isset($field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store_status'])) {
				if ($element['store_id'] && $field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store'] && $field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store_status']) {
					$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET " . $this->db->escape($element['field_code']) . " = '" . $this->db->escape($element['value']) . "' WHERE route='manufacturer_id=" . (int)$element['element_id'] . "' AND store_id = '" . (int)$element['store_id'] . "' AND language_id = '" . (int)$element['language_id'] . "'");
					
					if (!$this->db->countAffected()) {			
						$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='manufacturer_id=" . (int)$element['element_id'] . "', store_id = '" . (int)$element['store_id'] . "', language_id = '" . (int)$element['language_id'] . "', " . $this->db->escape($element['field_code']) . " = '" . $this->db->escape($element['value']) . "'");
					}
				} else {
					$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET " . $this->db->escape($element['field_code']) . " = '" . $this->db->escape($element['value']) . "' WHERE route='manufacturer_id=" . (int)$element['element_id'] . "' AND store_id = '0' AND language_id = '" . (int)$element['language_id'] . "'");
					
					if (!$this->db->countAffected()) {			
						$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='manufacturer_id=" . (int)$element['element_id'] . "', store_id = '" . (int)$element['store_id'] . "', language_id = '" . (int)$element['language_id'] . "', " . $this->db->escape($element['field_code']) . " = '" . $this->db->escape($element['value']) . "'");
					}
					
					if (($element['field_code'] == 'name') && ($element['language_id'] == (int)$this->config->get('config_language_id'))) {
						$this->db->query("UPDATE " . DB_PREFIX . "manufacturer SET " . $this->db->escape($element['field_code']) . " = '" . $this->db->escape($element['value']) . "' WHERE manufacturer_id = '" . (int)$element['element_id'] . "'");
					}
				}
			}
		}
		
		if ($element['sheet_code'] == 'information') {
			if (($element['field_code'] == 'title') || ($element['field_code'] == 'description') || ($element['field_code'] == 'meta_title') || ($element['field_code'] == 'meta_description') || ($element['field_code'] == 'meta_keyword') && isset($field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store']) && isset($field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store_status'])) {
				if ($element['store_id'] && $field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store'] && $field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store_status']) {
					$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET " . $this->db->escape($element['field_code']) . " = '" . $this->db->escape($element['value']) . "' WHERE route='information_id=" . (int)$element['element_id'] . "' AND store_id = '" . (int)$element['store_id'] . "' AND language_id = '" . (int)$element['language_id'] . "'");
					
					if (!$this->db->countAffected()) {			
						$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='information_id=" . (int)$element['element_id'] . "', store_id = '" . (int)$element['store_id'] . "', language_id = '" . (int)$element['language_id'] . "', " . $this->db->escape($element['field_code']) . " = '" . $this->db->escape($element['value']) . "'");
					}
				} else {
					$this->db->query("UPDATE " . DB_PREFIX . "information_description SET " . $this->db->escape($element['field_code']) . " = '" . $this->db->escape($element['value']) . "' WHERE information_id = '" . (int)$element['element_id'] . "' AND language_id = '" . (int)$element['language_id'] . "'");
				}
			}
			
			if (($element['field_code'] == 'custom_title_1') || ($element['field_code'] == 'custom_title_2') || ($element['field_code'] == 'meta_robots') && isset($field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store']) && isset($field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store_status'])) {
				if ($element['store_id'] && $field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store'] && $field_info['sheet'][$element['sheet_code']]['field'][$element['field_code']]['multi_store_status']) {
					$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET " . $this->db->escape($element['field_code']) . " = '" . $this->db->escape($element['value']) . "' WHERE route='information_id=" . (int)$element['element_id'] . "' AND store_id = '" . (int)$element['store_id'] . "' AND language_id = '" . (int)$element['language_id'] . "'");
					
					if (!$this->db->countAffected()) {			
						$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='information_id=" . (int)$element['element_id'] . "', store_id = '" . (int)$element['store_id'] . "', language_id = '" . (int)$element['language_id'] . "', " . $this->db->escape($element['field_code']) . " = '" . $this->db->escape($element['value']) . "'");
					}
				} else {
					$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET " . $this->db->escape($element['field_code']) . " = '" . $this->db->escape($element['value']) . "' WHERE route='information_id=" . (int)$element['element_id'] . "' AND store_id = '0' AND language_id = '" . (int)$element['language_id'] . "'");
					
					if (!$this->db->countAffected()) {			
						$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='information_id=" . (int)$element['element_id'] . "', store_id = '" . (int)$element['store_id'] . "', language_id = '" . (int)$element['language_id'] . "', " . $this->db->escape($element['field_code']) . " = '" . $this->db->escape($element['value']) . "'");
					}
				}
			}
		}
	}
	
	/*
	*	Return Export Elements for Manager.
	*/
	public function getExportElements($data) {		
		$this->load->model('extension/module/' . $this->codename);
		
		$languages = $this->{'model_extension_module_' . $this->codename}->getLanguages();
		
		$field_info = $this->load->controller('extension/module/d_seo_module/getFieldInfo');
						
		if ($data['sheet_code'] == 'category') {
			$categories = array();
			$implode = array();
						
			foreach ($data['fields'] as $field) {
				if (isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status'])) {
					if ($field['code'] == 'name') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.name" : "cd.name";
					}
							
					if ($field['code'] == 'description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.description" : "cd.description";
					}
				
					if ($field['code'] == 'meta_title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_title" : "cd.meta_title";
					}
				
					if ($field['code'] == 'meta_description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_description" : "cd.meta_description";
					}
				
					if ($field['code'] == 'meta_keyword') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_keyword" : "cd.meta_keyword";
					}
					
					if ($field['code'] == 'custom_title_1') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_title_1" : "md.custom_title_1";
					}

					if ($field['code'] == 'custom_title_2') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_title_2" : "md.custom_title_2";
					}

					if ($field['code'] == 'custom_image_title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_image_title" : "md.custom_image_title";
					}

					if ($field['code'] == 'custom_image_alt') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_image_alt" : "md.custom_image_alt";
					}
					
					if ($field['code'] == 'meta_robots') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_robots" : "md.meta_robots";
					}
				}
			}
			
			if ($implode) {
				$query = $this->db->query("SELECT cd.category_id, cd.language_id, " . implode(', ', $implode) . " FROM " . DB_PREFIX . "category c LEFT JOIN " . DB_PREFIX . "category_description cd ON (cd.category_id = c.category_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md ON (md.route = CONCAT('category_id=', c.category_id) AND md.store_id = '0' AND md.language_id = cd.language_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md2 ON (md2.route = CONCAT('category_id=', c.category_id) AND md2.store_id = '" . (int)$data['store_id'] . "' AND md2.language_id = cd.language_id) GROUP BY c.category_id, cd.language_id");
								
				foreach ($query->rows as $result) {
					$categories[$result['category_id']]['category_id'] = $result['category_id'];
					
					foreach ($result as $field => $value) {
						if (($field != 'category_id') && ($field != 'language_id')) {
							$categories[$result['category_id']][$field][$result['language_id']] = $value;
						}
					}
				}
			}

			return $categories;	
		}
		
		if ($data['sheet_code'] == 'product') {
			$products = array();
			$implode = array();
						
			foreach ($data['fields'] as $field) {
				if (isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status'])) {
					if ($field['code'] == 'name') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.name" : "pd.name";
					}
				
					if ($field['code'] == 'description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.description" : "pd.description";
					}
				
					if ($field['code'] == 'meta_title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_title" : "pd.meta_title";
					}
				
					if ($field['code'] == 'meta_description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_description" : "pd.meta_description";
					}
				
					if ($field['code'] == 'meta_keyword') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_keyword" : "pd.meta_keyword";
					}
				
					if ($field['code'] == 'tag') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.tag" : "pd.tag";
					}
					
					if ($field['code'] == 'custom_title_1') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_title_1" : "md.custom_title_1";
					}
				
					if ($field['code'] == 'custom_title_2') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_title_2" : "md.custom_title_2";
					}
				
					if ($field['code'] == 'custom_image_title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_image_title" : "md.custom_image_title";
					}
				
					if ($field['code'] == 'custom_image_alt') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_image_alt" : "md.custom_image_alt";
					}
				
					if ($field['code'] == 'meta_robots') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_robots" : "md.meta_robots";
					}
				}
			}
			
			if ($implode) {
				$query = $this->db->query("SELECT pd.product_id, pd.language_id, " . implode(', ', $implode) . " FROM " . DB_PREFIX . "product p LEFT JOIN " . DB_PREFIX . "product_description pd ON (pd.product_id = p.product_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md ON (md.route = CONCAT('product_id=', p.product_id) AND md.store_id = '0' AND md.language_id = pd.language_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md2 ON (md2.route = CONCAT('product_id=', p.product_id) AND md2.store_id = '" . (int)$data['store_id'] . "' AND md2.language_id = pd.language_id) GROUP BY p.product_id, pd.language_id");
		
				foreach ($query->rows as $result) {
					$products[$result['product_id']]['product_id'] = $result['product_id'];
					
					foreach ($result as $field => $value) {
						if (($field != 'product_id') && ($field != 'language_id')) {
							$products[$result['product_id']][$field][$result['language_id']] = $value;
						}
					}
				}
			}

			return $products;	
		}
		
		if ($data['sheet_code'] == 'manufacturer') {
			$manufacturers = array();		
			$implode = array();
						
			foreach ($data['fields'] as $field) {
				if (isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status'])) {
					if ($field['code'] == 'name') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.name" : "md.name";
					}
					
					if ($field['code'] == 'description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.description" : "md.description";
					}
				
					if ($field['code'] == 'meta_title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_title" : "md.meta_title";
					}
				
					if ($field['code'] == 'meta_description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_description" : "md.meta_description";
					}
				
					if ($field['code'] == 'meta_keyword') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_keyword" : "md.meta_keyword";
					}
				
					if ($field['code'] == 'custom_title_1') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_title_1" : "md.custom_title_1";
					}
					
					if ($field['code'] == 'custom_title_2') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_title_2" : "md.custom_title_2";
					}
					
					if ($field['code'] == 'custom_image_title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_image_title" : "md.custom_image_title";
					}
					
					if ($field['code'] == 'custom_image_alt') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_image_alt" : "md.custom_image_alt";
					}
				
					if ($field['code'] == 'meta_robots') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_robots" : "md.meta_robots";
					}
				}
			}
			
			if ($implode) {
				$query = $this->db->query("SELECT m.manufacturer_id, l.language_id, " . implode(', ', $implode) . " FROM " . DB_PREFIX . "manufacturer m CROSS JOIN " . DB_PREFIX . "language l LEFT JOIN " . DB_PREFIX . "d_meta_data md ON (md.route = CONCAT('manufacturer_id=', m.manufacturer_id) AND md.store_id = '0' AND md.language_id = l.language_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md2 ON (md2.route = CONCAT('manufacturer_id=', m.manufacturer_id) AND md2.store_id = '" . (int)$data['store_id'] . "' AND md2.language_id = l.language_id) GROUP BY m.manufacturer_id, l.language_id");
		
				foreach ($query->rows as $result) {
					$manufacturers[$result['manufacturer_id']]['manufacturer_id'] = $result['manufacturer_id'];
					
					foreach ($result as $field => $value) {
						if (($field != 'manufacturer_id') && ($field != 'language_id')) {
							$manufacturers[$result['manufacturer_id']][$field][$result['language_id']] = $value;
						}
					}
				}
			}
						
			return $manufacturers;	
		}
		
		if ($data['sheet_code'] == 'information') {
			$informations = array();
			$implode = array();
						
			foreach ($data['fields'] as $field) {
				if (isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status'])) {
					if ($field['code'] == 'title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.title" : "id.title";
					}
					
					if ($field['code'] == 'description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.description" : "id.description";
					}
				
					if ($field['code'] == 'meta_title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_title" : "id.meta_title";
					}
				
					if ($field['code'] == 'meta_description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_description" : "id.meta_description";
					}
				
					if ($field['code'] == 'meta_keyword') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_keyword" : "id.meta_keyword";
					}
					
					if ($field['code'] == 'custom_title_1') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_title_1" : "md.custom_title_1";
					}
				
					if ($field['code'] == 'custom_title_2') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_title_2" : "md.custom_title_2";
					}
				
					if ($field['code'] == 'meta_robots') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_robots" : "md.meta_robots";
					}
				}
			}
			
			if ($implode) {
				$query = $this->db->query("SELECT id.information_id, id.language_id, " . implode(', ', $implode) . " FROM " . DB_PREFIX . "information i LEFT JOIN " . DB_PREFIX . "information_description id ON (id.information_id = i.information_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md ON (md.route = CONCAT('information_id=', i.information_id) AND md.store_id = '0' AND md.language_id = id.language_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md2 ON (md2.route = CONCAT('information_id=', i.information_id) AND md2.store_id = '" . (int)$data['store_id'] . "' AND md2.language_id = id.language_id) GROUP BY i.information_id, id.language_id");
		
				foreach ($query->rows as $result) {
					$informations[$result['information_id']]['information_id'] = $result['information_id'];
					
					foreach ($result as $field => $value) {
						if (($field != 'information_id') && ($field != 'language_id')) {
							$informations[$result['information_id']][$field][$result['language_id']] = $value;
						}
					}
				}
			}
				
			return $informations;	
		}
	}
	
	/*
	*	Save Import Elements for Manager.
	*/
	public function saveImportElements($data) {		
		$this->load->model('extension/module/' . $this->codename);
		
		$languages = $this->{'model_extension_module_' . $this->codename}->getLanguages();
		
		$field_info = $this->load->controller('extension/module/d_seo_module/getFieldInfo');
						
		if ($data['sheet_code'] == 'category') {
			$categories = array();
			$implode = array();
			
			foreach ($data['fields'] as $field) {
				if (isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status'])) {
					if ($field['code'] == 'name') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.name" : "cd.name";
					}
							
					if ($field['code'] == 'description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.description" : "cd.description";
					}
				
					if ($field['code'] == 'meta_title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_title" : "cd.meta_title";
					}
				
					if ($field['code'] == 'meta_description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_description" : "cd.meta_description";
					}
				
					if ($field['code'] == 'meta_keyword') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_keyword" : "cd.meta_keyword";
					}
					
					if ($field['code'] == 'custom_title_1') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_title_1" : "md.custom_title_1";
					}

					if ($field['code'] == 'custom_title_2') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_title_2" : "md.custom_title_2";
					}

					if ($field['code'] == 'custom_image_title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_image_title" : "md.custom_image_title";
					}

					if ($field['code'] == 'custom_image_alt') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_image_alt" : "md.custom_image_alt";
					}
					
					if ($field['code'] == 'meta_robots') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_robots" : "md.meta_robots";
					}
				}
			}
			
			if ($implode) {
				$query = $this->db->query("SELECT cd.category_id, cd.language_id, " . implode(', ', $implode) . " FROM " . DB_PREFIX . "category c LEFT JOIN " . DB_PREFIX . "category_description cd ON (cd.category_id = c.category_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md ON (md.route = CONCAT('category_id=', c.category_id) AND md.store_id = '0' AND md.language_id = cd.language_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md2 ON (md2.route = CONCAT('category_id=', c.category_id) AND md2.store_id = '" . (int)$data['store_id'] . "' AND md2.language_id = cd.language_id) GROUP BY c.category_id, cd.language_id");
								
				foreach ($query->rows as $result) {
					$categories[$result['category_id']]['category_id'] = $result['category_id'];
					
					foreach ($result as $field => $value) {
						if (($field != 'category_id') && ($field != 'language_id')) {
							$categories[$result['category_id']][$field][$result['language_id']] = $value;
						}
					}
				}
			}
			
			foreach ($data['elements'] as $element) {
				if (isset($categories[$element['category_id']])) {
					$category = $categories[$element['category_id']];
					
					foreach ($languages as $language) {
						$implode1 = array();
						$implode2 = array();
						$implode3 = array();
							
						foreach ($data['fields'] as $field) {
							if (($field['code'] == 'name') || ($field['code'] == 'description') || ($field['code'] == 'meta_title') || ($field['code'] == 'meta_description') || ($field['code'] == 'meta_keyword')) {
								if (isset($element[$field['code']][$language['language_id']])) {
									if ((isset($category[$field['code']][$language['language_id']]) && ($element[$field['code']][$language['language_id']] != $category[$field['code']][$language['language_id']])) || !isset($category[$field['code']][$language['language_id']])) {
										if ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) {
											$implode3[] = $field['code'] . " = '" . $this->db->escape($element[$field['code']][$language['language_id']]) . "'";
										} else {
											$implode1[] = $field['code'] . " = '" . $this->db->escape($element[$field['code']][$language['language_id']]) . "'";
										}
									}
								}
							}
							
							if (($field['code'] == 'custom_title_1') || ($field['code'] == 'custom_title_2') || ($field['code'] == 'custom_image_title') || ($field['code'] == 'custom_image_alt') || ($field['code'] == 'meta_robots')) {
								if (isset($element[$field['code']][$language['language_id']])) {
									if ((isset($category[$field['code']][$language['language_id']]) && ($element[$field['code']][$language['language_id']] != $category[$field['code']][$language['language_id']])) || !isset($category[$field['code']][$language['language_id']])) {
										if ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) {
											$implode3[] = $field['code'] . " = '" . $this->db->escape($element[$field['code']][$language['language_id']]) . "'";
										} else {
											$implode2[] = $field['code'] . " = '" . $this->db->escape($element[$field['code']][$language['language_id']]) . "'";
										}
									}
								}
							}
						}
						
						if ($implode1) {
							$this->db->query("UPDATE " . DB_PREFIX . "category_description SET " . implode(', ', $implode1) . " WHERE category_id = '" . (int)$category['category_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						}
						
						if ($implode2) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET " . implode(', ', $implode2) . " WHERE route='category_id=" . (int)$category['category_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
							
							if (!$this->db->countAffected()) {			
								$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='category_id=" . (int)$category['category_id'] . "', store_id = '0', language_id = '" . (int)$language['language_id'] . "', " . implode(', ', $implode2));
							}
						}
						
						if ($implode3) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET " . implode(', ', $implode3) . " WHERE route='category_id=" . (int)$category['category_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
							
							if (!$this->db->countAffected()) {			
								$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='category_id=" . (int)$category['category_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', " . implode(', ', $implode3));
							}
						}
					}
				}	
			}			
		}
		
		if ($data['sheet_code'] == 'product') {
			$products = array();
			$implode = array();
						
			foreach ($data['fields'] as $field) {
				if (isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status'])) {
					if ($field['code'] == 'name') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.name" : "pd.name";
					}
				
					if ($field['code'] == 'description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.description" : "pd.description";
					}
				
					if ($field['code'] == 'meta_title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_title" : "pd.meta_title";
					}
				
					if ($field['code'] == 'meta_description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_description" : "pd.meta_description";
					}
				
					if ($field['code'] == 'meta_keyword') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_keyword" : "pd.meta_keyword";
					}
				
					if ($field['code'] == 'tag') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.tag" : "pd.tag";
					}
					
					if ($field['code'] == 'custom_title_1') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_title_1" : "md.custom_title_1";
					}
				
					if ($field['code'] == 'custom_title_2') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_title_2" : "md.custom_title_2";
					}
				
					if ($field['code'] == 'custom_image_title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_image_title" : "md.custom_image_title";
					}
				
					if ($field['code'] == 'custom_image_alt') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_image_alt" : "md.custom_image_alt";
					}
				
					if ($field['code'] == 'meta_robots') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_robots" : "md.meta_robots";
					}
				}
			}
			
			if ($implode) {
				$query = $this->db->query("SELECT pd.product_id, pd.language_id, " . implode(', ', $implode) . " FROM " . DB_PREFIX . "product p LEFT JOIN " . DB_PREFIX . "product_description pd ON (pd.product_id = p.product_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md ON (md.route = CONCAT('product_id=', p.product_id) AND md.store_id = '0' AND md.language_id = pd.language_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md2 ON (md2.route = CONCAT('product_id=', p.product_id) AND md2.store_id = '" . (int)$data['store_id'] . "' AND md2.language_id = pd.language_id) LEFT JOIN " . DB_PREFIX . "product_to_category pc ON (pc.product_id = pd.product_id) GROUP BY p.product_id, pd.language_id");
		
				foreach ($query->rows as $result) {
					$products[$result['product_id']]['product_id'] = $result['product_id'];
					
					foreach ($result as $field => $value) {
						if (($field != 'product_id') && ($field != 'language_id')) {
							$products[$result['product_id']][$field][$result['language_id']] = $value;
						}
					}
				}
			}
			
			foreach ($data['elements'] as $element) {
				if (isset($products[$element['product_id']])) {
					$product = $products[$element['product_id']];
					
					foreach ($languages as $language) {
						$implode1 = array();
						$implode2 = array();
						$implode3 = array();
							
						foreach ($data['fields'] as $field) {
							if (($field['code'] == 'name') || ($field['code'] == 'description') || ($field['code'] == 'meta_title') || ($field['code'] == 'meta_description') || ($field['code'] == 'meta_keyword') || ($field['code'] == 'tag')) {
								if (isset($element[$field['code']][$language['language_id']])) {
									if ((isset($product[$field['code']][$language['language_id']]) && ($element[$field['code']][$language['language_id']] != $product[$field['code']][$language['language_id']])) || !isset($product[$field['code']][$language['language_id']])) {
										if ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) {
											$implode3[] = $field['code'] . " = '" . $this->db->escape($element[$field['code']][$language['language_id']]) . "'";
										} else {
											$implode1[] = $field['code'] . " = '" . $this->db->escape($element[$field['code']][$language['language_id']]) . "'";
										}
									}
								}
							}
							
							if (($field['code'] == 'custom_title_1') || ($field['code'] == 'custom_title_2') || ($field['code'] == 'custom_image_title') || ($field['code'] == 'custom_image_alt') || ($field['code'] == 'meta_robots')) {
								if (isset($element[$field['code']][$language['language_id']])) {
									if ((isset($product[$field['code']][$language['language_id']]) && ($element[$field['code']][$language['language_id']] != $product[$field['code']][$language['language_id']])) || !isset($product[$field['code']][$language['language_id']])) {
										if ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) {
											$implode3[] = $field['code'] . " = '" . $this->db->escape($element[$field['code']][$language['language_id']]) . "'";
										} else {
											$implode2[] = $field['code'] . " = '" . $this->db->escape($element[$field['code']][$language['language_id']]) . "'";
										}
									}
								}
							}
						}
						
						if ($implode1) {
							$this->db->query("UPDATE " . DB_PREFIX . "product_description SET " . implode(', ', $implode1) . " WHERE product_id = '" . (int)$product['product_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						}
						
						if ($implode2) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET " . implode(', ', $implode2) . " WHERE route='product_id=" . (int)$product['product_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
							
							if (!$this->db->countAffected()) {			
								$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='product_id=" . (int)$product['product_id'] . "', store_id = '0', language_id = '" . (int)$language['language_id'] . "', " . implode(', ', $implode2));
							}
						}
						
						if ($implode3) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET " . implode(', ', $implode3) . " WHERE route='product_id=" . (int)$product['product_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
							
							if (!$this->db->countAffected()) {			
								$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='product_id=" . (int)$product['product_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', " . implode(', ', $implode3));
							}
						}
					}
				}	
			}
		}
		
		if ($data['sheet_code'] == 'manufacturer') {
			$manufacturers = array();		
			$implode = array();
						
			foreach ($data['fields'] as $field) {
				if (isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status'])) {
					if ($field['code'] == 'name') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.name" : "md.name";
					}
					
					if ($field['code'] == 'description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.description" : "md.description";
					}
				
					if ($field['code'] == 'meta_title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_title" : "md.meta_title";
					}
				
					if ($field['code'] == 'meta_description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_description" : "md.meta_description";
					}
				
					if ($field['code'] == 'meta_keyword') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_keyword" : "md.meta_keyword";
					}
				
					if ($field['code'] == 'custom_title_1') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_title_1" : "md.custom_title_1";
					}
					
					if ($field['code'] == 'custom_title_2') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_title_2" : "md.custom_title_2";
					}
					
					if ($field['code'] == 'custom_image_title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_image_title" : "md.custom_image_title";
					}
					
					if ($field['code'] == 'custom_image_alt') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_image_alt" : "md.custom_image_alt";
					}
				
					if ($field['code'] == 'meta_robots') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_robots" : "md.meta_robots";
					}
				}
			}
			
			if ($implode) {
				$query = $this->db->query("SELECT m.manufacturer_id, l.language_id, " . implode(', ', $implode) . " FROM " . DB_PREFIX . "manufacturer m CROSS JOIN " . DB_PREFIX . "language l LEFT JOIN " . DB_PREFIX . "d_meta_data md ON (md.route = CONCAT('manufacturer_id=', m.manufacturer_id) AND md.store_id = '0' AND md.language_id = l.language_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md2 ON (md2.route = CONCAT('manufacturer_id=', m.manufacturer_id) AND md2.store_id = '" . (int)$data['store_id'] . "' AND md2.language_id = l.language_id) GROUP BY m.manufacturer_id, l.language_id");
		
				foreach ($query->rows as $result) {
					$manufacturers[$result['manufacturer_id']]['manufacturer_id'] = $result['manufacturer_id'];
					
					foreach ($result as $field => $value) {
						if (($field != 'manufacturer_id') && ($field != 'language_id')) {
							$manufacturers[$result['manufacturer_id']][$field][$result['language_id']] = $value;
						}
					}
				}
			}
				
			foreach ($data['elements'] as $element) {
				if (isset($manufacturers[$element['manufacturer_id']])) {
					$manufacturer = $manufacturers[$element['manufacturer_id']];
					
					foreach ($languages as $language) {
						$implode1 = array();
						$implode2 = array();
							
						foreach ($data['fields'] as $field) {							
							if (($field['code'] == 'name') || ($field['code'] == 'description') || ($field['code'] == 'meta_title') || ($field['code'] == 'meta_description') || ($field['code'] == 'meta_keyword') || ($field['code'] == 'custom_title_1') || ($field['code'] == 'custom_title_2') || ($field['code'] == 'custom_image_title') || ($field['code'] == 'custom_image_alt') || ($field['code'] == 'meta_robots')) {
								if (isset($element[$field['code']][$language['language_id']])) {
									if ((isset($manufacturer[$field['code']][$language['language_id']]) && ($element[$field['code']][$language['language_id']] != $manufacturer[$field['code']][$language['language_id']])) || !isset($manufacturer[$field['code']][$language['language_id']])) {
										if ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) {
											$implode2[] = $field['code'] . " = '" . $this->db->escape($element[$field['code']][$language['language_id']]) . "'";
										} else {
											$implode1[] = $field['code'] . " = '" . $this->db->escape($element[$field['code']][$language['language_id']]) . "'";
											
											if (($field['code'] == 'name') && ($language['language_id'] == (int)$this->config->get('config_language_id'))) {
												$this->db->query("UPDATE " . DB_PREFIX . "manufacturer SET " . $field['code'] . " = '" . $this->db->escape($element[$field['code']][$language['language_id']]) . "' WHERE manufacturer_id = '" . (int)$manufacturer['manufacturer_id'] . "'");
											}
										}
									}
								}
							}
						}
												
						if ($implode1) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET " . implode(', ', $implode1) . " WHERE route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
							
							if (!$this->db->countAffected()) {			
								$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', " . implode(', ', $implode1));
							}
						}
						
						if ($implode2) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET " . implode(', ', $implode2) . " WHERE route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
							
							if (!$this->db->countAffected()) {			
								$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='manufacturer_id=" . (int)$manufacturer['manufacturer_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', " . implode(', ', $implode2));
							}
						}
					}
				}	
			}
		}
		
		if ($data['sheet_code']=='information') {
			$informations = array();
			$implode = array();
						
			foreach ($data['fields'] as $field) {
				if (isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store']) && isset($field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status'])) {
					if ($field['code'] == 'title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.title" : "id.title";
					}
					
					if ($field['code'] == 'description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.description" : "id.description";
					}
				
					if ($field['code'] == 'meta_title') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_title" : "id.meta_title";
					}
				
					if ($field['code'] == 'meta_description') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_description" : "id.meta_description";
					}
				
					if ($field['code'] == 'meta_keyword') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_keyword" : "id.meta_keyword";
					}
					
					if ($field['code'] == 'custom_title_1') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_title_1" : "md.custom_title_1";
					}
				
					if ($field['code'] == 'custom_title_2') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.custom_title_2" : "md.custom_title_2";
					}
				
					if ($field['code'] == 'meta_robots') {
						$implode[] = ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) ? "md2.meta_robots" : "md.meta_robots";
					}
				}
			}
			
			if ($implode) {
				$query = $this->db->query("SELECT id.information_id, id.language_id, " . implode(', ', $implode) . " FROM " . DB_PREFIX . "information i LEFT JOIN " . DB_PREFIX . "information_description id ON (id.information_id = i.information_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md ON (md.route = CONCAT('information_id=', i.information_id) AND md.store_id = '0' AND md.language_id = id.language_id) LEFT JOIN " . DB_PREFIX . "d_meta_data md2 ON (md2.route = CONCAT('information_id=', i.information_id) AND md2.store_id = '" . (int)$data['store_id'] . "' AND md2.language_id = id.language_id) GROUP BY i.information_id, id.language_id");
		
				foreach ($query->rows as $result) {
					$informations[$result['information_id']]['information_id'] = $result['information_id'];
					
					foreach ($result as $field => $value) {
						if (($field != 'information_id') && ($field != 'language_id')) {
							$informations[$result['information_id']][$field][$result['language_id']] = $value;
						}
					}
				}
			}
			
			foreach ($data['elements'] as $element) {
				if (isset($informations[$element['information_id']])) {
					$information = $informations[$element['information_id']];
					
					foreach ($languages as $language) {
						$implode1 = array();
						$implode2 = array();
						$implode3 = array();
							
						foreach ($data['fields'] as $field) {
							if (($field['code'] == 'title') || ($field['code'] == 'description') || ($field['code'] == 'meta_title') || ($field['code'] == 'meta_description') || ($field['code'] == 'meta_keyword')) {
								if (isset($element[$field['code']][$language['language_id']])) {
									if ((isset($information[$field['code']][$language['language_id']]) && ($element[$field['code']][$language['language_id']] != $information[$field['code']][$language['language_id']])) || !isset($information[$field['code']][$language['language_id']])) {
										if ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) {
											$implode3[] = $field['code'] . " = '" . $this->db->escape($element[$field['code']][$language['language_id']]) . "'";
										} else {
											$implode1[] = $field['code'] . " = '" . $this->db->escape($element[$field['code']][$language['language_id']]) . "'";
										}
									}
								}
							}
							
							if (($field['code'] == 'custom_title_1') || ($field['code'] == 'custom_title_2') || ($field['code'] == 'meta_robots')) {
								if (isset($element[$field['code']][$language['language_id']])) {
									if ((isset($information[$field['code']][$language['language_id']]) && ($element[$field['code']][$language['language_id']] != $information[$field['code']][$language['language_id']])) || !isset($information[$field['code']][$language['language_id']])) {
										if ($data['store_id'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store'] && $field_info['sheet'][$data['sheet_code']]['field'][$field['code']]['multi_store_status']) {
											$implode3[] = $field['code'] . " = '" . $this->db->escape($element[$field['code']][$language['language_id']]) . "'";
										} else {
											$implode2[] = $field['code'] . " = '" . $this->db->escape($element[$field['code']][$language['language_id']]) . "'";
										}
									}
								}
							}
						}
						
						if ($implode1) {
							$this->db->query("UPDATE " . DB_PREFIX . "information_description SET " . implode(', ', $implode1) . " WHERE information_id = '" . (int)$information['information_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
						}
						
						if ($implode2) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET " . implode(', ', $implode2) . " WHERE route='information_id=" . (int)$information['information_id'] . "' AND store_id = '0' AND language_id = '" . (int)$language['language_id'] . "'");
							
							if (!$this->db->countAffected()) {			
								$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='information_id=" . (int)$information['information_id'] . "', store_id = '0', language_id = '" . (int)$language['language_id'] . "', " . implode(', ', $implode2));
							}
						}
						
						if ($implode3) {
							$this->db->query("UPDATE " . DB_PREFIX . "d_meta_data SET " . implode(', ', $implode3) . " WHERE route='information_id=" . (int)$information['information_id'] . "' AND store_id = '" . (int)$data['store_id'] . "' AND language_id = '" . (int)$language['language_id'] . "'");
							
							if (!$this->db->countAffected()) {			
								$this->db->query("INSERT INTO " . DB_PREFIX . "d_meta_data SET route='information_id=" . (int)$information['information_id'] . "', store_id = '" . (int)$data['store_id'] . "', language_id = '" . (int)$language['language_id'] . "', " . implode(', ', $implode3));
							}
						}
					}
				}	
			}
		}
	}
}
?>