<?php

class ModelIpCurrencyIpCurrency extends Model {
    /* adriit customization install ipcurrancy module */

    public function installipcurency() {
        $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "adri_ipcurrency` (
        `ipcurrency_id` int(10) NOT NULL AUTO_INCREMENT,
        `country_id` int(10) NOT NULL,
        `currency_id` int(10) NOT NULL,
        `status` int(10) NOT NULL,
        PRIMARY KEY (`ipcurrency_id`)
        )ENGINE = InnoDB DEFAULT CHARSET = latin1 AUTO_INCREMENT = 1");
    }

    public function GetDefaultCurrency() {
        $sql = "SELECT * FROM `" . DB_PREFIX . "adri_ipcurrency` 
LEFT JOIN " . DB_PREFIX . "currency as " . DB_PREFIX . "currency on " . DB_PREFIX . "currency.`currency_id`=" . DB_PREFIX . "adri_ipcurrency.`currency_id`
where " . DB_PREFIX . "adri_ipcurrency.`country_id`=0";
        $query = $this->db->query($sql);
        return $query->rows;
    }

    public function AddDefaultCurrancy($currency_id) {
        if ($currency_id) {
            $sql = "UPDATE `" . DB_PREFIX . "adri_ipcurrency` SET `currency_id`='" . $currency_id . "' WHERE `country_id`=0";
            $this->db->query($sql);
        } else {
            $sql = "INSERT INTO `" . DB_PREFIX . "adri_ipcurrency`(`country_id`, `currency_id`, `status`) VALUES (0,1,1)";
            $this->db->query($sql);
        }
    }

    public function GetDefaultStates() {
        $sql = "SELECT * FROM `" . DB_PREFIX . "adri_ipcurrency` WHERE `status`= 2";
        $query = $this->db->query($sql);
        return $query->rows;
    }

    public function GetCountrieName($country_id) {
        $sql = "SELECT * FROM `" . DB_PREFIX . "country` WHERE `country_id`='" . $country_id . "' and `status`=1";
        $this->db->query($sql);
    }

    public function updateipcurrency($country_id, $data) {
        $sql = "UPDATE " . DB_PREFIX . "adri_ipcurrency SET currency_id = '" . $this->db->escape($data['currency_id']) . "'  WHERE  country_id = '" . $country_id . "'";
        $this->db->query($sql);
    }

    public function getipcountry($countryid) {
        $sql = "SELECT * FROM `" . DB_PREFIX . "adri_ipcurrency` WHERE `country_id` ='" . $countryid . "'";
        $query = $this->db->query($sql);
        return $query->rows;
    }

    public function addipcurrency($data) {
//        $this->installipcurency();
        $this->db->query("INSERT INTO `" . DB_PREFIX . "adri_ipcurrency`(`country_id`, `currency_id`, `status`)"
                . " VALUES ('" . $this->db->escape($data['country_id']) . "','" . $this->db->escape($data['currency_id']) . "','" . (int) $data['status'] . "')");
    }

    public function deleteCurrancy($country_id) {
        $sql = "UPDATE " . DB_PREFIX . "adri_ipcurrency SET status = '0' WHERE country_id = '" . $country_id . "'";

        $this->db->query($sql);
    }

    /*     * Adriit Customization for ip currency */

    public function GetAllCountries() {
        $query = $this->db->query("SELECT country_id,name,iso_code_2,iso_code_3 FROM " . DB_PREFIX . "country  WHERE status=1  ORDER BY name");

        return $query->rows;
    }

    public function GetAllCurrency() {
        $query = $this->db->query("SELECT currency_id,title,code,symbol_left,symbol_right,decimal_place,value FROM " . DB_PREFIX . "currency  WHERE status=1  ORDER BY title");

        return $query->rows;
    }

    public function addCountry($data) {
        $this->db->query("INSERT INTO " . DB_PREFIX . "country_master SET country_name = '" . $this->db->escape($data['name']) . "', status = '" . (int) $data['status'] . "'");
        $country_id = $this->db->getLastId();
        return $country_id;
    }

    public function editCurrancy($data) {
        $this->db->query("UPDATE " . DB_PREFIX . "country_master SET country_name = '" . $this->db->escape($data['name']) . "' WHERE country_id = '" . $this->db->escape($data['country_id']) . "'");
    }

}

?>
