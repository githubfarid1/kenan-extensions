<?php

class ControllerModuleipcurrency extends Controller {

    private $error = array();

    public function install() {
        $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "adri_ipcurrency` (
        `ipcurrency_id` int(10) NOT NULL AUTO_INCREMENT,
        `country_id` int(10) NOT NULL,
        `currency_id` int(10) NOT NULL,
        `status` int(10) NOT NULL,
        PRIMARY KEY (`ipcurrency_id`)
        )ENGINE = InnoDB DEFAULT CHARSET = latin1 AUTO_INCREMENT = 1");
        $sql = "INSERT INTO `" . DB_PREFIX . "adri_ipcurrency`(`country_id`, `currency_id`, `status`) VALUES (0,1,1)";
        $this->db->query($sql);

        $setting['code'] = 'ipcurrency';
        $setting['key'] = 'ipcurrency_status';
        $setting['value'] = 0;

        $this->load->model('extension/module');
        $this->model_extension_module->editSetting('ipcurrency', $setting);
    }

    public function index() {
//        $this->installipcurency();

        $this->load->language('module/ipcurrency');
        $this->document->setTitle($this->language->get('heading_title'));


        $this->load->model('extension/module');
        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            /*
              if (!isset($this->request->get['module_id'])) {
              $this->model_extension_module->addModule('ipcurrency', $this->request->post);
              } else {
              $this->model_extension_module->editModule($this->request->get['module_id'], $this->request->post);
              } */



            /* insert data for enable and disable moduel start */
            $setting['code'] = 'ipcurrency';
            $setting['key'] = 'ipcurrency_status';
            $setting['value'] = $this->request->post['status'];

            $this->load->model('extension/module');
            $this->model_extension_module->editSetting('ipcurrency', $setting);
            /* insert data for enable and disable moduel End */

            $this->session->data['success'] = $this->language->get('text_success');

//            $this->response->redirect($this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL'));
        }



        $data['heading_title'] = $this->language->get('heading_title');
        $data['text_edit'] = $this->language->get('text_edit');
        $data['text_enabled'] = $this->language->get('text_enabled');
        $data['text_disabled'] = $this->language->get('text_disabled');

        $data['entry_name'] = $this->language->get('entry_name');
        $data['entry_limit'] = $this->language->get('entry_limit');
        $data['entry_width'] = $this->language->get('entry_width');
        $data['entry_height'] = $this->language->get('entry_height');
        $data['entry_status'] = $this->language->get('entry_status');
        $data['entry_area'] = $this->language->get('entry_area');

        $data['button_save'] = $this->language->get('button_save');
        $data['button_cancel'] = $this->language->get('button_cancel');

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if (isset($this->error['name'])) {
            $data['error_name'] = $this->error['name'];
        } else {
            $data['error_name'] = '';
        }

        $data['breadcrumbs'] = array();
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_module'),
            'href' => $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL')
        );

        if (!isset($this->request->get['module_id'])) {
            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link('module/ipcurrency', 'token=' . $this->session->data['token'], 'SSL')
            );
        } else {
            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link('module/ipcurrency', 'token=' . $this->session->data['token'] . '&module_id=' . $this->request->get['module_id'], 'SSL')
            );
        }

        if (!isset($this->request->get['module_id'])) {
            $data['action'] = $this->url->link('module/ipcurrency', 'token=' . $this->session->data['token'], 'SSL');
        } else {
            $data['action'] = $this->url->link('module/ipcurrency', 'token=' . $this->session->data['token'] . '&module_id=' . $this->request->get['module_id'], 'SSL');
        }

        $data['cancel'] = $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL');

        if (isset($this->request->get['module_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
            $module_info = $this->model_extension_module->getModule($this->request->get['module_id']);
        }

        if (isset($this->request->post['name'])) {
            $data['name'] = $this->request->post['name'];
        } elseif (!empty($module_info)) {
            $data['name'] = $module_info['name'];
        } else {
            $data['name'] = '';
        }


        if (isset($this->request->post['status'])) {
            $data['status'] = $this->request->post['status'];
        } elseif (!empty($module_info)) {
            $data['status'] = $this->request->post['status'];
        } else {
            $data['status'] = $this->config->get('ipcurrency_status');
        }

//        if (isset($this->request->post['status'])) {
//            $data['status'] = $this->request->post['filter_status'];
//        } else {
//            $data['status'] = $this->config->get('filter_status');
//        }
//$this->document->addScript('view/javascript/datatables/jquery.js');
        $this->document->addScript('view/javascript/datatables/jquery.dataTables.min.js');
        $this->document->addStyle('view/stylesheet/datatables/jquery.dataTables.min.css');


        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $data['country_list'] = $this->GetCountry();
        $data['country_add'] = $this->AddCountryView();

        /* default currency */
        $data['ajaxLinkdefaultCurrancyadd'] = '?route=module/ipcurrency/adddefaultcurrancy&token=' . $this->session->data['token'];

        $this->load->model('ipcurrency/ipcurrency');
        $data['AllCurrency'] = $this->model_ipcurrency_ipcurrency->GetAllCurrency();
        $data['DefaultCurrency'] = $this->model_ipcurrency_ipcurrency->GetDefaultCurrency();
        /* default currency */

        $this->response->setOutput($this->load->view('module/ipcurrency/ipcurrency.tpl', $data));
    }

    public function adddefaultcurrancy() {
        $currency_id = $this->request->post['currency_id'];
        $this->load->model('ipcurrency/ipcurrency');
        $this->model_ipcurrency_ipcurrency->AddDefaultCurrancy($currency_id);
    }

    public function addIpcurrency() {
        $country_id = $this->request->post['country_id'];
        $currency_id = $this->request->post['currency_id'];
        $this->load->model('ipcurrency/ipcurrency');

        $entry = $this->model_ipcurrency_ipcurrency->getipcountry($country_id);
        if (count($entry) > 0) {
            $data = array(
                'currency_id' => $currency_id,
            );
            $this->load->model('ipcurrency/ipcurrency');
            $this->model_ipcurrency_ipcurrency->updateipcurrency($country_id, $data);
        } else {
            $data = array(
                'country_id' => $country_id,
                'currency_id' => $currency_id,
                'status' => '1'
            );
            $this->load->model('ipcurrency/ipcurrency');
            $this->model_ipcurrency_ipcurrency->addipcurrency($data);
        }
    }

    private function AddCountryView() {

        $country_data = array();
        $country_data['ajaxLinkCountryAdd'] = '?route=module/ipcurrency/addIpcurrency&token=' . $this->session->data['token'];
        /**/
        $this->load->model('ipcurrency/ipcurrency');
        $country_data['AllCountries'] = $this->model_ipcurrency_ipcurrency->GetAllCountries();
        $country_data['AllCurrency'] = $this->model_ipcurrency_ipcurrency->GetAllCurrency();
        /**/
        $this->load->model('ipcurrency/ipcurrency');
        $country_data['AllCountries'] = $this->model_ipcurrency_ipcurrency->GetAllCountries();
        $country_data['AllCurrency'] = $this->model_ipcurrency_ipcurrency->GetAllCurrency();
        /**/
        $this->load->model('ipcurrency/ipcurrency');
        $deafultstatues = $this->model_ipcurrency_ipcurrency->GetDefaultStates();
        $country_data['defaultStates'] = '';
        return $this->load->view('module/ipcurrency/country_add.tpl', $country_data);
    }

    public function deleteCurrancy() {
        $this->load->model('ipcurrency/ipcurrency');
        $country_id = $this->request->post['country_id'];
        $data = array(
            'status' => 0
        );
        $this->load->model('ipcurrency/ipcurrency');
        $this->model_ipcurrency_ipcurrency->deleteCurrancy($country_id);
    }

    public function editCurrancy() {
        $this->load->model('ipcurrency/ipcurrency');
        $country_id = $this->request->post['country_id'];
        $currency_id = $this->request->post['currency_id'];

        $data = array(
            'currency_id' => $currency_id,
        );
        $this->load->model('ipcurrency/ipcurrency');
        $this->model_ipcurrency_ipcurrency->updateipcurrency($country_id, $data);
        $country_data['ajaxLinkCurrancyEdit'] = '?route=module/ipcurrency/editCurrancy&token=' . $this->session->data['token'];
    }

    private function GetCountry() {
        $country_data = array();
        $country_data['country_delete_confirmation_msg'] = $this->language->get('country_delete_confirmation_msg');
        $country_data['country_delete_title_msg'] = $this->language->get('country_delete_title_msg');
        $country_data['country_edit_title_msg'] = $this->language->get('country_edit_title_msg');

        $country_data['ajaxLinkCurrancyList'] = '?route=module/ipcurrency/getCurrancyList&token=' . $this->session->data['token'];
        $country_data['ajaxLinkcurrancyDelete'] = '?route=module/ipcurrency/deleteCurrancy&token=' . $this->session->data['token'];
        $country_data['ajaxLinkCurrancyEdit'] = '?route=module/ipcurrency/editCurrancy&token=' . $this->session->data['token'];

        /* default currency */
        $this->load->model('ipcurrency/ipcurrency');
        $country_data['AllCurrency'] = $this->model_ipcurrency_ipcurrency->GetAllCurrency();
        /* default currency */
        return $this->load->view('module/ipcurrency/country_list.tpl', $country_data);
    }

    public function getCurrancyList() {
        $table = DB_PREFIX . 'adri_ipcurrency';

// Table's primary key
        $primaryKey = 'ipcurrency_id';
// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes
        $columns = array(
            array('db' => DB_PREFIX . 'adri_ipcurrency.ipcurrency_id', 'dt' => 0, 'field' => 'ipcurrency_id'),
            array('db' => DB_PREFIX . 'country.name', 'dt' => 1, 'field' => 'name',
                'formatter' => function( $d, $row ) {

                    return $row[1] . " (" . $row[4] . ") ";
                }),
            array('db' => DB_PREFIX . 'currency.title', 'dt' => 2, 'field' => 'title',
                'formatter' => function( $d, $row ) {

                    if ($row[6] == '2') {

                        return $row[2] . " (" . $row[5] . ") " . '<strong>Default</strong>';
                    }
                    return $row[2] . " (" . $row[5] . ") " . $row[7] . $row[8];
                }),
            array(
                'db' => DB_PREFIX . 'adri_ipcurrency.country_id',
                'dt' => 3, 'field' => 'country_id',
                'formatter' => function( $d, $row ) {
                    $name = "'" . $row[0] . "'";
                    return '<a onclick="editCurrancy(' . $row[3] . ',' . $name . ') "   data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Edit"><i class="fa fa-pencil"></i></a>
                  ' . '&nbsp;<a onclick="deleteCurrancyCnfrm(' . $row[3] . ') " data-toggle="tooltip" title="" class="btn btn-danger" data-original-title="Delete"><i class="fa fa-trash-o"></i></a>';
                }
            ),
            array(
                'db' => DB_PREFIX . 'country.iso_code_2',
                'dt' => 4, 'field' => 'iso_code_2'
            ),
            array(
                'db' => DB_PREFIX . 'currency.code',
                'dt' => 5, 'field' => 'code'
            ),
            array('db' => DB_PREFIX . 'adri_ipcurrency.status', 'dt' => 6, 'field' => 'status',
                'formatter' => function( $d, $row) {
                    if ($row[6] == '2') {
                        return 'Default';
                    }
                }),
            array(
                'db' => DB_PREFIX . 'currency.symbol_right',
                'dt' => 7, 'field' => 'symbol_right'
            ),
            array(
                'db' => DB_PREFIX . 'currency.symbol_left',
                'dt' => 8, 'field' => 'symbol_left'
            ),
        );
// SQL server connection information
        $sql_details = array(
            'user' => DB_USERNAME,
            'pass' => DB_PASSWORD,
            'db' => DB_DATABASE,
            'host' => 'localhost'
        );
        $joinQuery = "FROM " . DB_PREFIX . "adri_ipcurrency "
                . " JOIN " . DB_PREFIX . "country ON (" . DB_PREFIX . "adri_ipcurrency.country_id=" . DB_PREFIX . "country.country_id)"
                . " JOIN " . DB_PREFIX . "currency ON (" . DB_PREFIX . "adri_ipcurrency.currency_id=" . DB_PREFIX . "currency.currency_id)";
        $extraWhere = DB_PREFIX . "adri_ipcurrency.status != 0";

        echo json_encode(
                SSP::simple($_GET, $sql_details, $table, $primaryKey, $columns, $joinQuery, $extraWhere)
        );
    }

    protected function validate() {
        if (!$this->user->hasPermission('modify', 'module/ipcurrency')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }
        /*
          if ((utf8_strlen($this->request->post['name']) < 3) || (utf8_strlen($this->request->post['name']) > 64)) {
          $this->error['name'] = $this->language->get('error_name');
          } */

        return !$this->error;
    }

}

?>
