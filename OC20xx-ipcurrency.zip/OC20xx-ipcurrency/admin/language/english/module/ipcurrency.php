<?php

// Heading
$_['heading_title'] = 'IP Currency (Adri it)';

// Text
$_['text_module'] = 'Modules';
$_['text_success'] = 'Success: You have modified module "IP Currency (Adri it)"!';
$_['text_edit'] = 'Edit Currency Module';

// Entry
$_['entry_name'] = 'Module Name';
$_['entry_limit'] = 'Limit';
$_['entry_width'] = 'Width';
$_['entry_height'] = 'Height';
$_['entry_status'] = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify module "IP Currency (Adri it)"!';
$_['error_width'] = 'Width required!';
$_['error_height'] = 'Height required!';

//Custom Development
$_['entry_area'] = 'Modify Currency';
$_['country_delete_confirmation_msg'] = 'Are you really want to delete?';
$_['country_delete_title_msg'] = 'Delete Currency ???';
$_['country_edit_title_msg'] = 'Edit Country Currency ';
