<?php

class ControllerModuleIpCurrency extends Controller {

    public function index($setting = array()) {
        $this->setCurrency();
    }

    /* Adri Customization Currency */

   

    function ipaddress_info($ip = NULL, $purpose = "location", $deep_detect = TRUE) {
        $output = NULL;
        if (filter_var($ip, FILTER_VALIDATE_IP) === FALSE) {
            $ip = $_SERVER["REMOTE_ADDR"];
            if ($deep_detect) {
                if (filter_var(@$_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP))
                    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
                if (filter_var(@$_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP))
                    $ip = $_SERVER['HTTP_CLIENT_IP'];
            }
        }
        $purpose = str_replace(array("name", "\n", "\t", " ", "-", "_"), NULL, strtolower(trim($purpose)));
        $support = array("country", "countrycode", "state", "region", "city", "location", "address");
        $continents = array(
            "AF" => "Africa",
            "AN" => "Antarctica",
            "AS" => "Asia",
            "EU" => "Europe",
            "OC" => "Australia (Oceania)",
            "NA" => "North America",
            "SA" => "South America"
        );
        if (filter_var($ip, FILTER_VALIDATE_IP) && in_array($purpose, $support)) {
            $ipdat = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
            if (@strlen(trim($ipdat->geoplugin_countryCode)) == 2) {
                switch ($purpose) {
                    case "location":
                        $output = array(
                            "city" => @$ipdat->geoplugin_city,
                            "state" => @$ipdat->geoplugin_regionName,
                            "country" => @$ipdat->geoplugin_countryName,
                            "country_code" => @$ipdat->geoplugin_countryCode,
                            "continent" => @$continents[strtoupper($ipdat->geoplugin_continentCode)],
                            "continent_code" => @$ipdat->geoplugin_continentCode
                        );
                        break;
                    case "address":
                        $address = array($ipdat->geoplugin_countryName);
                        if (@strlen($ipdat->geoplugin_regionName) >= 1)
                            $address[] = $ipdat->geoplugin_regionName;
                        if (@strlen($ipdat->geoplugin_city) >= 1)
                            $address[] = $ipdat->geoplugin_city;
                        $output = implode(", ", array_reverse($address));
                        break;
                    case "city":
                        $output = @$ipdat->geoplugin_city;
                        break;
                    case "state":
                        $output = @$ipdat->geoplugin_regionName;
                        break;
                    case "region":
                        $output = @$ipdat->geoplugin_regionName;
                        break;
                    case "country":
                        $output = @$ipdat->geoplugin_countryName;
                        break;
                    case "countrycode":
                        $output = @$ipdat->geoplugin_countryCode;
                        break;
                }
            }
        }
        return $output;
    }
     function getUserIPAddress() {
        $clientip = @$_SERVER['HTTP_CLIENT_IP'];
        $forwardip = @$_SERVER['HTTP_X_FORWARDED_FOR'];
        $remoteip = $_SERVER['REMOTE_ADDR'];

        if (filter_var($clientip, FILTER_VALIDATE_IP)) {
            $ip = $clientip;
        } elseif (filter_var($forwardip, FILTER_VALIDATE_IP)) {
            $ip = $forwardip;
        } else {
            $ip = $remoteip;
        }

        return $ip;
    }
    public function setCurrency() {
        $this->config->get('ipcurrency_status');
        $ip = $this->getUserIPAddress();
        $Country_Code = $this->ipaddress_info($ip, "Country Code");

        $this->load->model('module/ipcurrency');
        $currency_info = $this->model_module_ipcurrency->getcurrency();
        $match_found = false;
        foreach ($currency_info as $currency_code) {
            if ($Country_Code == $currency_code['iso_code_2']) {
                $match_found = true;
                $this->currency->set($currency_code['code']);
                    // setcookie('currency', $currency_code['code'], time() + 60 * 60 * 24 * 30, '/', $this->request->server['HTTP_HOST']);
            }
        }
        if (!$match_found) {
            $this->currency->set($currency_info[0]['code']);
        }
 
    }

    /* End Adri Customization for Currency */
}

?>
