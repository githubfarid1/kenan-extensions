<?php

class ModelModuleIpcurrency extends Model {

    public function getdefaultcurrency() {
        $sql = "SELECT " . DB_PREFIX . "currency.code FROM `" . DB_PREFIX . "adri_ipcurrency` 
                LEFT JOIN " . DB_PREFIX . "currency as " . DB_PREFIX . "currency on " . DB_PREFIX . "currency.`currency_id`=" . DB_PREFIX . "adri_ipcurrency.`currency_id`
                WHERE " . DB_PREFIX . "adri_ipcurrency.`country_id`=0";
        $query = $this->db->query($sql);
        return $query->rows;
    }

    public function getcurrency() {
       $sql = "SELECT " . DB_PREFIX . "adri_ipcurrency.`ipcurrency_id`," . DB_PREFIX . "currency.code," . DB_PREFIX . "country.iso_code_2 FROM `" . DB_PREFIX . "adri_ipcurrency` 
                LEFT JOIN " . DB_PREFIX . "country as " . DB_PREFIX . "country on " . DB_PREFIX . "country.`country_id`=" . DB_PREFIX . "adri_ipcurrency.`country_id`
                LEFT JOIN " . DB_PREFIX . "currency as " . DB_PREFIX . "currency on " . DB_PREFIX . "currency.`currency_id`=" . DB_PREFIX . "adri_ipcurrency.`currency_id`
                WHERE " . DB_PREFIX . "adri_ipcurrency.status=1";
        $query = $this->db->query($sql);
        return $query->rows;
    }

}
