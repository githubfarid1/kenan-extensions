<?php
// ***************************************************
//               Advanced Smart Search   
//       
// Author : Francesco Pisanò - francesco1279@gmail.com
//              
//                   www.leverod.com		
//               © All rights reserved	  
// ***************************************************


// Admin language file

// backward compatibility with Opencart 2.1.0.2 and earlier

$lang_file = DIR_LANGUAGE . ('en-gb/module/adsmart_search.php');

if (file_exists($lang_file)) require($lang_file);