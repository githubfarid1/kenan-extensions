<?php
class ControllerExtensionModuleDigitCartContact extends Controller {
	private $error = array();
	private $moduleFilePath = 'extension/module/digitcart_contact';
	public function displayForm(&$route = false, &$data = false, &$output = false){
		if(!$this->config->get('module_digitcart_contact_status')) return;
		$lang = $this->load->language($this->moduleFilePath);
		foreach($lang as $k => $v){
			$dc_data[$k] = $v;
		}
		$config_language_id = $this->config->get('config_language_id');
		$form_data = $this->config->get('module_digitcart_contact_form_data');
		if(!empty($form_data[$config_language_id])){
			$form_data = html_entity_decode($form_data[$config_language_id], ENT_QUOTES, 'utf-8');
			// Captcha
			$dc_data['captcha'] = '';
			$dc_data['js_captcha'] = '';
			if (strpos($form_data, '"type":"captcha"') !== false) {
				if ($this->config->get('captcha_' . $this->config->get('config_captcha') . '_status')) {
					$captcha = $this->load->controller('extension/captcha/' . $this->config->get('config_captcha'), $this->error);
				} else {
					$captcha = '';
				}
				$js_hook = $this->createHook($captcha, '<script', '</script>');
				$dc_data['js_captcha'] = !empty($js_hook) ? $js_hook : '';
				$captcha = str_replace($js_hook, '', $captcha);
				$captcha = preg_replace('/(\>)\s*(\<)/m', '$1$2', $captcha);
				$dc_data['captcha'] = trim($captcha);
			}
			$dc_data['has_file_input'] = false;
			$dc_data['file_subtype'] = false;
			if (strpos($form_data, '"type":"file"') !== false) {
				$dc_data['has_file_input']= true;
				if (strpos($form_data, '"subtype":"file"') !== false) {
					$dc_data['file_subtype'] = 'file';
				}
				if (strpos($form_data, '"subtype":"dropzone"') !== false) {
					$dc_data['file_subtype'] = 'dropzone';
				}
			}
			$dc_data['form_data'] = $form_data;
			$hook = $this->createHook($output, '<form action="' . $data['action'], '</form>');
			$replacement = $this->load->view($this->moduleFilePath, $dc_data);
			$output = str_replace($hook, $replacement, $output);
		}
	}
	public function submitForm() {
		if(!$this->config->get('module_digitcart_contact_status')) return;
		$lang = $this->load->language($this->moduleFilePath);
		foreach($lang as $k => $v){
			$data[$k] = $v;
		}
		$this->load->language('information/contact');
		$config_language_id = $this->config->get('config_language_id');
		$json = array();
		$post = array_filter($this->request->post);
		$form_data = $this->config->get('module_digitcart_contact_form_data');
		if(!empty($form_data[$config_language_id])){
			$form_data = html_entity_decode($form_data[$config_language_id], ENT_QUOTES, 'utf-8');
			$form_data = json_decode($form_data, true);
			$final_data = array();
			$final_data_attachments = array();
			$this->load->model('tool/upload');
			foreach($form_data as $field){
				$posted_field_name = !empty($field['name']) ? (!empty($post[$field['name']]) ? $post[$field['name']] : '') : '';
				$field_label = !empty($field['label']) ? html_entity_decode($field['label'], ENT_QUOTES, 'UTF-8') : '';
				$field_label = strip_tags($field_label);
				if(!is_array($posted_field_name)){
					/* اگر چک باکس نیست */
					$posted_field_name = trim($posted_field_name);
					$posted_field_name = (string)$posted_field_name;
					if(!empty($field['required']) && empty($posted_field_name)){
						$json['error'][$field['name']] = sprintf($this->language->get('dc_error_required'), $field_label);
					}
				}
				// Number
				if($field['type'] == 'number'){
					if(!empty($posted_field_name)){
						if(!is_numeric($posted_field_name)){
							$json['error'][$field['name']] = sprintf($this->language->get('dc_error_numeric'), $field_label);
						} else {
							if(!empty($field['min']) && (int)$posted_field_name < $field['min']){
								$json['error'][$field['name']] = sprintf($this->language->get('dc_error_min'), $field_label, $field['min']);
							}
							if(!empty($field['max']) && (int)$posted_field_name > $field['max']){
								$json['error'][$field['name']] = sprintf($this->language->get('dc_error_max'), $field_label, $field['max']);
							}
						}
					}
				}
				// Maxlength
				if(!empty($field['maxlength']) && utf8_strlen($posted_field_name) > $field['maxlength']){
					$json['error'][$field['name']] = sprintf($this->language->get('dc_error_maximum'), $field_label, $field['maxlength']);
				}
				// Email
				if(!empty($field['subtype'])){
					if($field['subtype'] == 'email'){
						if(!filter_var($posted_field_name, FILTER_VALIDATE_EMAIL)){
							$json['error'][$field['name']] = sprintf($this->language->get('dc_error_email'), $field_label);
						} else {
							$sender_email = $posted_field_name;
						}
					}
				}
				// Captcha
				if($field['type'] == 'captcha'){
					if ($this->config->get('captcha_' . $this->config->get('config_captcha') . '_status')) {
						$captcha = $this->load->controller('extension/captcha/' . $this->config->get('config_captcha') . '/validate');
						if ($captcha) {
							$json['error']['captcha'] = $captcha;
						}
					}
				}
				if($field['type'] != 'button' && $field['type'] != 'captcha' && $field['type'] != 'line'){
					/*
					آماده سازی اطلاعات دریافتی
					اگر دو فیلد همنام (منظور هم  لیبل است.) در فرم وجود داشته باشد، به منظور جلوگیری از رونویسی به شکل زیر انجام دادم.
					*/
					// File
					if($field['type'] == 'file'){
						if(!empty($posted_field_name)){
							/* یک پوشه ی موقت میسازیم */
							$temp_folder = DIR_UPLOAD . 'dcfbthempfolder/';
							if(!is_dir($temp_folder)){
								mkdir($temp_folder);
							}
							$file = $this->model_tool_upload->getUploadByCode($posted_field_name);
							if(is_file(DIR_UPLOAD . $file['filename'])){
								copy(DIR_UPLOAD . $file['filename'], $temp_folder . $file['filename']);
								rename($temp_folder . $file['filename'], $temp_folder . $file['name']);
							}
							if(is_file($temp_folder . $file['name'])){
								$attachment = $temp_folder . $file['name'];
							}
							if(!empty($attachment)){
								$final_data_attachments[] = array(
									'actual' => $attachment,
									'mask' => DIR_UPLOAD . $file['filename'],
								);
							}
						}
					} else if(!empty($field['name'])) {
						if ($field['type'] == 'textarea') {
							$posted_field_name = nl2br($posted_field_name);
						}
						$final_data[$field['name']] = array(
							'label' => $field_label,
							'value' => $posted_field_name,
						);
					}
				}
			}
		}
		if(!$json){
			// Email to Admin
			if(empty($sender_email)){
				$sender_email = $this->customer->getEmail() ? $this->customer->getEmail() : $this->config->get('config_email');
			}
			$mail_data['form_data'] = $final_data;
			$mail_text = $this->config->get('module_digitcart_contact_mail_text');
			$mail_data['form_name'] = $this->language->get('dc_text_new_enquiry');
			$mail_data['mail_top'] = !empty($mail_text['top'][$config_language_id]) ? $mail_text['top'][$config_language_id] : '';
			$mail_data['mail_bottom'] = !empty($mail_text['bottom'][$config_language_id]) ? $mail_text['bottom'][$config_language_id] : '';
			$mail_data['store_name'] = $this->config->get('config_name');
			$mail_data['dc_text_footer'] = $this->language->get('dc_text_footer');
			$mail_data['logo'] = $this->config->get('config_url') . 'image/' . $this->config->get('config_logo');
			$mail_data['store_url'] = $this->config->get('config_url');
			$mail_data['customer_id'] = $this->customer->getId();
			$mail_data['link'] = $this->config->get('config_url');
			$mail = new SendgridMail($this->config->get('config_mail_smtp_password'));
			$mail->parameter = $this->config->get('config_mail_parameter');
			$mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
			$mail->smtp_username = $this->config->get('config_mail_smtp_username');
			$mail->smtp_password = html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
			$mail->smtp_port = $this->config->get('config_mail_smtp_port');
			$mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');
			$mail->setTo($this->config->get('config_email'));
			$mail->setFrom($this->config->get('config_email'));
			$mail->setSender(html_entity_decode($this->language->get('dc_text_new_enquiry'), ENT_QUOTES, 'UTF-8'));
			// Attach Files
			if ($final_data_attachments) {
				foreach($final_data_attachments as $final_data_attachment){
					if(is_file($final_data_attachment['actual'])){
						$mail->addAttachment($final_data_attachment['actual']);
					}
				}
			}
			$mail->setSubject(html_entity_decode(sprintf($this->language->get('dc_email_subject'), 'Contact us'), ENT_QUOTES, 'UTF-8'));
			$mail->setHtml($this->load->view($this->moduleFilePath . '_mail', $mail_data));
			$mail->send();
			// Send to additional alert emails
			if($this->config->get('module_digitcart_contact_additional_notify')){
				$emails = explode(',', $this->config->get('config_alert_email'));
				foreach ($emails as $email) {
					if ($email && filter_var($email, FILTER_VALIDATE_EMAIL)) {
						$mail->setTo($email);
						$mail->send();
					}
				}
			}
			// Send to customer
			if($this->config->get('module_digitcart_contact_customer_notify')){
				if($sender_email != $this->config->get('config_email')){
					$mail->setTo($sender_email);
					$mail->send();
				}
			}
			/* به فایل احتیاجی نیست، حذفش می کنیم. */
			foreach($final_data_attachments as $final_data_attachment){
				if(is_file($final_data_attachment['actual'])){
					unlink($final_data_attachment['actual']);
				}
				if(is_file($final_data_attachment['mask'])){
					unlink($final_data_attachment['mask']);
				}
			}
			$action_type = $this->config->get('module_digitcart_contact_form_submission');
			if($action_type == 'html'){
				$json['success_action'] = 'html';
				$action = $this->config->get('module_digitcart_contact_success');
				if(!empty($action['html'][$config_language_id])){
					$json['success_html'] = html_entity_decode($action['html'][$config_language_id], ENT_QUOTES, 'utf-8');
				}
			} else if($action_type == 'redirect'){
				$json['success_action'] = 'redirect';
				$action = $this->config->get('module_digitcart_contact_success');
				if(!empty($action['redirect'])){
					$json['redirect'] = html_entity_decode($action['redirect'], ENT_QUOTES, 'utf-8');
				}
			} else if($action_type == 'reset'){
				$json['success_action'] = 'reset';
			} else if($action_type == 'nothing'){
				$json['success_action'] = 'nothing';
			}
			$json['success'] = $this->language->get('dc_text_submitted');
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	public function addFiles(){
		if(!$this->config->get('module_digitcart_contact_status')) return;
		$config_language_id = $this->config->get('config_language_id');
		$form_data = $this->config->get('module_digitcart_contact_form_data');
		if(!empty($form_data[$config_language_id])){
			$form_data = html_entity_decode($form_data[$config_language_id], ENT_QUOTES, 'utf-8');
			if (strpos($form_data, '"subtype":"dropzone"') !== false) {
				$this->document->addScript('catalog/view/javascript/digitcart_contact/dropzone.min.js');
				$this->document->addStyle('catalog/view/javascript/digitcart_contact/dropzone.css');
				$this->document->addStyle('catalog/view/javascript/digitcart_contact/style.css');
			}
		}
	}
	protected function createHook($output, $pre, $post){
		$output = ' ' . $output;
		$ini = strpos($output, $pre);
		if ($ini == 0) return '';
		$ini += strlen($pre);
		$len = strpos($output, $post, $ini) - $ini;
		$between =  substr($output, $ini, $len);
		return $pre . $between . $post;
	}
}