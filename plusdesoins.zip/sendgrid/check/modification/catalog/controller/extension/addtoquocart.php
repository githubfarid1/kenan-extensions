<?php
class Controllerextensionaddtoquocart extends Controller {
	private $modpath = 'extension/addtoquo';
	private $modpathcart = 'extension/addtoquocart';
	private $modcarttpl = 'default/template/extension/addtoquocart.tpl';
 	private $modmailtpl = 'default/template/extension/addtoquomail.tpl';
	private $modname = 'addtoquo';
	private $modssl = 'SSL';
 	private $langid = 0;
	private $storeid = 0;
	private $custgrpid = 0;
	
	public function __construct($registry) {
		parent::__construct($registry);
		
		$this->langid = (int)$this->config->get('config_language_id');
		$this->storeid = (int)$this->config->get('config_store_id');
		$this->custgrpid = (int)$this->config->get('config_customer_group_id');
		
		if(substr(VERSION,0,3)>='3.0') { 
			$this->modname = 'module_addtoquo';
		}
		
		if(substr(VERSION,0,3)>='3.0' || substr(VERSION,0,3)=='2.3' || substr(VERSION,0,3)=='2.2') { 
			$this->modssl = true;
			$this->modcarttpl = 'extension/addtoquocart';
 			$this->modmailtpl = 'extension/addtoquomail';
		}
 	}
	
	public function index() {
 		$this->load->model($this->modpath);
		$getmodstatus = $this->model_extension_addtoquo->getmodstatus();
 		if($getmodstatus) { 
 			$data['langdata'] = $this->model_extension_addtoquo->getlang(); 
			
 			$this->document->setTitle($data['langdata']['page_head_title']);
	
			$data['breadcrumbs'] = array();
 	
			$data['breadcrumbs'][] = array(
				'href' => $this->url->link('extension/addtoquocart'),
				'text' => $data['langdata']['page_head_title']
			);
 			
 			$data['column_left'] = $this->load->controller('common/column_left');
			$data['column_right'] = $this->load->controller('common/column_right');
			$data['content_top'] = $this->load->controller('common/content_top');
			$data['content_bottom'] = $this->load->controller('common/content_bottom');
			$data['footer'] = $this->load->controller('common/footer');
			$data['header'] = $this->load->controller('common/header');

			$this->response->setOutput($this->load->view($this->modcarttpl, $data));
		} 
	}
	
	public function add() {
		$this->load->language('checkout/cart');
 		$this->load->model('extension/addtoquo');
		
		$addtoquo_setting = $this->model_extension_addtoquo->getsetting();
		$langdata = $this->model_extension_addtoquo->getlang();
  
		$json = array();

		$product_id = 0;
		if (isset($this->request->post['product_id'])) {
			$product_id = (int)$this->request->post['product_id'];
		}

		$this->load->model('catalog/product');

		$product_info = $this->model_catalog_product->getProduct($product_id);

		if ($product_info) { 
			if (isset($this->request->post['quantity']) && ((int)$this->request->post['quantity'] >= $product_info['minimum'])) {
				$quantity = (int)$this->request->post['quantity'];
			} else {
				$quantity = $product_info['minimum'] ? $product_info['minimum'] : 1;
			}
			
 			if (isset($this->request->post['option'])) {
				$option = array_filter($this->request->post['option']);
			} else {
				$option = array();
			}
				
			if($addtoquo_setting['prodoption']) {

				$product_options = $this->model_catalog_product->getProductOptions($this->request->post['product_id']);
		
				foreach ($product_options as $product_option) {
					if ($product_option['required'] && empty($option[$product_option['product_option_id']])) {
						$json['error']['option'][$product_option['product_option_id']] = sprintf($this->language->get('error_required'), $product_option['name']);
					}
				} 			
			} else {
				$option = array();
			}
			
			if (!$json) {
 				$this->model_extension_addtoquo->add($this->request->post['product_id'], $quantity, $option);
	
				$json['btnact'] = $addtoquo_setting['btnact']; 
  				
 				$langdata['add_success_label'] = html_entity_decode($langdata['add_success_label'], ENT_QUOTES, 'UTF-8');
	
				$json['success'] = sprintf($langdata['add_success_label'], $this->url->link('product/product', 'product_id=' . $this->request->post['product_id']), $product_info['name'], $this->url->link($this->modpathcart));

			} else {
				$json['redirect'] = str_replace('&amp;', '&', $this->url->link('product/product', 'product_id=' . $this->request->post['product_id'])); 
			}
 		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	public function remove() {
		$this->load->language('checkout/cart');
		$this->load->model('extension/addtoquo');

		$json = array();

		// Remove
		if (isset($this->request->post['key'])) {
			$this->model_extension_addtoquo->remove($this->request->post['key']);
  			$json['success'] = 1;
		}
		 
 		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	public function updatequote() {
		$this->load->model('extension/addtoquo');
		$this->load->language('checkout/cart');

		$json = array();

		// Update
		if (!empty($this->request->post['quantity'])) {
			$this->model_extension_addtoquo->update($this->request->post['key'], $this->request->post['quantity']);
			$json['success'] = 1;
  		}
		
 		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
 	public function save() {
 		$this->load->model('extension/addtoquo');
		$langdata = $this->model_extension_addtoquo->getlang();
		$addtoquo_setting = $this->model_extension_addtoquo->getsetting();
 
		$json = array();
 
		if (!$json) {
  			if (isset($this->request->post['email']) && ((utf8_strlen($this->request->post['email']) > 96) || !filter_var($this->request->post['email'], FILTER_VALIDATE_EMAIL))) {
				$json['error']['email'] = $langdata['error_email'];
			}
    
			// Custom field validation
			$this->load->model('extension/addtoquofield');

			$addtoquofields = $this->model_extension_addtoquofield->getFields($this->custgrpid);

			foreach ($addtoquofields as $addtoquofield) {
				if ($addtoquofield['required'] && empty($this->request->post['addtoquofield'][$addtoquofield['addtoquofield_id']])) {
					$json['error']['addtoquofield' . $addtoquofield['addtoquofield_id']] = sprintf($addtoquofield['errortext'], $addtoquofield['name']);
				} elseif (($addtoquofield['type'] == 'text') && !empty($addtoquofield['validation']) && !filter_var($this->request->post['addtoquofield'][$addtoquofield['addtoquofield_id']], FILTER_VALIDATE_REGEXP, array('options' => array('regexp' => $addtoquofield['validation'])))) {
					$json['error']['addtoquofield' . $addtoquofield['addtoquofield_id']] = sprintf($addtoquofield['errortext'], $addtoquofield['name']);
				}
			}

			// Captcha
			$validatecaptcha = $this->model_extension_addtoquo->validatecaptcha();
			if ($validatecaptcha) {
				$json['error']['captcha'] = $validatecaptcha;
			}
		}
 
		if (!$json) {			
 			$this->db->query("INSERT INTO " . DB_PREFIX . "addtoquo SET 
 			email = '" . $this->db->escape(isset($this->request->post['email']) ? $this->request->post['email'] : '') . "', 
			addtoquofield = '" . $this->db->escape(isset($this->request->post['addtoquofield']) ? json_encode($this->request->post['addtoquofield']) : '') . "',
  			store_id = '" . $this->config->get('config_store_id') . "', 
			store_name = '" . $this->db->escape($this->config->get('config_name')) . "', 
			store_url = '" . $this->db->escape($this->config->get('config_url')) . "', 
			date_added = NOW()");
			
			$addtoquo_id = $this->db->getLastId();
			
			$this->db->query("insert into `" . DB_PREFIX . "addtoquocart` (`addtoquo_id`, `product_id`, `option`, `quantity`, `store_id`, `date_added`) SELECT '".$addtoquo_id."', `product_id`, `option`, `quantity`, '".$this->modstoreid."', now() FROM `" . DB_PREFIX . "addtoquoquotecart` WHERE 1 and session_id = '" . $this->db->escape($this->session->getId()) . "' ");
			
			$this->sendmail($this->request->post, $addtoquo_id);
			
			$this->model_extension_addtoquo->clear();
			
			$json['redirect'] = $this->url->link('extension/addtoquosuccess');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	public function sendmail($postdata, $addtoquo_id) {
		$this->load->model('extension/addtoquo');
		$langdata = $this->model_extension_addtoquo->getlang();
		$data['langdata'] = $langdata;
 		
 		// Saved Custom Fields
		$this->load->model('extension/addtoquofield');
		$this->load->model('tool/upload');
		
  		$data['addtoquofields'] = array();

		$filter_data = array(
			'sort'  => 'cf.sort_order',
			'order' => 'ASC',
			'filter_customer_group_id' => $this->modgrpid,
		);

		$addtoquofields = $this->model_extension_addtoquofield->getSavedFields($filter_data);
		
		foreach ($addtoquofields as $addtoquofield) {
			if (isset($postdata['addtoquofield'][$addtoquofield['addtoquofield_id']])) {
				if ($addtoquofield['type'] == 'select' || $addtoquofield['type'] == 'radio') {
					$addtoquofield_value_info = $this->model_extension_addtoquofield->getSavedFieldValue($postdata['addtoquofield'][$addtoquofield['addtoquofield_id']]);

					if ($addtoquofield_value_info) {
						$data['addtoquofields'][] = array(
							'name'  => $addtoquofield['name'],
							'value' => $addtoquofield_value_info['name']
						);
					}
				}

				if ($addtoquofield['type'] == 'checkbox' && is_array($postdata['addtoquofield'][$addtoquofield['addtoquofield_id']])) {
					foreach ($postdata['addtoquofield'][$addtoquofield['addtoquofield_id']] as $addtoquofield_value_id) {
						$addtoquofield_value_info = $this->model_extension_addtoquofield->getSavedFieldValue($addtoquofield_value_id);

						if ($addtoquofield_value_info) {
							$data['addtoquofields'][] = array(
								'name'  => $addtoquofield['name'],
								'value' => $addtoquofield_value_info['name']
							);
						}
					}
				}

				if ($addtoquofield['type'] == 'text' || $addtoquofield['type'] == 'textarea' || $addtoquofield['type'] == 'date' || $addtoquofield['type'] == 'datetime' || $addtoquofield['type'] == 'time') {
					$data['addtoquofields'][] = array(
						'name'  => $addtoquofield['name'],
						'value' => $postdata['addtoquofield'][$addtoquofield['addtoquofield_id']]
					);
				}

				if ($addtoquofield['type'] == 'file') {
					$upload_info = $this->model_tool_upload->getUploadByCode($postdata['addtoquofield'][$addtoquofield['addtoquofield_id']]);

					if ($upload_info) {
						$data['addtoquofields'][] = array(
							'name'  => $addtoquofield['name'],
							'value' => $upload_info['name'],
							'download'  => $this->url->link('extension/addtoquocart/downloadfile&code=' . $upload_info['code']),
						);
					}
				}
			}
		} 
		// Saved Custom Fields
 		
		// products 
		$this->load->model('tool/image');
		$this->load->model('tool/upload');

		$data['products'] = array();

		$products = $this->model_extension_addtoquo->getcartProducts();
		
		foreach ($products as $product) {			 
			$image = '';
			if ($product['image']) {
				$image = $this->model_tool_image->resize($product['image'], 80, 80);
			}  
			
			$option_data = array();

			foreach ($product['option'] as $option) {
				if ($option['type'] != 'file') {
					$value = $option['value'];
				} else {
					$upload_info = $this->model_tool_upload->getUploadByCode($option['value']);
 					if ($upload_info) {
						$value = $upload_info['name'];
					} else {
						$value = '';
					}
				} 
				$option_data[] = array(
					'name'  => $option['name'],
					'value' => (utf8_strlen($value) > 20 ? utf8_substr($value, 0, 20) . '..' : $value)
				);
			}  			
			$data['products'][]  =  array(
				'cart_id'   => $product['cart_id'],
				'thumb'     => $image,
				'name'      => $product['name'],
				'model'     => $product['model'],
				'option'    => $option_data,
				'quantity'     => $product['quantity'],
  				'href'      => $this->url->link('product/product', 'product_id=' . $product['product_id'])
			);
		}
		
  		$data['title'] = $langdata['page_head_title'];
		$data['store_url'] = HTTP_SERVER;
		$data['store_name'] = html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8');
		$data['logo'] = $this->config->get('config_url') . 'image/' . $this->config->get('config_logo');
 		$data['addtoquo_id'] = $addtoquo_id;
		$data['enqdate'] = date("Y-m-d");
		$data['postdata'] = $postdata;
 		$data['ip'] = $this->request->server['REMOTE_ADDR'];
 	
		// send mail to admin //
		$subject = sprintf($langdata['txt_admin_subject'], html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8'));
		$data['text_greeting'] = html_entity_decode($langdata['txt_admin_greeting'], ENT_QUOTES, 'UTF-8');
						
		if(substr(VERSION,0,3)>='3.0') {
			$mail = new SendgridMail($this->config->get('config_mail_smtp_password'));
			$admin_emails = explode(',', $this->config->get('config_mail_alert_email'));
		} else {
			$mail = new Mail();
			$mail->protocol = $this->config->get('config_mail_protocol');
			if(substr(VERSION,0,3)>='2.3') {
				$admin_emails = explode(',', $this->config->get('config_alert_email'));
			} else {
				$admin_emails = explode(',', $this->config->get('config_mail_alert'));
			}
		}
		
		$mail->parameter = $this->config->get('config_mail_parameter');
		$mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
		$mail->smtp_username = $this->config->get('config_mail_smtp_username');
		$mail->smtp_password = html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
		$mail->smtp_port = $this->config->get('config_mail_smtp_port');
		$mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');
		
		//$mail->setTo($postdata['email']);
		$mail->setTo($this->config->get('config_email'));
		$mail->setFrom($this->config->get('config_email'));
		$mail->setSender(html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8'));
		$mail->setSubject(html_entity_decode($subject, ENT_QUOTES, 'UTF-8'));
		$mail->setHtml($this->load->view($this->modmailtpl, $data));
		$mail->send();
		
		// admin additional email notification
		if($admin_emails) {
			foreach ($admin_emails as $email) {
				if ($email && filter_var($email, FILTER_VALIDATE_EMAIL)) {
					$mail->setTo($email);
					$mail->send();
				}
			}
		}
	
	
		// send send mail to customer //
		$subject = sprintf($langdata['txt_customer_subject'], html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8'));
		$data['text_greeting'] = html_entity_decode($langdata['txt_customer_greeting'], ENT_QUOTES, 'UTF-8');
		
		if(substr(VERSION,0,3)>='3.0') {
			$mail = new SendgridMail($this->config->get('config_mail_smtp_password'));
		} else {
			$mail = new Mail();
			$mail->protocol = $this->config->get('config_mail_protocol');
		}
		
		$mail->parameter = $this->config->get('config_mail_parameter');
		$mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
		$mail->smtp_username = $this->config->get('config_mail_smtp_username');
		$mail->smtp_password = html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
		$mail->smtp_port = $this->config->get('config_mail_smtp_port');
		$mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');

		$mail->setTo($postdata['email']);
		$mail->setFrom($this->config->get('config_email'));
		$mail->setSender(html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8'));
		$mail->setSubject(html_entity_decode($subject, ENT_QUOTES, 'UTF-8'));
		$mail->setHtml($this->load->view($this->modmailtpl, $data));
		$mail->send(); 
	}
	 
	public function downloadfile() {
		$this->load->model('tool/upload');

		if (isset($this->request->get['code'])) {
			$code = $this->request->get['code'];
		} else {
			$code = 0;
		}

		$upload_info = $this->model_tool_upload->getUploadByCode($code);

		if ($upload_info) {
			$file = DIR_UPLOAD . $upload_info['filename'];
			$mask = basename($upload_info['name']);

			if (!headers_sent()) {
				if (is_file($file)) {
					header('Content-Type: application/octet-stream');
					header('Content-Description: File Transfer');
					header('Content-Disposition: attachment; filename="' . ($mask ? $mask : basename($file)) . '"');
					header('Content-Transfer-Encoding: binary');
					header('Expires: 0');
					header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
					header('Pragma: public');
					header('Content-Length: ' . filesize($file));

					readfile($file, 'rb');
					exit;
				} else {
					exit('Error: Could not find file ' . $file . '!');
				}
			} else {
				exit('Error: Headers already sent out!');
			}
		} 
	}
	
	public function downloadfileadmin() {
		$this->load->model('tool/upload');

		if (isset($this->request->get['filecode'])) {
			$filecode = $this->request->get['filecode'];
		} else {
			$filecode = 0;
		}
  		
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "addtoquo_order_history WHERE filecode = '" . $this->db->escape($filecode) . "'");

		$upload_info = $query->row;

		if ($upload_info) {
			$file = DIR_UPLOAD . $upload_info['filepath'];
			$mask = basename($upload_info['filename']);

			if (!headers_sent()) {
				if (is_file($file)) {
					header('Content-Type: application/octet-stream');
					header('Content-Description: File Transfer');
					header('Content-Disposition: attachment; filename="' . ($mask ? $mask : basename($file)) . '"');
					header('Content-Transfer-Encoding: binary');
					header('Expires: 0');
					header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
					header('Pragma: public');
					header('Content-Length: ' . filesize($file));

					readfile($file, 'rb');
					exit;
				} else {
					exit('Error: Could not find file ' . $file . '!');
				}
			} else {
				exit('Error: Headers already sent out!');
			}
		}
	}
	
	protected function setvalue($postfield) {
		return $this->config->get($postfield);
	}
}
