<?php
class ModelSaleSendyExport extends Model {
	
	public function getOrders($data = array()) {
		$sql = "SELECT o.order_id, o.email, o.payment_company, o.payment_firstname, o.payment_city, o.payment_zone, o.payment_country FROM `" . DB_PREFIX . "order` o " ;;

		
		if (isset($data['filter_order_status'])) {
		   $sql .= " WHERE o.order_status_id = '" . (int)$data['filter_order_status'] . "'";
		} else {
			$sql .= " WHERE o.order_status_id > '0'";
		}

		if (!empty($data['filter_order_id'])) {
			$sql .= " AND o.order_id = '" . (int)$data['filter_order_id'] . "'";
		}

		if (!empty($data['filter_company'])) {
			$sql .= " AND o.payment_company LIKE '%" . $this->db->escape($data['filter_company']) . "%'";
		}

		if (!empty($data['filter_date_from'])) {
			$sql .= " AND DATE(o.date_added) >= DATE('" . $this->db->escape($data['filter_date_from']) . "')";
		}

		if (!empty($data['filter_date_to'])) {
			$sql .= " AND DATE(o.date_added) <= DATE('" . $this->db->escape($data['filter_date_to']) . "')";
		}


       $sql .= " ORDER BY o.payment_firstname";


		$query = $this->db->query($sql);

		$header =array(
      'fisrtname' => 'Name',
      'email'=> 'Email',
      'payment_company' => 'Company', 
      'payment_city' => 'City',
  	  'payment_zone' => 'State',
  	  'payment_country' => 'Country',
      'source' => 'Source');
      
      $returndata[] = $header;
      
	  foreach ($query->rows as $row) {
	   $returndata[] = array(
                       'firstname' => $row['payment_firstname'],
                       'email' => $row['email'],
                       'company' => $row['payment_company'],
                       'payment_city' => $row['payment_city'],
                   	   'payment_zone' => $row['payment_zone'],
                   	   'Payment_country' => $row['payment_country'],
                       'source' => 'Opencart ' . date('m/d/Y'));
	  }
      return $returndata;
	}




	public function getCompany($data = array()) {
		$sql = "SELECT DISTINCT payment_company FROM " . DB_PREFIX . "order where 1";

		$implode = array();

		if (!empty($data['filter_company'])) {
			$implode[] = "payment_company LIKE '%" . $this->db->escape($data['filter_company']) . "%'";
		}

		if ($implode) {
			$sql .= " AND " . implode(" AND ", $implode);
		}

		$sort_data = array(
			'payment_company'
		);

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];
		} else {
			$sql .= " ORDER BY payment_company";
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}

		$query = $this->db->query($sql);

		return $query->rows;
	}

}
