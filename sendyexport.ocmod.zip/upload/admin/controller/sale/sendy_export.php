<?php
class ControllerSaleSendyExport extends Controller {
	private $error = array();

	public function index() {
		
		$this->load->language('sale/sendy_export');

		$this->document->setTitle($this->language->get('heading_title'));

        $data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('sale/sendy_export', 'token=' . $this->session->data['token'], true)
		);

		$data['action_button_export'] = $this->url->link('sale/sendy_export', 'token=' . $this->session->data['token'], true);


		if (isset($this->request->get['filter_order_id'])) {
			$filter_order_id = $this->request->get['filter_order_id'];
			$datashow = true;
		} else {
			$filter_order_id = null;
		}

		if (isset($this->request->get['filter_company'])) {
			$datashow = true;
			$filter_company = $this->request->get['filter_company'];
		} else {
			$filter_company = null;
		}
        
        if (isset($this->request->get['filter_order_status'])) {
			$filter_order_status = $this->request->get['filter_order_status'];
            $datashow = true;
		} else {
			$filter_order_status = null;
		}

		if (isset($this->request->get['filter_date_from'])) {
			$datashow = true;
			$filter_date_from = $this->request->get['filter_date_from'];
		} else {
			$filter_date_from = null;
		}

		if (isset($this->request->get['filter_date_to'])) {
			$datashow = true;
			$filter_date_to = $this->request->get['filter_date_to'];
		} else {
			$filter_date_to = null;
		}

	if (isset($this->request->get['action']) && $this->request->get['action'] == 'export') {
        $this->load->model('sale/sendy_export');
        $filter_data = array(
			'filter_order_id'      => $filter_order_id,
			'filter_company'	   => $filter_company,
            'filter_order_status'  => $filter_order_status,
			'filter_date_from'    => $filter_date_from,
			'filter_date_to' => $filter_date_to
		);
        $results = $this->model_sale_sendy_export->getOrders($filter_data);
        $this->exportcsv($results);
        return;

       }
       
       	$data['heading_title'] = $this->language->get('heading_title');

		$data['text_no_results'] = $this->language->get('text_no_results');
		$data['text_loading'] = $this->language->get('text_loading');

		$data['entry_order_id'] = $this->language->get('entry_order_id');
		$data['entry_company'] = $this->language->get('entry_company');
        $data['entry_order_status'] = $this->language->get('entry_order_status');
		$data['entry_date_from'] = $this->language->get('entry_date_from');
		$data['entry_date_to'] = $this->language->get('entry_date_to');

		$data['button_export'] = $this->language->get('button_export');
		$data['token'] = $this->session->data['token'];
        $this->load->model('localisation/order_status');

		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('sale/sendy_export', $data));

	}


	public function autocomplete() {
		$json = array();

		if (isset($this->request->get['filter_company'])) {
			if (isset($this->request->get['filter_company'])) {
				$filter_company = $this->request->get['filter_company'];
			} else {
				$filter_company = '';
			}

		
			$this->load->model('sale/sendy_export');

			$filter_data = array(
				'filter_company'  => $filter_company,
				'start'        => 0,
				'limit'        => 5
			);

			$results = $this->model_sale_sendy_export->getCompany($filter_data);

			foreach ($results as $result) {
				$json[] = array(
					'payment_company'       => $result['payment_company']
				);
			}
		}

		$sort_order = array();

		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['payment_company'];
		}

		array_multisort($sort_order, SORT_ASC, $json);

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function exportcsv($data) { 
		
		/* CSV Header Starts Here */
		 
		header("Content-Type: text/csv");
		header("Content-Disposition: attachment; filename=SendyExport-".date('d-m-Y').".csv");
		// Disable caching
		header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1
		header("Pragma: no-cache"); // HTTP 1.0
		header("Expires: 0"); // Proxies
		 
		/* CSV Header Ends Here */
		 
		$output = fopen("php://output", "w"); //Opens and clears the contents of file; or creates a new file if it doesn't exist		
		
		foreach($data as $row)
		{
		    fputcsv($output, $row); // here you can change delimiter/enclosure
		}
		 
		fclose($output); // Closing the File


	}
	
}
