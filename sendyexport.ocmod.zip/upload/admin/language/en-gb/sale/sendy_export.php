<?php
// Heading
$_['heading_title']              = 'Sendy Export';


// Entry
$_['entry_order_id']             = 'Order ID';
$_['entry_company']             = 'Company';
$_['entry_order_status']         = 'Order Status';
$_['entry_date_from']           = 'Date From';
$_['entry_date_to']        = 'Date to';


// Error

$_['error_permission']           = 'Warning: You do not have permission to this page!';

$_['error_no_data']			 = 'No data to export!';

$_['button_export']			 = 'Export';



