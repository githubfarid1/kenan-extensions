<?php
$_['text_bulkimage']		 		 = 'Bulk Product Image';
$_['text_bulkopt']		 		 = 'Bulk Product Option';
$_['text_bulkatt']		 		 = 'Bulk Product Attribute';
