<?php
// Heading 
$_['heading_title']   = 'My Pokemon Online Codes';

// Text
$_['text_account']    = 'Account';
$_['text_serial_keys']  = 'My Pokemon Online Codes';
$_['text_order']      = 'Order ID:';
$_['text_date_added'] = 'Date Added:';
$_['text_orderid']       = 'Order ID';
$_['text_productname']       = 'Product Name';
$_['text_serialkey']       = 'Product Name & Codes';
$_['text_dateoforder']       = 'Date of order';
$_['text_remaining']  = 'Remaining:';
$_['text_size']       = 'Size:';
$_['text_empty']      = 'You haven\'t bought any key yet!';
$_['text_downloadlink']      = 'Download link';
?>